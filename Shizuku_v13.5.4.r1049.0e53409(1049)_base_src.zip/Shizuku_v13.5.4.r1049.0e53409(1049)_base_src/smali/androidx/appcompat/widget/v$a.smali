.class Landroidx/appcompat/widget/v$a;
.super Lrikka/shizuku/vo;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/appcompat/widget/v;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;IILandroid/content/res/Resources$Theme;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic j:Landroidx/appcompat/widget/v$h;

.field final synthetic k:Landroidx/appcompat/widget/v;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/v;Landroid/view/View;Landroidx/appcompat/widget/v$h;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/v$a;->k:Landroidx/appcompat/widget/v;

    iput-object p3, p0, Landroidx/appcompat/widget/v$a;->j:Landroidx/appcompat/widget/v$h;

    invoke-direct {p0, p2}, Lrikka/shizuku/vo;-><init>(Landroid/view/View;)V

    return-void
.end method


# virtual methods
.method public b()Lrikka/shizuku/aj0;
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/v$a;->j:Landroidx/appcompat/widget/v$h;

    return-object v0
.end method

.method public c()Z
    .locals 1
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Landroidx/appcompat/widget/v$a;->k:Landroidx/appcompat/widget/v;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroidx/appcompat/widget/v;->getInternalPopup()Landroidx/appcompat/widget/v$j;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-interface {v0}, Landroidx/appcompat/widget/v$j;->c()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_0

    .line 12
    .line 13
    iget-object v0, p0, Landroidx/appcompat/widget/v$a;->k:Landroidx/appcompat/widget/v;

    .line 14
    .line 15
    invoke-virtual {v0}, Landroidx/appcompat/widget/v;->b()V

    .line 16
    .line 17
    .line 18
    :cond_0
    const/4 v0, 0x1

    .line 19
    return v0
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
.end method
