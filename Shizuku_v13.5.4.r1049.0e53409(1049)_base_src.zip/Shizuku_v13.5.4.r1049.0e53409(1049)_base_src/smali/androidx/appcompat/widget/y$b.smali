.class Landroidx/appcompat/widget/y$b;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/appcompat/widget/y$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/y;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/widget/y;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/y;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/y$b;->a:Landroidx/appcompat/widget/y;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a([II)V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/y$b;->a:Landroidx/appcompat/widget/y;

    invoke-static {v0, p1, p2}, Landroidx/appcompat/widget/y;->n(Landroidx/appcompat/widget/y;[II)V

    return-void
.end method

.method public b(Landroid/view/textclassifier/TextClassifier;)V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/y$b;->a:Landroidx/appcompat/widget/y;

    invoke-static {v0, p1}, Landroidx/appcompat/widget/y;->p(Landroidx/appcompat/widget/y;Landroid/view/textclassifier/TextClassifier;)V

    return-void
.end method

.method public c()I
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/y$b;->a:Landroidx/appcompat/widget/y;

    invoke-static {v0}, Landroidx/appcompat/widget/y;->g(Landroidx/appcompat/widget/y;)I

    move-result v0

    return v0
.end method

.method public d()[I
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/y$b;->a:Landroidx/appcompat/widget/y;

    invoke-static {v0}, Landroidx/appcompat/widget/y;->j(Landroidx/appcompat/widget/y;)[I

    move-result-object v0

    return-object v0
.end method

.method public e(I)V
    .locals 0

    return-void
.end method

.method public f(I)V
    .locals 0

    return-void
.end method

.method public g()Landroid/view/textclassifier/TextClassifier;
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/y$b;->a:Landroidx/appcompat/widget/y;

    invoke-static {v0}, Landroidx/appcompat/widget/y;->l(Landroidx/appcompat/widget/y;)Landroid/view/textclassifier/TextClassifier;

    move-result-object v0

    return-object v0
.end method

.method public h()I
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/y$b;->a:Landroidx/appcompat/widget/y;

    invoke-static {v0}, Landroidx/appcompat/widget/y;->i(Landroidx/appcompat/widget/y;)I

    move-result v0

    return v0
.end method

.method public i()I
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/y$b;->a:Landroidx/appcompat/widget/y;

    invoke-static {v0}, Landroidx/appcompat/widget/y;->c(Landroidx/appcompat/widget/y;)I

    move-result v0

    return v0
.end method

.method public j(I)V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/y$b;->a:Landroidx/appcompat/widget/y;

    invoke-static {v0, p1}, Landroidx/appcompat/widget/y;->o(Landroidx/appcompat/widget/y;I)V

    return-void
.end method

.method public k(IIII)V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/y$b;->a:Landroidx/appcompat/widget/y;

    invoke-static {v0, p1, p2, p3, p4}, Landroidx/appcompat/widget/y;->m(Landroidx/appcompat/widget/y;IIII)V

    return-void
.end method

.method public l()I
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/y$b;->a:Landroidx/appcompat/widget/y;

    invoke-static {v0}, Landroidx/appcompat/widget/y;->k(Landroidx/appcompat/widget/y;)I

    move-result v0

    return v0
.end method
