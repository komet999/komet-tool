.class Landroidx/appcompat/widget/y$c;
.super Landroidx/appcompat/widget/y$b;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/y;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "c"
.end annotation


# instance fields
.field final synthetic b:Landroidx/appcompat/widget/y;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/y;)V
    .locals 0

    iput-object p1, p0, Landroidx/appcompat/widget/y$c;->b:Landroidx/appcompat/widget/y;

    invoke-direct {p0, p1}, Landroidx/appcompat/widget/y$b;-><init>(Landroidx/appcompat/widget/y;)V

    return-void
.end method


# virtual methods
.method public e(I)V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/y$c;->b:Landroidx/appcompat/widget/y;

    invoke-static {v0, p1}, Landroidx/appcompat/widget/y;->h(Landroidx/appcompat/widget/y;I)V

    return-void
.end method

.method public f(I)V
    .locals 1

    iget-object v0, p0, Landroidx/appcompat/widget/y$c;->b:Landroidx/appcompat/widget/y;

    invoke-static {v0, p1}, Landroidx/appcompat/widget/y;->f(Landroidx/appcompat/widget/y;I)V

    return-void
.end method
