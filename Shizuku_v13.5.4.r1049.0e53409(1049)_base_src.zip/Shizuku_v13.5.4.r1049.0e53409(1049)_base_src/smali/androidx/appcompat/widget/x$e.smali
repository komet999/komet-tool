.class Landroidx/appcompat/widget/x$e;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/x;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "e"
.end annotation


# direct methods
.method static a(Landroid/widget/TextView;)I
    .locals 0

    invoke-static {p0}, Lrikka/shizuku/i6;->a(Landroid/widget/TextView;)I

    move-result p0

    return p0
.end method

.method static b(Landroid/widget/TextView;IIII)V
    .locals 0

    invoke-static {p0, p1, p2, p3, p4}, Lrikka/shizuku/h6;->a(Landroid/widget/TextView;IIII)V

    return-void
.end method

.method static c(Landroid/widget/TextView;[II)V
    .locals 0

    invoke-static {p0, p1, p2}, Lrikka/shizuku/j6;->a(Landroid/widget/TextView;[II)V

    return-void
.end method

.method static d(Landroid/widget/TextView;Ljava/lang/String;)Z
    .locals 0

    invoke-static {p0, p1}, Lrikka/shizuku/g6;->a(Landroid/widget/TextView;Ljava/lang/String;)Z

    move-result p0

    return p0
.end method
