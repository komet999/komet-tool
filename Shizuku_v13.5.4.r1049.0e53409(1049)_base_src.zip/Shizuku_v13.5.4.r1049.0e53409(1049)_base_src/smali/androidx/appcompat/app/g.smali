.class public final synthetic Landroidx/appcompat/app/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic d:Landroidx/appcompat/app/h$a;

.field public final synthetic e:Ljava/lang/Runnable;


# direct methods
.method public synthetic constructor <init>(Landroidx/appcompat/app/h$a;Ljava/lang/Runnable;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Landroidx/appcompat/app/g;->d:Landroidx/appcompat/app/h$a;

    iput-object p2, p0, Landroidx/appcompat/app/g;->e:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    iget-object v0, p0, Landroidx/appcompat/app/g;->d:Landroidx/appcompat/app/h$a;

    iget-object v1, p0, Landroidx/appcompat/app/g;->e:Ljava/lang/Runnable;

    invoke-static {v0, v1}, Landroidx/appcompat/app/h$a;->a(Landroidx/appcompat/app/h$a;Ljava/lang/Runnable;)V

    return-void
.end method
