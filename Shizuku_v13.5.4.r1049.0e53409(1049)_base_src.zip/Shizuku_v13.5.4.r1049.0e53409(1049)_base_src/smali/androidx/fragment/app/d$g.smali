.class Landroidx/fragment/app/d$g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/d;->x(Ljava/util/List;Ljava/util/List;ZLandroidx/fragment/app/z$e;Landroidx/fragment/app/z$e;)Ljava/util/Map;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic d:Landroidx/fragment/app/z$e;

.field final synthetic e:Landroidx/fragment/app/z$e;

.field final synthetic f:Z

.field final synthetic g:Lrikka/shizuku/l7;

.field final synthetic h:Landroidx/fragment/app/d;


# direct methods
.method constructor <init>(Landroidx/fragment/app/d;Landroidx/fragment/app/z$e;Landroidx/fragment/app/z$e;ZLrikka/shizuku/l7;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/d$g;->h:Landroidx/fragment/app/d;

    iput-object p2, p0, Landroidx/fragment/app/d$g;->d:Landroidx/fragment/app/z$e;

    iput-object p3, p0, Landroidx/fragment/app/d$g;->e:Landroidx/fragment/app/z$e;

    iput-boolean p4, p0, Landroidx/fragment/app/d$g;->f:Z

    iput-object p5, p0, Landroidx/fragment/app/d$g;->g:Lrikka/shizuku/l7;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 1
    iget-object v0, p0, Landroidx/fragment/app/d$g;->d:Landroidx/fragment/app/z$e;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroidx/fragment/app/z$e;->f()Landroidx/fragment/app/Fragment;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-object v1, p0, Landroidx/fragment/app/d$g;->e:Landroidx/fragment/app/z$e;

    .line 8
    .line 9
    invoke-virtual {v1}, Landroidx/fragment/app/z$e;->f()Landroidx/fragment/app/Fragment;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    iget-boolean v2, p0, Landroidx/fragment/app/d$g;->f:Z

    .line 14
    .line 15
    iget-object v3, p0, Landroidx/fragment/app/d$g;->g:Lrikka/shizuku/l7;

    .line 16
    .line 17
    const/4 v4, 0x0

    .line 18
    invoke-static {v0, v1, v2, v3, v4}, Landroidx/fragment/app/u;->a(Landroidx/fragment/app/Fragment;Landroidx/fragment/app/Fragment;ZLrikka/shizuku/l7;Z)V

    .line 19
    .line 20
    .line 21
    return-void
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
.end method
