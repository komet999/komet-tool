.class Landroidx/fragment/app/f$a;
.super Landroidx/fragment/app/j;
.source "SourceFile"

# interfaces
.implements Lrikka/shizuku/x50;
.implements Lrikka/shizuku/e60;
.implements Lrikka/shizuku/z50;
.implements Lrikka/shizuku/a60;
.implements Lrikka/shizuku/ou0;
.implements Lrikka/shizuku/w50;
.implements Lrikka/shizuku/y2;
.implements Lrikka/shizuku/sf0;
.implements Lrikka/shizuku/gp;
.implements Lrikka/shizuku/w20;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/fragment/app/j<",
        "Landroidx/fragment/app/f;",
        ">;",
        "Lrikka/shizuku/x50;",
        "Lrikka/shizuku/e60;",
        "Lrikka/shizuku/z50;",
        "Lrikka/shizuku/a60;",
        "Lrikka/shizuku/ou0;",
        "Lrikka/shizuku/w50;",
        "Lrikka/shizuku/y2;",
        "Lrikka/shizuku/sf0;",
        "Lrikka/shizuku/gp;",
        "Lrikka/shizuku/w20;"
    }
.end annotation


# instance fields
.field final synthetic f:Landroidx/fragment/app/f;


# direct methods
.method public constructor <init>(Landroidx/fragment/app/f;)V
    .locals 0

    .line 1
    iput-object p1, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    .line 2
    .line 3
    invoke-direct {p0, p1}, Landroidx/fragment/app/j;-><init>(Landroidx/fragment/app/f;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
.end method


# virtual methods
.method public A()V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0}, Landroid/app/Activity;->invalidateOptionsMenu()V

    return-void
.end method

.method public B()Landroidx/fragment/app/f;
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    return-object v0
.end method

.method public a()Landroidx/lifecycle/g;
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    iget-object v0, v0, Landroidx/fragment/app/f;->t:Landroidx/lifecycle/k;

    return-object v0
.end method

.method public b(Landroidx/fragment/app/m;Landroidx/fragment/app/Fragment;)V
    .locals 0

    iget-object p1, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {p1, p2}, Landroidx/fragment/app/f;->Y(Landroidx/fragment/app/Fragment;)V

    return-void
.end method

.method public c(Lrikka/shizuku/ef;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lrikka/shizuku/ef<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, p1}, Landroidx/activity/ComponentActivity;->c(Lrikka/shizuku/ef;)V

    return-void
.end method

.method public e(I)Landroid/view/View;
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, p1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public f(Lrikka/shizuku/ef;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lrikka/shizuku/ef<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, p1}, Landroidx/activity/ComponentActivity;->f(Lrikka/shizuku/ef;)V

    return-void
.end method

.method public g()Landroidx/activity/OnBackPressedDispatcher;
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0}, Landroidx/activity/ComponentActivity;->g()Landroidx/activity/OnBackPressedDispatcher;

    move-result-object v0

    return-object v0
.end method

.method public h()Lrikka/shizuku/qf0;
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0}, Landroidx/activity/ComponentActivity;->h()Lrikka/shizuku/qf0;

    move-result-object v0

    return-object v0
.end method

.method public i(Lrikka/shizuku/ef;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lrikka/shizuku/ef<",
            "Lrikka/shizuku/g40;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, p1}, Landroidx/activity/ComponentActivity;->i(Lrikka/shizuku/ef;)V

    return-void
.end method

.method public j(Lrikka/shizuku/q30;)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, p1}, Landroidx/activity/ComponentActivity;->j(Lrikka/shizuku/q30;)V

    return-void
.end method

.method public k()Landroidx/activity/result/ActivityResultRegistry;
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0}, Landroidx/activity/ComponentActivity;->k()Landroidx/activity/result/ActivityResultRegistry;

    move-result-object v0

    return-object v0
.end method

.method public l(Lrikka/shizuku/ef;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lrikka/shizuku/ef<",
            "Lrikka/shizuku/g40;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, p1}, Landroidx/activity/ComponentActivity;->l(Lrikka/shizuku/ef;)V

    return-void
.end method

.method public m(Lrikka/shizuku/q30;)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, p1}, Landroidx/activity/ComponentActivity;->m(Lrikka/shizuku/q30;)V

    return-void
.end method

.method public n()Z
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {v0}, Landroid/view/Window;->peekDecorView()Landroid/view/View;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    const/4 v0, 0x1

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    const/4 v0, 0x0

    .line 18
    :goto_0
    return v0
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
.end method

.method public p(Lrikka/shizuku/ef;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lrikka/shizuku/ef<",
            "Lrikka/shizuku/n70;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, p1}, Landroidx/activity/ComponentActivity;->p(Lrikka/shizuku/ef;)V

    return-void
.end method

.method public q(Lrikka/shizuku/ef;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lrikka/shizuku/ef<",
            "Landroid/content/res/Configuration;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, p1}, Landroidx/activity/ComponentActivity;->q(Lrikka/shizuku/ef;)V

    return-void
.end method

.method public s()Landroidx/lifecycle/s;
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0}, Landroidx/activity/ComponentActivity;->s()Landroidx/lifecycle/s;

    move-result-object v0

    return-object v0
.end method

.method public t(Lrikka/shizuku/ef;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lrikka/shizuku/ef<",
            "Landroid/content/res/Configuration;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, p1}, Landroidx/activity/ComponentActivity;->t(Lrikka/shizuku/ef;)V

    return-void
.end method

.method public v(Lrikka/shizuku/ef;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lrikka/shizuku/ef<",
            "Lrikka/shizuku/n70;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, p1}, Landroidx/activity/ComponentActivity;->v(Lrikka/shizuku/ef;)V

    return-void
.end method

.method public w(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, p1, p2, p3, p4}, Landroidx/fragment/app/f;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    return-void
.end method

.method public bridge synthetic x()Ljava/lang/Object;
    .locals 1

    invoke-virtual {p0}, Landroidx/fragment/app/f$a;->B()Landroidx/fragment/app/f;

    move-result-object v0

    return-object v0
.end method

.method public y()Landroid/view/LayoutInflater;
    .locals 2

    iget-object v0, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    iget-object v1, p0, Landroidx/fragment/app/f$a;->f:Landroidx/fragment/app/f;

    invoke-virtual {v0, v1}, Landroid/view/LayoutInflater;->cloneInContext(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    return-object v0
.end method

.method public z()V
    .locals 0

    invoke-virtual {p0}, Landroidx/fragment/app/f$a;->A()V

    return-void
.end method
