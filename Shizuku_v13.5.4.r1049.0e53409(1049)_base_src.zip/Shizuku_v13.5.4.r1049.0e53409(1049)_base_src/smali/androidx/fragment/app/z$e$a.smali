.class Landroidx/fragment/app/z$e$a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lrikka/shizuku/tb$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/fragment/app/z$e;-><init>(Landroidx/fragment/app/z$e$c;Landroidx/fragment/app/z$e$b;Landroidx/fragment/app/Fragment;Lrikka/shizuku/tb;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/fragment/app/z$e;


# direct methods
.method constructor <init>(Landroidx/fragment/app/z$e;)V
    .locals 0

    iput-object p1, p0, Landroidx/fragment/app/z$e$a;->a:Landroidx/fragment/app/z$e;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a()V
    .locals 1

    iget-object v0, p0, Landroidx/fragment/app/z$e$a;->a:Landroidx/fragment/app/z$e;

    invoke-virtual {v0}, Landroidx/fragment/app/z$e;->b()V

    return-void
.end method
