.class public final Lc5/d;
.super Lb6/f;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Lj6/p;


# instance fields
.field public final synthetic q:I

.field public r:I

.field public s:Ljava/lang/Object;

.field public synthetic t:Ljava/lang/Object;

.field public final synthetic u:Ljava/lang/Object;


# direct methods
.method public constructor <init>(ILjava/io/InputStream;Ljava/io/OutputStream;Lz5/d;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lc5/d;->q:I

    .line 18
    iput p1, p0, Lc5/d;->r:I

    iput-object p2, p0, Lc5/d;->t:Ljava/lang/Object;

    iput-object p3, p0, Lc5/d;->u:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lb6/f;-><init>(ILz5/d;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lz5/d;I)V
    .locals 0

    .line 16
    iput p5, p0, Lc5/d;->q:I

    iput-object p1, p0, Lc5/d;->s:Ljava/lang/Object;

    iput-object p2, p0, Lc5/d;->t:Ljava/lang/Object;

    iput-object p3, p0, Lc5/d;->u:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lb6/f;-><init>(ILz5/d;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Lz5/d;I)V
    .locals 0

    .line 17
    iput p4, p0, Lc5/d;->q:I

    iput-object p1, p0, Lc5/d;->t:Ljava/lang/Object;

    iput-object p2, p0, Lc5/d;->u:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lb6/f;-><init>(ILz5/d;)V

    return-void
.end method

.method public constructor <init>(Lt6/l;Lj6/p;Lz5/d;)V
    .locals 1

    .line 1
    const/16 v0, 0xa

    .line 2
    .line 3
    iput v0, p0, Lc5/d;->q:I

    .line 4
    .line 5
    iput-object p1, p0, Lc5/d;->t:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p2, Lb6/f;

    .line 8
    .line 9
    iput-object p2, p0, Lc5/d;->u:Ljava/lang/Object;

    .line 10
    .line 11
    const/4 p1, 0x2

    .line 12
    invoke-direct {p0, p1, p3}, Lb6/f;-><init>(ILz5/d;)V

    .line 13
    .line 14
    .line 15
    return-void
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
.end method

.method public constructor <init>(Lx1/e0;Lz5/d;)V
    .locals 1

    const/4 v0, 0x6

    iput v0, p0, Lc5/d;->q:I

    .line 19
    iput-object p1, p0, Lc5/d;->u:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lb6/f;-><init>(ILz5/d;)V

    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Lc5/d;->q:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lt6/s;

    .line 7
    .line 8
    check-cast p2, Lz5/d;

    .line 9
    .line 10
    invoke-virtual {p0, p1, p2}, Lc5/d;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lc5/d;

    .line 15
    .line 16
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 17
    .line 18
    invoke-virtual {p1, p2}, Lc5/d;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    return-object p1

    .line 23
    :pswitch_0
    check-cast p1, Lt6/s;

    .line 24
    .line 25
    check-cast p2, Lz5/d;

    .line 26
    .line 27
    invoke-virtual {p0, p1, p2}, Lc5/d;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    check-cast p1, Lc5/d;

    .line 32
    .line 33
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 34
    .line 35
    invoke-virtual {p1, p2}, Lc5/d;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    return-object p1

    .line 40
    :pswitch_1
    check-cast p1, Lt6/s;

    .line 41
    .line 42
    check-cast p2, Lz5/d;

    .line 43
    .line 44
    invoke-virtual {p0, p1, p2}, Lc5/d;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    check-cast p1, Lc5/d;

    .line 49
    .line 50
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 51
    .line 52
    invoke-virtual {p1, p2}, Lc5/d;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    return-object p1

    .line 57
    :pswitch_2
    check-cast p1, Lt6/s;

    .line 58
    .line 59
    check-cast p2, Lz5/d;

    .line 60
    .line 61
    invoke-virtual {p0, p1, p2}, Lc5/d;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    check-cast p1, Lc5/d;

    .line 66
    .line 67
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 68
    .line 69
    invoke-virtual {p1, p2}, Lc5/d;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    return-object p1

    .line 74
    :pswitch_3
    check-cast p1, Lx1/w;

    .line 75
    .line 76
    check-cast p2, Lz5/d;

    .line 77
    .line 78
    invoke-virtual {p0, p1, p2}, Lc5/d;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    check-cast p1, Lc5/d;

    .line 83
    .line 84
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 85
    .line 86
    invoke-virtual {p1, p2}, Lc5/d;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    return-object p1

    .line 91
    :pswitch_4
    check-cast p1, Lx1/w;

    .line 92
    .line 93
    check-cast p2, Lz5/d;

    .line 94
    .line 95
    invoke-virtual {p0, p1, p2}, Lc5/d;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    check-cast p1, Lc5/d;

    .line 100
    .line 101
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 102
    .line 103
    invoke-virtual {p1, p2}, Lc5/d;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    return-object p1

    .line 108
    :pswitch_5
    check-cast p1, Lt6/s;

    .line 109
    .line 110
    check-cast p2, Lz5/d;

    .line 111
    .line 112
    invoke-virtual {p0, p1, p2}, Lc5/d;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    check-cast p1, Lc5/d;

    .line 117
    .line 118
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 119
    .line 120
    invoke-virtual {p1, p2}, Lc5/d;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    return-object p1

    .line 125
    :pswitch_6
    check-cast p1, Lt6/s;

    .line 126
    .line 127
    check-cast p2, Lz5/d;

    .line 128
    .line 129
    invoke-virtual {p0, p1, p2}, Lc5/d;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 130
    .line 131
    .line 132
    move-result-object p1

    .line 133
    check-cast p1, Lc5/d;

    .line 134
    .line 135
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 136
    .line 137
    invoke-virtual {p1, p2}, Lc5/d;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    return-object p1

    .line 142
    :pswitch_7
    check-cast p1, Lt6/s;

    .line 143
    .line 144
    check-cast p2, Lz5/d;

    .line 145
    .line 146
    invoke-virtual {p0, p1, p2}, Lc5/d;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    check-cast p1, Lc5/d;

    .line 151
    .line 152
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 153
    .line 154
    invoke-virtual {p1, p2}, Lc5/d;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 155
    .line 156
    .line 157
    move-result-object p1

    .line 158
    return-object p1

    .line 159
    :pswitch_8
    check-cast p1, Lt6/s;

    .line 160
    .line 161
    check-cast p2, Lz5/d;

    .line 162
    .line 163
    invoke-virtual {p0, p1, p2}, Lc5/d;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 164
    .line 165
    .line 166
    move-result-object p1

    .line 167
    check-cast p1, Lc5/d;

    .line 168
    .line 169
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 170
    .line 171
    invoke-virtual {p1, p2}, Lc5/d;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object p1

    .line 175
    return-object p1

    .line 176
    :pswitch_9
    check-cast p1, Lt6/s;

    .line 177
    .line 178
    check-cast p2, Lz5/d;

    .line 179
    .line 180
    invoke-virtual {p0, p1, p2}, Lc5/d;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 181
    .line 182
    .line 183
    move-result-object p1

    .line 184
    check-cast p1, Lc5/d;

    .line 185
    .line 186
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 187
    .line 188
    invoke-virtual {p1, p2}, Lc5/d;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object p1

    .line 192
    return-object p1

    .line 193
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
.end method

.method public final l(Ljava/lang/Object;Lz5/d;)Lz5/d;
    .locals 10

    .line 1
    iget v0, p0, Lc5/d;->q:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v0, Lc5/d;

    .line 7
    .line 8
    iget-object v1, p0, Lc5/d;->t:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lt6/l;

    .line 11
    .line 12
    iget-object v2, p0, Lc5/d;->u:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v2, Lb6/f;

    .line 15
    .line 16
    invoke-direct {v0, v1, v2, p2}, Lc5/d;-><init>(Lt6/l;Lj6/p;Lz5/d;)V

    .line 17
    .line 18
    .line 19
    iput-object p1, v0, Lc5/d;->s:Ljava/lang/Object;

    .line 20
    .line 21
    return-object v0

    .line 22
    :pswitch_0
    new-instance p1, Lc5/d;

    .line 23
    .line 24
    iget-object v0, p0, Lc5/d;->t:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v0, Lk6/p;

    .line 27
    .line 28
    iget-object v1, p0, Lc5/d;->u:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v1, Lz1/t;

    .line 31
    .line 32
    const/16 v2, 0x9

    .line 33
    .line 34
    invoke-direct {p1, v0, v1, p2, v2}, Lc5/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lz5/d;I)V

    .line 35
    .line 36
    .line 37
    return-object p1

    .line 38
    :pswitch_1
    new-instance v3, Lc5/d;

    .line 39
    .line 40
    iget-object p1, p0, Lc5/d;->s:Ljava/lang/Object;

    .line 41
    .line 42
    move-object v4, p1

    .line 43
    check-cast v4, Lw6/b;

    .line 44
    .line 45
    iget-object p1, p0, Lc5/d;->t:Ljava/lang/Object;

    .line 46
    .line 47
    move-object v5, p1

    .line 48
    check-cast v5, Lw6/g;

    .line 49
    .line 50
    iget-object p1, p0, Lc5/d;->u:Ljava/lang/Object;

    .line 51
    .line 52
    move-object v6, p1

    .line 53
    check-cast v6, Lb7/i;

    .line 54
    .line 55
    const/16 v8, 0x8

    .line 56
    .line 57
    move-object v7, p2

    .line 58
    invoke-direct/range {v3 .. v8}, Lc5/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lz5/d;I)V

    .line 59
    .line 60
    .line 61
    return-object v3

    .line 62
    :pswitch_2
    move-object v8, p2

    .line 63
    new-instance p2, Lc5/d;

    .line 64
    .line 65
    iget-object v0, p0, Lc5/d;->t:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast v0, Lw6/c;

    .line 68
    .line 69
    iget-object v1, p0, Lc5/d;->u:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast v1, Lx6/f;

    .line 72
    .line 73
    const/4 v2, 0x7

    .line 74
    invoke-direct {p2, v0, v1, v8, v2}, Lc5/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lz5/d;I)V

    .line 75
    .line 76
    .line 77
    iput-object p1, p2, Lc5/d;->s:Ljava/lang/Object;

    .line 78
    .line 79
    return-object p2

    .line 80
    :pswitch_3
    move-object v8, p2

    .line 81
    new-instance p2, Lc5/d;

    .line 82
    .line 83
    iget-object v0, p0, Lc5/d;->u:Ljava/lang/Object;

    .line 84
    .line 85
    check-cast v0, Lx1/e0;

    .line 86
    .line 87
    invoke-direct {p2, v0, v8}, Lc5/d;-><init>(Lx1/e0;Lz5/d;)V

    .line 88
    .line 89
    .line 90
    iput-object p1, p2, Lc5/d;->t:Ljava/lang/Object;

    .line 91
    .line 92
    return-object p2

    .line 93
    :pswitch_4
    move-object v8, p2

    .line 94
    new-instance p2, Lc5/d;

    .line 95
    .line 96
    iget-object v0, p0, Lc5/d;->t:Ljava/lang/Object;

    .line 97
    .line 98
    check-cast v0, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;

    .line 99
    .line 100
    iget-object v1, p0, Lc5/d;->u:Ljava/lang/Object;

    .line 101
    .line 102
    check-cast v1, [Ljava/lang/String;

    .line 103
    .line 104
    const/4 v2, 0x5

    .line 105
    invoke-direct {p2, v0, v1, v8, v2}, Lc5/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lz5/d;I)V

    .line 106
    .line 107
    .line 108
    iput-object p1, p2, Lc5/d;->s:Ljava/lang/Object;

    .line 109
    .line 110
    return-object p2

    .line 111
    :pswitch_5
    move-object v8, p2

    .line 112
    new-instance v4, Lc5/d;

    .line 113
    .line 114
    iget-object p1, p0, Lc5/d;->s:Ljava/lang/Object;

    .line 115
    .line 116
    move-object v5, p1

    .line 117
    check-cast v5, Ljava/lang/String;

    .line 118
    .line 119
    iget-object p1, p0, Lc5/d;->t:Ljava/lang/Object;

    .line 120
    .line 121
    move-object v6, p1

    .line 122
    check-cast v6, Landroid/net/Uri;

    .line 123
    .line 124
    iget-object p1, p0, Lc5/d;->u:Ljava/lang/Object;

    .line 125
    .line 126
    move-object v7, p1

    .line 127
    check-cast v7, Lw4/e;

    .line 128
    .line 129
    const/4 v9, 0x4

    .line 130
    invoke-direct/range {v4 .. v9}, Lc5/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lz5/d;I)V

    .line 131
    .line 132
    .line 133
    return-object v4

    .line 134
    :pswitch_6
    move-object v8, p2

    .line 135
    new-instance v4, Lc5/d;

    .line 136
    .line 137
    iget-object p1, p0, Lc5/d;->s:Ljava/lang/Object;

    .line 138
    .line 139
    move-object v5, p1

    .line 140
    check-cast v5, La4/g;

    .line 141
    .line 142
    iget-object p1, p0, Lc5/d;->t:Ljava/lang/Object;

    .line 143
    .line 144
    move-object v6, p1

    .line 145
    check-cast v6, Laa/e;

    .line 146
    .line 147
    iget-object p1, p0, Lc5/d;->u:Ljava/lang/Object;

    .line 148
    .line 149
    move-object v7, p1

    .line 150
    check-cast v7, Ljava/lang/String;

    .line 151
    .line 152
    const/4 v9, 0x3

    .line 153
    invoke-direct/range {v4 .. v9}, Lc5/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lz5/d;I)V

    .line 154
    .line 155
    .line 156
    return-object v4

    .line 157
    :pswitch_7
    move-object v8, p2

    .line 158
    new-instance p2, Lc5/d;

    .line 159
    .line 160
    iget v0, p0, Lc5/d;->r:I

    .line 161
    .line 162
    iget-object v1, p0, Lc5/d;->t:Ljava/lang/Object;

    .line 163
    .line 164
    check-cast v1, Ljava/io/InputStream;

    .line 165
    .line 166
    iget-object v2, p0, Lc5/d;->u:Ljava/lang/Object;

    .line 167
    .line 168
    check-cast v2, Ljava/io/OutputStream;

    .line 169
    .line 170
    invoke-direct {p2, v0, v1, v2, v8}, Lc5/d;-><init>(ILjava/io/InputStream;Ljava/io/OutputStream;Lz5/d;)V

    .line 171
    .line 172
    .line 173
    iput-object p1, p2, Lc5/d;->s:Ljava/lang/Object;

    .line 174
    .line 175
    return-object p2

    .line 176
    :pswitch_8
    move-object v8, p2

    .line 177
    new-instance p1, Lc5/d;

    .line 178
    .line 179
    iget-object p2, p0, Lc5/d;->t:Ljava/lang/Object;

    .line 180
    .line 181
    check-cast p2, Lf4/d;

    .line 182
    .line 183
    iget-object v0, p0, Lc5/d;->u:Ljava/lang/Object;

    .line 184
    .line 185
    check-cast v0, Lf4/k;

    .line 186
    .line 187
    const/4 v1, 0x1

    .line 188
    invoke-direct {p1, p2, v0, v8, v1}, Lc5/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lz5/d;I)V

    .line 189
    .line 190
    .line 191
    return-object p1

    .line 192
    :pswitch_9
    move-object v8, p2

    .line 193
    new-instance p1, Lc5/d;

    .line 194
    .line 195
    iget-object p2, p0, Lc5/d;->t:Ljava/lang/Object;

    .line 196
    .line 197
    check-cast p2, Lc5/i;

    .line 198
    .line 199
    iget-object v0, p0, Lc5/d;->u:Ljava/lang/Object;

    .line 200
    .line 201
    check-cast v0, Lc5/a;

    .line 202
    .line 203
    const/4 v1, 0x0

    .line 204
    invoke-direct {p1, p2, v0, v8, v1}, Lc5/d;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lz5/d;I)V

    .line 205
    .line 206
    .line 207
    return-object p1

    .line 208
    nop

    .line 209
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 28

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, Lc5/d;->q:I

    .line 4
    .line 5
    const/4 v2, 0x6

    .line 6
    const/4 v3, 0x5

    .line 7
    const/4 v6, 0x4

    .line 8
    const/4 v7, 0x3

    .line 9
    const/4 v8, 0x2

    .line 10
    const/4 v9, 0x0

    .line 11
    const-string v10, "call to \'resume\' before \'invoke\' with coroutine"

    .line 12
    .line 13
    const/4 v11, 0x1

    .line 14
    const/4 v12, 0x0

    .line 15
    packed-switch v0, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    sget-object v0, La6/a;->m:La6/a;

    .line 19
    .line 20
    iget v2, v1, Lc5/d;->r:I

    .line 21
    .line 22
    if-eqz v2, :cond_1

    .line 23
    .line 24
    if-ne v2, v11, :cond_0

    .line 25
    .line 26
    iget-object v0, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 27
    .line 28
    move-object v2, v0

    .line 29
    check-cast v2, Lt6/l;

    .line 30
    .line 31
    :try_start_0
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 32
    .line 33
    .line 34
    move-object v3, v2

    .line 35
    move-object/from16 v2, p1

    .line 36
    .line 37
    goto :goto_1

    .line 38
    :catchall_0
    move-exception v0

    .line 39
    goto :goto_0

    .line 40
    :cond_0
    invoke-static {v10}, Lq0/b;->m(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    goto :goto_3

    .line 44
    :cond_1
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    iget-object v2, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v2, Lt6/s;

    .line 50
    .line 51
    iget-object v3, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v3, Lt6/l;

    .line 54
    .line 55
    iget-object v4, v1, Lc5/d;->u:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v4, Lb6/f;

    .line 58
    .line 59
    :try_start_1
    iput-object v3, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 60
    .line 61
    iput v11, v1, Lc5/d;->r:I

    .line 62
    .line 63
    invoke-interface {v4, v2, v1}, Lj6/p;->i(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 67
    if-ne v2, v0, :cond_2

    .line 68
    .line 69
    move-object v12, v0

    .line 70
    goto :goto_3

    .line 71
    :catchall_1
    move-exception v0

    .line 72
    move-object v2, v3

    .line 73
    :goto_0
    new-instance v3, Lv5/f;

    .line 74
    .line 75
    invoke-direct {v3, v0}, Lv5/f;-><init>(Ljava/lang/Throwable;)V

    .line 76
    .line 77
    .line 78
    move-object/from16 v27, v3

    .line 79
    .line 80
    move-object v3, v2

    .line 81
    move-object/from16 v2, v27

    .line 82
    .line 83
    :cond_2
    :goto_1
    invoke-static {v2}, Lv5/g;->a(Ljava/lang/Object;)Ljava/lang/Throwable;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    if-nez v0, :cond_3

    .line 88
    .line 89
    invoke-virtual {v3, v2}, Lt6/v0;->I(Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    goto :goto_2

    .line 93
    :cond_3
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 94
    .line 95
    .line 96
    new-instance v2, Lt6/n;

    .line 97
    .line 98
    invoke-direct {v2, v0, v9}, Lt6/n;-><init>(Ljava/lang/Throwable;Z)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {v3, v2}, Lt6/v0;->I(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    :goto_2
    sget-object v12, Lv5/k;->a:Lv5/k;

    .line 105
    .line 106
    :goto_3
    return-object v12

    .line 107
    :pswitch_0
    sget-object v0, La6/a;->m:La6/a;

    .line 108
    .line 109
    iget v2, v1, Lc5/d;->r:I

    .line 110
    .line 111
    if-eqz v2, :cond_5

    .line 112
    .line 113
    if-ne v2, v11, :cond_4

    .line 114
    .line 115
    iget-object v0, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 116
    .line 117
    check-cast v0, Lk6/p;

    .line 118
    .line 119
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    move-object/from16 v3, p1

    .line 123
    .line 124
    goto :goto_4

    .line 125
    :cond_4
    invoke-static {v10}, Lq0/b;->m(Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    goto :goto_5

    .line 129
    :cond_5
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    iget-object v2, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast v2, Lk6/p;

    .line 135
    .line 136
    iget-object v3, v1, Lc5/d;->u:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast v3, Lz1/t;

    .line 139
    .line 140
    iput-object v2, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 141
    .line 142
    iput v11, v1, Lc5/d;->r:I

    .line 143
    .line 144
    invoke-virtual {v3, v1}, Lz1/t;->a(Lb6/c;)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v3

    .line 148
    if-ne v3, v0, :cond_6

    .line 149
    .line 150
    move-object v12, v0

    .line 151
    goto :goto_5

    .line 152
    :cond_6
    move-object v0, v2

    .line 153
    :goto_4
    iput-object v3, v0, Lk6/p;->m:Ljava/lang/Object;

    .line 154
    .line 155
    sget-object v12, Lv5/k;->a:Lv5/k;

    .line 156
    .line 157
    :goto_5
    return-object v12

    .line 158
    :pswitch_1
    iget-object v0, v1, Lc5/d;->u:Ljava/lang/Object;

    .line 159
    .line 160
    move-object v2, v0

    .line 161
    check-cast v2, Lb7/i;

    .line 162
    .line 163
    sget-object v0, La6/a;->m:La6/a;

    .line 164
    .line 165
    iget v3, v1, Lc5/d;->r:I

    .line 166
    .line 167
    if-eqz v3, :cond_8

    .line 168
    .line 169
    if-ne v3, v11, :cond_7

    .line 170
    .line 171
    :try_start_2
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 172
    .line 173
    .line 174
    goto :goto_6

    .line 175
    :catchall_2
    move-exception v0

    .line 176
    goto :goto_8

    .line 177
    :cond_7
    invoke-static {v10}, Lq0/b;->m(Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    goto :goto_7

    .line 181
    :cond_8
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 182
    .line 183
    .line 184
    :try_start_3
    iget-object v3, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 185
    .line 186
    check-cast v3, Lw6/b;

    .line 187
    .line 188
    iget-object v4, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 189
    .line 190
    check-cast v4, Lw6/g;

    .line 191
    .line 192
    iput v11, v1, Lc5/d;->r:I

    .line 193
    .line 194
    invoke-interface {v3, v4, v1}, Lw6/b;->a(Lw6/c;Lz5/d;)Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    .line 198
    if-ne v3, v0, :cond_9

    .line 199
    .line 200
    move-object v12, v0

    .line 201
    goto :goto_7

    .line 202
    :cond_9
    :goto_6
    invoke-virtual {v2}, Lb7/h;->c()V

    .line 203
    .line 204
    .line 205
    sget-object v12, Lv5/k;->a:Lv5/k;

    .line 206
    .line 207
    :goto_7
    return-object v12

    .line 208
    :goto_8
    invoke-virtual {v2}, Lb7/h;->c()V

    .line 209
    .line 210
    .line 211
    throw v0

    .line 212
    :pswitch_2
    sget-object v0, Lv5/k;->a:Lv5/k;

    .line 213
    .line 214
    sget-object v2, La6/a;->m:La6/a;

    .line 215
    .line 216
    iget v3, v1, Lc5/d;->r:I

    .line 217
    .line 218
    if-eqz v3, :cond_c

    .line 219
    .line 220
    if-ne v3, v11, :cond_b

    .line 221
    .line 222
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 223
    .line 224
    .line 225
    :cond_a
    move-object v12, v0

    .line 226
    goto :goto_a

    .line 227
    :cond_b
    invoke-static {v10}, Lq0/b;->m(Ljava/lang/String;)V

    .line 228
    .line 229
    .line 230
    goto :goto_a

    .line 231
    :cond_c
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 232
    .line 233
    .line 234
    iget-object v3, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 235
    .line 236
    check-cast v3, Lt6/s;

    .line 237
    .line 238
    iget-object v4, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 239
    .line 240
    check-cast v4, Lw6/c;

    .line 241
    .line 242
    iget-object v5, v1, Lc5/d;->u:Ljava/lang/Object;

    .line 243
    .line 244
    check-cast v5, Lx6/f;

    .line 245
    .line 246
    sget-object v6, Lz5/i;->m:Lz5/i;

    .line 247
    .line 248
    new-instance v7, La4/p;

    .line 249
    .line 250
    const/16 v8, 0x10

    .line 251
    .line 252
    invoke-direct {v7, v5, v12, v8}, La4/p;-><init>(Ljava/lang/Object;Lz5/d;I)V

    .line 253
    .line 254
    .line 255
    new-instance v5, Lv6/b;

    .line 256
    .line 257
    sget-object v8, Lv6/f;->j:Lv6/e;

    .line 258
    .line 259
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 260
    .line 261
    .line 262
    sget v8, Lv6/e;->b:I

    .line 263
    .line 264
    invoke-direct {v5, v8}, Lv6/b;-><init>(I)V

    .line 265
    .line 266
    .line 267
    invoke-interface {v3}, Lt6/s;->l()Lz5/h;

    .line 268
    .line 269
    .line 270
    move-result-object v3

    .line 271
    invoke-static {v3, v6, v11}, Lt6/t;->a(Lz5/h;Lz5/h;Z)Lz5/h;

    .line 272
    .line 273
    .line 274
    move-result-object v3

    .line 275
    sget-object v6, Lt6/a0;->a:La7/d;

    .line 276
    .line 277
    if-eq v3, v6, :cond_d

    .line 278
    .line 279
    sget-object v8, Lz5/e;->m:Lz5/e;

    .line 280
    .line 281
    invoke-interface {v3, v8}, Lz5/h;->A(Lz5/g;)Lz5/f;

    .line 282
    .line 283
    .line 284
    move-result-object v8

    .line 285
    if-nez v8, :cond_d

    .line 286
    .line 287
    invoke-interface {v3, v6}, Lz5/h;->z(Lz5/h;)Lz5/h;

    .line 288
    .line 289
    .line 290
    move-result-object v3

    .line 291
    :cond_d
    new-instance v6, Lv6/j;

    .line 292
    .line 293
    invoke-direct {v6, v3, v5}, Lv6/j;-><init>(Lz5/h;Lv6/b;)V

    .line 294
    .line 295
    .line 296
    invoke-virtual {v6, v11, v6, v7}, Lt6/a;->X(ILt6/a;Lj6/p;)V

    .line 297
    .line 298
    .line 299
    iput v11, v1, Lc5/d;->r:I

    .line 300
    .line 301
    invoke-static {v4, v6, v11, v1}, Lw6/p;->c(Lw6/c;Lv6/j;ZLb6/c;)Ljava/lang/Object;

    .line 302
    .line 303
    .line 304
    move-result-object v3

    .line 305
    if-ne v3, v2, :cond_e

    .line 306
    .line 307
    goto :goto_9

    .line 308
    :cond_e
    move-object v3, v0

    .line 309
    :goto_9
    if-ne v3, v2, :cond_a

    .line 310
    .line 311
    move-object v12, v2

    .line 312
    :goto_a
    return-object v12

    .line 313
    :pswitch_3
    sget-object v0, Lv5/k;->a:Lv5/k;

    .line 314
    .line 315
    sget-object v2, La6/a;->m:La6/a;

    .line 316
    .line 317
    iget v3, v1, Lc5/d;->r:I

    .line 318
    .line 319
    if-eqz v3, :cond_11

    .line 320
    .line 321
    if-eq v3, v11, :cond_10

    .line 322
    .line 323
    if-ne v3, v8, :cond_f

    .line 324
    .line 325
    iget-object v2, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 326
    .line 327
    check-cast v2, Ljava/util/concurrent/locks/ReentrantLock;

    .line 328
    .line 329
    iget-object v3, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 330
    .line 331
    check-cast v3, Lx1/l;

    .line 332
    .line 333
    :try_start_4
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 334
    .line 335
    .line 336
    goto/16 :goto_13

    .line 337
    .line 338
    :catchall_3
    move-exception v0

    .line 339
    move v4, v9

    .line 340
    goto/16 :goto_15

    .line 341
    .line 342
    :cond_f
    invoke-static {v10}, Lq0/b;->m(Ljava/lang/String;)V

    .line 343
    .line 344
    .line 345
    goto/16 :goto_17

    .line 346
    .line 347
    :cond_10
    iget-object v3, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 348
    .line 349
    check-cast v3, Lx1/w;

    .line 350
    .line 351
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 352
    .line 353
    .line 354
    move-object/from16 v6, p1

    .line 355
    .line 356
    goto :goto_b

    .line 357
    :cond_11
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 358
    .line 359
    .line 360
    iget-object v3, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 361
    .line 362
    check-cast v3, Lx1/w;

    .line 363
    .line 364
    iput-object v3, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 365
    .line 366
    iput v11, v1, Lc5/d;->r:I

    .line 367
    .line 368
    invoke-interface {v3, v1}, Lx1/w;->d(Lz5/d;)Ljava/lang/Boolean;

    .line 369
    .line 370
    .line 371
    move-result-object v6

    .line 372
    if-ne v6, v2, :cond_12

    .line 373
    .line 374
    goto/16 :goto_12

    .line 375
    .line 376
    :cond_12
    :goto_b
    check-cast v6, Ljava/lang/Boolean;

    .line 377
    .line 378
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    .line 379
    .line 380
    .line 381
    move-result v6

    .line 382
    if-eqz v6, :cond_13

    .line 383
    .line 384
    :goto_c
    move-object v12, v0

    .line 385
    goto/16 :goto_17

    .line 386
    .line 387
    :cond_13
    iget-object v6, v1, Lc5/d;->u:Ljava/lang/Object;

    .line 388
    .line 389
    check-cast v6, Lx1/e0;

    .line 390
    .line 391
    iget-object v7, v6, Lx1/e0;->h:Lx1/l;

    .line 392
    .line 393
    iget-object v10, v7, Lx1/l;->e:Ljava/util/concurrent/locks/ReentrantLock;

    .line 394
    .line 395
    invoke-virtual {v10}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 396
    .line 397
    .line 398
    :try_start_5
    iput-boolean v11, v7, Lx1/l;->f:Z

    .line 399
    .line 400
    iget-object v13, v7, Lx1/l;->a:Ljava/util/concurrent/locks/ReentrantLock;

    .line 401
    .line 402
    invoke-virtual {v13}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_7

    .line 403
    .line 404
    .line 405
    :try_start_6
    iget-boolean v14, v7, Lx1/l;->d:Z

    .line 406
    .line 407
    if-nez v14, :cond_15

    .line 408
    .line 409
    :cond_14
    move-object v15, v12

    .line 410
    goto :goto_11

    .line 411
    :cond_15
    iput-boolean v9, v7, Lx1/l;->d:Z

    .line 412
    .line 413
    iget-object v14, v7, Lx1/l;->b:[J

    .line 414
    .line 415
    array-length v14, v14

    .line 416
    new-array v15, v14, [Lx1/k;

    .line 417
    .line 418
    move v4, v9

    .line 419
    move v5, v4

    .line 420
    const-wide/16 v16, 0x0

    .line 421
    .line 422
    :goto_d
    if-ge v4, v14, :cond_19

    .line 423
    .line 424
    iget-object v11, v7, Lx1/l;->b:[J

    .line 425
    .line 426
    aget-wide v18, v11, v4

    .line 427
    .line 428
    cmp-long v11, v18, v16

    .line 429
    .line 430
    if-lez v11, :cond_16

    .line 431
    .line 432
    const/4 v11, 0x1

    .line 433
    goto :goto_e

    .line 434
    :cond_16
    move v11, v9

    .line 435
    :goto_e
    iget-object v9, v7, Lx1/l;->c:[Z

    .line 436
    .line 437
    aget-boolean v8, v9, v4

    .line 438
    .line 439
    if-eq v11, v8, :cond_18

    .line 440
    .line 441
    aput-boolean v11, v9, v4

    .line 442
    .line 443
    if-eqz v11, :cond_17

    .line 444
    .line 445
    sget-object v5, Lx1/k;->n:Lx1/k;

    .line 446
    .line 447
    :goto_f
    const/4 v8, 0x1

    .line 448
    goto :goto_10

    .line 449
    :catchall_4
    move-exception v0

    .line 450
    goto :goto_18

    .line 451
    :cond_17
    sget-object v5, Lx1/k;->o:Lx1/k;

    .line 452
    .line 453
    goto :goto_f

    .line 454
    :cond_18
    sget-object v8, Lx1/k;->m:Lx1/k;

    .line 455
    .line 456
    move-object/from16 v27, v8

    .line 457
    .line 458
    move v8, v5

    .line 459
    move-object/from16 v5, v27

    .line 460
    .line 461
    :goto_10
    aput-object v5, v15, v4
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    .line 462
    .line 463
    add-int/lit8 v4, v4, 0x1

    .line 464
    .line 465
    move v5, v8

    .line 466
    const/4 v8, 0x2

    .line 467
    const/4 v9, 0x0

    .line 468
    const/4 v11, 0x1

    .line 469
    goto :goto_d

    .line 470
    :cond_19
    if-eqz v5, :cond_14

    .line 471
    .line 472
    :goto_11
    :try_start_7
    invoke-virtual {v13}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_7

    .line 473
    .line 474
    .line 475
    if-eqz v15, :cond_1c

    .line 476
    .line 477
    :try_start_8
    array-length v4, v15

    .line 478
    if-nez v4, :cond_1a

    .line 479
    .line 480
    goto :goto_14

    .line 481
    :cond_1a
    sget-object v4, Lx1/v;->n:Lx1/v;

    .line 482
    .line 483
    new-instance v5, Lx1/d0;

    .line 484
    .line 485
    invoke-direct {v5, v15, v6, v3, v12}, Lx1/d0;-><init>([Lx1/k;Lx1/e0;Lx1/w;Lz5/d;)V

    .line 486
    .line 487
    .line 488
    iput-object v7, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 489
    .line 490
    iput-object v10, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 491
    .line 492
    const/4 v6, 0x2

    .line 493
    iput v6, v1, Lc5/d;->r:I

    .line 494
    .line 495
    invoke-interface {v3, v4, v5, v1}, Lx1/w;->b(Lx1/v;Lj6/p;Lb6/f;)Ljava/lang/Object;

    .line 496
    .line 497
    .line 498
    move-result-object v3
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_5

    .line 499
    if-ne v3, v2, :cond_1b

    .line 500
    .line 501
    :goto_12
    move-object v12, v2

    .line 502
    goto :goto_17

    .line 503
    :cond_1b
    move-object v3, v7

    .line 504
    move-object v2, v10

    .line 505
    :goto_13
    move-object v10, v2

    .line 506
    move-object v7, v3

    .line 507
    :cond_1c
    :goto_14
    const/4 v4, 0x0

    .line 508
    goto :goto_16

    .line 509
    :catchall_5
    move-exception v0

    .line 510
    move-object v3, v7

    .line 511
    move-object v2, v10

    .line 512
    const/4 v4, 0x0

    .line 513
    :goto_15
    :try_start_9
    iput-boolean v4, v3, Lx1/l;->f:Z

    .line 514
    .line 515
    throw v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_6

    .line 516
    :catchall_6
    move-exception v0

    .line 517
    move-object v10, v2

    .line 518
    goto :goto_19

    .line 519
    :goto_16
    :try_start_a
    iput-boolean v4, v7, Lx1/l;->f:Z
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_7

    .line 520
    .line 521
    invoke-virtual {v10}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 522
    .line 523
    .line 524
    goto/16 :goto_c

    .line 525
    .line 526
    :goto_17
    return-object v12

    .line 527
    :catchall_7
    move-exception v0

    .line 528
    goto :goto_19

    .line 529
    :goto_18
    :try_start_b
    invoke-virtual {v13}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 530
    .line 531
    .line 532
    throw v0
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_7

    .line 533
    :goto_19
    invoke-virtual {v10}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 534
    .line 535
    .line 536
    throw v0

    .line 537
    :pswitch_4
    sget-object v0, Lv5/k;->a:Lv5/k;

    .line 538
    .line 539
    iget-object v4, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 540
    .line 541
    check-cast v4, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;

    .line 542
    .line 543
    sget-object v5, La6/a;->m:La6/a;

    .line 544
    .line 545
    iget v8, v1, Lc5/d;->r:I

    .line 546
    .line 547
    packed-switch v8, :pswitch_data_1

    .line 548
    .line 549
    .line 550
    invoke-static {v10}, Lq0/b;->m(Ljava/lang/String;)V

    .line 551
    .line 552
    .line 553
    goto/16 :goto_23

    .line 554
    .line 555
    :pswitch_5
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 556
    .line 557
    .line 558
    goto/16 :goto_21

    .line 559
    .line 560
    :pswitch_6
    iget-object v3, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 561
    .line 562
    check-cast v3, Lx1/w;

    .line 563
    .line 564
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 565
    .line 566
    .line 567
    goto/16 :goto_1f

    .line 568
    .line 569
    :pswitch_7
    iget-object v6, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 570
    .line 571
    check-cast v6, Lx1/w;

    .line 572
    .line 573
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 574
    .line 575
    .line 576
    move-object v7, v6

    .line 577
    move-object/from16 v6, p1

    .line 578
    .line 579
    goto/16 :goto_1e

    .line 580
    .line 581
    :pswitch_8
    iget-object v7, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 582
    .line 583
    check-cast v7, Lx1/w;

    .line 584
    .line 585
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 586
    .line 587
    .line 588
    goto :goto_1d

    .line 589
    :pswitch_9
    iget-object v8, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 590
    .line 591
    check-cast v8, Lx1/w;

    .line 592
    .line 593
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 594
    .line 595
    .line 596
    goto :goto_1c

    .line 597
    :pswitch_a
    iget-object v8, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 598
    .line 599
    check-cast v8, Lx1/w;

    .line 600
    .line 601
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 602
    .line 603
    .line 604
    move-object/from16 v9, p1

    .line 605
    .line 606
    goto :goto_1a

    .line 607
    :pswitch_b
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 608
    .line 609
    .line 610
    iget-object v8, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 611
    .line 612
    check-cast v8, Lx1/w;

    .line 613
    .line 614
    iput-object v8, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 615
    .line 616
    const/4 v9, 0x1

    .line 617
    iput v9, v1, Lc5/d;->r:I

    .line 618
    .line 619
    invoke-interface {v8, v1}, Lx1/w;->d(Lz5/d;)Ljava/lang/Boolean;

    .line 620
    .line 621
    .line 622
    move-result-object v9

    .line 623
    if-ne v9, v5, :cond_1d

    .line 624
    .line 625
    goto/16 :goto_20

    .line 626
    .line 627
    :cond_1d
    :goto_1a
    check-cast v9, Ljava/lang/Boolean;

    .line 628
    .line 629
    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    .line 630
    .line 631
    .line 632
    move-result v9

    .line 633
    if-nez v9, :cond_20

    .line 634
    .line 635
    iget-object v9, v4, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->f:Lx1/g;

    .line 636
    .line 637
    if-nez v9, :cond_1e

    .line 638
    .line 639
    move-object v9, v12

    .line 640
    :cond_1e
    iput-object v8, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 641
    .line 642
    const/4 v10, 0x2

    .line 643
    iput v10, v1, Lc5/d;->r:I

    .line 644
    .line 645
    iget-object v9, v9, Lx1/g;->c:Lx1/e0;

    .line 646
    .line 647
    invoke-virtual {v9, v1}, Lx1/e0;->e(Lb6/c;)Ljava/lang/Object;

    .line 648
    .line 649
    .line 650
    move-result-object v9

    .line 651
    if-ne v9, v5, :cond_1f

    .line 652
    .line 653
    goto :goto_1b

    .line 654
    :cond_1f
    move-object v9, v0

    .line 655
    :goto_1b
    if-ne v9, v5, :cond_20

    .line 656
    .line 657
    goto :goto_20

    .line 658
    :cond_20
    :goto_1c
    sget-object v9, Lx1/v;->n:Lx1/v;

    .line 659
    .line 660
    new-instance v10, Lc5/h;

    .line 661
    .line 662
    iget-object v11, v1, Lc5/d;->u:Ljava/lang/Object;

    .line 663
    .line 664
    check-cast v11, [Ljava/lang/String;

    .line 665
    .line 666
    invoke-direct {v10, v11, v12}, Lc5/h;-><init>([Ljava/lang/String;Lz5/d;)V

    .line 667
    .line 668
    .line 669
    iput-object v8, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 670
    .line 671
    iput v7, v1, Lc5/d;->r:I

    .line 672
    .line 673
    invoke-interface {v8, v9, v10, v1}, Lx1/w;->b(Lx1/v;Lj6/p;Lb6/f;)Ljava/lang/Object;

    .line 674
    .line 675
    .line 676
    move-result-object v7

    .line 677
    if-ne v7, v5, :cond_21

    .line 678
    .line 679
    goto :goto_20

    .line 680
    :cond_21
    move-object v7, v8

    .line 681
    :goto_1d
    iput-object v7, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 682
    .line 683
    iput v6, v1, Lc5/d;->r:I

    .line 684
    .line 685
    invoke-interface {v7, v1}, Lx1/w;->d(Lz5/d;)Ljava/lang/Boolean;

    .line 686
    .line 687
    .line 688
    move-result-object v6

    .line 689
    if-ne v6, v5, :cond_22

    .line 690
    .line 691
    goto :goto_20

    .line 692
    :cond_22
    :goto_1e
    check-cast v6, Ljava/lang/Boolean;

    .line 693
    .line 694
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    .line 695
    .line 696
    .line 697
    move-result v6

    .line 698
    if-nez v6, :cond_26

    .line 699
    .line 700
    iput-object v7, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 701
    .line 702
    iput v3, v1, Lc5/d;->r:I

    .line 703
    .line 704
    const-string v3, "PRAGMA wal_checkpoint(FULL)"

    .line 705
    .line 706
    invoke-static {v7, v3, v1}, Lo2/b;->m(Lx1/n;Ljava/lang/String;Lb6/c;)Ljava/lang/Object;

    .line 707
    .line 708
    .line 709
    move-result-object v3

    .line 710
    if-ne v3, v5, :cond_23

    .line 711
    .line 712
    goto :goto_20

    .line 713
    :cond_23
    move-object v3, v7

    .line 714
    :goto_1f
    iput-object v12, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 715
    .line 716
    iput v2, v1, Lc5/d;->r:I

    .line 717
    .line 718
    const-string v2, "VACUUM"

    .line 719
    .line 720
    invoke-static {v3, v2, v1}, Lo2/b;->m(Lx1/n;Ljava/lang/String;Lb6/c;)Ljava/lang/Object;

    .line 721
    .line 722
    .line 723
    move-result-object v2

    .line 724
    if-ne v2, v5, :cond_24

    .line 725
    .line 726
    :goto_20
    move-object v12, v5

    .line 727
    goto :goto_23

    .line 728
    :cond_24
    :goto_21
    iget-object v2, v4, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->f:Lx1/g;

    .line 729
    .line 730
    if-nez v2, :cond_25

    .line 731
    .line 732
    goto :goto_22

    .line 733
    :cond_25
    move-object v12, v2

    .line 734
    :goto_22
    invoke-virtual {v12}, Lx1/g;->a()V

    .line 735
    .line 736
    .line 737
    :cond_26
    move-object v12, v0

    .line 738
    :goto_23
    return-object v12

    .line 739
    :pswitch_c
    iget-object v0, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 740
    .line 741
    check-cast v0, Landroid/net/Uri;

    .line 742
    .line 743
    sget-object v4, Lv5/k;->a:Lv5/k;

    .line 744
    .line 745
    iget-object v5, v1, Lc5/d;->u:Ljava/lang/Object;

    .line 746
    .line 747
    check-cast v5, Lw4/e;

    .line 748
    .line 749
    iget-object v8, v5, Lw4/e;->u:Ljava/util/List;

    .line 750
    .line 751
    iget-object v9, v5, Lw4/e;->v:La4/m;

    .line 752
    .line 753
    sget-object v11, La6/a;->m:La6/a;

    .line 754
    .line 755
    iget v13, v1, Lc5/d;->r:I

    .line 756
    .line 757
    packed-switch v13, :pswitch_data_2

    .line 758
    .line 759
    .line 760
    invoke-static {v10}, Lq0/b;->m(Ljava/lang/String;)V

    .line 761
    .line 762
    .line 763
    goto/16 :goto_2f

    .line 764
    .line 765
    :pswitch_d
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 766
    .line 767
    .line 768
    move-object/from16 v0, p1

    .line 769
    .line 770
    goto :goto_24

    .line 771
    :pswitch_e
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 772
    .line 773
    .line 774
    move-object/from16 v0, p1

    .line 775
    .line 776
    goto/16 :goto_27

    .line 777
    .line 778
    :pswitch_f
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 779
    .line 780
    .line 781
    move-object/from16 v0, p1

    .line 782
    .line 783
    goto/16 :goto_2c

    .line 784
    .line 785
    :pswitch_10
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 786
    .line 787
    .line 788
    move-object/from16 v0, p1

    .line 789
    .line 790
    goto/16 :goto_2a

    .line 791
    .line 792
    :pswitch_11
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 793
    .line 794
    .line 795
    move-object/from16 v0, p1

    .line 796
    .line 797
    goto/16 :goto_28

    .line 798
    .line 799
    :pswitch_12
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 800
    .line 801
    .line 802
    move-object/from16 v0, p1

    .line 803
    .line 804
    goto :goto_26

    .line 805
    :pswitch_13
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 806
    .line 807
    .line 808
    iget-object v10, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 809
    .line 810
    check-cast v10, Ljava/lang/String;

    .line 811
    .line 812
    invoke-virtual {v10}, Ljava/lang/String;->hashCode()I

    .line 813
    .line 814
    .line 815
    move-result v13

    .line 816
    const/16 v14, 0x22

    .line 817
    .line 818
    sparse-switch v13, :sswitch_data_0

    .line 819
    .line 820
    .line 821
    goto/16 :goto_29

    .line 822
    .line 823
    :sswitch_0
    const-string v3, "patch"

    .line 824
    .line 825
    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 826
    .line 827
    .line 828
    move-result v3

    .line 829
    if-nez v3, :cond_27

    .line 830
    .line 831
    goto/16 :goto_29

    .line 832
    .line 833
    :cond_27
    if-nez v0, :cond_28

    .line 834
    .line 835
    goto :goto_25

    .line 836
    :cond_28
    iget-boolean v3, v5, Lw4/e;->r:Z

    .line 837
    .line 838
    if-eqz v3, :cond_29

    .line 839
    .line 840
    const/4 v3, 0x0

    .line 841
    iput-boolean v3, v5, Lw4/e;->r:Z

    .line 842
    .line 843
    invoke-static {v5, v14}, Lb/m;->c(Lp4/x0;I)V

    .line 844
    .line 845
    .line 846
    :cond_29
    new-instance v3, Ln4/f0;

    .line 847
    .line 848
    invoke-direct {v3, v0, v9, v8}, Ln4/f0;-><init>(Landroid/net/Uri;Ljava/util/List;Ljava/util/List;)V

    .line 849
    .line 850
    .line 851
    iput v2, v1, Lc5/d;->r:I

    .line 852
    .line 853
    invoke-static {v3, v1}, Ln4/l;->e(Ln4/l;Lb6/c;)Ljava/lang/Object;

    .line 854
    .line 855
    .line 856
    move-result-object v0

    .line 857
    if-ne v0, v11, :cond_2a

    .line 858
    .line 859
    goto/16 :goto_2b

    .line 860
    .line 861
    :cond_2a
    :goto_24
    check-cast v0, Ljava/lang/Boolean;

    .line 862
    .line 863
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 864
    .line 865
    .line 866
    move-result v0

    .line 867
    goto/16 :goto_2d

    .line 868
    .line 869
    :sswitch_1
    const-string v2, "flash"

    .line 870
    .line 871
    invoke-virtual {v10, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 872
    .line 873
    .line 874
    move-result v2

    .line 875
    if-eqz v2, :cond_33

    .line 876
    .line 877
    if-nez v0, :cond_2b

    .line 878
    .line 879
    :goto_25
    move-object v12, v4

    .line 880
    goto/16 :goto_2f

    .line 881
    .line 882
    :cond_2b
    new-instance v2, Lc7/e0;

    .line 883
    .line 884
    invoke-direct {v2, v0, v9, v8}, Lc7/e0;-><init>(Landroid/net/Uri;Ljava/util/List;Ljava/util/List;)V

    .line 885
    .line 886
    .line 887
    const/4 v9, 0x1

    .line 888
    iput v9, v1, Lc5/d;->r:I

    .line 889
    .line 890
    sget-object v0, Lt6/a0;->a:La7/d;

    .line 891
    .line 892
    sget-object v0, La7/c;->n:La7/c;

    .line 893
    .line 894
    new-instance v3, La5/r;

    .line 895
    .line 896
    invoke-direct {v3, v2, v12, v7}, La5/r;-><init>(Ljava/lang/Object;Lz5/d;I)V

    .line 897
    .line 898
    .line 899
    invoke-static {v0, v3, v1}, Lt6/t;->o(Lz5/h;Lj6/p;Lz5/d;)Ljava/lang/Object;

    .line 900
    .line 901
    .line 902
    move-result-object v0

    .line 903
    if-ne v0, v11, :cond_2c

    .line 904
    .line 905
    goto/16 :goto_2b

    .line 906
    .line 907
    :cond_2c
    :goto_26
    check-cast v0, Ljava/lang/Boolean;

    .line 908
    .line 909
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 910
    .line 911
    .line 912
    move-result v0

    .line 913
    goto/16 :goto_2d

    .line 914
    .line 915
    :sswitch_2
    const-string v0, "slot"

    .line 916
    .line 917
    invoke-virtual {v10, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 918
    .line 919
    .line 920
    move-result v0

    .line 921
    if-nez v0, :cond_2d

    .line 922
    .line 923
    goto :goto_29

    .line 924
    :cond_2d
    iget-boolean v0, v5, Lw4/e;->r:Z

    .line 925
    .line 926
    if-eqz v0, :cond_2e

    .line 927
    .line 928
    const/4 v2, 0x0

    .line 929
    iput-boolean v2, v5, Lw4/e;->r:Z

    .line 930
    .line 931
    invoke-static {v5, v14}, Lb/m;->c(Lp4/x0;I)V

    .line 932
    .line 933
    .line 934
    :cond_2e
    new-instance v0, Ln4/d0;

    .line 935
    .line 936
    const/4 v6, 0x2

    .line 937
    invoke-direct {v0, v9, v8, v6}, Ln4/d0;-><init>(Ljava/util/List;Ljava/util/List;I)V

    .line 938
    .line 939
    .line 940
    iput v3, v1, Lc5/d;->r:I

    .line 941
    .line 942
    invoke-static {v0, v1}, Ln4/l;->e(Ln4/l;Lb6/c;)Ljava/lang/Object;

    .line 943
    .line 944
    .line 945
    move-result-object v0

    .line 946
    if-ne v0, v11, :cond_2f

    .line 947
    .line 948
    goto/16 :goto_2b

    .line 949
    .line 950
    :cond_2f
    :goto_27
    check-cast v0, Ljava/lang/Boolean;

    .line 951
    .line 952
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 953
    .line 954
    .line 955
    move-result v0

    .line 956
    goto/16 :goto_2d

    .line 957
    .line 958
    :sswitch_3
    const-string v0, "uninstall"

    .line 959
    .line 960
    invoke-virtual {v10, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 961
    .line 962
    .line 963
    move-result v0

    .line 964
    if-nez v0, :cond_30

    .line 965
    .line 966
    goto :goto_29

    .line 967
    :cond_30
    iget-boolean v0, v5, Lw4/e;->r:Z

    .line 968
    .line 969
    if-eqz v0, :cond_31

    .line 970
    .line 971
    const/4 v2, 0x0

    .line 972
    iput-boolean v2, v5, Lw4/e;->r:Z

    .line 973
    .line 974
    invoke-static {v5, v14}, Lb/m;->c(Lp4/x0;I)V

    .line 975
    .line 976
    .line 977
    :cond_31
    new-instance v0, Ln4/d0;

    .line 978
    .line 979
    invoke-direct {v0, v9, v8, v7}, Ln4/d0;-><init>(Ljava/util/List;Ljava/util/List;I)V

    .line 980
    .line 981
    .line 982
    const/4 v6, 0x2

    .line 983
    iput v6, v1, Lc5/d;->r:I

    .line 984
    .line 985
    invoke-virtual {v0, v1}, Ln4/d0;->v(Lb6/c;)Ljava/lang/Object;

    .line 986
    .line 987
    .line 988
    move-result-object v0

    .line 989
    if-ne v0, v11, :cond_32

    .line 990
    .line 991
    goto :goto_2b

    .line 992
    :cond_32
    :goto_28
    check-cast v0, Ljava/lang/Boolean;

    .line 993
    .line 994
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 995
    .line 996
    .line 997
    move-result v0

    .line 998
    goto :goto_2d

    .line 999
    :sswitch_4
    const-string v0, "magisk"

    .line 1000
    .line 1001
    invoke-virtual {v10, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1002
    .line 1003
    .line 1004
    move-result v0

    .line 1005
    if-nez v0, :cond_34

    .line 1006
    .line 1007
    :cond_33
    :goto_29
    new-instance v0, Lr4/c;

    .line 1008
    .line 1009
    const/4 v2, 0x0

    .line 1010
    invoke-direct {v0, v2}, Lr4/c;-><init>(I)V

    .line 1011
    .line 1012
    .line 1013
    invoke-virtual {v5, v0}, Lz3/f;->m(Lz3/j;)V

    .line 1014
    .line 1015
    .line 1016
    goto/16 :goto_25

    .line 1017
    .line 1018
    :cond_34
    sget-boolean v0, La4/n;->q:Z

    .line 1019
    .line 1020
    if-eqz v0, :cond_36

    .line 1021
    .line 1022
    new-instance v0, Ln4/d0;

    .line 1023
    .line 1024
    const/4 v2, 0x1

    .line 1025
    invoke-direct {v0, v9, v8, v2}, Ln4/d0;-><init>(Ljava/util/List;Ljava/util/List;I)V

    .line 1026
    .line 1027
    .line 1028
    iput v7, v1, Lc5/d;->r:I

    .line 1029
    .line 1030
    invoke-static {v0, v1}, Ln4/l;->e(Ln4/l;Lb6/c;)Ljava/lang/Object;

    .line 1031
    .line 1032
    .line 1033
    move-result-object v0

    .line 1034
    if-ne v0, v11, :cond_35

    .line 1035
    .line 1036
    goto :goto_2b

    .line 1037
    :cond_35
    :goto_2a
    check-cast v0, Ljava/lang/Boolean;

    .line 1038
    .line 1039
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1040
    .line 1041
    .line 1042
    move-result v0

    .line 1043
    goto :goto_2d

    .line 1044
    :cond_36
    new-instance v0, Ln4/d0;

    .line 1045
    .line 1046
    const/4 v2, 0x0

    .line 1047
    invoke-direct {v0, v9, v8, v2}, Ln4/d0;-><init>(Ljava/util/List;Ljava/util/List;I)V

    .line 1048
    .line 1049
    .line 1050
    iput v6, v1, Lc5/d;->r:I

    .line 1051
    .line 1052
    invoke-static {v0, v1}, Ln4/l;->e(Ln4/l;Lb6/c;)Ljava/lang/Object;

    .line 1053
    .line 1054
    .line 1055
    move-result-object v0

    .line 1056
    if-ne v0, v11, :cond_37

    .line 1057
    .line 1058
    :goto_2b
    move-object v12, v11

    .line 1059
    goto :goto_2f

    .line 1060
    :cond_37
    :goto_2c
    check-cast v0, Ljava/lang/Boolean;

    .line 1061
    .line 1062
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1063
    .line 1064
    .line 1065
    move-result v0

    .line 1066
    :goto_2d
    iget-object v2, v5, Lw4/e;->p:Lk1/y;

    .line 1067
    .line 1068
    if-eqz v0, :cond_38

    .line 1069
    .line 1070
    sget-object v0, Lw4/d;->n:Lw4/d;

    .line 1071
    .line 1072
    goto :goto_2e

    .line 1073
    :cond_38
    sget-object v0, Lw4/d;->o:Lw4/d;

    .line 1074
    .line 1075
    :goto_2e
    invoke-virtual {v2, v0}, Lk1/y;->k(Ljava/lang/Object;)V

    .line 1076
    .line 1077
    .line 1078
    goto/16 :goto_25

    .line 1079
    .line 1080
    :goto_2f
    return-object v12

    .line 1081
    :pswitch_14
    sget-object v0, La6/a;->m:La6/a;

    .line 1082
    .line 1083
    iget v2, v1, Lc5/d;->r:I

    .line 1084
    .line 1085
    if-eqz v2, :cond_3a

    .line 1086
    .line 1087
    const/4 v9, 0x1

    .line 1088
    if-ne v2, v9, :cond_39

    .line 1089
    .line 1090
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 1091
    .line 1092
    .line 1093
    goto :goto_32

    .line 1094
    :cond_39
    invoke-static {v10}, Lq0/b;->m(Ljava/lang/String;)V

    .line 1095
    .line 1096
    .line 1097
    goto :goto_33

    .line 1098
    :cond_3a
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 1099
    .line 1100
    .line 1101
    sget-object v2, Le4/b;->e:Ld4/f;

    .line 1102
    .line 1103
    iget-object v3, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 1104
    .line 1105
    check-cast v3, Laa/e;

    .line 1106
    .line 1107
    iget-object v3, v3, Laa/e;->n:Ljava/lang/Object;

    .line 1108
    .line 1109
    check-cast v3, Ljava/lang/String;

    .line 1110
    .line 1111
    iget-object v4, v1, Lc5/d;->u:Ljava/lang/Object;

    .line 1112
    .line 1113
    check-cast v4, Ljava/lang/String;

    .line 1114
    .line 1115
    const/4 v9, 0x1

    .line 1116
    iput v9, v1, Lc5/d;->r:I

    .line 1117
    .line 1118
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1119
    .line 1120
    .line 1121
    new-instance v2, Lv5/e;

    .line 1122
    .line 1123
    const-string v5, "key"

    .line 1124
    .line 1125
    invoke-direct {v2, v5, v3}, Lv5/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1126
    .line 1127
    .line 1128
    new-instance v3, Lv5/e;

    .line 1129
    .line 1130
    const-string v5, "value"

    .line 1131
    .line 1132
    invoke-direct {v3, v5, v4}, Lv5/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1133
    .line 1134
    .line 1135
    const/4 v6, 0x2

    .line 1136
    new-array v4, v6, [Lv5/e;

    .line 1137
    .line 1138
    const/16 v18, 0x0

    .line 1139
    .line 1140
    aput-object v2, v4, v18

    .line 1141
    .line 1142
    aput-object v3, v4, v9

    .line 1143
    .line 1144
    new-instance v2, Ljava/util/LinkedHashMap;

    .line 1145
    .line 1146
    invoke-static {v6}, Lw5/u;->B(I)I

    .line 1147
    .line 1148
    .line 1149
    move-result v3

    .line 1150
    invoke-direct {v2, v3}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 1151
    .line 1152
    .line 1153
    const/4 v9, 0x0

    .line 1154
    :goto_30
    if-ge v9, v6, :cond_3b

    .line 1155
    .line 1156
    aget-object v3, v4, v9

    .line 1157
    .line 1158
    iget-object v5, v3, Lv5/e;->m:Ljava/lang/Object;

    .line 1159
    .line 1160
    iget-object v3, v3, Lv5/e;->n:Ljava/lang/Object;

    .line 1161
    .line 1162
    invoke-interface {v2, v5, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1163
    .line 1164
    .line 1165
    add-int/lit8 v9, v9, 0x1

    .line 1166
    .line 1167
    const/4 v6, 0x2

    .line 1168
    goto :goto_30

    .line 1169
    :cond_3b
    invoke-static {v2}, Lx1/r;->f0(Ljava/util/Map;)Ljava/lang/String;

    .line 1170
    .line 1171
    .line 1172
    move-result-object v2

    .line 1173
    const-string v3, "REPLACE INTO strings "

    .line 1174
    .line 1175
    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 1176
    .line 1177
    .line 1178
    move-result-object v2

    .line 1179
    invoke-static {v2, v1}, Lx1/r;->p(Ljava/lang/String;Lb6/f;)Ljava/lang/Object;

    .line 1180
    .line 1181
    .line 1182
    move-result-object v2

    .line 1183
    sget-object v3, La6/a;->m:La6/a;

    .line 1184
    .line 1185
    if-ne v2, v3, :cond_3c

    .line 1186
    .line 1187
    goto :goto_31

    .line 1188
    :cond_3c
    sget-object v2, Lv5/k;->a:Lv5/k;

    .line 1189
    .line 1190
    :goto_31
    if-ne v2, v0, :cond_3d

    .line 1191
    .line 1192
    move-object v12, v0

    .line 1193
    goto :goto_33

    .line 1194
    :cond_3d
    :goto_32
    sget-object v12, Lv5/k;->a:Lv5/k;

    .line 1195
    .line 1196
    :goto_33
    return-object v12

    .line 1197
    :pswitch_15
    const-wide/16 v16, 0x0

    .line 1198
    .line 1199
    iget-object v0, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 1200
    .line 1201
    check-cast v0, Lt6/s;

    .line 1202
    .line 1203
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 1204
    .line 1205
    .line 1206
    iget v2, v1, Lc5/d;->r:I

    .line 1207
    .line 1208
    new-array v2, v2, [B

    .line 1209
    .line 1210
    iget-object v3, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 1211
    .line 1212
    check-cast v3, Ljava/io/InputStream;

    .line 1213
    .line 1214
    invoke-virtual {v3, v2}, Ljava/io/InputStream;->read([B)I

    .line 1215
    .line 1216
    .line 1217
    move-result v4

    .line 1218
    move-wide/from16 v5, v16

    .line 1219
    .line 1220
    :goto_34
    invoke-interface {v0}, Lt6/s;->l()Lz5/h;

    .line 1221
    .line 1222
    .line 1223
    move-result-object v7

    .line 1224
    sget-object v8, Lt6/q;->n:Lt6/q;

    .line 1225
    .line 1226
    invoke-interface {v7, v8}, Lz5/h;->A(Lz5/g;)Lz5/f;

    .line 1227
    .line 1228
    .line 1229
    move-result-object v7

    .line 1230
    check-cast v7, Lt6/v0;

    .line 1231
    .line 1232
    if-eqz v7, :cond_3e

    .line 1233
    .line 1234
    invoke-virtual {v7}, Lt6/v0;->F()Z

    .line 1235
    .line 1236
    .line 1237
    move-result v7

    .line 1238
    goto :goto_35

    .line 1239
    :cond_3e
    const/4 v7, 0x1

    .line 1240
    :goto_35
    if-eqz v7, :cond_3f

    .line 1241
    .line 1242
    if-ltz v4, :cond_3f

    .line 1243
    .line 1244
    iget-object v7, v1, Lc5/d;->u:Ljava/lang/Object;

    .line 1245
    .line 1246
    check-cast v7, Ljava/io/OutputStream;

    .line 1247
    .line 1248
    const/4 v8, 0x0

    .line 1249
    invoke-virtual {v7, v2, v8, v4}, Ljava/io/OutputStream;->write([BII)V

    .line 1250
    .line 1251
    .line 1252
    int-to-long v7, v4

    .line 1253
    add-long/2addr v5, v7

    .line 1254
    invoke-virtual {v3, v2}, Ljava/io/InputStream;->read([B)I

    .line 1255
    .line 1256
    .line 1257
    move-result v4

    .line 1258
    goto :goto_34

    .line 1259
    :cond_3f
    new-instance v0, Ljava/lang/Long;

    .line 1260
    .line 1261
    invoke-direct {v0, v5, v6}, Ljava/lang/Long;-><init>(J)V

    .line 1262
    .line 1263
    .line 1264
    return-object v0

    .line 1265
    :pswitch_16
    iget-object v0, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 1266
    .line 1267
    move-object v2, v0

    .line 1268
    check-cast v2, Lf4/d;

    .line 1269
    .line 1270
    iget-object v3, v2, Lf4/d;->m:Lf4/i;

    .line 1271
    .line 1272
    iget-object v0, v1, Lc5/d;->u:Ljava/lang/Object;

    .line 1273
    .line 1274
    move-object v4, v0

    .line 1275
    check-cast v4, Lf4/k;

    .line 1276
    .line 1277
    sget-object v0, La6/a;->m:La6/a;

    .line 1278
    .line 1279
    iget v5, v1, Lc5/d;->r:I

    .line 1280
    .line 1281
    const/4 v7, -0x1

    .line 1282
    if-eqz v5, :cond_42

    .line 1283
    .line 1284
    const/4 v9, 0x1

    .line 1285
    if-eq v5, v9, :cond_41

    .line 1286
    .line 1287
    const/4 v8, 0x2

    .line 1288
    if-ne v5, v8, :cond_40

    .line 1289
    .line 1290
    iget-object v0, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 1291
    .line 1292
    check-cast v0, Lf4/d;

    .line 1293
    .line 1294
    check-cast v0, Ljava/io/InputStream;

    .line 1295
    .line 1296
    :try_start_c
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_0

    .line 1297
    .line 1298
    .line 1299
    goto/16 :goto_38

    .line 1300
    .line 1301
    :catch_0
    move-exception v0

    .line 1302
    goto/16 :goto_3a

    .line 1303
    .line 1304
    :cond_40
    invoke-static {v10}, Lq0/b;->m(Ljava/lang/String;)V

    .line 1305
    .line 1306
    .line 1307
    goto/16 :goto_3c

    .line 1308
    .line 1309
    :cond_41
    iget-object v5, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 1310
    .line 1311
    check-cast v5, Lf4/d;

    .line 1312
    .line 1313
    :try_start_d
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_0

    .line 1314
    .line 1315
    .line 1316
    move-object v8, v5

    .line 1317
    move-object/from16 v5, p1

    .line 1318
    .line 1319
    goto :goto_36

    .line 1320
    :cond_42
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 1321
    .line 1322
    .line 1323
    :try_start_e
    sget-object v5, Lf4/d;->r:Lk1/y;

    .line 1324
    .line 1325
    invoke-static {}, Le4/b;->b()Lk4/r;

    .line 1326
    .line 1327
    .line 1328
    move-result-object v5

    .line 1329
    invoke-virtual {v4}, Lf4/k;->g()Ljava/lang/String;

    .line 1330
    .line 1331
    .line 1332
    move-result-object v8

    .line 1333
    iput-object v2, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 1334
    .line 1335
    const/4 v9, 0x1

    .line 1336
    iput v9, v1, Lc5/d;->r:I

    .line 1337
    .line 1338
    invoke-virtual {v5, v8, v1}, Lk4/r;->d(Ljava/lang/String;Lb6/c;)Ljava/lang/Object;

    .line 1339
    .line 1340
    .line 1341
    move-result-object v5

    .line 1342
    if-ne v5, v0, :cond_43

    .line 1343
    .line 1344
    goto :goto_37

    .line 1345
    :cond_43
    move-object v8, v2

    .line 1346
    :goto_36
    check-cast v5, Lc7/m0;

    .line 1347
    .line 1348
    sget-object v9, Lf4/d;->r:Lk1/y;

    .line 1349
    .line 1350
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1351
    .line 1352
    .line 1353
    invoke-virtual {v5}, Lc7/m0;->f()J

    .line 1354
    .line 1355
    .line 1356
    move-result-wide v9

    .line 1357
    long-to-float v11, v9

    .line 1358
    const/high16 v13, 0x100000

    .line 1359
    .line 1360
    int-to-float v13, v13

    .line 1361
    div-float v25, v11, v13

    .line 1362
    .line 1363
    invoke-virtual {v4}, Lf4/k;->e()I

    .line 1364
    .line 1365
    .line 1366
    move-result v11

    .line 1367
    new-instance v13, La5/b;

    .line 1368
    .line 1369
    invoke-direct {v13, v6, v4}, La5/b;-><init>(ILjava/lang/Object;)V

    .line 1370
    .line 1371
    .line 1372
    invoke-virtual {v8, v11, v13}, Lf4/d;->h(ILj6/l;)V

    .line 1373
    .line 1374
    .line 1375
    new-instance v6, Lo4/p;

    .line 1376
    .line 1377
    invoke-virtual {v5}, Lc7/m0;->u()Lt7/h;

    .line 1378
    .line 1379
    .line 1380
    move-result-object v5

    .line 1381
    invoke-interface {v5}, Lt7/h;->O()Ljava/io/InputStream;

    .line 1382
    .line 1383
    .line 1384
    move-result-object v5

    .line 1385
    new-instance v20, Lf4/a;
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_0

    .line 1386
    .line 1387
    move-object/from16 v26, v4

    .line 1388
    .line 1389
    move-object/from16 v21, v8

    .line 1390
    .line 1391
    move-wide/from16 v23, v9

    .line 1392
    .line 1393
    move/from16 v22, v11

    .line 1394
    .line 1395
    :try_start_f
    invoke-direct/range {v20 .. v26}, Lf4/a;-><init>(Lf4/d;IJFLf4/k;)V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_f} :catch_1

    .line 1396
    .line 1397
    .line 1398
    move-object/from16 v8, v20

    .line 1399
    .line 1400
    move-object/from16 v4, v26

    .line 1401
    .line 1402
    :try_start_10
    invoke-direct {v6, v5, v8}, Lo4/p;-><init>(Ljava/io/InputStream;Lf4/a;)V

    .line 1403
    .line 1404
    .line 1405
    iget-object v5, v2, Lf4/d;->q:Laa/b;

    .line 1406
    .line 1407
    iput-object v12, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 1408
    .line 1409
    const/4 v8, 0x2

    .line 1410
    iput v8, v1, Lc5/d;->r:I

    .line 1411
    .line 1412
    invoke-virtual {v5, v6, v4, v1}, Laa/b;->s(Lo4/p;Lf4/k;Lb6/c;)Ljava/lang/Object;

    .line 1413
    .line 1414
    .line 1415
    move-result-object v5

    .line 1416
    if-ne v5, v0, :cond_44

    .line 1417
    .line 1418
    :goto_37
    move-object v12, v0

    .line 1419
    goto/16 :goto_3c

    .line 1420
    .line 1421
    :cond_44
    :goto_38
    sget-object v0, La4/d;->m:La4/d;

    .line 1422
    .line 1423
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1424
    .line 1425
    .line 1426
    sget-object v0, La4/d;->n:Ljava/lang/ref/WeakReference;

    .line 1427
    .line 1428
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 1429
    .line 1430
    .line 1431
    move-result-object v0

    .line 1432
    check-cast v0, Landroid/app/Activity;

    .line 1433
    .line 1434
    if-eqz v0, :cond_45

    .line 1435
    .line 1436
    invoke-virtual {v4}, Lf4/k;->a()Z

    .line 1437
    .line 1438
    .line 1439
    move-result v5

    .line 1440
    if-eqz v5, :cond_45

    .line 1441
    .line 1442
    invoke-virtual {v4}, Lf4/k;->e()I

    .line 1443
    .line 1444
    .line 1445
    move-result v5

    .line 1446
    sget-object v6, Lf4/d;->r:Lk1/y;

    .line 1447
    .line 1448
    invoke-virtual {v2, v5}, Lf4/d;->e(I)Landroid/app/Notification$Builder;

    .line 1449
    .line 1450
    .line 1451
    invoke-virtual {v4, v0}, Lf4/k;->h(Landroid/content/Context;)Landroid/app/PendingIntent;

    .line 1452
    .line 1453
    .line 1454
    move-result-object v0

    .line 1455
    if-eqz v0, :cond_49

    .line 1456
    .line 1457
    invoke-virtual {v0}, Landroid/app/PendingIntent;->send()V

    .line 1458
    .line 1459
    .line 1460
    goto/16 :goto_3b

    .line 1461
    .line 1462
    :cond_45
    sget-object v0, Lf4/d;->r:Lk1/y;

    .line 1463
    .line 1464
    invoke-virtual {v4}, Lf4/k;->e()I

    .line 1465
    .line 1466
    .line 1467
    move-result v0

    .line 1468
    invoke-virtual {v2, v0}, Lf4/d;->e(I)Landroid/app/Notification$Builder;

    .line 1469
    .line 1470
    .line 1471
    move-result-object v0

    .line 1472
    if-eqz v0, :cond_47

    .line 1473
    .line 1474
    sget-object v5, Lf4/d;->r:Lk1/y;

    .line 1475
    .line 1476
    const/high16 v5, 0x3f800000    # 1.0f

    .line 1477
    .line 1478
    invoke-static {v5, v4}, Lf4/c;->a(FLf4/k;)V

    .line 1479
    .line 1480
    .line 1481
    invoke-virtual {v4}, Lf4/k;->f()Ljava/lang/String;

    .line 1482
    .line 1483
    .line 1484
    move-result-object v5

    .line 1485
    invoke-virtual {v0, v5}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 1486
    .line 1487
    .line 1488
    move-result-object v5

    .line 1489
    invoke-interface {v3}, Lf4/i;->a()Landroid/content/Context;

    .line 1490
    .line 1491
    .line 1492
    move-result-object v6

    .line 1493
    const v8, 0x7f11003d

    .line 1494
    .line 1495
    .line 1496
    invoke-virtual {v6, v8}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1497
    .line 1498
    .line 1499
    move-result-object v6

    .line 1500
    invoke-virtual {v5, v6}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 1501
    .line 1502
    .line 1503
    move-result-object v5

    .line 1504
    const v6, 0x1080082

    .line 1505
    .line 1506
    .line 1507
    invoke-virtual {v5, v6}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    .line 1508
    .line 1509
    .line 1510
    move-result-object v5

    .line 1511
    const/4 v8, 0x0

    .line 1512
    invoke-virtual {v5, v8, v8, v8}, Landroid/app/Notification$Builder;->setProgress(IIZ)Landroid/app/Notification$Builder;

    .line 1513
    .line 1514
    .line 1515
    move-result-object v5

    .line 1516
    invoke-virtual {v5, v8}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    .line 1517
    .line 1518
    .line 1519
    move-result-object v5

    .line 1520
    const/4 v9, 0x1

    .line 1521
    invoke-virtual {v5, v9}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    .line 1522
    .line 1523
    .line 1524
    invoke-interface {v3}, Lf4/i;->a()Landroid/content/Context;

    .line 1525
    .line 1526
    .line 1527
    move-result-object v5

    .line 1528
    invoke-virtual {v4, v5}, Lf4/k;->h(Landroid/content/Context;)Landroid/app/PendingIntent;

    .line 1529
    .line 1530
    .line 1531
    move-result-object v5

    .line 1532
    if-eqz v5, :cond_46

    .line 1533
    .line 1534
    invoke-virtual {v0, v5}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    .line 1535
    .line 1536
    .line 1537
    :cond_46
    sget-object v5, Lg5/h;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 1538
    .line 1539
    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 1540
    .line 1541
    .line 1542
    move-result v5

    .line 1543
    invoke-static {}, Lg5/h;->a()Landroid/app/NotificationManager;

    .line 1544
    .line 1545
    .line 1546
    move-result-object v6

    .line 1547
    invoke-virtual {v0}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    .line 1548
    .line 1549
    .line 1550
    move-result-object v0

    .line 1551
    invoke-virtual {v6, v5, v0}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 1552
    .line 1553
    .line 1554
    goto :goto_39

    .line 1555
    :cond_47
    move v5, v7

    .line 1556
    :goto_39
    new-instance v0, Ljava/lang/Integer;

    .line 1557
    .line 1558
    invoke-direct {v0, v5}, Ljava/lang/Integer;-><init>(I)V
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_10 .. :try_end_10} :catch_0

    .line 1559
    .line 1560
    .line 1561
    goto :goto_3b

    .line 1562
    :catch_1
    move-exception v0

    .line 1563
    move-object/from16 v4, v26

    .line 1564
    .line 1565
    :goto_3a
    sget-object v5, Lqa/d;->a:Lqa/b;

    .line 1566
    .line 1567
    invoke-virtual {v5, v0}, Lqa/b;->c(Ljava/lang/Throwable;)V

    .line 1568
    .line 1569
    .line 1570
    sget-object v0, Lf4/d;->r:Lk1/y;

    .line 1571
    .line 1572
    invoke-virtual {v4}, Lf4/k;->e()I

    .line 1573
    .line 1574
    .line 1575
    move-result v0

    .line 1576
    invoke-virtual {v2, v0}, Lf4/d;->e(I)Landroid/app/Notification$Builder;

    .line 1577
    .line 1578
    .line 1579
    move-result-object v0

    .line 1580
    if-eqz v0, :cond_48

    .line 1581
    .line 1582
    const/high16 v2, -0x40000000    # -2.0f

    .line 1583
    .line 1584
    invoke-static {v2, v4}, Lf4/c;->a(FLf4/k;)V

    .line 1585
    .line 1586
    .line 1587
    invoke-interface {v3}, Lf4/i;->a()Landroid/content/Context;

    .line 1588
    .line 1589
    .line 1590
    move-result-object v2

    .line 1591
    const v3, 0x7f11003e

    .line 1592
    .line 1593
    .line 1594
    invoke-virtual {v2, v3}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 1595
    .line 1596
    .line 1597
    move-result-object v2

    .line 1598
    invoke-virtual {v0, v2}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 1599
    .line 1600
    .line 1601
    move-result-object v2

    .line 1602
    const v3, 0x1080078

    .line 1603
    .line 1604
    .line 1605
    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    .line 1606
    .line 1607
    .line 1608
    move-result-object v2

    .line 1609
    const/4 v8, 0x0

    .line 1610
    invoke-virtual {v2, v8}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    .line 1611
    .line 1612
    .line 1613
    sget-object v2, Lg5/h;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 1614
    .line 1615
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    .line 1616
    .line 1617
    .line 1618
    move-result v7

    .line 1619
    invoke-static {}, Lg5/h;->a()Landroid/app/NotificationManager;

    .line 1620
    .line 1621
    .line 1622
    move-result-object v2

    .line 1623
    invoke-virtual {v0}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    .line 1624
    .line 1625
    .line 1626
    move-result-object v0

    .line 1627
    invoke-virtual {v2, v7, v0}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 1628
    .line 1629
    .line 1630
    :cond_48
    new-instance v0, Ljava/lang/Integer;

    .line 1631
    .line 1632
    invoke-direct {v0, v7}, Ljava/lang/Integer;-><init>(I)V

    .line 1633
    .line 1634
    .line 1635
    :cond_49
    :goto_3b
    sget-object v12, Lv5/k;->a:Lv5/k;

    .line 1636
    .line 1637
    :goto_3c
    return-object v12

    .line 1638
    :pswitch_17
    iget-object v0, v1, Lc5/d;->u:Ljava/lang/Object;

    .line 1639
    .line 1640
    check-cast v0, Lc5/a;

    .line 1641
    .line 1642
    iget-object v2, v1, Lc5/d;->t:Ljava/lang/Object;

    .line 1643
    .line 1644
    check-cast v2, Lc5/i;

    .line 1645
    .line 1646
    iget-object v3, v2, Lc5/i;->s:Lb1/k;

    .line 1647
    .line 1648
    iget-object v4, v2, Lc5/i;->t:Lp4/l;

    .line 1649
    .line 1650
    sget-object v5, La6/a;->m:La6/a;

    .line 1651
    .line 1652
    iget v6, v1, Lc5/d;->r:I

    .line 1653
    .line 1654
    if-eqz v6, :cond_4c

    .line 1655
    .line 1656
    const/4 v9, 0x1

    .line 1657
    if-eq v6, v9, :cond_4b

    .line 1658
    .line 1659
    const/4 v8, 0x2

    .line 1660
    if-ne v6, v8, :cond_4a

    .line 1661
    .line 1662
    iget-object v0, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 1663
    .line 1664
    check-cast v0, Ljava/util/ArrayList;

    .line 1665
    .line 1666
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 1667
    .line 1668
    .line 1669
    goto :goto_3f

    .line 1670
    :cond_4a
    invoke-static {v10}, Lq0/b;->m(Ljava/lang/String;)V

    .line 1671
    .line 1672
    .line 1673
    goto :goto_40

    .line 1674
    :cond_4b
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 1675
    .line 1676
    .line 1677
    goto :goto_3d

    .line 1678
    :cond_4c
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 1679
    .line 1680
    .line 1681
    iget-object v6, v2, Lc5/i;->q:Ld4/f;

    .line 1682
    .line 1683
    iget-object v8, v0, Lc5/a;->o:Lj4/b;

    .line 1684
    .line 1685
    iget v8, v8, Lj4/b;->a:I

    .line 1686
    .line 1687
    const/4 v9, 0x1

    .line 1688
    iput v9, v1, Lc5/d;->r:I

    .line 1689
    .line 1690
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1691
    .line 1692
    .line 1693
    invoke-static {v8, v1}, Ld4/f;->l0(ILb6/f;)Ljava/lang/Object;

    .line 1694
    .line 1695
    .line 1696
    move-result-object v6

    .line 1697
    if-ne v6, v5, :cond_4d

    .line 1698
    .line 1699
    goto :goto_3e

    .line 1700
    :cond_4d
    :goto_3d
    new-instance v6, Ljava/util/ArrayList;

    .line 1701
    .line 1702
    invoke-direct {v6, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 1703
    .line 1704
    .line 1705
    new-instance v8, La5/b;

    .line 1706
    .line 1707
    invoke-direct {v8, v7, v0}, La5/b;-><init>(ILjava/lang/Object;)V

    .line 1708
    .line 1709
    .line 1710
    invoke-static {v6, v8}, Lw5/j;->f0(Ljava/util/List;Lj6/l;)V

    .line 1711
    .line 1712
    .line 1713
    iput-object v6, v1, Lc5/d;->s:Ljava/lang/Object;

    .line 1714
    .line 1715
    const/4 v8, 0x2

    .line 1716
    iput v8, v1, Lc5/d;->r:I

    .line 1717
    .line 1718
    invoke-virtual {v4, v6, v1}, Lp4/l;->j(Ljava/util/ArrayList;Lb6/f;)Ljava/lang/Object;

    .line 1719
    .line 1720
    .line 1721
    move-result-object v0

    .line 1722
    if-ne v0, v5, :cond_4e

    .line 1723
    .line 1724
    :goto_3e
    move-object v12, v5

    .line 1725
    goto :goto_40

    .line 1726
    :cond_4e
    move-object v0, v6

    .line 1727
    :goto_3f
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 1728
    .line 1729
    .line 1730
    move-result v0

    .line 1731
    if-eqz v0, :cond_4f

    .line 1732
    .line 1733
    invoke-virtual {v3}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 1734
    .line 1735
    .line 1736
    move-result v0

    .line 1737
    if-eqz v0, :cond_4f

    .line 1738
    .line 1739
    iget-object v0, v2, Lc5/i;->r:Lg5/j;

    .line 1740
    .line 1741
    invoke-virtual {v3, v0}, Lb1/k;->add(Ljava/lang/Object;)Z

    .line 1742
    .line 1743
    .line 1744
    :cond_4f
    sget-object v12, Lv5/k;->a:Lv5/k;

    .line 1745
    .line 1746
    :goto_40
    return-object v12

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_c
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
    .end packed-switch

    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
    .end packed-switch

    :sswitch_data_0
    .sparse-switch
        -0x407871b2 -> :sswitch_4
        -0x2549d71e -> :sswitch_3
        0x35e9fe -> :sswitch_2
        0x5cfeff0 -> :sswitch_1
        0x6582048 -> :sswitch_0
    .end sparse-switch
.end method
