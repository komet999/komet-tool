.class public final Lc5/i;
.super Lz3/b;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# instance fields
.field public final q:Ld4/f;

.field public final r:Lg5/j;

.field public final s:Lb1/k;

.field public final t:Lp4/l;

.field public final u:Lp4/w0;

.field public final v:Landroid/util/SparseArray;

.field public w:Z


# direct methods
.method public constructor <init>(Ld4/f;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Lz3/b;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lc5/i;->q:Ld4/f;

    .line 5
    .line 6
    new-instance p1, Lg5/j;

    .line 7
    .line 8
    const v0, 0x7f110175

    .line 9
    .line 10
    .line 11
    invoke-direct {p1, v0}, Lg5/j;-><init>(I)V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, Lc5/i;->r:Lg5/j;

    .line 15
    .line 16
    new-instance p1, Lb1/k;

    .line 17
    .line 18
    invoke-direct {p1}, Lb1/k;-><init>()V

    .line 19
    .line 20
    .line 21
    iput-object p1, p0, Lc5/i;->s:Lb1/k;

    .line 22
    .line 23
    new-instance v0, Lp4/l;

    .line 24
    .line 25
    invoke-direct {v0}, Lp4/l;-><init>()V

    .line 26
    .line 27
    .line 28
    iput-object v0, p0, Lc5/i;->t:Lp4/l;

    .line 29
    .line 30
    new-instance v1, Lp4/w0;

    .line 31
    .line 32
    invoke-direct {v1}, Lp4/w0;-><init>()V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v1, p1}, Lp4/w0;->f(Ljava/util/AbstractList;)V

    .line 36
    .line 37
    .line 38
    invoke-virtual {v1, v0}, Lp4/w0;->f(Ljava/util/AbstractList;)V

    .line 39
    .line 40
    .line 41
    iput-object v1, p0, Lc5/i;->u:Lp4/w0;

    .line 42
    .line 43
    new-instance p1, Landroid/util/SparseArray;

    .line 44
    .line 45
    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    .line 46
    .line 47
    .line 48
    const/16 v0, 0x15

    .line 49
    .line 50
    invoke-virtual {p1, v0, p0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    iput-object p1, p0, Lc5/i;->v:Landroid/util/SparseArray;

    .line 54
    .line 55
    const/4 p1, 0x1

    .line 56
    iput-boolean p1, p0, Lc5/i;->w:Z

    .line 57
    .line 58
    return-void
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method


# virtual methods
.method public final p(Lb6/c;)Ljava/lang/Object;
    .locals 7

    .line 1
    instance-of v0, p1, Lc5/e;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Lc5/e;

    .line 7
    .line 8
    iget v1, v0, Lc5/e;->r:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lc5/e;->r:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lc5/e;

    .line 21
    .line 22
    invoke-direct {v0, p0, p1}, Lc5/e;-><init>(Lc5/i;Lb6/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p1, v0, Lc5/e;->p:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lc5/e;->r:I

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    const/16 v3, 0x16

    .line 31
    .line 32
    sget-object v4, Lv5/k;->a:Lv5/k;

    .line 33
    .line 34
    const/4 v5, 0x0

    .line 35
    const/4 v6, 0x1

    .line 36
    if-eqz v1, :cond_2

    .line 37
    .line 38
    if-ne v1, v6, :cond_1

    .line 39
    .line 40
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_1
    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-static {p1}, Lq0/b;->m(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return-object v2

    .line 50
    :cond_2
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    sget-object p1, La4/n;->a:La4/n;

    .line 54
    .line 55
    invoke-static {}, La4/n;->b()Z

    .line 56
    .line 57
    .line 58
    move-result p1

    .line 59
    iget-boolean v1, p0, Lc5/i;->w:Z

    .line 60
    .line 61
    if-nez p1, :cond_3

    .line 62
    .line 63
    if-eqz v1, :cond_8

    .line 64
    .line 65
    iput-boolean v5, p0, Lc5/i;->w:Z

    .line 66
    .line 67
    invoke-static {p0, v3}, Lb/m;->c(Lp4/x0;I)V

    .line 68
    .line 69
    .line 70
    return-object v4

    .line 71
    :cond_3
    if-eq v1, v6, :cond_4

    .line 72
    .line 73
    iput-boolean v6, p0, Lc5/i;->w:Z

    .line 74
    .line 75
    invoke-static {p0, v3}, Lb/m;->c(Lp4/x0;I)V

    .line 76
    .line 77
    .line 78
    :cond_4
    sget-object p1, Lt6/a0;->a:La7/d;

    .line 79
    .line 80
    sget-object p1, La7/c;->n:La7/c;

    .line 81
    .line 82
    new-instance v1, Lc5/f;

    .line 83
    .line 84
    invoke-direct {v1, p0, v2}, Lc5/f;-><init>(Lc5/i;Lz5/d;)V

    .line 85
    .line 86
    .line 87
    iput v6, v0, Lc5/e;->r:I

    .line 88
    .line 89
    invoke-static {p1, v1, v0}, Lt6/t;->o(Lz5/h;Lj6/p;Lz5/d;)Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    sget-object v0, La6/a;->m:La6/a;

    .line 94
    .line 95
    if-ne p1, v0, :cond_5

    .line 96
    .line 97
    return-object v0

    .line 98
    :cond_5
    :goto_1
    iget-object p1, p0, Lc5/i;->t:Lp4/l;

    .line 99
    .line 100
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 101
    .line 102
    .line 103
    move-result p1

    .line 104
    iget-object v0, p0, Lc5/i;->s:Lb1/k;

    .line 105
    .line 106
    if-nez p1, :cond_6

    .line 107
    .line 108
    invoke-virtual {v0}, Lb1/k;->clear()V

    .line 109
    .line 110
    .line 111
    goto :goto_2

    .line 112
    :cond_6
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 113
    .line 114
    .line 115
    move-result p1

    .line 116
    if-eqz p1, :cond_7

    .line 117
    .line 118
    iget-object p1, p0, Lc5/i;->r:Lg5/j;

    .line 119
    .line 120
    invoke-virtual {v0, p1}, Lb1/k;->add(Ljava/lang/Object;)Z

    .line 121
    .line 122
    .line 123
    :cond_7
    :goto_2
    iget-boolean p1, p0, Lc5/i;->w:Z

    .line 124
    .line 125
    if-eqz p1, :cond_8

    .line 126
    .line 127
    iput-boolean v5, p0, Lc5/i;->w:Z

    .line 128
    .line 129
    invoke-static {p0, v3}, Lb/m;->c(Lp4/x0;I)V

    .line 130
    .line 131
    .line 132
    :cond_8
    return-object v4
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method

.method public final r(Lc5/a;I)V
    .locals 7

    .line 1
    new-instance v4, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lc5/i;->t:Lp4/l;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/util/AbstractList;->iterator()Ljava/util/Iterator;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_1

    .line 17
    .line 18
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    move-object v2, v1

    .line 23
    check-cast v2, Lc5/a;

    .line 24
    .line 25
    iget-object v2, v2, Lc5/a;->o:Lj4/b;

    .line 26
    .line 27
    iget v2, v2, Lj4/b;->a:I

    .line 28
    .line 29
    iget-object v3, p1, Lc5/a;->o:Lj4/b;

    .line 30
    .line 31
    iget v3, v3, Lj4/b;->a:I

    .line 32
    .line 33
    if-ne v2, v3, :cond_0

    .line 34
    .line 35
    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_1
    sget-object v0, La4/g;->a:La4/g;

    .line 40
    .line 41
    invoke-virtual {v0}, La4/g;->d()Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_2

    .line 46
    .line 47
    new-instance v0, Lr4/b;

    .line 48
    .line 49
    new-instance v1, Lc5/c;

    .line 50
    .line 51
    invoke-direct {v1, p0, p2, p1, v4}, Lc5/c;-><init>(Lc5/i;ILc5/a;Ljava/util/ArrayList;)V

    .line 52
    .line 53
    .line 54
    const/4 p1, 0x0

    .line 55
    invoke-direct {v0, p1, v1}, Lr4/b;-><init>(ILjava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p0, v0}, Lz3/f;->m(Lz3/j;)V

    .line 59
    .line 60
    .line 61
    return-void

    .line 62
    :cond_2
    invoke-static {p0}, Lk1/g0;->f(Lk1/m0;)Ln1/a;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    new-instance v0, Lc5/h;

    .line 67
    .line 68
    const/4 v5, 0x0

    .line 69
    move-object v3, p0

    .line 70
    move-object v2, p1

    .line 71
    move v1, p2

    .line 72
    invoke-direct/range {v0 .. v5}, Lc5/h;-><init>(ILc5/a;Lc5/i;Ljava/util/ArrayList;Lz5/d;)V

    .line 73
    .line 74
    .line 75
    const/4 p1, 0x3

    .line 76
    const/4 p2, 0x0

    .line 77
    invoke-static {v6, p2, v0, p1}, Lt6/t;->g(Lt6/s;Lz5/h;Lj6/p;I)Lt6/z0;

    .line 78
    .line 79
    .line 80
    return-void
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method
