.class public final Lb2/c;
.super Lb6/f;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Lj6/p;


# instance fields
.field public final synthetic q:I

.field public synthetic r:Ljava/lang/Object;

.field public final synthetic s:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lj6/p;Lz5/d;)V
    .locals 1

    .line 1
    const/4 v0, 0x4

    .line 2
    iput v0, p0, Lb2/c;->q:I

    .line 3
    .line 4
    check-cast p1, Lb6/f;

    .line 5
    .line 6
    iput-object p1, p0, Lb2/c;->s:Ljava/lang/Object;

    .line 7
    .line 8
    const/4 p1, 0x2

    .line 9
    invoke-direct {p0, p1, p2}, Lb6/f;-><init>(ILz5/d;)V

    .line 10
    .line 11
    .line 12
    return-void
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/CharSequence;Lz5/d;I)V
    .locals 0

    .line 13
    iput p4, p0, Lb2/c;->q:I

    iput-object p1, p0, Lb2/c;->r:Ljava/lang/Object;

    iput-object p2, p0, Lb2/c;->s:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lb6/f;-><init>(ILz5/d;)V

    return-void
.end method

.method public constructor <init>(Lk1/m;Lz5/d;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, Lb2/c;->q:I

    .line 14
    iput-object p1, p0, Lb2/c;->s:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lb6/f;-><init>(ILz5/d;)V

    return-void
.end method

.method public constructor <init>(Lz5/d;Lj6/l;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, Lb2/c;->q:I

    .line 15
    iput-object p2, p0, Lb2/c;->s:Ljava/lang/Object;

    const/4 p2, 0x2

    invoke-direct {p0, p2, p1}, Lb6/f;-><init>(ILz5/d;)V

    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Lb2/c;->q:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lt6/s;

    .line 7
    .line 8
    check-cast p2, Lz5/d;

    .line 9
    .line 10
    invoke-virtual {p0, p1, p2}, Lb2/c;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Lb2/c;

    .line 15
    .line 16
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 17
    .line 18
    invoke-virtual {p1, p2}, Lb2/c;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    return-object p1

    .line 23
    :pswitch_0
    check-cast p1, Lt6/s;

    .line 24
    .line 25
    check-cast p2, Lz5/d;

    .line 26
    .line 27
    invoke-virtual {p0, p1, p2}, Lb2/c;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    check-cast p1, Lb2/c;

    .line 32
    .line 33
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 34
    .line 35
    invoke-virtual {p1, p2}, Lb2/c;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    return-object p2

    .line 39
    :pswitch_1
    check-cast p1, Lt6/s;

    .line 40
    .line 41
    check-cast p2, Lz5/d;

    .line 42
    .line 43
    invoke-virtual {p0, p1, p2}, Lb2/c;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    check-cast p1, Lb2/c;

    .line 48
    .line 49
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 50
    .line 51
    invoke-virtual {p1, p2}, Lb2/c;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    return-object p2

    .line 55
    :pswitch_2
    check-cast p1, Lt6/s;

    .line 56
    .line 57
    check-cast p2, Lz5/d;

    .line 58
    .line 59
    invoke-virtual {p0, p1, p2}, Lb2/c;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    check-cast p1, Lb2/c;

    .line 64
    .line 65
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 66
    .line 67
    invoke-virtual {p1, p2}, Lb2/c;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    return-object p2

    .line 71
    :pswitch_3
    check-cast p1, Lz1/j;

    .line 72
    .line 73
    check-cast p2, Lz5/d;

    .line 74
    .line 75
    invoke-virtual {p0, p1, p2}, Lb2/c;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    check-cast p1, Lb2/c;

    .line 80
    .line 81
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 82
    .line 83
    invoke-virtual {p1, p2}, Lb2/c;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    return-object p1

    .line 88
    nop

    .line 89
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method

.method public final l(Ljava/lang/Object;Lz5/d;)Lz5/d;
    .locals 3

    .line 1
    iget v0, p0, Lb2/c;->q:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v0, Lb2/c;

    .line 7
    .line 8
    iget-object v1, p0, Lb2/c;->s:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Lb6/f;

    .line 11
    .line 12
    invoke-direct {v0, v1, p2}, Lb2/c;-><init>(Lj6/p;Lz5/d;)V

    .line 13
    .line 14
    .line 15
    iput-object p1, v0, Lb2/c;->r:Ljava/lang/Object;

    .line 16
    .line 17
    return-object v0

    .line 18
    :pswitch_0
    new-instance p1, Lb2/c;

    .line 19
    .line 20
    iget-object v0, p0, Lb2/c;->r:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, Ly4/c;

    .line 23
    .line 24
    iget-object v1, p0, Lb2/c;->s:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast v1, Landroid/text/SpannableStringBuilder;

    .line 27
    .line 28
    const/4 v2, 0x3

    .line 29
    invoke-direct {p1, v0, v1, p2, v2}, Lb2/c;-><init>(Ljava/lang/Object;Ljava/lang/CharSequence;Lz5/d;I)V

    .line 30
    .line 31
    .line 32
    return-object p1

    .line 33
    :pswitch_1
    new-instance v0, Lb2/c;

    .line 34
    .line 35
    iget-object v1, p0, Lb2/c;->s:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v1, Lk1/m;

    .line 38
    .line 39
    invoke-direct {v0, v1, p2}, Lb2/c;-><init>(Lk1/m;Lz5/d;)V

    .line 40
    .line 41
    .line 42
    iput-object p1, v0, Lb2/c;->r:Ljava/lang/Object;

    .line 43
    .line 44
    return-object v0

    .line 45
    :pswitch_2
    new-instance p1, Lb2/c;

    .line 46
    .line 47
    iget-object v0, p0, Lb2/c;->r:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v0, Lcom/topjohnwu/magisk/ui/surequest/SuRequestActivity;

    .line 50
    .line 51
    iget-object v1, p0, Lb2/c;->s:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v1, Ljava/lang/String;

    .line 54
    .line 55
    const/4 v2, 0x1

    .line 56
    invoke-direct {p1, v0, v1, p2, v2}, Lb2/c;-><init>(Ljava/lang/Object;Ljava/lang/CharSequence;Lz5/d;I)V

    .line 57
    .line 58
    .line 59
    return-object p1

    .line 60
    :pswitch_3
    new-instance v0, Lb2/c;

    .line 61
    .line 62
    iget-object v1, p0, Lb2/c;->s:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast v1, Lj6/l;

    .line 65
    .line 66
    invoke-direct {v0, p2, v1}, Lb2/c;-><init>(Lz5/d;Lj6/l;)V

    .line 67
    .line 68
    .line 69
    iput-object p1, v0, Lb2/c;->r:Ljava/lang/Object;

    .line 70
    .line 71
    return-object v0

    .line 72
    nop

    .line 73
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, Lb2/c;->q:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 7
    .line 8
    .line 9
    iget-object p1, p0, Lb2/c;->r:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast p1, Lt6/s;

    .line 12
    .line 13
    invoke-interface {p1}, Lt6/s;->l()Lz5/h;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    sget-object v0, Lz5/e;->m:Lz5/e;

    .line 18
    .line 19
    invoke-interface {p1, v0}, Lz5/h;->A(Lz5/g;)Lz5/f;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    check-cast p1, Lt6/p;

    .line 24
    .line 25
    new-instance v1, Lt6/l;

    .line 26
    .line 27
    const/4 v2, 0x1

    .line 28
    invoke-direct {v1, v2}, Lt6/v0;-><init>(Z)V

    .line 29
    .line 30
    .line 31
    const/4 v3, 0x0

    .line 32
    invoke-virtual {v1, v3}, Lt6/v0;->D(Lt6/v0;)V

    .line 33
    .line 34
    .line 35
    new-instance v4, Lc5/d;

    .line 36
    .line 37
    iget-object v5, p0, Lb2/c;->s:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast v5, Lb6/f;

    .line 40
    .line 41
    invoke-direct {v4, v1, v5, v3}, Lc5/d;-><init>(Lt6/l;Lj6/p;Lz5/d;)V

    .line 42
    .line 43
    .line 44
    sget-object v5, Lz5/i;->m:Lz5/i;

    .line 45
    .line 46
    invoke-static {v5, p1, v2}, Lt6/t;->a(Lz5/h;Lz5/h;Z)Lz5/h;

    .line 47
    .line 48
    .line 49
    move-result-object v5

    .line 50
    sget-object v6, Lt6/a0;->a:La7/d;

    .line 51
    .line 52
    if-eq v5, v6, :cond_0

    .line 53
    .line 54
    invoke-interface {v5, v0}, Lz5/h;->A(Lz5/g;)Lz5/f;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    if-nez v0, :cond_0

    .line 59
    .line 60
    invoke-interface {v5, v6}, Lz5/h;->z(Lz5/h;)Lz5/h;

    .line 61
    .line 62
    .line 63
    move-result-object v5

    .line 64
    :cond_0
    new-instance v0, Lt6/z0;

    .line 65
    .line 66
    invoke-direct {v0, v5, v2}, Lt6/a;-><init>(Lz5/h;Z)V

    .line 67
    .line 68
    .line 69
    const/4 v2, 0x4

    .line 70
    invoke-virtual {v0, v2, v0, v4}, Lt6/a;->X(ILt6/a;Lj6/p;)V

    .line 71
    .line 72
    .line 73
    :catch_0
    sget-object v0, Lt6/v0;->m:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 74
    .line 75
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v2

    .line 79
    instance-of v2, v2, Lt6/l0;

    .line 80
    .line 81
    if-eqz v2, :cond_1

    .line 82
    .line 83
    :try_start_0
    new-instance v0, La5/r;

    .line 84
    .line 85
    const/16 v2, 0x8

    .line 86
    .line 87
    invoke-direct {v0, v1, v3, v2}, La5/r;-><init>(Ljava/lang/Object;Lz5/d;I)V

    .line 88
    .line 89
    .line 90
    invoke-static {p1, v0}, Lt6/t;->j(Lz5/h;Lj6/p;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 94
    goto :goto_0

    .line 95
    :cond_1
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    instance-of v0, p1, Lt6/l0;

    .line 100
    .line 101
    if-nez v0, :cond_3

    .line 102
    .line 103
    instance-of v0, p1, Lt6/n;

    .line 104
    .line 105
    if-nez v0, :cond_2

    .line 106
    .line 107
    invoke-static {p1}, Lt6/t;->m(Ljava/lang/Object;)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    goto :goto_0

    .line 112
    :cond_2
    check-cast p1, Lt6/n;

    .line 113
    .line 114
    iget-object p1, p1, Lt6/n;->a:Ljava/lang/Throwable;

    .line 115
    .line 116
    throw p1

    .line 117
    :cond_3
    const-string p1, "This job has not completed yet"

    .line 118
    .line 119
    invoke-static {p1}, Lq0/b;->m(Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    const/4 p1, 0x0

    .line 123
    :goto_0
    return-object p1

    .line 124
    :pswitch_0
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 125
    .line 126
    .line 127
    iget-object p1, p0, Lb2/c;->r:Ljava/lang/Object;

    .line 128
    .line 129
    check-cast p1, Ly4/c;

    .line 130
    .line 131
    iget-object v0, p0, Lb2/c;->s:Ljava/lang/Object;

    .line 132
    .line 133
    check-cast v0, Landroid/text/SpannableStringBuilder;

    .line 134
    .line 135
    iget-object v1, p1, Ly4/c;->t:Ljava/lang/Object;

    .line 136
    .line 137
    invoke-static {v1, v0}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 138
    .line 139
    .line 140
    move-result v1

    .line 141
    if-nez v1, :cond_4

    .line 142
    .line 143
    iput-object v0, p1, Ly4/c;->t:Ljava/lang/Object;

    .line 144
    .line 145
    const/16 v0, 0x1a

    .line 146
    .line 147
    invoke-static {p1, v0}, Lb/m;->c(Lp4/x0;I)V

    .line 148
    .line 149
    .line 150
    :cond_4
    sget-object p1, Lv5/k;->a:Lv5/k;

    .line 151
    .line 152
    return-object p1

    .line 153
    :pswitch_1
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 154
    .line 155
    .line 156
    iget-object p1, p0, Lb2/c;->r:Ljava/lang/Object;

    .line 157
    .line 158
    check-cast p1, Lt6/s;

    .line 159
    .line 160
    iget-object v0, p0, Lb2/c;->s:Ljava/lang/Object;

    .line 161
    .line 162
    check-cast v0, Lk1/m;

    .line 163
    .line 164
    iget-object v1, v0, Lk1/m;->m:Lk1/r;

    .line 165
    .line 166
    iget-object v2, v1, Lk1/r;->d:Lk1/l;

    .line 167
    .line 168
    sget-object v3, Lk1/l;->n:Lk1/l;

    .line 169
    .line 170
    invoke-virtual {v2, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 171
    .line 172
    .line 173
    move-result v2

    .line 174
    if-ltz v2, :cond_5

    .line 175
    .line 176
    invoke-virtual {v1, v0}, Lk1/r;->a(Lk1/o;)V

    .line 177
    .line 178
    .line 179
    goto :goto_1

    .line 180
    :cond_5
    invoke-interface {p1}, Lt6/s;->l()Lz5/h;

    .line 181
    .line 182
    .line 183
    move-result-object p1

    .line 184
    sget-object v0, Lt6/q;->n:Lt6/q;

    .line 185
    .line 186
    invoke-interface {p1, v0}, Lz5/h;->A(Lz5/g;)Lz5/f;

    .line 187
    .line 188
    .line 189
    move-result-object p1

    .line 190
    check-cast p1, Lt6/v0;

    .line 191
    .line 192
    if-eqz p1, :cond_6

    .line 193
    .line 194
    const/4 v0, 0x0

    .line 195
    invoke-virtual {p1, v0}, Lt6/v0;->c(Ljava/util/concurrent/CancellationException;)V

    .line 196
    .line 197
    .line 198
    :cond_6
    :goto_1
    sget-object p1, Lv5/k;->a:Lv5/k;

    .line 199
    .line 200
    return-object p1

    .line 201
    :pswitch_2
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 202
    .line 203
    .line 204
    iget-object p1, p0, Lb2/c;->r:Ljava/lang/Object;

    .line 205
    .line 206
    check-cast p1, Lcom/topjohnwu/magisk/ui/surequest/SuRequestActivity;

    .line 207
    .line 208
    iget-object v0, p0, Lb2/c;->s:Ljava/lang/Object;

    .line 209
    .line 210
    check-cast v0, Ljava/lang/String;

    .line 211
    .line 212
    invoke-virtual {p1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 213
    .line 214
    .line 215
    move-result-object v1

    .line 216
    invoke-virtual {v1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 217
    .line 218
    .line 219
    move-result-object v1

    .line 220
    invoke-static {p1, v0, v1}, Lo7/g;->Q(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;)V

    .line 221
    .line 222
    .line 223
    sget-object p1, Lv5/k;->a:Lv5/k;

    .line 224
    .line 225
    return-object p1

    .line 226
    :pswitch_3
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    iget-object p1, p0, Lb2/c;->r:Ljava/lang/Object;

    .line 230
    .line 231
    check-cast p1, Lz1/j;

    .line 232
    .line 233
    check-cast p1, Lz1/b0;

    .line 234
    .line 235
    invoke-interface {p1}, Lz1/b0;->c()Le2/a;

    .line 236
    .line 237
    .line 238
    move-result-object p1

    .line 239
    iget-object v0, p0, Lb2/c;->s:Ljava/lang/Object;

    .line 240
    .line 241
    check-cast v0, Lj6/l;

    .line 242
    .line 243
    invoke-interface {v0, p1}, Lj6/l;->j(Ljava/lang/Object;)Ljava/lang/Object;

    .line 244
    .line 245
    .line 246
    move-result-object p1

    .line 247
    return-object p1

    .line 248
    nop

    .line 249
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method
