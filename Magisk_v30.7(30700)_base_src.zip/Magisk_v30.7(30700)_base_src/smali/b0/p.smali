.class public abstract Lb0/p;
.super Ljava/lang/Object;
