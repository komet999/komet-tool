.class public interface abstract Lb1/j;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# virtual methods
.method public abstract d(Lb1/i;)V
.end method

.method public abstract e(Lb1/i;)V
.end method
