.class public abstract Lb1/l;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# virtual methods
.method public abstract d(Lb1/m;)V
.end method

.method public abstract e(Lb1/m;II)V
.end method

.method public abstract f(Lb1/m;II)V
.end method

.method public abstract g(Lb1/m;III)V
.end method

.method public abstract h(Lb1/m;II)V
.end method
