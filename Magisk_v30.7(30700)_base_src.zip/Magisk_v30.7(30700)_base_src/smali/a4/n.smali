.class public final La4/n;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# static fields
.field public static final a:La4/n;

.field public static b:Lm1/c;

.field public static final c:Lcom/topjohnwu/magisk/core/model/UpdateInfo;

.field public static d:Lcom/topjohnwu/magisk/core/model/UpdateInfo;

.field public static e:Z

.field public static f:Z

.field public static g:Z

.field public static h:La4/k;

.field public static i:Z

.field public static j:Z

.field public static k:Z

.field public static l:Ljava/lang/String;

.field public static m:Z

.field public static final n:Z

.field public static o:Z

.field public static p:Ljava/lang/String;

.field public static final q:Z

.field public static final r:Lk1/y;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    .line 1
    new-instance v0, La4/n;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La4/n;->a:La4/n;

    .line 7
    .line 8
    new-instance v1, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 9
    .line 10
    const/4 v5, 0x0

    .line 11
    const/16 v6, 0xf

    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    const/4 v3, 0x0

    .line 15
    const/4 v4, 0x0

    .line 16
    invoke-direct/range {v1 .. v6}, Lcom/topjohnwu/magisk/core/model/UpdateInfo;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;I)V

    .line 17
    .line 18
    .line 19
    sput-object v1, La4/n;->c:Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 20
    .line 21
    sput-object v1, La4/n;->d:Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 22
    .line 23
    new-instance v0, La4/k;

    .line 24
    .line 25
    const/4 v1, -0x1

    .line 26
    const-string v2, ""

    .line 27
    .line 28
    invoke-direct {v0, v1, v2, v3}, La4/k;-><init>(ILjava/lang/String;Z)V

    .line 29
    .line 30
    .line 31
    sput-object v0, La4/n;->h:La4/k;

    .line 32
    .line 33
    sput-object v2, La4/n;->l:Ljava/lang/String;

    .line 34
    .line 35
    const-string v0, "ZYGISK_ENABLED"

    .line 36
    .line 37
    invoke-static {v0}, Ljava/lang/System;->getenv(Ljava/lang/String;)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    const-string v1, "1"

    .line 42
    .line 43
    invoke-static {v0, v1}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    sput-boolean v0, La4/n;->n:Z

    .line 48
    .line 49
    sput-object v2, La4/n;->p:Ljava/lang/String;

    .line 50
    .line 51
    sget-object v0, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 52
    .line 53
    const-string v2, "vsoc"

    .line 54
    .line 55
    invoke-static {v0, v2, v3}, Lr6/i;->O(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z

    .line 56
    .line 57
    .line 58
    move-result v0

    .line 59
    if-nez v0, :cond_0

    .line 60
    .line 61
    const-string v0, "ro.kernel.qemu"

    .line 62
    .line 63
    invoke-static {v0}, Lf5/d;->l(Ljava/lang/String;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-static {v0, v1}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    if-nez v0, :cond_0

    .line 72
    .line 73
    const-string v0, "ro.boot.qemu"

    .line 74
    .line 75
    invoke-static {v0}, Lf5/d;->l(Ljava/lang/String;)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    invoke-static {v0, v1}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    if-eqz v0, :cond_1

    .line 84
    .line 85
    :cond_0
    const/4 v3, 0x1

    .line 86
    :cond_1
    sput-boolean v3, La4/n;->q:Z

    .line 87
    .line 88
    new-instance v0, Lk1/y;

    .line 89
    .line 90
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 91
    .line 92
    invoke-direct {v0, v1}, Lk1/y;-><init>(Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    sput-object v0, La4/n;->r:Lk1/y;

    .line 96
    .line 97
    return-void
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
.end method

.method public static b()Z
    .locals 4

    .line 1
    sget-object v0, La4/n;->h:La4/k;

    .line 2
    .line 3
    iget-boolean v0, v0, La4/k;->e:Z

    .line 4
    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    sget v0, La4/h;->b:I

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    sget-object v0, La4/g;->a:La4/g;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    sget-object v1, La4/g;->A:Li0/d;

    .line 17
    .line 18
    sget-object v2, La4/g;->b:[Lp6/b;

    .line 19
    .line 20
    const/16 v3, 0x14

    .line 21
    .line 22
    aget-object v2, v2, v3

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2}, Li0/d;->c(La4/g;Lp6/b;)Ljava/lang/Integer;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    const/4 v1, 0x2

    .line 33
    if-ne v0, v1, :cond_1

    .line 34
    .line 35
    :cond_0
    const/4 v0, 0x1

    .line 36
    return v0

    .line 37
    :cond_1
    const/4 v0, 0x0

    .line 38
    return v0
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method


# virtual methods
.method public final a(Lk4/r;Lb6/c;)Ljava/lang/Object;
    .locals 4

    .line 1
    instance-of v0, p2, La4/l;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, La4/l;

    .line 7
    .line 8
    iget v1, v0, La4/l;->r:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, La4/l;->r:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, La4/l;

    .line 21
    .line 22
    invoke-direct {v0, p0, p2}, La4/l;-><init>(La4/n;Lb6/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p2, v0, La4/l;->p:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, La4/l;->r:I

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    if-ne v1, v2, :cond_1

    .line 33
    .line 34
    invoke-static {p2}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 35
    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 39
    .line 40
    invoke-static {p1}, Lq0/b;->m(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    const/4 p1, 0x0

    .line 44
    return-object p1

    .line 45
    :cond_2
    invoke-static {p2}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    sget-object p2, La4/n;->d:Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 49
    .line 50
    sget-object v1, La4/n;->c:Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 51
    .line 52
    if-ne p2, v1, :cond_5

    .line 53
    .line 54
    iput v2, v0, La4/l;->r:I

    .line 55
    .line 56
    invoke-virtual {p1, v0}, Lk4/r;->i(Lb6/c;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object p2

    .line 60
    sget-object p1, La6/a;->m:La6/a;

    .line 61
    .line 62
    if-ne p2, p1, :cond_3

    .line 63
    .line 64
    return-object p1

    .line 65
    :cond_3
    :goto_1
    check-cast p2, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 66
    .line 67
    if-eqz p2, :cond_4

    .line 68
    .line 69
    sput-object p2, La4/n;->d:Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 70
    .line 71
    return-object p2

    .line 72
    :cond_4
    const/4 p1, 0x0

    .line 73
    return-object p1

    .line 74
    :cond_5
    return-object p2
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method
