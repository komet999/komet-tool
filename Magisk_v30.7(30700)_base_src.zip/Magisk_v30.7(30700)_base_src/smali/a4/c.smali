.class public final La4/c;
.super Lb6/f;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Lj6/p;


# instance fields
.field public final synthetic q:I


# direct methods
.method public synthetic constructor <init>(ILz5/d;I)V
    .locals 0

    .line 1
    iput p3, p0, La4/c;->q:I

    .line 2
    .line 3
    invoke-direct {p0, p1, p2}, Lb6/f;-><init>(ILz5/d;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
.end method


# virtual methods
.method public final i(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, La4/c;->q:I

    .line 2
    .line 3
    check-cast p1, Lt6/s;

    .line 4
    .line 5
    check-cast p2, Lz5/d;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, p1, p2}, La4/c;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, La4/c;

    .line 15
    .line 16
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 17
    .line 18
    invoke-virtual {p1, p2}, La4/c;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    return-object p1

    .line 23
    :pswitch_0
    invoke-virtual {p0, p1, p2}, La4/c;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 24
    .line 25
    .line 26
    move-result-object p1

    .line 27
    check-cast p1, La4/c;

    .line 28
    .line 29
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 30
    .line 31
    invoke-virtual {p1, p2}, La4/c;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    return-object p1

    .line 36
    :pswitch_1
    invoke-virtual {p0, p1, p2}, La4/c;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    check-cast p1, La4/c;

    .line 41
    .line 42
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 43
    .line 44
    invoke-virtual {p1, p2}, La4/c;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    return-object p1

    .line 49
    :pswitch_2
    invoke-virtual {p0, p1, p2}, La4/c;->l(Ljava/lang/Object;Lz5/d;)Lz5/d;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    check-cast p1, La4/c;

    .line 54
    .line 55
    sget-object p2, Lv5/k;->a:Lv5/k;

    .line 56
    .line 57
    invoke-virtual {p1, p2}, La4/c;->o(Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    return-object p2

    .line 61
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method

.method public final l(Ljava/lang/Object;Lz5/d;)Lz5/d;
    .locals 2

    .line 1
    iget p1, p0, La4/c;->q:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance p1, La4/c;

    .line 7
    .line 8
    const/4 v0, 0x2

    .line 9
    const/4 v1, 0x3

    .line 10
    invoke-direct {p1, v0, p2, v1}, La4/c;-><init>(ILz5/d;I)V

    .line 11
    .line 12
    .line 13
    return-object p1

    .line 14
    :pswitch_0
    new-instance p1, La4/c;

    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    const/4 v1, 0x2

    .line 18
    invoke-direct {p1, v0, p2, v1}, La4/c;-><init>(ILz5/d;I)V

    .line 19
    .line 20
    .line 21
    return-object p1

    .line 22
    :pswitch_1
    new-instance p1, La4/c;

    .line 23
    .line 24
    const/4 v0, 0x2

    .line 25
    const/4 v1, 0x1

    .line 26
    invoke-direct {p1, v0, p2, v1}, La4/c;-><init>(ILz5/d;I)V

    .line 27
    .line 28
    .line 29
    return-object p1

    .line 30
    :pswitch_2
    new-instance p1, La4/c;

    .line 31
    .line 32
    const/4 v0, 0x2

    .line 33
    const/4 v1, 0x0

    .line 34
    invoke-direct {p1, v0, p2, v1}, La4/c;-><init>(ILz5/d;I)V

    .line 35
    .line 36
    .line 37
    return-object p1

    .line 38
    nop

    .line 39
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method

.method public final o(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 17

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, La4/c;->q:I

    .line 4
    .line 5
    const/4 v2, 0x6

    .line 6
    const-string v3, "/data/adb/modules"

    .line 7
    .line 8
    const/4 v4, 0x0

    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    sget-object v0, Lo4/v;->d:Lo4/s;

    .line 16
    .line 17
    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 18
    .line 19
    :try_start_0
    sget-object v0, Lo4/v;->d:Lo4/s;

    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    sget-object v0, Lo4/t;->m:Lo4/t;

    .line 25
    .line 26
    invoke-virtual {v0}, Lo4/t;->a()V

    .line 27
    .line 28
    .line 29
    invoke-static {}, Lo4/v;->t()Lo4/d;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    if-eqz v0, :cond_0

    .line 34
    .line 35
    invoke-interface {v0}, Lo4/d;->q()Z

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    goto :goto_0

    .line 40
    :catchall_0
    move-exception v0

    .line 41
    goto :goto_1

    .line 42
    :cond_0
    :goto_0
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 43
    .line 44
    .line 45
    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    goto :goto_2

    .line 47
    :goto_1
    sget-object v3, Lqa/d;->a:Lqa/b;

    .line 48
    .line 49
    invoke-virtual {v3, v0}, Lqa/b;->c(Ljava/lang/Throwable;)V

    .line 50
    .line 51
    .line 52
    :goto_2
    return-object v2

    .line 53
    :pswitch_0
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    sget-object v0, Lo4/v;->d:Lo4/s;

    .line 57
    .line 58
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    invoke-static {}, Lo4/s;->a()Ll5/b;

    .line 62
    .line 63
    .line 64
    move-result-object v0

    .line 65
    invoke-virtual {v0, v3}, Ll5/b;->a(Ljava/lang/String;)Ll5/a;

    .line 66
    .line 67
    .line 68
    move-result-object v0

    .line 69
    check-cast v0, Lj5/d;

    .line 70
    .line 71
    invoke-virtual {v0}, Ljava/io/File;->list()[Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v3

    .line 75
    if-nez v3, :cond_1

    .line 76
    .line 77
    const/4 v5, 0x0

    .line 78
    goto :goto_4

    .line 79
    :cond_1
    array-length v5, v3

    .line 80
    invoke-virtual {v0, v5}, Lj5/d;->e(I)[Ll5/a;

    .line 81
    .line 82
    .line 83
    move-result-object v6

    .line 84
    move v7, v4

    .line 85
    :goto_3
    if-ge v7, v5, :cond_2

    .line 86
    .line 87
    aget-object v8, v3, v7

    .line 88
    .line 89
    invoke-virtual {v0, v8}, Ll5/a;->a(Ljava/lang/String;)Ll5/a;

    .line 90
    .line 91
    .line 92
    move-result-object v8

    .line 93
    aput-object v8, v6, v7

    .line 94
    .line 95
    add-int/lit8 v7, v7, 0x1

    .line 96
    .line 97
    goto :goto_3

    .line 98
    :cond_2
    move-object v5, v6

    .line 99
    :goto_4
    if-nez v5, :cond_3

    .line 100
    .line 101
    new-array v5, v4, [Ll5/a;

    .line 102
    .line 103
    :cond_3
    new-instance v0, Ljava/util/ArrayList;

    .line 104
    .line 105
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 106
    .line 107
    .line 108
    array-length v3, v5

    .line 109
    move v6, v4

    .line 110
    :goto_5
    if-ge v6, v3, :cond_5

    .line 111
    .line 112
    aget-object v7, v5, v6

    .line 113
    .line 114
    invoke-virtual {v7}, Ljava/io/File;->isFile()Z

    .line 115
    .line 116
    .line 117
    move-result v8

    .line 118
    if-nez v8, :cond_4

    .line 119
    .line 120
    invoke-virtual {v7}, Ljava/io/File;->isHidden()Z

    .line 121
    .line 122
    .line 123
    move-result v8

    .line 124
    if-nez v8, :cond_4

    .line 125
    .line 126
    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    :cond_4
    add-int/lit8 v6, v6, 0x1

    .line 130
    .line 131
    goto :goto_5

    .line 132
    :cond_5
    new-instance v3, Ljava/util/ArrayList;

    .line 133
    .line 134
    const/16 v5, 0xa

    .line 135
    .line 136
    invoke-static {v0, v5}, Lw5/m;->P(Ljava/lang/Iterable;I)I

    .line 137
    .line 138
    .line 139
    move-result v5

    .line 140
    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 141
    .line 142
    .line 143
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 144
    .line 145
    .line 146
    move-result v5

    .line 147
    :goto_6
    if-ge v4, v5, :cond_6

    .line 148
    .line 149
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v6

    .line 153
    add-int/lit8 v4, v4, 0x1

    .line 154
    .line 155
    check-cast v6, Ll5/a;

    .line 156
    .line 157
    new-instance v7, Li4/b;

    .line 158
    .line 159
    invoke-direct {v7, v6}, Li4/b;-><init>(Ll5/a;)V

    .line 160
    .line 161
    .line 162
    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 163
    .line 164
    .line 165
    goto :goto_6

    .line 166
    :cond_6
    new-instance v0, Lb2/f;

    .line 167
    .line 168
    invoke-direct {v0, v2}, Lb2/f;-><init>(I)V

    .line 169
    .line 170
    .line 171
    invoke-static {v3, v0}, Lw5/j;->k0(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    return-object v0

    .line 176
    :pswitch_1
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 177
    .line 178
    .line 179
    sget-object v0, Lo4/v;->d:Lo4/s;

    .line 180
    .line 181
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 182
    .line 183
    .line 184
    invoke-static {}, Lo4/s;->a()Ll5/b;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    invoke-virtual {v0, v3}, Ll5/b;->a(Ljava/lang/String;)Ll5/a;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 193
    .line 194
    .line 195
    move-result v0

    .line 196
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 197
    .line 198
    .line 199
    move-result-object v0

    .line 200
    return-object v0

    .line 201
    :pswitch_2
    invoke-static/range {p1 .. p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 202
    .line 203
    .line 204
    sget-object v3, La4/d;->m:La4/d;

    .line 205
    .line 206
    new-instance v6, Lj5/y0;

    .line 207
    .line 208
    const/4 v0, 0x2

    .line 209
    invoke-direct {v6, v0}, Lj5/y0;-><init>(I)V

    .line 210
    .line 211
    .line 212
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 213
    .line 214
    .line 215
    sget-object v0, La4/d;->o:Landroid/app/Application;

    .line 216
    .line 217
    if-nez v0, :cond_7

    .line 218
    .line 219
    const/4 v0, 0x0

    .line 220
    :cond_7
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 221
    .line 222
    .line 223
    move-result-object v7

    .line 224
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 225
    .line 226
    .line 227
    move-result-object v8

    .line 228
    invoke-virtual {v0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    .line 229
    .line 230
    .line 231
    move-result-object v9

    .line 232
    new-instance v0, Ljava/io/File;

    .line 233
    .line 234
    iget-object v8, v8, Landroid/content/pm/ApplicationInfo;->sourceDir:Ljava/lang/String;

    .line 235
    .line 236
    invoke-direct {v0, v8}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 237
    .line 238
    .line 239
    invoke-virtual {v0}, Ljava/io/File;->getName()Ljava/lang/String;

    .line 240
    .line 241
    .line 242
    move-result-object v8

    .line 243
    invoke-virtual {v3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 244
    .line 245
    .line 246
    move-result-object v0

    .line 247
    :try_start_1
    invoke-virtual {v0, v7, v4}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 248
    .line 249
    .line 250
    move-result-object v10
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_f

    .line 251
    invoke-virtual {v3}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    .line 252
    .line 253
    .line 254
    move-result-object v11

    .line 255
    new-instance v0, Ljava/io/File;

    .line 256
    .line 257
    const-string v12, "profileinstaller_profileWrittenFor_lastUpdateTime.dat"

    .line 258
    .line 259
    invoke-direct {v0, v11, v12}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 260
    .line 261
    .line 262
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 263
    .line 264
    .line 265
    move-result v13

    .line 266
    const-string v14, "ProfileInstaller"

    .line 267
    .line 268
    if-nez v13, :cond_8

    .line 269
    .line 270
    :catch_0
    move-object/from16 p1, v6

    .line 271
    .line 272
    goto :goto_8

    .line 273
    :cond_8
    :try_start_2
    new-instance v13, Ljava/io/DataInputStream;

    .line 274
    .line 275
    new-instance v15, Ljava/io/FileInputStream;

    .line 276
    .line 277
    invoke-direct {v15, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 278
    .line 279
    .line 280
    invoke-direct {v13, v15}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    .line 281
    .line 282
    .line 283
    :try_start_3
    invoke-virtual {v13}, Ljava/io/DataInputStream;->readLong()J

    .line 284
    .line 285
    .line 286
    move-result-wide v15
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 287
    :try_start_4
    invoke-virtual {v13}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    .line 288
    .line 289
    .line 290
    move-object/from16 p1, v6

    .line 291
    .line 292
    iget-wide v5, v10, Landroid/content/pm/PackageInfo;->lastUpdateTime:J

    .line 293
    .line 294
    cmp-long v0, v15, v5

    .line 295
    .line 296
    if-nez v0, :cond_9

    .line 297
    .line 298
    new-instance v0, Ljava/lang/StringBuilder;

    .line 299
    .line 300
    const-string v2, "Skipping profile installation for "

    .line 301
    .line 302
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 303
    .line 304
    .line 305
    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 306
    .line 307
    .line 308
    move-result-object v2

    .line 309
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 310
    .line 311
    .line 312
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 313
    .line 314
    .line 315
    move-result-object v0

    .line 316
    invoke-static {v14, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 317
    .line 318
    .line 319
    invoke-static {v3, v4}, Lu1/f;->c(Landroid/content/Context;Z)V

    .line 320
    .line 321
    .line 322
    goto/16 :goto_26

    .line 323
    .line 324
    :catchall_1
    move-exception v0

    .line 325
    move-object/from16 p1, v6

    .line 326
    .line 327
    move-object v5, v0

    .line 328
    :try_start_5
    invoke-virtual {v13}, Ljava/io/InputStream;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 329
    .line 330
    .line 331
    goto :goto_7

    .line 332
    :catchall_2
    move-exception v0

    .line 333
    :try_start_6
    invoke-virtual {v5, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 334
    .line 335
    .line 336
    :goto_7
    throw v5
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_1

    .line 337
    :catch_1
    :cond_9
    :goto_8
    new-instance v0, Ljava/lang/StringBuilder;

    .line 338
    .line 339
    const-string v5, "Installing profile for "

    .line 340
    .line 341
    invoke-direct {v0, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 342
    .line 343
    .line 344
    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 345
    .line 346
    .line 347
    move-result-object v5

    .line 348
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 349
    .line 350
    .line 351
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 352
    .line 353
    .line 354
    move-result-object v0

    .line 355
    invoke-static {v14, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 356
    .line 357
    .line 358
    sget-object v5, Lu1/c;->a:[B

    .line 359
    .line 360
    new-instance v0, Ljava/io/File;

    .line 361
    .line 362
    new-instance v6, Ljava/io/File;

    .line 363
    .line 364
    const-string v13, "/data/misc/profiles/cur/0"

    .line 365
    .line 366
    invoke-direct {v6, v13, v7}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 367
    .line 368
    .line 369
    const-string v7, "primary.prof"

    .line 370
    .line 371
    invoke-direct {v0, v6, v7}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 372
    .line 373
    .line 374
    new-instance v6, Lu1/a;

    .line 375
    .line 376
    const-string v7, "dexopt/baseline.prof"

    .line 377
    .line 378
    move-object/from16 v13, p1

    .line 379
    .line 380
    invoke-direct {v6, v9, v13, v8, v0}, Lu1/a;-><init>(Landroid/content/res/AssetManager;Lj5/y0;Ljava/lang/String;Ljava/io/File;)V

    .line 381
    .line 382
    .line 383
    iget-object v8, v6, Lu1/a;->a:[B

    .line 384
    .line 385
    if-nez v8, :cond_a

    .line 386
    .line 387
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 388
    .line 389
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 390
    .line 391
    .line 392
    move-result-object v0

    .line 393
    const/4 v2, 0x3

    .line 394
    invoke-virtual {v6, v2, v0}, Lu1/a;->b(ILjava/io/Serializable;)V

    .line 395
    .line 396
    .line 397
    goto/16 :goto_25

    .line 398
    .line 399
    :cond_a
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 400
    .line 401
    .line 402
    move-result v13

    .line 403
    const/4 v14, 0x4

    .line 404
    if-eqz v13, :cond_b

    .line 405
    .line 406
    invoke-virtual {v0}, Ljava/io/File;->canWrite()Z

    .line 407
    .line 408
    .line 409
    move-result v0

    .line 410
    if-nez v0, :cond_c

    .line 411
    .line 412
    const/4 v13, 0x0

    .line 413
    invoke-virtual {v6, v14, v13}, Lu1/a;->b(ILjava/io/Serializable;)V

    .line 414
    .line 415
    .line 416
    goto/16 :goto_25

    .line 417
    .line 418
    :cond_b
    const/4 v13, 0x0

    .line 419
    :try_start_7
    invoke-virtual {v0}, Ljava/io/File;->createNewFile()Z

    .line 420
    .line 421
    .line 422
    move-result v0

    .line 423
    if-nez v0, :cond_c

    .line 424
    .line 425
    invoke-virtual {v6, v14, v13}, Lu1/a;->b(ILjava/io/Serializable;)V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_d

    .line 426
    .line 427
    .line 428
    goto/16 :goto_25

    .line 429
    .line 430
    :cond_c
    const/4 v13, 0x1

    .line 431
    iput-boolean v13, v6, Lu1/a;->d:Z

    .line 432
    .line 433
    :try_start_8
    invoke-virtual {v6, v9, v7}, Lu1/a;->a(Landroid/content/res/AssetManager;Ljava/lang/String;)Ljava/io/FileInputStream;

    .line 434
    .line 435
    .line 436
    move-result-object v0
    :try_end_8
    .catch Ljava/io/FileNotFoundException; {:try_start_8 .. :try_end_8} :catch_2
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_2

    .line 437
    move-object v7, v0

    .line 438
    goto :goto_9

    .line 439
    :catch_2
    const/4 v7, 0x0

    .line 440
    :goto_9
    const-string v0, "Invalid magic"

    .line 441
    .line 442
    if-eqz v7, :cond_e

    .line 443
    .line 444
    :try_start_9
    invoke-static {v7, v14}, Lu1/c;->d(Ljava/io/InputStream;I)[B

    .line 445
    .line 446
    .line 447
    move-result-object v15

    .line 448
    invoke-static {v5, v15}, Ljava/util/Arrays;->equals([B[B)Z

    .line 449
    .line 450
    .line 451
    move-result v15

    .line 452
    if-eqz v15, :cond_d

    .line 453
    .line 454
    invoke-static {v7, v14}, Lu1/c;->d(Ljava/io/InputStream;I)[B

    .line 455
    .line 456
    .line 457
    move-result-object v15

    .line 458
    iget-object v2, v6, Lu1/a;->c:Ljava/lang/String;

    .line 459
    .line 460
    invoke-static {v7, v15, v2}, Lu1/c;->j(Ljava/io/FileInputStream;[BLjava/lang/String;)[Lu1/b;

    .line 461
    .line 462
    .line 463
    move-result-object v2
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_4
    .catch Ljava/lang/IllegalStateException; {:try_start_9 .. :try_end_9} :catch_4
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    .line 464
    :try_start_a
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_6

    .line 465
    .line 466
    .line 467
    goto :goto_b

    .line 468
    :catchall_3
    move-exception v0

    .line 469
    goto :goto_a

    .line 470
    :cond_d
    :try_start_b
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 471
    .line 472
    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 473
    .line 474
    .line 475
    throw v2
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_4
    .catch Ljava/lang/IllegalStateException; {:try_start_b .. :try_end_b} :catch_4
    .catchall {:try_start_b .. :try_end_b} :catchall_3

    .line 476
    :goto_a
    :try_start_c
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V
    :try_end_c
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_c} :catch_3

    .line 477
    .line 478
    .line 479
    :catch_3
    throw v0

    .line 480
    :catch_4
    :try_start_d
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V
    :try_end_d
    .catch Ljava/io/IOException; {:try_start_d .. :try_end_d} :catch_5

    .line 481
    .line 482
    .line 483
    :catch_5
    const/4 v2, 0x0

    .line 484
    :catch_6
    :goto_b
    iput-object v2, v6, Lu1/a;->e:[Lu1/b;

    .line 485
    .line 486
    :cond_e
    iget-object v2, v6, Lu1/a;->e:[Lu1/b;

    .line 487
    .line 488
    if-eqz v2, :cond_15

    .line 489
    .line 490
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 491
    .line 492
    const/16 v15, 0x18

    .line 493
    .line 494
    if-ge v7, v15, :cond_f

    .line 495
    .line 496
    goto :goto_12

    .line 497
    :cond_f
    const/16 v13, 0x1f

    .line 498
    .line 499
    if-lt v7, v13, :cond_10

    .line 500
    .line 501
    goto :goto_c

    .line 502
    :cond_10
    if-eq v7, v15, :cond_11

    .line 503
    .line 504
    const/16 v13, 0x19

    .line 505
    .line 506
    if-eq v7, v13, :cond_11

    .line 507
    .line 508
    goto :goto_12

    .line 509
    :cond_11
    :goto_c
    :try_start_e
    const-string v7, "dexopt/baseline.profm"

    .line 510
    .line 511
    invoke-virtual {v6, v9, v7}, Lu1/a;->a(Landroid/content/res/AssetManager;Ljava/lang/String;)Ljava/io/FileInputStream;

    .line 512
    .line 513
    .line 514
    move-result-object v7
    :try_end_e
    .catch Ljava/io/FileNotFoundException; {:try_start_e .. :try_end_e} :catch_8
    .catch Ljava/io/IOException; {:try_start_e .. :try_end_e} :catch_8
    .catch Ljava/lang/IllegalStateException; {:try_start_e .. :try_end_e} :catch_7

    .line 515
    if-eqz v7, :cond_13

    .line 516
    .line 517
    :try_start_f
    sget-object v9, Lu1/c;->b:[B

    .line 518
    .line 519
    invoke-static {v7, v14}, Lu1/c;->d(Ljava/io/InputStream;I)[B

    .line 520
    .line 521
    .line 522
    move-result-object v13

    .line 523
    invoke-static {v9, v13}, Ljava/util/Arrays;->equals([B[B)Z

    .line 524
    .line 525
    .line 526
    move-result v9

    .line 527
    if-eqz v9, :cond_12

    .line 528
    .line 529
    invoke-static {v7, v14}, Lu1/c;->d(Ljava/io/InputStream;I)[B

    .line 530
    .line 531
    .line 532
    move-result-object v0

    .line 533
    invoke-static {v7, v0, v8, v2}, Lu1/c;->g(Ljava/io/FileInputStream;[B[B[Lu1/b;)[Lu1/b;

    .line 534
    .line 535
    .line 536
    move-result-object v0

    .line 537
    iput-object v0, v6, Lu1/a;->e:[Lu1/b;
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_4

    .line 538
    .line 539
    :try_start_10
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V
    :try_end_10
    .catch Ljava/io/FileNotFoundException; {:try_start_10 .. :try_end_10} :catch_8
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_10} :catch_8
    .catch Ljava/lang/IllegalStateException; {:try_start_10 .. :try_end_10} :catch_7

    .line 540
    .line 541
    .line 542
    move-object v0, v6

    .line 543
    goto :goto_11

    .line 544
    :catch_7
    const/4 v13, 0x0

    .line 545
    goto :goto_f

    .line 546
    :catchall_4
    move-exception v0

    .line 547
    move-object v2, v0

    .line 548
    goto :goto_d

    .line 549
    :cond_12
    :try_start_11
    new-instance v2, Ljava/lang/IllegalStateException;

    .line 550
    .line 551
    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 552
    .line 553
    .line 554
    throw v2
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_4

    .line 555
    :goto_d
    :try_start_12
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_5

    .line 556
    .line 557
    .line 558
    goto :goto_e

    .line 559
    :catchall_5
    move-exception v0

    .line 560
    :try_start_13
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 561
    .line 562
    .line 563
    :goto_e
    throw v2

    .line 564
    :cond_13
    if-eqz v7, :cond_14

    .line 565
    .line 566
    invoke-virtual {v7}, Ljava/io/InputStream;->close()V
    :try_end_13
    .catch Ljava/io/FileNotFoundException; {:try_start_13 .. :try_end_13} :catch_8
    .catch Ljava/io/IOException; {:try_start_13 .. :try_end_13} :catch_8
    .catch Ljava/lang/IllegalStateException; {:try_start_13 .. :try_end_13} :catch_7

    .line 567
    .line 568
    .line 569
    goto :goto_10

    .line 570
    :goto_f
    iput-object v13, v6, Lu1/a;->e:[Lu1/b;

    .line 571
    .line 572
    :catch_8
    :cond_14
    :goto_10
    const/4 v0, 0x0

    .line 573
    :goto_11
    if-eqz v0, :cond_15

    .line 574
    .line 575
    move-object v6, v0

    .line 576
    :cond_15
    :goto_12
    iget-object v0, v6, Lu1/a;->e:[Lu1/b;

    .line 577
    .line 578
    iget-object v2, v6, Lu1/a;->a:[B

    .line 579
    .line 580
    const-string v7, "This device doesn\'t support aot. Did you call deviceSupportsAotProfile()?"

    .line 581
    .line 582
    if-eqz v0, :cond_19

    .line 583
    .line 584
    if-nez v2, :cond_16

    .line 585
    .line 586
    goto :goto_16

    .line 587
    :cond_16
    iget-boolean v8, v6, Lu1/a;->d:Z

    .line 588
    .line 589
    if-eqz v8, :cond_18

    .line 590
    .line 591
    :try_start_14
    new-instance v8, Ljava/io/ByteArrayOutputStream;

    .line 592
    .line 593
    invoke-direct {v8}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_14
    .catch Ljava/io/IOException; {:try_start_14 .. :try_end_14} :catch_9
    .catch Ljava/lang/IllegalStateException; {:try_start_14 .. :try_end_14} :catch_9

    .line 594
    .line 595
    .line 596
    :try_start_15
    invoke-virtual {v8, v5}, Ljava/io/OutputStream;->write([B)V

    .line 597
    .line 598
    .line 599
    invoke-virtual {v8, v2}, Ljava/io/OutputStream;->write([B)V

    .line 600
    .line 601
    .line 602
    invoke-static {v8, v2, v0}, Lu1/c;->m(Ljava/io/ByteArrayOutputStream;[B[Lu1/b;)Z

    .line 603
    .line 604
    .line 605
    move-result v0

    .line 606
    if-nez v0, :cond_17

    .line 607
    .line 608
    const/4 v13, 0x0

    .line 609
    iput-object v13, v6, Lu1/a;->e:[Lu1/b;
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_6

    .line 610
    .line 611
    :try_start_16
    invoke-virtual {v8}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_16
    .catch Ljava/io/IOException; {:try_start_16 .. :try_end_16} :catch_9
    .catch Ljava/lang/IllegalStateException; {:try_start_16 .. :try_end_16} :catch_9

    .line 612
    .line 613
    .line 614
    goto :goto_16

    .line 615
    :catchall_6
    move-exception v0

    .line 616
    move-object v2, v0

    .line 617
    goto :goto_13

    .line 618
    :cond_17
    :try_start_17
    invoke-virtual {v8}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    .line 619
    .line 620
    .line 621
    move-result-object v0

    .line 622
    iput-object v0, v6, Lu1/a;->f:[B
    :try_end_17
    .catchall {:try_start_17 .. :try_end_17} :catchall_6

    .line 623
    .line 624
    :try_start_18
    invoke-virtual {v8}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_18
    .catch Ljava/io/IOException; {:try_start_18 .. :try_end_18} :catch_9
    .catch Ljava/lang/IllegalStateException; {:try_start_18 .. :try_end_18} :catch_9

    .line 625
    .line 626
    .line 627
    :catch_9
    const/4 v13, 0x0

    .line 628
    goto :goto_15

    .line 629
    :goto_13
    :try_start_19
    invoke-virtual {v8}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_19
    .catchall {:try_start_19 .. :try_end_19} :catchall_7

    .line 630
    .line 631
    .line 632
    goto :goto_14

    .line 633
    :catchall_7
    move-exception v0

    .line 634
    :try_start_1a
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 635
    .line 636
    .line 637
    :goto_14
    throw v2
    :try_end_1a
    .catch Ljava/io/IOException; {:try_start_1a .. :try_end_1a} :catch_9
    .catch Ljava/lang/IllegalStateException; {:try_start_1a .. :try_end_1a} :catch_9

    .line 638
    :goto_15
    iput-object v13, v6, Lu1/a;->e:[Lu1/b;

    .line 639
    .line 640
    goto :goto_16

    .line 641
    :cond_18
    invoke-static {v7}, Lq0/b;->m(Ljava/lang/String;)V

    .line 642
    .line 643
    .line 644
    const/4 v5, 0x0

    .line 645
    goto/16 :goto_27

    .line 646
    .line 647
    :cond_19
    :goto_16
    iget-object v0, v6, Lu1/a;->f:[B

    .line 648
    .line 649
    if-nez v0, :cond_1a

    .line 650
    .line 651
    goto/16 :goto_25

    .line 652
    .line 653
    :cond_1a
    iget-boolean v2, v6, Lu1/a;->d:Z

    .line 654
    .line 655
    if-eqz v2, :cond_1f

    .line 656
    .line 657
    :try_start_1b
    new-instance v2, Ljava/io/ByteArrayInputStream;
    :try_end_1b
    .catch Ljava/io/FileNotFoundException; {:try_start_1b .. :try_end_1b} :catch_c
    .catch Ljava/io/IOException; {:try_start_1b .. :try_end_1b} :catch_a
    .catchall {:try_start_1b .. :try_end_1b} :catchall_a

    .line 658
    .line 659
    :try_start_1c
    invoke-direct {v2, v0}, Ljava/io/ByteArrayInputStream;-><init>([B)V
    :try_end_1c
    .catch Ljava/io/FileNotFoundException; {:try_start_1c .. :try_end_1c} :catch_b
    .catch Ljava/io/IOException; {:try_start_1c .. :try_end_1c} :catch_a
    .catchall {:try_start_1c .. :try_end_1c} :catchall_a

    .line 660
    .line 661
    .line 662
    :try_start_1d
    new-instance v5, Ljava/io/FileOutputStream;

    .line 663
    .line 664
    iget-object v0, v6, Lu1/a;->b:Ljava/io/File;

    .line 665
    .line 666
    invoke-direct {v5, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_1d
    .catchall {:try_start_1d .. :try_end_1d} :catchall_b

    .line 667
    .line 668
    .line 669
    :try_start_1e
    invoke-static {v5}, Lu0/b;->a(Ljava/io/FileOutputStream;)Ljava/nio/channels/FileChannel;

    .line 670
    .line 671
    .line 672
    move-result-object v7
    :try_end_1e
    .catchall {:try_start_1e .. :try_end_1e} :catchall_c

    .line 673
    :try_start_1f
    invoke-virtual {v7}, Ljava/nio/channels/FileChannel;->tryLock()Ljava/nio/channels/FileLock;

    .line 674
    .line 675
    .line 676
    move-result-object v8
    :try_end_1f
    .catchall {:try_start_1f .. :try_end_1f} :catchall_d

    .line 677
    if-eqz v8, :cond_1c

    .line 678
    .line 679
    :try_start_20
    invoke-virtual {v8}, Ljava/nio/channels/FileLock;->isValid()Z

    .line 680
    .line 681
    .line 682
    move-result v0

    .line 683
    if-eqz v0, :cond_1c

    .line 684
    .line 685
    const/16 v0, 0x200

    .line 686
    .line 687
    new-array v0, v0, [B

    .line 688
    .line 689
    :goto_17
    invoke-virtual {v2, v0}, Ljava/io/InputStream;->read([B)I

    .line 690
    .line 691
    .line 692
    move-result v9

    .line 693
    if-lez v9, :cond_1b

    .line 694
    .line 695
    invoke-virtual {v5, v0, v4, v9}, Ljava/io/OutputStream;->write([BII)V

    .line 696
    .line 697
    .line 698
    goto :goto_17

    .line 699
    :cond_1b
    const/4 v9, 0x1

    .line 700
    const/4 v13, 0x0

    .line 701
    invoke-virtual {v6, v9, v13}, Lu1/a;->b(ILjava/io/Serializable;)V
    :try_end_20
    .catchall {:try_start_20 .. :try_end_20} :catchall_e

    .line 702
    .line 703
    .line 704
    :try_start_21
    invoke-virtual {v8}, Ljava/nio/channels/FileLock;->close()V
    :try_end_21
    .catchall {:try_start_21 .. :try_end_21} :catchall_d

    .line 705
    .line 706
    .line 707
    :try_start_22
    invoke-virtual {v7}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_22
    .catchall {:try_start_22 .. :try_end_22} :catchall_c

    .line 708
    .line 709
    .line 710
    :try_start_23
    invoke-virtual {v5}, Ljava/io/FileOutputStream;->close()V
    :try_end_23
    .catchall {:try_start_23 .. :try_end_23} :catchall_b

    .line 711
    .line 712
    .line 713
    :try_start_24
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V
    :try_end_24
    .catch Ljava/io/FileNotFoundException; {:try_start_24 .. :try_end_24} :catch_b
    .catch Ljava/io/IOException; {:try_start_24 .. :try_end_24} :catch_a
    .catchall {:try_start_24 .. :try_end_24} :catchall_a

    .line 714
    .line 715
    .line 716
    iput-object v13, v6, Lu1/a;->f:[B

    .line 717
    .line 718
    iput-object v13, v6, Lu1/a;->e:[Lu1/b;

    .line 719
    .line 720
    new-instance v0, Ljava/io/File;

    .line 721
    .line 722
    invoke-direct {v0, v11, v12}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 723
    .line 724
    .line 725
    :try_start_25
    new-instance v2, Ljava/io/DataOutputStream;

    .line 726
    .line 727
    new-instance v5, Ljava/io/FileOutputStream;

    .line 728
    .line 729
    invoke-direct {v5, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    .line 730
    .line 731
    .line 732
    invoke-direct {v2, v5}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_25
    .catch Ljava/io/IOException; {:try_start_25 .. :try_end_25} :catch_e

    .line 733
    .line 734
    .line 735
    :try_start_26
    iget-wide v5, v10, Landroid/content/pm/PackageInfo;->lastUpdateTime:J

    .line 736
    .line 737
    invoke-virtual {v2, v5, v6}, Ljava/io/DataOutputStream;->writeLong(J)V
    :try_end_26
    .catchall {:try_start_26 .. :try_end_26} :catchall_8

    .line 738
    .line 739
    .line 740
    :try_start_27
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_27
    .catch Ljava/io/IOException; {:try_start_27 .. :try_end_27} :catch_e

    .line 741
    .line 742
    .line 743
    goto/16 :goto_25

    .line 744
    .line 745
    :catchall_8
    move-exception v0

    .line 746
    move-object v5, v0

    .line 747
    :try_start_28
    invoke-virtual {v2}, Ljava/io/OutputStream;->close()V
    :try_end_28
    .catchall {:try_start_28 .. :try_end_28} :catchall_9

    .line 748
    .line 749
    .line 750
    goto :goto_18

    .line 751
    :catchall_9
    move-exception v0

    .line 752
    :try_start_29
    invoke-virtual {v5, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 753
    .line 754
    .line 755
    :goto_18
    throw v5
    :try_end_29
    .catch Ljava/io/IOException; {:try_start_29 .. :try_end_29} :catch_e

    .line 756
    :catchall_a
    move-exception v0

    .line 757
    const/4 v13, 0x0

    .line 758
    goto :goto_24

    .line 759
    :catch_a
    move-exception v0

    .line 760
    goto :goto_21

    .line 761
    :catch_b
    move-exception v0

    .line 762
    const/4 v2, 0x6

    .line 763
    const/4 v13, 0x0

    .line 764
    goto :goto_23

    .line 765
    :catchall_b
    move-exception v0

    .line 766
    move-object v5, v0

    .line 767
    goto :goto_1f

    .line 768
    :catchall_c
    move-exception v0

    .line 769
    move-object v7, v0

    .line 770
    goto :goto_1d

    .line 771
    :catchall_d
    move-exception v0

    .line 772
    move-object v8, v0

    .line 773
    goto :goto_1b

    .line 774
    :catchall_e
    move-exception v0

    .line 775
    move-object v9, v0

    .line 776
    goto :goto_19

    .line 777
    :cond_1c
    :try_start_2a
    new-instance v0, Ljava/io/IOException;

    .line 778
    .line 779
    const-string v9, "Unable to acquire a lock on the underlying file channel."

    .line 780
    .line 781
    invoke-direct {v0, v9}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 782
    .line 783
    .line 784
    throw v0
    :try_end_2a
    .catchall {:try_start_2a .. :try_end_2a} :catchall_e

    .line 785
    :goto_19
    if-eqz v8, :cond_1d

    .line 786
    .line 787
    :try_start_2b
    invoke-virtual {v8}, Ljava/nio/channels/FileLock;->close()V
    :try_end_2b
    .catchall {:try_start_2b .. :try_end_2b} :catchall_f

    .line 788
    .line 789
    .line 790
    goto :goto_1a

    .line 791
    :catchall_f
    move-exception v0

    .line 792
    :try_start_2c
    invoke-virtual {v9, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 793
    .line 794
    .line 795
    :cond_1d
    :goto_1a
    throw v9
    :try_end_2c
    .catchall {:try_start_2c .. :try_end_2c} :catchall_d

    .line 796
    :goto_1b
    if-eqz v7, :cond_1e

    .line 797
    .line 798
    :try_start_2d
    invoke-virtual {v7}, Ljava/nio/channels/spi/AbstractInterruptibleChannel;->close()V
    :try_end_2d
    .catchall {:try_start_2d .. :try_end_2d} :catchall_10

    .line 799
    .line 800
    .line 801
    goto :goto_1c

    .line 802
    :catchall_10
    move-exception v0

    .line 803
    :try_start_2e
    invoke-virtual {v8, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 804
    .line 805
    .line 806
    :cond_1e
    :goto_1c
    throw v8
    :try_end_2e
    .catchall {:try_start_2e .. :try_end_2e} :catchall_c

    .line 807
    :goto_1d
    :try_start_2f
    invoke-virtual {v5}, Ljava/io/FileOutputStream;->close()V
    :try_end_2f
    .catchall {:try_start_2f .. :try_end_2f} :catchall_11

    .line 808
    .line 809
    .line 810
    goto :goto_1e

    .line 811
    :catchall_11
    move-exception v0

    .line 812
    :try_start_30
    invoke-virtual {v7, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 813
    .line 814
    .line 815
    :goto_1e
    throw v7
    :try_end_30
    .catchall {:try_start_30 .. :try_end_30} :catchall_b

    .line 816
    :goto_1f
    :try_start_31
    invoke-virtual {v2}, Ljava/io/InputStream;->close()V
    :try_end_31
    .catchall {:try_start_31 .. :try_end_31} :catchall_12

    .line 817
    .line 818
    .line 819
    goto :goto_20

    .line 820
    :catchall_12
    move-exception v0

    .line 821
    :try_start_32
    invoke-virtual {v5, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    .line 822
    .line 823
    .line 824
    :goto_20
    throw v5
    :try_end_32
    .catch Ljava/io/FileNotFoundException; {:try_start_32 .. :try_end_32} :catch_b
    .catch Ljava/io/IOException; {:try_start_32 .. :try_end_32} :catch_a
    .catchall {:try_start_32 .. :try_end_32} :catchall_a

    .line 825
    :goto_21
    const/4 v2, 0x7

    .line 826
    :try_start_33
    invoke-virtual {v6, v2, v0}, Lu1/a;->b(ILjava/io/Serializable;)V
    :try_end_33
    .catchall {:try_start_33 .. :try_end_33} :catchall_a

    .line 827
    .line 828
    .line 829
    const/4 v13, 0x0

    .line 830
    :goto_22
    iput-object v13, v6, Lu1/a;->f:[B

    .line 831
    .line 832
    iput-object v13, v6, Lu1/a;->e:[Lu1/b;

    .line 833
    .line 834
    goto :goto_25

    .line 835
    :catch_c
    move-exception v0

    .line 836
    const/4 v13, 0x0

    .line 837
    const/4 v2, 0x6

    .line 838
    :goto_23
    :try_start_34
    invoke-virtual {v6, v2, v0}, Lu1/a;->b(ILjava/io/Serializable;)V
    :try_end_34
    .catchall {:try_start_34 .. :try_end_34} :catchall_13

    .line 839
    .line 840
    .line 841
    goto :goto_22

    .line 842
    :catchall_13
    move-exception v0

    .line 843
    :goto_24
    iput-object v13, v6, Lu1/a;->f:[B

    .line 844
    .line 845
    iput-object v13, v6, Lu1/a;->e:[Lu1/b;

    .line 846
    .line 847
    throw v0

    .line 848
    :cond_1f
    const/4 v13, 0x0

    .line 849
    invoke-static {v7}, Lq0/b;->m(Ljava/lang/String;)V

    .line 850
    .line 851
    .line 852
    move-object v5, v13

    .line 853
    goto :goto_27

    .line 854
    :catch_d
    invoke-virtual {v6, v14, v13}, Lu1/a;->b(ILjava/io/Serializable;)V

    .line 855
    .line 856
    .line 857
    :catch_e
    :goto_25
    invoke-static {v3, v4}, Lu1/f;->c(Landroid/content/Context;Z)V

    .line 858
    .line 859
    .line 860
    goto :goto_26

    .line 861
    :catch_f
    invoke-static {v3, v4}, Lu1/f;->c(Landroid/content/Context;Z)V

    .line 862
    .line 863
    .line 864
    :goto_26
    sget-object v5, Lv5/k;->a:Lv5/k;

    .line 865
    .line 866
    :goto_27
    return-object v5

    .line 867
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
.end method
