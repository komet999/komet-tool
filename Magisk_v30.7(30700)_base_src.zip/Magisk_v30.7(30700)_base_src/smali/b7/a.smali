.class public interface abstract Lb7/a;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# virtual methods
.method public abstract f(Ljava/lang/Object;)V
.end method
