.class public final Lcom/topjohnwu/magisk/core/model/ReleaseAssetsJsonAdapter;
.super Lw3/q;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lw3/q;"
    }
.end annotation


# instance fields
.field public final a:Lv3/d;

.field public final b:Lw3/q;


# direct methods
.method public constructor <init>(Lw3/c0;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "browser_download_url"

    .line 5
    .line 6
    const-string v1, "name"

    .line 7
    .line 8
    filled-new-array {v1, v0}, [Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-static {v0}, Lv3/d;->l([Ljava/lang/String;)Lv3/d;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    iput-object v0, p0, Lcom/topjohnwu/magisk/core/model/ReleaseAssetsJsonAdapter;->a:Lv3/d;

    .line 17
    .line 18
    const-class v0, Ljava/lang/String;

    .line 19
    .line 20
    sget-object v2, Lw5/s;->m:Lw5/s;

    .line 21
    .line 22
    invoke-virtual {p1, v0, v2, v1}, Lw3/c0;->a(Ljava/lang/reflect/Type;Ljava/util/Set;Ljava/lang/String;)Lw3/q;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    iput-object p1, p0, Lcom/topjohnwu/magisk/core/model/ReleaseAssetsJsonAdapter;->b:Lw3/q;

    .line 27
    .line 28
    return-void
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method


# virtual methods
.method public final a(Lw3/u;)Ljava/lang/Object;
    .locals 12

    .line 1
    invoke-virtual {p1}, Lw3/u;->l()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    const/4 v1, 0x0

    .line 6
    sget-object v2, Lw5/s;->m:Lw5/s;

    .line 7
    .line 8
    move v4, v1

    .line 9
    move v5, v4

    .line 10
    move-object v3, v2

    .line 11
    move-object v2, v0

    .line 12
    :goto_0
    invoke-virtual {p1}, Lw3/u;->S()Z

    .line 13
    .line 14
    .line 15
    move-result v6

    .line 16
    const-string v7, "browser_download_url"

    .line 17
    .line 18
    const-string v8, "url"

    .line 19
    .line 20
    const-string v9, "name"

    .line 21
    .line 22
    const/4 v10, 0x1

    .line 23
    if-eqz v6, :cond_5

    .line 24
    .line 25
    iget-object v6, p0, Lcom/topjohnwu/magisk/core/model/ReleaseAssetsJsonAdapter;->a:Lv3/d;

    .line 26
    .line 27
    invoke-virtual {p1, v6}, Lw3/u;->f0(Lv3/d;)I

    .line 28
    .line 29
    .line 30
    move-result v6

    .line 31
    const/4 v11, -0x1

    .line 32
    if-eq v6, v11, :cond_4

    .line 33
    .line 34
    iget-object v11, p0, Lcom/topjohnwu/magisk/core/model/ReleaseAssetsJsonAdapter;->b:Lw3/q;

    .line 35
    .line 36
    if-eqz v6, :cond_2

    .line 37
    .line 38
    if-eq v6, v10, :cond_0

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    invoke-virtual {v11, p1}, Lw3/q;->a(Lw3/u;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    if-nez v6, :cond_1

    .line 46
    .line 47
    invoke-static {v8, v7, p1}, Lx3/e;->l(Ljava/lang/String;Ljava/lang/String;Lw3/u;)Lw3/s;

    .line 48
    .line 49
    .line 50
    move-result-object v5

    .line 51
    invoke-virtual {v5}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v5

    .line 55
    invoke-static {v3, v5}, Lo3/b;->I(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 56
    .line 57
    .line 58
    move-result-object v3

    .line 59
    move v5, v10

    .line 60
    goto :goto_0

    .line 61
    :cond_1
    move-object v2, v6

    .line 62
    check-cast v2, Ljava/lang/String;

    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_2
    invoke-virtual {v11, p1}, Lw3/q;->a(Lw3/u;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v6

    .line 69
    if-nez v6, :cond_3

    .line 70
    .line 71
    invoke-static {v9, v9, p1}, Lx3/e;->l(Ljava/lang/String;Ljava/lang/String;Lw3/u;)Lw3/s;

    .line 72
    .line 73
    .line 74
    move-result-object v4

    .line 75
    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v4

    .line 79
    invoke-static {v3, v4}, Lo3/b;->I(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 80
    .line 81
    .line 82
    move-result-object v3

    .line 83
    move v4, v10

    .line 84
    goto :goto_0

    .line 85
    :cond_3
    move-object v0, v6

    .line 86
    check-cast v0, Ljava/lang/String;

    .line 87
    .line 88
    goto :goto_0

    .line 89
    :cond_4
    invoke-virtual {p1}, Lw3/u;->g0()V

    .line 90
    .line 91
    .line 92
    invoke-virtual {p1}, Lw3/u;->i0()V

    .line 93
    .line 94
    .line 95
    goto :goto_0

    .line 96
    :cond_5
    invoke-virtual {p1}, Lw3/u;->H()V

    .line 97
    .line 98
    .line 99
    xor-int/2addr v4, v10

    .line 100
    if-nez v0, :cond_6

    .line 101
    .line 102
    move v6, v10

    .line 103
    goto :goto_1

    .line 104
    :cond_6
    move v6, v1

    .line 105
    :goto_1
    and-int/2addr v4, v6

    .line 106
    if-eqz v4, :cond_7

    .line 107
    .line 108
    invoke-static {v9, v9, p1}, Lx3/e;->f(Ljava/lang/String;Ljava/lang/String;Lw3/u;)Lw3/s;

    .line 109
    .line 110
    .line 111
    move-result-object v4

    .line 112
    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v4

    .line 116
    invoke-static {v3, v4}, Lo3/b;->I(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 117
    .line 118
    .line 119
    move-result-object v3

    .line 120
    :cond_7
    xor-int/lit8 v4, v5, 0x1

    .line 121
    .line 122
    if-nez v2, :cond_8

    .line 123
    .line 124
    move v1, v10

    .line 125
    :cond_8
    and-int/2addr v1, v4

    .line 126
    if-eqz v1, :cond_9

    .line 127
    .line 128
    invoke-static {v8, v7, p1}, Lx3/e;->f(Ljava/lang/String;Ljava/lang/String;Lw3/u;)Lw3/s;

    .line 129
    .line 130
    .line 131
    move-result-object p1

    .line 132
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object p1

    .line 136
    invoke-static {v3, p1}, Lo3/b;->I(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 137
    .line 138
    .line 139
    move-result-object v3

    .line 140
    :cond_9
    move-object v4, v3

    .line 141
    invoke-interface {v4}, Ljava/util/Set;->size()I

    .line 142
    .line 143
    .line 144
    move-result p1

    .line 145
    if-nez p1, :cond_a

    .line 146
    .line 147
    new-instance p1, Lcom/topjohnwu/magisk/core/model/ReleaseAssets;

    .line 148
    .line 149
    invoke-direct {p1, v0, v2}, Lcom/topjohnwu/magisk/core/model/ReleaseAssets;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    return-object p1

    .line 153
    :cond_a
    new-instance p1, Lw3/s;

    .line 154
    .line 155
    const/4 v8, 0x0

    .line 156
    const/16 v9, 0x3e

    .line 157
    .line 158
    const-string v5, "\n"

    .line 159
    .line 160
    const/4 v6, 0x0

    .line 161
    const/4 v7, 0x0

    .line 162
    invoke-static/range {v4 .. v9}, Lw5/j;->Z(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lj6/l;I)Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    throw p1
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method

.method public final c(Lw3/v;Ljava/lang/Object;)V
    .locals 2

    .line 1
    if-eqz p2, :cond_0

    .line 2
    .line 3
    check-cast p2, Lcom/topjohnwu/magisk/core/model/ReleaseAssets;

    .line 4
    .line 5
    invoke-virtual {p1}, Lw3/v;->u()Lw3/v;

    .line 6
    .line 7
    .line 8
    const-string v0, "name"

    .line 9
    .line 10
    invoke-virtual {p1, v0}, Lw3/v;->P(Ljava/lang/String;)Lw3/v;

    .line 11
    .line 12
    .line 13
    iget-object v0, p2, Lcom/topjohnwu/magisk/core/model/ReleaseAssets;->a:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v1, p0, Lcom/topjohnwu/magisk/core/model/ReleaseAssetsJsonAdapter;->b:Lw3/q;

    .line 16
    .line 17
    invoke-virtual {v1, p1, v0}, Lw3/q;->c(Lw3/v;Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    const-string v0, "browser_download_url"

    .line 21
    .line 22
    invoke-virtual {p1, v0}, Lw3/v;->P(Ljava/lang/String;)Lw3/v;

    .line 23
    .line 24
    .line 25
    iget-object p2, p2, Lcom/topjohnwu/magisk/core/model/ReleaseAssets;->b:Ljava/lang/String;

    .line 26
    .line 27
    invoke-virtual {v1, p1, p2}, Lw3/q;->c(Lw3/v;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p1}, Lw3/v;->A()Lw3/v;

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :cond_0
    new-instance p1, Lv5/b;

    .line 35
    .line 36
    const-string p2, "value was null! Wrap in .nullSafe() to write nullable values."

    .line 37
    .line 38
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw p1
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "GeneratedJsonAdapter(ReleaseAssets)"

    .line 2
    .line 3
    return-object v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method
