.class public final Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;
.super Lw3/q;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lw3/q;"
    }
.end annotation


# instance fields
.field public final a:Lv3/d;

.field public final b:Lw3/q;

.field public final c:Lw3/q;


# direct methods
.method public constructor <init>(Lw3/c0;)V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "link"

    .line 5
    .line 6
    const-string v1, "note"

    .line 7
    .line 8
    const-string v2, "version"

    .line 9
    .line 10
    const-string v3, "versionCode"

    .line 11
    .line 12
    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-static {v0}, Lv3/d;->l([Ljava/lang/String;)Lv3/d;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    iput-object v0, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->a:Lv3/d;

    .line 21
    .line 22
    const-class v0, Ljava/lang/String;

    .line 23
    .line 24
    sget-object v1, Lw5/s;->m:Lw5/s;

    .line 25
    .line 26
    invoke-virtual {p1, v0, v1, v2}, Lw3/c0;->a(Ljava/lang/reflect/Type;Ljava/util/Set;Ljava/lang/String;)Lw3/q;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    iput-object v0, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->b:Lw3/q;

    .line 31
    .line 32
    sget-object v0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 33
    .line 34
    invoke-virtual {p1, v0, v1, v3}, Lw3/c0;->a(Ljava/lang/reflect/Type;Ljava/util/Set;Ljava/lang/String;)Lw3/q;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    iput-object p1, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->c:Lw3/q;

    .line 39
    .line 40
    return-void
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method


# virtual methods
.method public final a(Lw3/u;)Ljava/lang/Object;
    .locals 13

    .line 1
    invoke-virtual {p1}, Lw3/u;->l()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    const/4 v1, 0x0

    .line 6
    sget-object v2, Lw5/s;->m:Lw5/s;

    .line 7
    .line 8
    const/4 v3, -0x1

    .line 9
    move v6, v1

    .line 10
    move-object v7, v2

    .line 11
    move v9, v3

    .line 12
    move-object v1, v0

    .line 13
    move-object v2, v1

    .line 14
    :goto_0
    invoke-virtual {p1}, Lw3/u;->S()Z

    .line 15
    .line 16
    .line 17
    move-result v4

    .line 18
    if-eqz v4, :cond_9

    .line 19
    .line 20
    iget-object v4, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->a:Lv3/d;

    .line 21
    .line 22
    invoke-virtual {p1, v4}, Lw3/u;->f0(Lv3/d;)I

    .line 23
    .line 24
    .line 25
    move-result v4

    .line 26
    if-eq v4, v3, :cond_8

    .line 27
    .line 28
    iget-object v5, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->b:Lw3/q;

    .line 29
    .line 30
    if-eqz v4, :cond_6

    .line 31
    .line 32
    const/4 v8, 0x1

    .line 33
    if-eq v4, v8, :cond_4

    .line 34
    .line 35
    const/4 v8, 0x2

    .line 36
    if-eq v4, v8, :cond_2

    .line 37
    .line 38
    const/4 v8, 0x3

    .line 39
    if-eq v4, v8, :cond_0

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :cond_0
    invoke-virtual {v5, p1}, Lw3/q;->a(Lw3/u;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    if-nez v4, :cond_1

    .line 47
    .line 48
    const-string v4, "note"

    .line 49
    .line 50
    invoke-static {v4, v4, p1}, Lx3/e;->l(Ljava/lang/String;Ljava/lang/String;Lw3/u;)Lw3/s;

    .line 51
    .line 52
    .line 53
    move-result-object v4

    .line 54
    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object v4

    .line 58
    invoke-static {v7, v4}, Lo3/b;->I(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 59
    .line 60
    .line 61
    move-result-object v4

    .line 62
    move-object v7, v4

    .line 63
    goto :goto_1

    .line 64
    :cond_1
    move-object v2, v4

    .line 65
    :goto_1
    and-int/lit8 v9, v9, -0x9

    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_2
    invoke-virtual {v5, p1}, Lw3/q;->a(Lw3/u;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v4

    .line 72
    if-nez v4, :cond_3

    .line 73
    .line 74
    const-string v4, "link"

    .line 75
    .line 76
    invoke-static {v4, v4, p1}, Lx3/e;->l(Ljava/lang/String;Ljava/lang/String;Lw3/u;)Lw3/s;

    .line 77
    .line 78
    .line 79
    move-result-object v4

    .line 80
    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v4

    .line 84
    invoke-static {v7, v4}, Lo3/b;->I(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 85
    .line 86
    .line 87
    move-result-object v4

    .line 88
    move-object v7, v4

    .line 89
    goto :goto_2

    .line 90
    :cond_3
    move-object v1, v4

    .line 91
    :goto_2
    and-int/lit8 v9, v9, -0x5

    .line 92
    .line 93
    goto :goto_0

    .line 94
    :cond_4
    iget-object v4, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->c:Lw3/q;

    .line 95
    .line 96
    invoke-virtual {v4, p1}, Lw3/q;->a(Lw3/u;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v4

    .line 100
    if-nez v4, :cond_5

    .line 101
    .line 102
    const-string v4, "versionCode"

    .line 103
    .line 104
    invoke-static {v4, v4, p1}, Lx3/e;->l(Ljava/lang/String;Ljava/lang/String;Lw3/u;)Lw3/s;

    .line 105
    .line 106
    .line 107
    move-result-object v4

    .line 108
    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v4

    .line 112
    invoke-static {v7, v4}, Lo3/b;->I(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 113
    .line 114
    .line 115
    move-result-object v4

    .line 116
    move-object v7, v4

    .line 117
    goto :goto_3

    .line 118
    :cond_5
    check-cast v4, Ljava/lang/Number;

    .line 119
    .line 120
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 121
    .line 122
    .line 123
    move-result v4

    .line 124
    move v6, v4

    .line 125
    :goto_3
    and-int/lit8 v9, v9, -0x3

    .line 126
    .line 127
    goto :goto_0

    .line 128
    :cond_6
    invoke-virtual {v5, p1}, Lw3/q;->a(Lw3/u;)Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v4

    .line 132
    if-nez v4, :cond_7

    .line 133
    .line 134
    const-string v4, "version"

    .line 135
    .line 136
    invoke-static {v4, v4, p1}, Lx3/e;->l(Ljava/lang/String;Ljava/lang/String;Lw3/u;)Lw3/s;

    .line 137
    .line 138
    .line 139
    move-result-object v4

    .line 140
    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object v4

    .line 144
    invoke-static {v7, v4}, Lo3/b;->I(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 145
    .line 146
    .line 147
    move-result-object v4

    .line 148
    move-object v7, v4

    .line 149
    goto :goto_4

    .line 150
    :cond_7
    move-object v0, v4

    .line 151
    :goto_4
    and-int/lit8 v9, v9, -0x2

    .line 152
    .line 153
    goto/16 :goto_0

    .line 154
    .line 155
    :cond_8
    invoke-virtual {p1}, Lw3/u;->g0()V

    .line 156
    .line 157
    .line 158
    invoke-virtual {p1}, Lw3/u;->i0()V

    .line 159
    .line 160
    .line 161
    goto/16 :goto_0

    .line 162
    .line 163
    :cond_9
    invoke-virtual {p1}, Lw3/u;->H()V

    .line 164
    .line 165
    .line 166
    invoke-interface {v7}, Ljava/util/Set;->size()I

    .line 167
    .line 168
    .line 169
    move-result p1

    .line 170
    if-nez p1, :cond_b

    .line 171
    .line 172
    const/16 p1, -0x10

    .line 173
    .line 174
    if-ne v9, p1, :cond_a

    .line 175
    .line 176
    new-instance p1, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 177
    .line 178
    check-cast v0, Ljava/lang/String;

    .line 179
    .line 180
    check-cast v1, Ljava/lang/String;

    .line 181
    .line 182
    check-cast v2, Ljava/lang/String;

    .line 183
    .line 184
    invoke-direct {p1, v0, v6, v1, v2}, Lcom/topjohnwu/magisk/core/model/UpdateInfo;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    return-object p1

    .line 188
    :cond_a
    new-instance v4, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 189
    .line 190
    move-object v5, v0

    .line 191
    check-cast v5, Ljava/lang/String;

    .line 192
    .line 193
    move-object v7, v1

    .line 194
    check-cast v7, Ljava/lang/String;

    .line 195
    .line 196
    move-object v8, v2

    .line 197
    check-cast v8, Ljava/lang/String;

    .line 198
    .line 199
    invoke-direct/range {v4 .. v9}, Lcom/topjohnwu/magisk/core/model/UpdateInfo;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;I)V

    .line 200
    .line 201
    .line 202
    return-object v4

    .line 203
    :cond_b
    new-instance p1, Lw3/s;

    .line 204
    .line 205
    const/4 v11, 0x0

    .line 206
    const/16 v12, 0x3e

    .line 207
    .line 208
    const-string v8, "\n"

    .line 209
    .line 210
    const/4 v9, 0x0

    .line 211
    const/4 v10, 0x0

    .line 212
    invoke-static/range {v7 .. v12}, Lw5/j;->Z(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lj6/l;I)Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    move-result-object v0

    .line 216
    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 217
    .line 218
    .line 219
    throw p1
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method

.method public final c(Lw3/v;Ljava/lang/Object;)V
    .locals 3

    .line 1
    if-eqz p2, :cond_0

    .line 2
    .line 3
    check-cast p2, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 4
    .line 5
    invoke-virtual {p1}, Lw3/v;->u()Lw3/v;

    .line 6
    .line 7
    .line 8
    const-string v0, "version"

    .line 9
    .line 10
    invoke-virtual {p1, v0}, Lw3/v;->P(Ljava/lang/String;)Lw3/v;

    .line 11
    .line 12
    .line 13
    iget-object v0, p2, Lcom/topjohnwu/magisk/core/model/UpdateInfo;->m:Ljava/lang/String;

    .line 14
    .line 15
    iget-object v1, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->b:Lw3/q;

    .line 16
    .line 17
    invoke-virtual {v1, p1, v0}, Lw3/q;->c(Lw3/v;Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    const-string v0, "versionCode"

    .line 21
    .line 22
    invoke-virtual {p1, v0}, Lw3/v;->P(Ljava/lang/String;)Lw3/v;

    .line 23
    .line 24
    .line 25
    iget v0, p2, Lcom/topjohnwu/magisk/core/model/UpdateInfo;->n:I

    .line 26
    .line 27
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    iget-object v2, p0, Lcom/topjohnwu/magisk/core/model/UpdateInfoJsonAdapter;->c:Lw3/q;

    .line 32
    .line 33
    invoke-virtual {v2, p1, v0}, Lw3/q;->c(Lw3/v;Ljava/lang/Object;)V

    .line 34
    .line 35
    .line 36
    const-string v0, "link"

    .line 37
    .line 38
    invoke-virtual {p1, v0}, Lw3/v;->P(Ljava/lang/String;)Lw3/v;

    .line 39
    .line 40
    .line 41
    iget-object v0, p2, Lcom/topjohnwu/magisk/core/model/UpdateInfo;->o:Ljava/lang/String;

    .line 42
    .line 43
    invoke-virtual {v1, p1, v0}, Lw3/q;->c(Lw3/v;Ljava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    const-string v0, "note"

    .line 47
    .line 48
    invoke-virtual {p1, v0}, Lw3/v;->P(Ljava/lang/String;)Lw3/v;

    .line 49
    .line 50
    .line 51
    iget-object p2, p2, Lcom/topjohnwu/magisk/core/model/UpdateInfo;->p:Ljava/lang/String;

    .line 52
    .line 53
    invoke-virtual {v1, p1, p2}, Lw3/q;->c(Lw3/v;Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p1}, Lw3/v;->A()Lw3/v;

    .line 57
    .line 58
    .line 59
    return-void

    .line 60
    :cond_0
    new-instance p1, Lv5/b;

    .line 61
    .line 62
    const-string p2, "value was null! Wrap in .nullSafe() to write nullable values."

    .line 63
    .line 64
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    throw p1
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "GeneratedJsonAdapter(UpdateInfo)"

    .line 2
    .line 3
    return-object v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method
