.class public final Lcom/topjohnwu/magisk/core/model/UpdateJsonJsonAdapter;
.super Lw3/q;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lw3/q;"
    }
.end annotation


# instance fields
.field public final a:Lv3/d;

.field public final b:Lw3/q;


# direct methods
.method public constructor <init>(Lw3/c0;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "magisk"

    .line 5
    .line 6
    filled-new-array {v0}, [Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-static {v1}, Lv3/d;->l([Ljava/lang/String;)Lv3/d;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    iput-object v1, p0, Lcom/topjohnwu/magisk/core/model/UpdateJsonJsonAdapter;->a:Lv3/d;

    .line 15
    .line 16
    const-class v1, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 17
    .line 18
    sget-object v2, Lw5/s;->m:Lw5/s;

    .line 19
    .line 20
    invoke-virtual {p1, v1, v2, v0}, Lw3/c0;->a(Ljava/lang/reflect/Type;Ljava/util/Set;Ljava/lang/String;)Lw3/q;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    iput-object p1, p0, Lcom/topjohnwu/magisk/core/model/UpdateJsonJsonAdapter;->b:Lw3/q;

    .line 25
    .line 26
    return-void
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method


# virtual methods
.method public final a(Lw3/u;)Ljava/lang/Object;
    .locals 9

    .line 1
    invoke-virtual {p1}, Lw3/u;->l()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    sget-object v1, Lw5/s;->m:Lw5/s;

    .line 6
    .line 7
    const/4 v2, -0x1

    .line 8
    move-object v3, v1

    .line 9
    move v1, v2

    .line 10
    :goto_0
    invoke-virtual {p1}, Lw3/u;->S()Z

    .line 11
    .line 12
    .line 13
    move-result v4

    .line 14
    const/4 v5, -0x2

    .line 15
    if-eqz v4, :cond_3

    .line 16
    .line 17
    iget-object v4, p0, Lcom/topjohnwu/magisk/core/model/UpdateJsonJsonAdapter;->a:Lv3/d;

    .line 18
    .line 19
    invoke-virtual {p1, v4}, Lw3/u;->f0(Lv3/d;)I

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    if-eq v4, v2, :cond_2

    .line 24
    .line 25
    if-eqz v4, :cond_0

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    iget-object v1, p0, Lcom/topjohnwu/magisk/core/model/UpdateJsonJsonAdapter;->b:Lw3/q;

    .line 29
    .line 30
    invoke-virtual {v1, p1}, Lw3/q;->a(Lw3/u;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    if-nez v1, :cond_1

    .line 35
    .line 36
    const-string v1, "magisk"

    .line 37
    .line 38
    invoke-static {v1, v1, p1}, Lx3/e;->l(Ljava/lang/String;Ljava/lang/String;Lw3/u;)Lw3/s;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    invoke-static {v3, v1}, Lo3/b;->I(Ljava/util/Set;Ljava/lang/Object;)Ljava/util/LinkedHashSet;

    .line 47
    .line 48
    .line 49
    move-result-object v1

    .line 50
    move-object v3, v1

    .line 51
    goto :goto_1

    .line 52
    :cond_1
    move-object v0, v1

    .line 53
    :goto_1
    move v1, v5

    .line 54
    goto :goto_0

    .line 55
    :cond_2
    invoke-virtual {p1}, Lw3/u;->g0()V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p1}, Lw3/u;->i0()V

    .line 59
    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_3
    invoke-virtual {p1}, Lw3/u;->H()V

    .line 63
    .line 64
    .line 65
    invoke-interface {v3}, Ljava/util/Set;->size()I

    .line 66
    .line 67
    .line 68
    move-result p1

    .line 69
    if-nez p1, :cond_6

    .line 70
    .line 71
    new-instance p1, Lcom/topjohnwu/magisk/core/model/UpdateJson;

    .line 72
    .line 73
    check-cast v0, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 74
    .line 75
    if-ne v1, v5, :cond_4

    .line 76
    .line 77
    invoke-direct {p1, v0}, Lcom/topjohnwu/magisk/core/model/UpdateJson;-><init>(Lcom/topjohnwu/magisk/core/model/UpdateInfo;)V

    .line 78
    .line 79
    .line 80
    return-object p1

    .line 81
    :cond_4
    and-int/lit8 v1, v1, 0x1

    .line 82
    .line 83
    if-eqz v1, :cond_5

    .line 84
    .line 85
    new-instance v2, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 86
    .line 87
    const/4 v6, 0x0

    .line 88
    const/16 v7, 0xf

    .line 89
    .line 90
    const/4 v3, 0x0

    .line 91
    const/4 v4, 0x0

    .line 92
    const/4 v5, 0x0

    .line 93
    invoke-direct/range {v2 .. v7}, Lcom/topjohnwu/magisk/core/model/UpdateInfo;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;I)V

    .line 94
    .line 95
    .line 96
    move-object v0, v2

    .line 97
    :cond_5
    invoke-direct {p1, v0}, Lcom/topjohnwu/magisk/core/model/UpdateJson;-><init>(Lcom/topjohnwu/magisk/core/model/UpdateInfo;)V

    .line 98
    .line 99
    .line 100
    return-object p1

    .line 101
    :cond_6
    new-instance p1, Lw3/s;

    .line 102
    .line 103
    const/4 v7, 0x0

    .line 104
    const/16 v8, 0x3e

    .line 105
    .line 106
    const-string v4, "\n"

    .line 107
    .line 108
    const/4 v5, 0x0

    .line 109
    const/4 v6, 0x0

    .line 110
    invoke-static/range {v3 .. v8}, Lw5/j;->Z(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lj6/l;I)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    throw p1
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method

.method public final c(Lw3/v;Ljava/lang/Object;)V
    .locals 1

    .line 1
    if-eqz p2, :cond_0

    .line 2
    .line 3
    check-cast p2, Lcom/topjohnwu/magisk/core/model/UpdateJson;

    .line 4
    .line 5
    invoke-virtual {p1}, Lw3/v;->u()Lw3/v;

    .line 6
    .line 7
    .line 8
    const-string v0, "magisk"

    .line 9
    .line 10
    invoke-virtual {p1, v0}, Lw3/v;->P(Ljava/lang/String;)Lw3/v;

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Lcom/topjohnwu/magisk/core/model/UpdateJsonJsonAdapter;->b:Lw3/q;

    .line 14
    .line 15
    iget-object p2, p2, Lcom/topjohnwu/magisk/core/model/UpdateJson;->a:Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 16
    .line 17
    invoke-virtual {v0, p1, p2}, Lw3/q;->c(Lw3/v;Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p1}, Lw3/v;->A()Lw3/v;

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :cond_0
    new-instance p1, Lv5/b;

    .line 25
    .line 26
    const-string p2, "value was null! Wrap in .nullSafe() to write nullable values."

    .line 27
    .line 28
    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    throw p1
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method

.method public final toString()Ljava/lang/String;
    .locals 1

    .line 1
    const-string v0, "GeneratedJsonAdapter(UpdateJson)"

    .line 2
    .line 3
    return-object v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method
