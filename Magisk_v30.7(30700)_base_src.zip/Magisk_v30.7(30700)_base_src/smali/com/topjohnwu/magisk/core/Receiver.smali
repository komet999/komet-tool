.class public Lcom/topjohnwu/magisk/core/Receiver;
.super Landroid/content/BroadcastReceiver;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# static fields
.field public static final synthetic a:I


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 9

    .line 1
    if-nez p2, :cond_0

    .line 2
    .line 3
    goto/16 :goto_5

    .line 4
    .line 5
    :cond_0
    invoke-static {p1}, La4/j;->b(Landroid/content/Context;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    if-nez v0, :cond_1

    .line 13
    .line 14
    goto/16 :goto_5

    .line 15
    .line 16
    :cond_1
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    sget-object v2, Lz5/e;->m:Lz5/e;

    .line 21
    .line 22
    sget-object v3, Lz5/i;->m:Lz5/i;

    .line 23
    .line 24
    const/4 v4, -0x1

    .line 25
    const-string v5, "android.intent.extra.UID"

    .line 26
    .line 27
    const/4 v6, 0x1

    .line 28
    const/4 v7, 0x0

    .line 29
    sparse-switch v1, :sswitch_data_0

    .line 30
    .line 31
    .line 32
    goto/16 :goto_5

    .line 33
    .line 34
    :sswitch_0
    const-string p2, "android.intent.action.MY_PACKAGE_REPLACED"

    .line 35
    .line 36
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result p2

    .line 40
    if-nez p2, :cond_2

    .line 41
    .line 42
    goto/16 :goto_5

    .line 43
    .line 44
    :cond_2
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 45
    .line 46
    .line 47
    move-result-object p2

    .line 48
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-virtual {p2, v0}, Landroid/content/pm/PackageManager;->getInstallerPackageName(Ljava/lang/String;)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object p2

    .line 56
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    invoke-static {p2, p1}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result p1

    .line 64
    if-eqz p1, :cond_11

    .line 65
    .line 66
    sget-object p1, Lg5/h;->a:Lv5/i;

    .line 67
    .line 68
    sget-object p1, La4/d;->m:La4/d;

    .line 69
    .line 70
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 71
    .line 72
    .line 73
    move-result-object p2

    .line 74
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    invoke-virtual {p2, v0}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 79
    .line 80
    .line 81
    move-result-object p2

    .line 82
    const v0, 0x10008000

    .line 83
    .line 84
    .line 85
    invoke-virtual {p2, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 86
    .line 87
    .line 88
    const/4 v0, 0x0

    .line 89
    const/high16 v1, 0xc000000

    .line 90
    .line 91
    invoke-static {p1, v0, p2, v1}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 92
    .line 93
    .line 94
    move-result-object p2

    .line 95
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 96
    .line 97
    const/16 v1, 0x1a

    .line 98
    .line 99
    const v2, 0x7f0800e9

    .line 100
    .line 101
    .line 102
    if-lt v0, v1, :cond_3

    .line 103
    .line 104
    new-instance v0, Landroid/app/Notification$Builder;

    .line 105
    .line 106
    invoke-static {p1}, Lg5/g;->a(Landroid/content/Context;)Landroid/app/Notification$Builder;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    invoke-static {p1, v2}, Lf5/d;->d(Landroid/content/Context;I)Landroid/graphics/Bitmap;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    invoke-static {v1}, Landroid/graphics/drawable/Icon;->createWithBitmap(Landroid/graphics/Bitmap;)Landroid/graphics/drawable/Icon;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setSmallIcon(Landroid/graphics/drawable/Icon;)Landroid/app/Notification$Builder;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    goto :goto_0

    .line 123
    :cond_3
    new-instance v0, Landroid/app/Notification$Builder;

    .line 124
    .line 125
    invoke-direct {v0, p1}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {v0, v6}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    invoke-virtual {v0, v2}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    :goto_0
    invoke-virtual {v0, p2}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    .line 137
    .line 138
    .line 139
    move-result-object p2

    .line 140
    const v0, 0x7f110193

    .line 141
    .line 142
    .line 143
    invoke-virtual {p1, v0}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    invoke-virtual {p2, v0}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 148
    .line 149
    .line 150
    move-result-object p2

    .line 151
    const v0, 0x7f110192

    .line 152
    .line 153
    .line 154
    invoke-virtual {p1, v0}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    .line 155
    .line 156
    .line 157
    move-result-object p1

    .line 158
    invoke-virtual {p2, p1}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    .line 159
    .line 160
    .line 161
    move-result-object p1

    .line 162
    invoke-virtual {p1, v6}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    .line 163
    .line 164
    .line 165
    move-result-object p1

    .line 166
    invoke-static {}, Lg5/h;->a()Landroid/app/NotificationManager;

    .line 167
    .line 168
    .line 169
    move-result-object p2

    .line 170
    const/4 v0, 0x4

    .line 171
    invoke-virtual {p1}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    .line 172
    .line 173
    .line 174
    move-result-object p1

    .line 175
    invoke-virtual {p2, v0, p1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    .line 176
    .line 177
    .line 178
    return-void

    .line 179
    :sswitch_1
    const-string p1, "android.intent.action.PACKAGE_FULLY_REMOVED"

    .line 180
    .line 181
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 182
    .line 183
    .line 184
    move-result p1

    .line 185
    if-nez p1, :cond_4

    .line 186
    .line 187
    goto/16 :goto_5

    .line 188
    .line 189
    :cond_4
    const-string p1, "android.intent.extra.PACKAGE_NAME"

    .line 190
    .line 191
    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    if-nez p1, :cond_6

    .line 196
    .line 197
    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 198
    .line 199
    .line 200
    move-result-object p1

    .line 201
    if-eqz p1, :cond_5

    .line 202
    .line 203
    invoke-virtual {p1}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object p1

    .line 207
    goto :goto_1

    .line 208
    :cond_5
    move-object p1, v7

    .line 209
    :cond_6
    :goto_1
    if-eqz p1, :cond_11

    .line 210
    .line 211
    const-string p2, "magisk --denylist rm "

    .line 212
    .line 213
    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 214
    .line 215
    .line 216
    move-result-object p1

    .line 217
    filled-new-array {p1}, [Ljava/lang/String;

    .line 218
    .line 219
    .line 220
    move-result-object p1

    .line 221
    invoke-static {p1}, Li5/f;->f([Ljava/lang/String;)Lj5/x;

    .line 222
    .line 223
    .line 224
    move-result-object p1

    .line 225
    invoke-virtual {p1, v7}, Lj5/x;->g(Li5/d;)V

    .line 226
    .line 227
    .line 228
    return-void

    .line 229
    :sswitch_2
    const-string v1, "com.topjohnwu.magisk.DOWNLOAD"

    .line 230
    .line 231
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 232
    .line 233
    .line 234
    move-result v0

    .line 235
    if-nez v0, :cond_7

    .line 236
    .line 237
    goto/16 :goto_5

    .line 238
    .line 239
    :cond_7
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 240
    .line 241
    const/16 v1, 0x22

    .line 242
    .line 243
    if-lt v0, v1, :cond_8

    .line 244
    .line 245
    invoke-static {p2}, Lg0/a;->a(Landroid/content/Intent;)Ljava/lang/Object;

    .line 246
    .line 247
    .line 248
    move-result-object v7

    .line 249
    goto :goto_2

    .line 250
    :cond_8
    const-string v0, "subject"

    .line 251
    .line 252
    invoke-virtual {p2, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 253
    .line 254
    .line 255
    move-result-object p2

    .line 256
    const-class v0, Lf4/k;

    .line 257
    .line 258
    invoke-virtual {v0, p2}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    .line 259
    .line 260
    .line 261
    move-result v0

    .line 262
    if-eqz v0, :cond_9

    .line 263
    .line 264
    move-object v7, p2

    .line 265
    :cond_9
    :goto_2
    check-cast v7, Lf4/k;

    .line 266
    .line 267
    if-eqz v7, :cond_11

    .line 268
    .line 269
    sget-object p2, Lf4/d;->r:Lk1/y;

    .line 270
    .line 271
    invoke-static {p1, v7}, Lf4/c;->c(Landroid/content/Context;Lf4/k;)V

    .line 272
    .line 273
    .line 274
    return-void

    .line 275
    :sswitch_3
    const-string p2, "android.intent.action.LOCALE_CHANGED"

    .line 276
    .line 277
    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 278
    .line 279
    .line 280
    move-result p2

    .line 281
    if-nez p2, :cond_a

    .line 282
    .line 283
    goto/16 :goto_5

    .line 284
    .line 285
    :cond_a
    invoke-static {p1}, Lf5/d;->y(Landroid/content/Context;)V

    .line 286
    .line 287
    .line 288
    return-void

    .line 289
    :sswitch_4
    const-string p1, "android.intent.action.PACKAGE_REPLACED"

    .line 290
    .line 291
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 292
    .line 293
    .line 294
    move-result p1

    .line 295
    if-nez p1, :cond_b

    .line 296
    .line 297
    goto/16 :goto_5

    .line 298
    .line 299
    :cond_b
    sget-object p1, La4/g;->a:La4/g;

    .line 300
    .line 301
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 302
    .line 303
    .line 304
    sget-object v0, La4/g;->C:Lk4/a;

    .line 305
    .line 306
    sget-object v1, La4/g;->b:[Lp6/b;

    .line 307
    .line 308
    const/16 v8, 0x16

    .line 309
    .line 310
    aget-object v1, v1, v8

    .line 311
    .line 312
    invoke-virtual {v0, p1, v1}, Lk4/a;->u0(La4/g;Lp6/b;)Ljava/lang/Boolean;

    .line 313
    .line 314
    .line 315
    move-result-object p1

    .line 316
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 317
    .line 318
    .line 319
    move-result p1

    .line 320
    if-eqz p1, :cond_11

    .line 321
    .line 322
    invoke-virtual {p2, v5, v4}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 323
    .line 324
    .line 325
    move-result p1

    .line 326
    if-ne p1, v4, :cond_c

    .line 327
    .line 328
    move-object p1, v7

    .line 329
    goto :goto_3

    .line 330
    :cond_c
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 331
    .line 332
    .line 333
    move-result-object p1

    .line 334
    :goto_3
    if-eqz p1, :cond_11

    .line 335
    .line 336
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 337
    .line 338
    .line 339
    move-result p1

    .line 340
    new-instance p2, La4/q;

    .line 341
    .line 342
    invoke-direct {p2, p0, p1, v7}, La4/q;-><init>(Lcom/topjohnwu/magisk/core/Receiver;ILz5/d;)V

    .line 343
    .line 344
    .line 345
    invoke-static {v3, v3, v6}, Lt6/t;->a(Lz5/h;Lz5/h;Z)Lz5/h;

    .line 346
    .line 347
    .line 348
    move-result-object p1

    .line 349
    sget-object v0, Lt6/a0;->a:La7/d;

    .line 350
    .line 351
    if-eq p1, v0, :cond_d

    .line 352
    .line 353
    invoke-interface {p1, v2}, Lz5/h;->A(Lz5/g;)Lz5/f;

    .line 354
    .line 355
    .line 356
    move-result-object v1

    .line 357
    if-nez v1, :cond_d

    .line 358
    .line 359
    invoke-interface {p1, v0}, Lz5/h;->z(Lz5/h;)Lz5/h;

    .line 360
    .line 361
    .line 362
    move-result-object p1

    .line 363
    :cond_d
    new-instance v0, Lt6/z0;

    .line 364
    .line 365
    invoke-direct {v0, p1, v6}, Lt6/a;-><init>(Lz5/h;Z)V

    .line 366
    .line 367
    .line 368
    invoke-virtual {v0, v6, v0, p2}, Lt6/a;->X(ILt6/a;Lj6/p;)V

    .line 369
    .line 370
    .line 371
    return-void

    .line 372
    :sswitch_5
    const-string p1, "android.intent.action.UID_REMOVED"

    .line 373
    .line 374
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 375
    .line 376
    .line 377
    move-result p1

    .line 378
    if-nez p1, :cond_e

    .line 379
    .line 380
    goto :goto_5

    .line 381
    :cond_e
    invoke-virtual {p2, v5, v4}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 382
    .line 383
    .line 384
    move-result p1

    .line 385
    if-ne p1, v4, :cond_f

    .line 386
    .line 387
    move-object p1, v7

    .line 388
    goto :goto_4

    .line 389
    :cond_f
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 390
    .line 391
    .line 392
    move-result-object p1

    .line 393
    :goto_4
    if-eqz p1, :cond_11

    .line 394
    .line 395
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 396
    .line 397
    .line 398
    move-result p1

    .line 399
    new-instance p2, La4/q;

    .line 400
    .line 401
    invoke-direct {p2, p0, p1, v7}, La4/q;-><init>(Lcom/topjohnwu/magisk/core/Receiver;ILz5/d;)V

    .line 402
    .line 403
    .line 404
    invoke-static {v3, v3, v6}, Lt6/t;->a(Lz5/h;Lz5/h;Z)Lz5/h;

    .line 405
    .line 406
    .line 407
    move-result-object p1

    .line 408
    sget-object v0, Lt6/a0;->a:La7/d;

    .line 409
    .line 410
    if-eq p1, v0, :cond_10

    .line 411
    .line 412
    invoke-interface {p1, v2}, Lz5/h;->A(Lz5/g;)Lz5/f;

    .line 413
    .line 414
    .line 415
    move-result-object v1

    .line 416
    if-nez v1, :cond_10

    .line 417
    .line 418
    invoke-interface {p1, v0}, Lz5/h;->z(Lz5/h;)Lz5/h;

    .line 419
    .line 420
    .line 421
    move-result-object p1

    .line 422
    :cond_10
    new-instance v0, Lt6/z0;

    .line 423
    .line 424
    invoke-direct {v0, p1, v6}, Lt6/a;-><init>(Lz5/h;Z)V

    .line 425
    .line 426
    .line 427
    invoke-virtual {v0, v6, v0, p2}, Lt6/a;->X(ILt6/a;Lj6/p;)V

    .line 428
    .line 429
    .line 430
    :cond_11
    :goto_5
    return-void

    .line 431
    :sswitch_data_0
    .sparse-switch
        -0x6849e2b4 -> :sswitch_5
        -0x304ed112 -> :sswitch_4
        -0x122164c -> :sswitch_3
        0x45301acb -> :sswitch_2
        0x5e33a4ad -> :sswitch_1
        0x6789a577 -> :sswitch_0
    .end sparse-switch
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
.end method
