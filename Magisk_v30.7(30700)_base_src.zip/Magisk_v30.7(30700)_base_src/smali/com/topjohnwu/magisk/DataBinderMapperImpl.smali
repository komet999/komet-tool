.class public Lcom/topjohnwu/magisk/DataBinderMapperImpl;
.super Lb1/b;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# static fields
.field public static final a:Landroid/util/SparseIntArray;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, Landroid/util/SparseIntArray;

    .line 2
    .line 3
    const/16 v1, 0x25

    .line 4
    .line 5
    invoke-direct {v0, v1}, Landroid/util/SparseIntArray;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lcom/topjohnwu/magisk/DataBinderMapperImpl;->a:Landroid/util/SparseIntArray;

    .line 9
    .line 10
    const v2, 0x7f0c001c

    .line 11
    .line 12
    .line 13
    const/4 v3, 0x1

    .line 14
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 15
    .line 16
    .line 17
    const v2, 0x7f0c001d

    .line 18
    .line 19
    .line 20
    const/4 v3, 0x2

    .line 21
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 22
    .line 23
    .line 24
    const v2, 0x7f0c002e

    .line 25
    .line 26
    .line 27
    const/4 v3, 0x3

    .line 28
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 29
    .line 30
    .line 31
    const v2, 0x7f0c002f

    .line 32
    .line 33
    .line 34
    const/4 v3, 0x4

    .line 35
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 36
    .line 37
    .line 38
    const v2, 0x7f0c0030

    .line 39
    .line 40
    .line 41
    const/4 v3, 0x5

    .line 42
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 43
    .line 44
    .line 45
    const v2, 0x7f0c0031

    .line 46
    .line 47
    .line 48
    const/4 v3, 0x6

    .line 49
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 50
    .line 51
    .line 52
    const v2, 0x7f0c0032

    .line 53
    .line 54
    .line 55
    const/4 v3, 0x7

    .line 56
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 57
    .line 58
    .line 59
    const v2, 0x7f0c0033

    .line 60
    .line 61
    .line 62
    const/16 v3, 0x8

    .line 63
    .line 64
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 65
    .line 66
    .line 67
    const v2, 0x7f0c0034

    .line 68
    .line 69
    .line 70
    const/16 v3, 0x9

    .line 71
    .line 72
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 73
    .line 74
    .line 75
    const v2, 0x7f0c0035

    .line 76
    .line 77
    .line 78
    const/16 v3, 0xa

    .line 79
    .line 80
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 81
    .line 82
    .line 83
    const v2, 0x7f0c0036

    .line 84
    .line 85
    .line 86
    const/16 v3, 0xb

    .line 87
    .line 88
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 89
    .line 90
    .line 91
    const v2, 0x7f0c0037

    .line 92
    .line 93
    .line 94
    const/16 v3, 0xc

    .line 95
    .line 96
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 97
    .line 98
    .line 99
    const v2, 0x7f0c0038

    .line 100
    .line 101
    .line 102
    const/16 v3, 0xd

    .line 103
    .line 104
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 105
    .line 106
    .line 107
    const v2, 0x7f0c0039

    .line 108
    .line 109
    .line 110
    const/16 v3, 0xe

    .line 111
    .line 112
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 113
    .line 114
    .line 115
    const v2, 0x7f0c003a

    .line 116
    .line 117
    .line 118
    const/16 v3, 0xf

    .line 119
    .line 120
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 121
    .line 122
    .line 123
    const v2, 0x7f0c003b

    .line 124
    .line 125
    .line 126
    const/16 v3, 0x10

    .line 127
    .line 128
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 129
    .line 130
    .line 131
    const v2, 0x7f0c003e

    .line 132
    .line 133
    .line 134
    const/16 v3, 0x11

    .line 135
    .line 136
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 137
    .line 138
    .line 139
    const v2, 0x7f0c003f

    .line 140
    .line 141
    .line 142
    const/16 v3, 0x12

    .line 143
    .line 144
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 145
    .line 146
    .line 147
    const v2, 0x7f0c0040

    .line 148
    .line 149
    .line 150
    const/16 v3, 0x13

    .line 151
    .line 152
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 153
    .line 154
    .line 155
    const v2, 0x7f0c0041

    .line 156
    .line 157
    .line 158
    const/16 v3, 0x14

    .line 159
    .line 160
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 161
    .line 162
    .line 163
    const v2, 0x7f0c0042

    .line 164
    .line 165
    .line 166
    const/16 v3, 0x15

    .line 167
    .line 168
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 169
    .line 170
    .line 171
    const v2, 0x7f0c0043

    .line 172
    .line 173
    .line 174
    const/16 v3, 0x16

    .line 175
    .line 176
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 177
    .line 178
    .line 179
    const v2, 0x7f0c0044

    .line 180
    .line 181
    .line 182
    const/16 v3, 0x17

    .line 183
    .line 184
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 185
    .line 186
    .line 187
    const v2, 0x7f0c0045

    .line 188
    .line 189
    .line 190
    const/16 v3, 0x18

    .line 191
    .line 192
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 193
    .line 194
    .line 195
    const v2, 0x7f0c0046

    .line 196
    .line 197
    .line 198
    const/16 v3, 0x19

    .line 199
    .line 200
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 201
    .line 202
    .line 203
    const v2, 0x7f0c0047

    .line 204
    .line 205
    .line 206
    const/16 v3, 0x1a

    .line 207
    .line 208
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 209
    .line 210
    .line 211
    const v2, 0x7f0c0048

    .line 212
    .line 213
    .line 214
    const/16 v3, 0x1b

    .line 215
    .line 216
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 217
    .line 218
    .line 219
    const v2, 0x7f0c0049

    .line 220
    .line 221
    .line 222
    const/16 v3, 0x1c

    .line 223
    .line 224
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 225
    .line 226
    .line 227
    const v2, 0x7f0c004a

    .line 228
    .line 229
    .line 230
    const/16 v3, 0x1d

    .line 231
    .line 232
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 233
    .line 234
    .line 235
    const v2, 0x7f0c004b

    .line 236
    .line 237
    .line 238
    const/16 v3, 0x1e

    .line 239
    .line 240
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 241
    .line 242
    .line 243
    const v2, 0x7f0c004c

    .line 244
    .line 245
    .line 246
    const/16 v3, 0x1f

    .line 247
    .line 248
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 249
    .line 250
    .line 251
    const v2, 0x7f0c004d

    .line 252
    .line 253
    .line 254
    const/16 v3, 0x20

    .line 255
    .line 256
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 257
    .line 258
    .line 259
    const v2, 0x7f0c004e

    .line 260
    .line 261
    .line 262
    const/16 v3, 0x21

    .line 263
    .line 264
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 265
    .line 266
    .line 267
    const v2, 0x7f0c004f

    .line 268
    .line 269
    .line 270
    const/16 v3, 0x22

    .line 271
    .line 272
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 273
    .line 274
    .line 275
    const v2, 0x7f0c0051

    .line 276
    .line 277
    .line 278
    const/16 v3, 0x23

    .line 279
    .line 280
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 281
    .line 282
    .line 283
    const v2, 0x7f0c0052

    .line 284
    .line 285
    .line 286
    const/16 v3, 0x24

    .line 287
    .line 288
    invoke-virtual {v0, v2, v3}, Landroid/util/SparseIntArray;->put(II)V

    .line 289
    .line 290
    .line 291
    const v2, 0x7f0c0053

    .line 292
    .line 293
    .line 294
    invoke-virtual {v0, v2, v1}, Landroid/util/SparseIntArray;->put(II)V

    .line 295
    .line 296
    .line 297
    return-void
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
.end method


# virtual methods
.method public final a()Ljava/util/List;
    .locals 2

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 5
    .line 6
    .line 7
    new-instance v1, Landroidx/databinding/library/baseAdapters/DataBinderMapperImpl;

    .line 8
    .line 9
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    return-object v0
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final b(Landroid/view/View;I)Lb1/w;
    .locals 4

    .line 1
    sget-object v0, Lcom/topjohnwu/magisk/DataBinderMapperImpl;->a:Landroid/util/SparseIntArray;

    .line 2
    .line 3
    invoke-virtual {v0, p2}, Landroid/util/SparseIntArray;->get(I)I

    .line 4
    .line 5
    .line 6
    move-result p2

    .line 7
    const/4 v0, 0x0

    .line 8
    if-lez p2, :cond_26

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    if-eqz v1, :cond_25

    .line 15
    .line 16
    packed-switch p2, :pswitch_data_0

    .line 17
    .line 18
    .line 19
    goto/16 :goto_0

    .line 20
    .line 21
    :pswitch_0
    const-string p2, "layout/item_theme_0"

    .line 22
    .line 23
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result p2

    .line 27
    if-eqz p2, :cond_0

    .line 28
    .line 29
    new-instance p2, Lp4/u0;

    .line 30
    .line 31
    invoke-direct {p2, p1}, Lp4/u0;-><init>(Landroid/view/View;)V

    .line 32
    .line 33
    .line 34
    return-object p2

    .line 35
    :cond_0
    const-string p1, "The tag for item_theme is invalid. Received: "

    .line 36
    .line 37
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    return-object v0

    .line 45
    :pswitch_1
    const-string p2, "layout/item_text_0"

    .line 46
    .line 47
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result p2

    .line 51
    if-eqz p2, :cond_1

    .line 52
    .line 53
    new-instance p2, Lp4/s0;

    .line 54
    .line 55
    invoke-direct {p2, p1}, Lp4/s0;-><init>(Landroid/view/View;)V

    .line 56
    .line 57
    .line 58
    return-object p2

    .line 59
    :cond_1
    const-string p1, "The tag for item_text is invalid. Received: "

    .line 60
    .line 61
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    return-object v0

    .line 69
    :pswitch_2
    const-string p2, "layout/item_tappable_headline_0"

    .line 70
    .line 71
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 72
    .line 73
    .line 74
    move-result p2

    .line 75
    if-eqz p2, :cond_2

    .line 76
    .line 77
    new-instance p2, Lp4/r0;

    .line 78
    .line 79
    invoke-direct {p2, p1}, Lp4/r0;-><init>(Landroid/view/View;)V

    .line 80
    .line 81
    .line 82
    return-object p2

    .line 83
    :cond_2
    const-string p1, "The tag for item_tappable_headline is invalid. Received: "

    .line 84
    .line 85
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object p1

    .line 89
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    return-object v0

    .line 93
    :pswitch_3
    const-string p2, "layout/item_settings_section_0"

    .line 94
    .line 95
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    move-result p2

    .line 99
    if-eqz p2, :cond_3

    .line 100
    .line 101
    new-instance p2, Lp4/q0;

    .line 102
    .line 103
    invoke-direct {p2, p1}, Lp4/q0;-><init>(Landroid/view/View;)V

    .line 104
    .line 105
    .line 106
    return-object p2

    .line 107
    :cond_3
    const-string p1, "The tag for item_settings_section is invalid. Received: "

    .line 108
    .line 109
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    return-object v0

    .line 117
    :pswitch_4
    const-string p2, "layout/item_settings_0"

    .line 118
    .line 119
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 120
    .line 121
    .line 122
    move-result p2

    .line 123
    if-eqz p2, :cond_4

    .line 124
    .line 125
    new-instance p2, Lp4/p0;

    .line 126
    .line 127
    invoke-direct {p2, p1}, Lp4/p0;-><init>(Landroid/view/View;)V

    .line 128
    .line 129
    .line 130
    return-object p2

    .line 131
    :cond_4
    const-string p1, "The tag for item_settings is invalid. Received: "

    .line 132
    .line 133
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object p1

    .line 137
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    return-object v0

    .line 141
    :pswitch_5
    const-string p2, "layout/item_policy_md2_0"

    .line 142
    .line 143
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    move-result p2

    .line 147
    if-eqz p2, :cond_5

    .line 148
    .line 149
    new-instance p2, Lp4/o0;

    .line 150
    .line 151
    invoke-direct {p2, p1}, Lp4/o0;-><init>(Landroid/view/View;)V

    .line 152
    .line 153
    .line 154
    return-object p2

    .line 155
    :cond_5
    const-string p1, "The tag for item_policy_md2 is invalid. Received: "

    .line 156
    .line 157
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object p1

    .line 161
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    return-object v0

    .line 165
    :pswitch_6
    const-string p2, "layout/item_module_md2_0"

    .line 166
    .line 167
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    move-result p2

    .line 171
    if-eqz p2, :cond_6

    .line 172
    .line 173
    new-instance p2, Lp4/m0;

    .line 174
    .line 175
    invoke-direct {p2, p1}, Lp4/m0;-><init>(Landroid/view/View;)V

    .line 176
    .line 177
    .line 178
    return-object p2

    .line 179
    :cond_6
    const-string p1, "The tag for item_module_md2 is invalid. Received: "

    .line 180
    .line 181
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object p1

    .line 185
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 186
    .line 187
    .line 188
    return-object v0

    .line 189
    :pswitch_7
    const-string p2, "layout/item_module_download_0"

    .line 190
    .line 191
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 192
    .line 193
    .line 194
    move-result p2

    .line 195
    if-eqz p2, :cond_7

    .line 196
    .line 197
    new-instance p2, Lp4/l0;

    .line 198
    .line 199
    invoke-direct {p2, p1}, Lp4/l0;-><init>(Landroid/view/View;)V

    .line 200
    .line 201
    .line 202
    return-object p2

    .line 203
    :cond_7
    const-string p1, "The tag for item_module_download is invalid. Received: "

    .line 204
    .line 205
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 206
    .line 207
    .line 208
    move-result-object p1

    .line 209
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 210
    .line 211
    .line 212
    return-object v0

    .line 213
    :pswitch_8
    const-string p2, "layout/item_log_track_md2_0"

    .line 214
    .line 215
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 216
    .line 217
    .line 218
    move-result p2

    .line 219
    if-eqz p2, :cond_8

    .line 220
    .line 221
    new-instance p2, Lp4/k0;

    .line 222
    .line 223
    invoke-direct {p2, p1}, Lp4/k0;-><init>(Landroid/view/View;)V

    .line 224
    .line 225
    .line 226
    return-object p2

    .line 227
    :cond_8
    const-string p1, "The tag for item_log_track_md2 is invalid. Received: "

    .line 228
    .line 229
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 230
    .line 231
    .line 232
    move-result-object p1

    .line 233
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 234
    .line 235
    .line 236
    return-object v0

    .line 237
    :pswitch_9
    const-string p2, "layout/item_log_textview_0"

    .line 238
    .line 239
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 240
    .line 241
    .line 242
    move-result p2

    .line 243
    if-eqz p2, :cond_9

    .line 244
    .line 245
    new-instance p2, Lp4/j0;

    .line 246
    .line 247
    invoke-direct {p2, p1}, Lp4/j0;-><init>(Landroid/view/View;)V

    .line 248
    .line 249
    .line 250
    return-object p2

    .line 251
    :cond_9
    const-string p1, "The tag for item_log_textview is invalid. Received: "

    .line 252
    .line 253
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 254
    .line 255
    .line 256
    move-result-object p1

    .line 257
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 258
    .line 259
    .line 260
    return-object v0

    .line 261
    :pswitch_a
    const-string p2, "layout/item_log_access_md2_0"

    .line 262
    .line 263
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 264
    .line 265
    .line 266
    move-result p2

    .line 267
    if-eqz p2, :cond_a

    .line 268
    .line 269
    new-instance p2, Lp4/i0;

    .line 270
    .line 271
    invoke-direct {p2, p1}, Lp4/i0;-><init>(Landroid/view/View;)V

    .line 272
    .line 273
    .line 274
    return-object p2

    .line 275
    :cond_a
    const-string p1, "The tag for item_log_access_md2 is invalid. Received: "

    .line 276
    .line 277
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 278
    .line 279
    .line 280
    move-result-object p1

    .line 281
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 282
    .line 283
    .line 284
    return-object v0

    .line 285
    :pswitch_b
    const-string p2, "layout/item_list_single_line_0"

    .line 286
    .line 287
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 288
    .line 289
    .line 290
    move-result p2

    .line 291
    if-eqz p2, :cond_b

    .line 292
    .line 293
    new-instance p2, Lp4/h0;

    .line 294
    .line 295
    invoke-direct {p2, p1}, Lp4/h0;-><init>(Landroid/view/View;)V

    .line 296
    .line 297
    .line 298
    return-object p2

    .line 299
    :cond_b
    const-string p1, "The tag for item_list_single_line is invalid. Received: "

    .line 300
    .line 301
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 302
    .line 303
    .line 304
    move-result-object p1

    .line 305
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 306
    .line 307
    .line 308
    return-object v0

    .line 309
    :pswitch_c
    const-string p2, "layout/item_icon_link_0"

    .line 310
    .line 311
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 312
    .line 313
    .line 314
    move-result p2

    .line 315
    if-eqz p2, :cond_c

    .line 316
    .line 317
    new-instance p2, Lp4/g0;

    .line 318
    .line 319
    invoke-direct {p2, p1}, Lp4/g0;-><init>(Landroid/view/View;)V

    .line 320
    .line 321
    .line 322
    return-object p2

    .line 323
    :cond_c
    const-string p1, "The tag for item_icon_link is invalid. Received: "

    .line 324
    .line 325
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 326
    .line 327
    .line 328
    move-result-object p1

    .line 329
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 330
    .line 331
    .line 332
    return-object v0

    .line 333
    :pswitch_d
    const-string p2, "layout/item_hide_process_md2_0"

    .line 334
    .line 335
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 336
    .line 337
    .line 338
    move-result p2

    .line 339
    if-eqz p2, :cond_d

    .line 340
    .line 341
    new-instance p2, Lp4/f0;

    .line 342
    .line 343
    invoke-direct {p2, p1}, Lp4/f0;-><init>(Landroid/view/View;)V

    .line 344
    .line 345
    .line 346
    return-object p2

    .line 347
    :cond_d
    const-string p1, "The tag for item_hide_process_md2 is invalid. Received: "

    .line 348
    .line 349
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 350
    .line 351
    .line 352
    move-result-object p1

    .line 353
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 354
    .line 355
    .line 356
    return-object v0

    .line 357
    :pswitch_e
    const-string p2, "layout/item_hide_md2_0"

    .line 358
    .line 359
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 360
    .line 361
    .line 362
    move-result p2

    .line 363
    if-eqz p2, :cond_e

    .line 364
    .line 365
    new-instance p2, Lp4/e0;

    .line 366
    .line 367
    invoke-direct {p2, p1}, Lp4/e0;-><init>(Landroid/view/View;)V

    .line 368
    .line 369
    .line 370
    return-object p2

    .line 371
    :cond_e
    const-string p1, "The tag for item_hide_md2 is invalid. Received: "

    .line 372
    .line 373
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 374
    .line 375
    .line 376
    move-result-object p1

    .line 377
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 378
    .line 379
    .line 380
    return-object v0

    .line 381
    :pswitch_f
    const-string p2, "layout/item_developer_0"

    .line 382
    .line 383
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 384
    .line 385
    .line 386
    move-result p2

    .line 387
    if-eqz p2, :cond_f

    .line 388
    .line 389
    new-instance p2, Lp4/d0;

    .line 390
    .line 391
    invoke-direct {p2, p1}, Lp4/d0;-><init>(Landroid/view/View;)V

    .line 392
    .line 393
    .line 394
    return-object p2

    .line 395
    :cond_f
    const-string p1, "The tag for item_developer is invalid. Received: "

    .line 396
    .line 397
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 398
    .line 399
    .line 400
    move-result-object p1

    .line 401
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 402
    .line 403
    .line 404
    return-object v0

    .line 405
    :pswitch_10
    const-string p2, "layout/item_console_md2_0"

    .line 406
    .line 407
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 408
    .line 409
    .line 410
    move-result p2

    .line 411
    if-eqz p2, :cond_10

    .line 412
    .line 413
    new-instance p2, Lp4/c0;

    .line 414
    .line 415
    invoke-direct {p2, p1}, Lp4/c0;-><init>(Landroid/view/View;)V

    .line 416
    .line 417
    .line 418
    return-object p2

    .line 419
    :cond_10
    const-string p1, "The tag for item_console_md2 is invalid. Received: "

    .line 420
    .line 421
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 422
    .line 423
    .line 424
    move-result-object p1

    .line 425
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 426
    .line 427
    .line 428
    return-object v0

    .line 429
    :pswitch_11
    const-string p2, "layout/include_log_superuser_0"

    .line 430
    .line 431
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 432
    .line 433
    .line 434
    move-result p2

    .line 435
    if-eqz p2, :cond_11

    .line 436
    .line 437
    new-instance p2, Lp4/b0;

    .line 438
    .line 439
    invoke-direct {p2, p1}, Lp4/b0;-><init>(Landroid/view/View;)V

    .line 440
    .line 441
    .line 442
    return-object p2

    .line 443
    :cond_11
    const-string p1, "The tag for include_log_superuser is invalid. Received: "

    .line 444
    .line 445
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 446
    .line 447
    .line 448
    move-result-object p1

    .line 449
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 450
    .line 451
    .line 452
    return-object v0

    .line 453
    :pswitch_12
    const-string p2, "layout/include_log_magisk_0"

    .line 454
    .line 455
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 456
    .line 457
    .line 458
    move-result p2

    .line 459
    if-eqz p2, :cond_12

    .line 460
    .line 461
    new-instance p2, Lp4/a0;

    .line 462
    .line 463
    invoke-direct {p2, p1}, Lp4/a0;-><init>(Landroid/view/View;)V

    .line 464
    .line 465
    .line 466
    return-object p2

    .line 467
    :cond_12
    const-string p1, "The tag for include_log_magisk is invalid. Received: "

    .line 468
    .line 469
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 470
    .line 471
    .line 472
    move-result-object p1

    .line 473
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 474
    .line 475
    .line 476
    return-object v0

    .line 477
    :pswitch_13
    const-string p2, "layout/include_home_manager_0"

    .line 478
    .line 479
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 480
    .line 481
    .line 482
    move-result p2

    .line 483
    if-eqz p2, :cond_13

    .line 484
    .line 485
    new-instance p2, Lp4/z;

    .line 486
    .line 487
    invoke-direct {p2, p1}, Lp4/z;-><init>(Landroid/view/View;)V

    .line 488
    .line 489
    .line 490
    return-object p2

    .line 491
    :cond_13
    const-string p1, "The tag for include_home_manager is invalid. Received: "

    .line 492
    .line 493
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 494
    .line 495
    .line 496
    move-result-object p1

    .line 497
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 498
    .line 499
    .line 500
    return-object v0

    .line 501
    :pswitch_14
    const-string p2, "layout/include_home_magisk_0"

    .line 502
    .line 503
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 504
    .line 505
    .line 506
    move-result p2

    .line 507
    if-eqz p2, :cond_14

    .line 508
    .line 509
    new-instance p2, Lp4/y;

    .line 510
    .line 511
    invoke-direct {p2, p1}, Lp4/y;-><init>(Landroid/view/View;)V

    .line 512
    .line 513
    .line 514
    return-object p2

    .line 515
    :cond_14
    const-string p1, "The tag for include_home_magisk is invalid. Received: "

    .line 516
    .line 517
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 518
    .line 519
    .line 520
    move-result-object p1

    .line 521
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 522
    .line 523
    .line 524
    return-object v0

    .line 525
    :pswitch_15
    const-string p2, "layout/fragment_theme_md2_0"

    .line 526
    .line 527
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 528
    .line 529
    .line 530
    move-result p2

    .line 531
    if-eqz p2, :cond_15

    .line 532
    .line 533
    new-instance p2, Lp4/x;

    .line 534
    .line 535
    invoke-direct {p2, p1}, Lp4/x;-><init>(Landroid/view/View;)V

    .line 536
    .line 537
    .line 538
    return-object p2

    .line 539
    :cond_15
    const-string p1, "The tag for fragment_theme_md2 is invalid. Received: "

    .line 540
    .line 541
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 542
    .line 543
    .line 544
    move-result-object p1

    .line 545
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 546
    .line 547
    .line 548
    return-object v0

    .line 549
    :pswitch_16
    const-string p2, "layout/fragment_superuser_md2_0"

    .line 550
    .line 551
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 552
    .line 553
    .line 554
    move-result p2

    .line 555
    if-eqz p2, :cond_16

    .line 556
    .line 557
    new-instance p2, Lp4/w;

    .line 558
    .line 559
    invoke-direct {p2, p1}, Lp4/w;-><init>(Landroid/view/View;)V

    .line 560
    .line 561
    .line 562
    return-object p2

    .line 563
    :cond_16
    const-string p1, "The tag for fragment_superuser_md2 is invalid. Received: "

    .line 564
    .line 565
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 566
    .line 567
    .line 568
    move-result-object p1

    .line 569
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 570
    .line 571
    .line 572
    return-object v0

    .line 573
    :pswitch_17
    const-string p2, "layout/fragment_settings_md2_0"

    .line 574
    .line 575
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 576
    .line 577
    .line 578
    move-result p2

    .line 579
    if-eqz p2, :cond_17

    .line 580
    .line 581
    new-instance p2, Lp4/v;

    .line 582
    .line 583
    invoke-direct {p2, p1}, Lp4/v;-><init>(Landroid/view/View;)V

    .line 584
    .line 585
    .line 586
    return-object p2

    .line 587
    :cond_17
    const-string p1, "The tag for fragment_settings_md2 is invalid. Received: "

    .line 588
    .line 589
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 590
    .line 591
    .line 592
    move-result-object p1

    .line 593
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 594
    .line 595
    .line 596
    return-object v0

    .line 597
    :pswitch_18
    const-string p2, "layout/fragment_module_md2_0"

    .line 598
    .line 599
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 600
    .line 601
    .line 602
    move-result p2

    .line 603
    if-eqz p2, :cond_18

    .line 604
    .line 605
    new-instance p2, Lp4/u;

    .line 606
    .line 607
    invoke-direct {p2, p1}, Lp4/u;-><init>(Landroid/view/View;)V

    .line 608
    .line 609
    .line 610
    return-object p2

    .line 611
    :cond_18
    const-string p1, "The tag for fragment_module_md2 is invalid. Received: "

    .line 612
    .line 613
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 614
    .line 615
    .line 616
    move-result-object p1

    .line 617
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 618
    .line 619
    .line 620
    return-object v0

    .line 621
    :pswitch_19
    const-string p2, "layout/fragment_log_md2_0"

    .line 622
    .line 623
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 624
    .line 625
    .line 626
    move-result p2

    .line 627
    if-eqz p2, :cond_19

    .line 628
    .line 629
    new-instance p2, Lp4/t;

    .line 630
    .line 631
    invoke-direct {p2, p1}, Lp4/t;-><init>(Landroid/view/View;)V

    .line 632
    .line 633
    .line 634
    return-object p2

    .line 635
    :cond_19
    const-string p1, "The tag for fragment_log_md2 is invalid. Received: "

    .line 636
    .line 637
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 638
    .line 639
    .line 640
    move-result-object p1

    .line 641
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 642
    .line 643
    .line 644
    return-object v0

    .line 645
    :pswitch_1a
    const-string p2, "layout/fragment_install_md2_0"

    .line 646
    .line 647
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 648
    .line 649
    .line 650
    move-result p2

    .line 651
    if-eqz p2, :cond_1a

    .line 652
    .line 653
    new-instance p2, Lp4/s;

    .line 654
    .line 655
    invoke-direct {p2, p1}, Lp4/s;-><init>(Landroid/view/View;)V

    .line 656
    .line 657
    .line 658
    return-object p2

    .line 659
    :cond_1a
    const-string p1, "The tag for fragment_install_md2 is invalid. Received: "

    .line 660
    .line 661
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 662
    .line 663
    .line 664
    move-result-object p1

    .line 665
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 666
    .line 667
    .line 668
    return-object v0

    .line 669
    :pswitch_1b
    const-string p2, "layout/fragment_home_md2_0"

    .line 670
    .line 671
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 672
    .line 673
    .line 674
    move-result p2

    .line 675
    if-eqz p2, :cond_1b

    .line 676
    .line 677
    new-instance p2, Lp4/q;

    .line 678
    .line 679
    invoke-direct {p2, p1}, Lp4/q;-><init>(Landroid/view/View;)V

    .line 680
    .line 681
    .line 682
    return-object p2

    .line 683
    :cond_1b
    const-string p1, "The tag for fragment_home_md2 is invalid. Received: "

    .line 684
    .line 685
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 686
    .line 687
    .line 688
    move-result-object p1

    .line 689
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 690
    .line 691
    .line 692
    return-object v0

    .line 693
    :pswitch_1c
    const-string p2, "layout/fragment_flash_md2_0"

    .line 694
    .line 695
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 696
    .line 697
    .line 698
    move-result p2

    .line 699
    if-eqz p2, :cond_1c

    .line 700
    .line 701
    new-instance p2, Lp4/p;

    .line 702
    .line 703
    invoke-direct {p2, p1}, Lp4/p;-><init>(Landroid/view/View;)V

    .line 704
    .line 705
    .line 706
    return-object p2

    .line 707
    :cond_1c
    const-string p1, "The tag for fragment_flash_md2 is invalid. Received: "

    .line 708
    .line 709
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 710
    .line 711
    .line 712
    move-result-object p1

    .line 713
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 714
    .line 715
    .line 716
    return-object v0

    .line 717
    :pswitch_1d
    const-string p2, "layout/fragment_deny_md2_0"

    .line 718
    .line 719
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 720
    .line 721
    .line 722
    move-result p2

    .line 723
    if-eqz p2, :cond_1d

    .line 724
    .line 725
    new-instance p2, Lp4/o;

    .line 726
    .line 727
    invoke-direct {p2, p1}, Lp4/o;-><init>(Landroid/view/View;)V

    .line 728
    .line 729
    .line 730
    return-object p2

    .line 731
    :cond_1d
    const-string p1, "The tag for fragment_deny_md2 is invalid. Received: "

    .line 732
    .line 733
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 734
    .line 735
    .line 736
    move-result-object p1

    .line 737
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 738
    .line 739
    .line 740
    return-object v0

    .line 741
    :pswitch_1e
    const-string p2, "layout/fragment_action_md2_0"

    .line 742
    .line 743
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 744
    .line 745
    .line 746
    move-result p2

    .line 747
    if-eqz p2, :cond_1e

    .line 748
    .line 749
    new-instance p2, Lp4/n;

    .line 750
    .line 751
    invoke-direct {p2, p1}, Lp4/n;-><init>(Landroid/view/View;)V

    .line 752
    .line 753
    .line 754
    return-object p2

    .line 755
    :cond_1e
    const-string p1, "The tag for fragment_action_md2 is invalid. Received: "

    .line 756
    .line 757
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 758
    .line 759
    .line 760
    move-result-object p1

    .line 761
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 762
    .line 763
    .line 764
    return-object v0

    .line 765
    :pswitch_1f
    const-string p2, "layout/dialog_settings_update_channel_0"

    .line 766
    .line 767
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 768
    .line 769
    .line 770
    move-result p2

    .line 771
    if-eqz p2, :cond_1f

    .line 772
    .line 773
    new-instance p2, Lp4/i;

    .line 774
    .line 775
    const/4 v1, 0x2

    .line 776
    invoke-static {p1, v1, v0, v0}, Lb1/w;->l(Landroid/view/View;ILb1/r;Landroid/util/SparseIntArray;)[Ljava/lang/Object;

    .line 777
    .line 778
    .line 779
    move-result-object v1

    .line 780
    const/4 v2, 0x1

    .line 781
    aget-object v2, v1, v2

    .line 782
    .line 783
    check-cast v2, Lcom/google/android/material/textfield/TextInputEditText;

    .line 784
    .line 785
    invoke-direct {p2, v0, p1, v2}, Lp4/i;-><init>(Lb1/c;Landroid/view/View;Lcom/google/android/material/textfield/TextInputEditText;)V

    .line 786
    .line 787
    .line 788
    new-instance v2, Lm1/c;

    .line 789
    .line 790
    const/16 v3, 0xc

    .line 791
    .line 792
    invoke-direct {v2, v3, p2}, Lm1/c;-><init>(ILjava/lang/Object;)V

    .line 793
    .line 794
    .line 795
    iput-object v2, p2, Lp4/i;->K:Lm1/c;

    .line 796
    .line 797
    const-wide/16 v2, -0x1

    .line 798
    .line 799
    iput-wide v2, p2, Lp4/i;->L:J

    .line 800
    .line 801
    iget-object v2, p2, Lp4/i;->I:Lcom/google/android/material/textfield/TextInputEditText;

    .line 802
    .line 803
    invoke-virtual {v2, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 804
    .line 805
    .line 806
    const/4 v2, 0x0

    .line 807
    aget-object v1, v1, v2

    .line 808
    .line 809
    check-cast v1, Landroid/widget/LinearLayout;

    .line 810
    .line 811
    invoke-virtual {v1, v0}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 812
    .line 813
    .line 814
    const v0, 0x7f0900af

    .line 815
    .line 816
    .line 817
    invoke-virtual {p1, v0, p2}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 818
    .line 819
    .line 820
    monitor-enter p2

    .line 821
    const-wide/16 v0, 0x2

    .line 822
    .line 823
    :try_start_0
    iput-wide v0, p2, Lp4/i;->L:J

    .line 824
    .line 825
    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 826
    invoke-virtual {p2}, Lb1/w;->p()V

    .line 827
    .line 828
    .line 829
    return-object p2

    .line 830
    :catchall_0
    move-exception p1

    .line 831
    :try_start_1
    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 832
    throw p1

    .line 833
    :cond_1f
    const-string p1, "The tag for dialog_settings_update_channel is invalid. Received: "

    .line 834
    .line 835
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 836
    .line 837
    .line 838
    move-result-object p1

    .line 839
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 840
    .line 841
    .line 842
    return-object v0

    .line 843
    :pswitch_20
    const-string p2, "layout/dialog_settings_download_path_0"

    .line 844
    .line 845
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 846
    .line 847
    .line 848
    move-result p2

    .line 849
    if-eqz p2, :cond_20

    .line 850
    .line 851
    new-instance p2, Lp4/h;

    .line 852
    .line 853
    invoke-direct {p2, p1}, Lp4/h;-><init>(Landroid/view/View;)V

    .line 854
    .line 855
    .line 856
    return-object p2

    .line 857
    :cond_20
    const-string p1, "The tag for dialog_settings_download_path is invalid. Received: "

    .line 858
    .line 859
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 860
    .line 861
    .line 862
    move-result-object p1

    .line 863
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 864
    .line 865
    .line 866
    return-object v0

    .line 867
    :pswitch_21
    const-string p2, "layout/dialog_settings_app_name_0"

    .line 868
    .line 869
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 870
    .line 871
    .line 872
    move-result p2

    .line 873
    if-eqz p2, :cond_21

    .line 874
    .line 875
    new-instance p2, Lp4/g;

    .line 876
    .line 877
    invoke-direct {p2, p1}, Lp4/g;-><init>(Landroid/view/View;)V

    .line 878
    .line 879
    .line 880
    return-object p2

    .line 881
    :cond_21
    const-string p1, "The tag for dialog_settings_app_name is invalid. Received: "

    .line 882
    .line 883
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 884
    .line 885
    .line 886
    move-result-object p1

    .line 887
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 888
    .line 889
    .line 890
    return-object v0

    .line 891
    :pswitch_22
    const-string p2, "layout/dialog_magisk_base_0"

    .line 892
    .line 893
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 894
    .line 895
    .line 896
    move-result p2

    .line 897
    if-eqz p2, :cond_22

    .line 898
    .line 899
    new-instance p2, Lp4/f;

    .line 900
    .line 901
    invoke-direct {p2, p1}, Lp4/f;-><init>(Landroid/view/View;)V

    .line 902
    .line 903
    .line 904
    return-object p2

    .line 905
    :cond_22
    const-string p1, "The tag for dialog_magisk_base is invalid. Received: "

    .line 906
    .line 907
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 908
    .line 909
    .line 910
    move-result-object p1

    .line 911
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 912
    .line 913
    .line 914
    return-object v0

    .line 915
    :pswitch_23
    const-string p2, "layout/activity_request_0"

    .line 916
    .line 917
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 918
    .line 919
    .line 920
    move-result p2

    .line 921
    if-eqz p2, :cond_23

    .line 922
    .line 923
    new-instance p2, Lp4/b;

    .line 924
    .line 925
    invoke-direct {p2, p1}, Lp4/b;-><init>(Landroid/view/View;)V

    .line 926
    .line 927
    .line 928
    return-object p2

    .line 929
    :cond_23
    const-string p1, "The tag for activity_request is invalid. Received: "

    .line 930
    .line 931
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 932
    .line 933
    .line 934
    move-result-object p1

    .line 935
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 936
    .line 937
    .line 938
    return-object v0

    .line 939
    :pswitch_24
    const-string p2, "layout/activity_main_md2_0"

    .line 940
    .line 941
    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 942
    .line 943
    .line 944
    move-result p2

    .line 945
    if-eqz p2, :cond_24

    .line 946
    .line 947
    new-instance p2, Lp4/a;

    .line 948
    .line 949
    invoke-direct {p2, p1}, Lp4/a;-><init>(Landroid/view/View;)V

    .line 950
    .line 951
    .line 952
    return-object p2

    .line 953
    :cond_24
    const-string p1, "The tag for activity_main_md2 is invalid. Received: "

    .line 954
    .line 955
    invoke-static {v1, p1}, Ly/d;->b(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    .line 956
    .line 957
    .line 958
    move-result-object p1

    .line 959
    invoke-static {p1}, Lq0/b;->g(Ljava/lang/String;)V

    .line 960
    .line 961
    .line 962
    return-object v0

    .line 963
    :cond_25
    new-instance p1, Ljava/lang/RuntimeException;

    .line 964
    .line 965
    const-string p2, "view must have a tag"

    .line 966
    .line 967
    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 968
    .line 969
    .line 970
    throw p1

    .line 971
    :cond_26
    :goto_0
    return-object v0

    .line 972
    nop

    .line 973
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
    .line 2155
    .line 2156
    .line 2157
    .line 2158
    .line 2159
    .line 2160
    .line 2161
    .line 2162
    .line 2163
    .line 2164
    .line 2165
    .line 2166
    .line 2167
    .line 2168
    .line 2169
    .line 2170
    .line 2171
    .line 2172
    .line 2173
    .line 2174
    .line 2175
    .line 2176
    .line 2177
    .line 2178
    .line 2179
    .line 2180
    .line 2181
    .line 2182
    .line 2183
    .line 2184
    .line 2185
    .line 2186
    .line 2187
    .line 2188
    .line 2189
    .line 2190
    .line 2191
    .line 2192
    .line 2193
    .line 2194
    .line 2195
    .line 2196
    .line 2197
    .line 2198
    .line 2199
    .line 2200
    .line 2201
    .line 2202
    .line 2203
    .line 2204
    .line 2205
    .line 2206
    .line 2207
    .line 2208
    .line 2209
    .line 2210
    .line 2211
    .line 2212
    .line 2213
    .line 2214
    .line 2215
    .line 2216
    .line 2217
    .line 2218
    .line 2219
    .line 2220
    .line 2221
    .line 2222
    .line 2223
    .line 2224
    .line 2225
    .line 2226
    .line 2227
    .line 2228
    .line 2229
    .line 2230
    .line 2231
    .line 2232
    .line 2233
    .line 2234
    .line 2235
    .line 2236
    .line 2237
    .line 2238
    .line 2239
    .line 2240
    .line 2241
    .line 2242
    .line 2243
    .line 2244
    .line 2245
    .line 2246
    .line 2247
    .line 2248
    .line 2249
    .line 2250
    .line 2251
    .line 2252
    .line 2253
    .line 2254
    .line 2255
    .line 2256
    .line 2257
    .line 2258
    .line 2259
    .line 2260
    .line 2261
    .line 2262
    .line 2263
    .line 2264
    .line 2265
    .line 2266
    .line 2267
    .line 2268
    .line 2269
    .line 2270
    .line 2271
    .line 2272
    .line 2273
    .line 2274
    .line 2275
    .line 2276
    .line 2277
    .line 2278
    .line 2279
    .line 2280
    .line 2281
    .line 2282
    .line 2283
    .line 2284
    .line 2285
    .line 2286
    .line 2287
    .line 2288
    .line 2289
    .line 2290
    .line 2291
    .line 2292
    .line 2293
    .line 2294
    .line 2295
    .line 2296
    .line 2297
    .line 2298
    .line 2299
    .line 2300
    .line 2301
    .line 2302
    .line 2303
    .line 2304
    .line 2305
    .line 2306
    .line 2307
    .line 2308
    .line 2309
    .line 2310
    .line 2311
    .line 2312
    .line 2313
    .line 2314
    .line 2315
    .line 2316
    .line 2317
    .line 2318
    .line 2319
    .line 2320
    .line 2321
    .line 2322
    .line 2323
    .line 2324
    .line 2325
    .line 2326
    .line 2327
    .line 2328
    .line 2329
    .line 2330
    .line 2331
    .line 2332
    .line 2333
    .line 2334
    .line 2335
    .line 2336
    .line 2337
    .line 2338
    .line 2339
    .line 2340
    .line 2341
    .line 2342
    .line 2343
    .line 2344
    .line 2345
    .line 2346
    .line 2347
    .line 2348
    .line 2349
    .line 2350
    .line 2351
    .line 2352
    .line 2353
    .line 2354
    .line 2355
    .line 2356
    .line 2357
    .line 2358
    .line 2359
    .line 2360
    .line 2361
    .line 2362
    .line 2363
    .line 2364
    .line 2365
    .line 2366
    .line 2367
    .line 2368
    .line 2369
    .line 2370
    .line 2371
    .line 2372
    .line 2373
    .line 2374
    .line 2375
    .line 2376
    .line 2377
    .line 2378
    .line 2379
    .line 2380
    .line 2381
    .line 2382
    .line 2383
    .line 2384
    .line 2385
    .line 2386
    .line 2387
    .line 2388
    .line 2389
    .line 2390
    .line 2391
    .line 2392
    .line 2393
    .line 2394
    .line 2395
    .line 2396
    .line 2397
    .line 2398
    .line 2399
    .line 2400
    .line 2401
    .line 2402
    .line 2403
    .line 2404
    .line 2405
    .line 2406
    .line 2407
    .line 2408
    .line 2409
    .line 2410
    .line 2411
    .line 2412
    .line 2413
    .line 2414
    .line 2415
    .line 2416
    .line 2417
    .line 2418
    .line 2419
    .line 2420
    .line 2421
    .line 2422
    .line 2423
    .line 2424
    .line 2425
    .line 2426
    .line 2427
    .line 2428
    .line 2429
    .line 2430
    .line 2431
    .line 2432
    .line 2433
    .line 2434
    .line 2435
    .line 2436
    .line 2437
    .line 2438
    .line 2439
    .line 2440
    .line 2441
    .line 2442
    .line 2443
    .line 2444
    .line 2445
    .line 2446
    .line 2447
    .line 2448
    .line 2449
    .line 2450
    .line 2451
    .line 2452
    .line 2453
    .line 2454
    .line 2455
    .line 2456
    .line 2457
    .line 2458
    .line 2459
    .line 2460
    .line 2461
    .line 2462
    .line 2463
    .line 2464
    .line 2465
    .line 2466
    .line 2467
    .line 2468
    .line 2469
    .line 2470
    .line 2471
    .line 2472
    .line 2473
    .line 2474
    .line 2475
    .line 2476
    .line 2477
    .line 2478
    .line 2479
    .line 2480
    .line 2481
    .line 2482
    .line 2483
    .line 2484
    .line 2485
    .line 2486
    .line 2487
    .line 2488
    .line 2489
    .line 2490
    .line 2491
    .line 2492
    .line 2493
    .line 2494
    .line 2495
    .line 2496
    .line 2497
    .line 2498
    .line 2499
    .line 2500
    .line 2501
    .line 2502
    .line 2503
    .line 2504
    .line 2505
    .line 2506
    .line 2507
    .line 2508
    .line 2509
    .line 2510
    .line 2511
    .line 2512
    .line 2513
    .line 2514
    .line 2515
    .line 2516
    .line 2517
    .line 2518
    .line 2519
    .line 2520
    .line 2521
    .line 2522
    .line 2523
    .line 2524
    .line 2525
    .line 2526
    .line 2527
    .line 2528
    .line 2529
    .line 2530
    .line 2531
    .line 2532
    .line 2533
    .line 2534
    .line 2535
    .line 2536
    .line 2537
    .line 2538
    .line 2539
    .line 2540
    .line 2541
    .line 2542
.end method

.method public final c([Landroid/view/View;I)Lb1/w;
    .locals 1

    .line 1
    array-length v0, p1

    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    goto :goto_0

    .line 5
    :cond_0
    sget-object v0, Lcom/topjohnwu/magisk/DataBinderMapperImpl;->a:Landroid/util/SparseIntArray;

    .line 6
    .line 7
    invoke-virtual {v0, p2}, Landroid/util/SparseIntArray;->get(I)I

    .line 8
    .line 9
    .line 10
    move-result p2

    .line 11
    if-lez p2, :cond_2

    .line 12
    .line 13
    const/4 p2, 0x0

    .line 14
    aget-object p1, p1, p2

    .line 15
    .line 16
    invoke-virtual {p1}, Landroid/view/View;->getTag()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    if-eqz p1, :cond_1

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_1
    new-instance p1, Ljava/lang/RuntimeException;

    .line 24
    .line 25
    const-string p2, "view must have a tag"

    .line 26
    .line 27
    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    throw p1

    .line 31
    :cond_2
    :goto_0
    const/4 p1, 0x0

    .line 32
    return-object p1
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method
