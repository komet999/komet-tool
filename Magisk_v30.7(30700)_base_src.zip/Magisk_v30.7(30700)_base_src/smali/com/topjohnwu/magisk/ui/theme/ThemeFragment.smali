.class public final Lcom/topjohnwu/magisk/ui/theme/ThemeFragment;
.super Lz3/d;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lz3/d<",
        "Lp4/x;",
        ">;"
    }
.end annotation


# instance fields
.field public final j0:I

.field public final k0:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Lz3/d;-><init>()V

    .line 2
    .line 3
    .line 4
    const v0, 0x7f0c003b

    .line 5
    .line 6
    .line 7
    iput v0, p0, Lcom/topjohnwu/magisk/ui/theme/ThemeFragment;->j0:I

    .line 8
    .line 9
    new-instance v0, La5/e;

    .line 10
    .line 11
    const/4 v1, 0x5

    .line 12
    invoke-direct {v0, v1, p0}, La5/e;-><init>(ILjava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    const/4 v1, 0x3

    .line 16
    invoke-static {v1, v0}, Lo3/b;->F(ILj6/a;)Lv5/c;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    iput-object v0, p0, Lcom/topjohnwu/magisk/ui/theme/ThemeFragment;->k0:Ljava/lang/Object;

    .line 21
    .line 22
    return-void
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method


# virtual methods
.method public final F()V
    .locals 3

    .line 1
    invoke-super {p0}, Lz3/d;->F()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lz3/d;->P()Lcom/topjohnwu/magisk/ui/MainActivity;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    invoke-virtual {p0}, Lh1/y;->L()Landroid/content/Context;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    const v2, 0x7f11011c

    .line 19
    .line 20
    .line 21
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-virtual {v0, v1}, Landroid/app/Activity;->setTitle(Ljava/lang/CharSequence;)V

    .line 26
    .line 27
    .line 28
    :cond_0
    return-void
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final Q()I
    .locals 1

    .line 1
    iget v0, p0, Lcom/topjohnwu/magisk/ui/theme/ThemeFragment;->j0:I

    .line 2
    .line 3
    return v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final c()Lz3/f;
    .locals 1

    .line 1
    iget-object v0, p0, Lcom/topjohnwu/magisk/ui/theme/ThemeFragment;->k0:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-interface {v0}, Lv5/c;->getValue()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Le5/b;

    .line 8
    .line 9
    return-object v0
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final y(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 9

    .line 1
    invoke-super {p0, p1, p2, p3}, Lz3/d;->y(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;

    .line 2
    .line 3
    .line 4
    invoke-static {}, Le5/a;->values()[Le5/a;

    .line 5
    .line 6
    .line 7
    move-result-object p2

    .line 8
    array-length p3, p2

    .line 9
    const/4 v0, 0x0

    .line 10
    const/4 v1, 0x0

    .line 11
    if-lez p3, :cond_1

    .line 12
    .line 13
    new-instance p3, Ljava/util/ArrayList;

    .line 14
    .line 15
    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    .line 16
    .line 17
    .line 18
    move v2, v1

    .line 19
    :goto_0
    array-length v3, p2

    .line 20
    if-ge v2, v3, :cond_2

    .line 21
    .line 22
    add-int/lit8 v3, v2, 0x1

    .line 23
    .line 24
    :try_start_0
    aget-object v4, p2, v2
    :try_end_0
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_1

    .line 25
    .line 26
    array-length v5, p2

    .line 27
    if-ge v3, v5, :cond_0

    .line 28
    .line 29
    add-int/lit8 v2, v2, 0x2

    .line 30
    .line 31
    :try_start_1
    aget-object v3, p2, v3
    :try_end_1
    .catch Ljava/lang/ArrayIndexOutOfBoundsException; {:try_start_1 .. :try_end_1} :catch_0

    .line 32
    .line 33
    goto :goto_1

    .line 34
    :catch_0
    move-exception p1

    .line 35
    new-instance p2, Ljava/util/NoSuchElementException;

    .line 36
    .line 37
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    invoke-direct {p2, p1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    throw p2

    .line 45
    :cond_0
    move v2, v3

    .line 46
    move-object v3, v0

    .line 47
    :goto_1
    new-instance v5, Lv5/e;

    .line 48
    .line 49
    invoke-direct {v5, v4, v3}, Lv5/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {p3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    goto :goto_0

    .line 56
    :catch_1
    move-exception p1

    .line 57
    new-instance p2, Ljava/util/NoSuchElementException;

    .line 58
    .line 59
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    invoke-direct {p2, p1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    throw p2

    .line 67
    :cond_1
    sget-object p3, Lw5/q;->m:Lw5/q;

    .line 68
    .line 69
    :cond_2
    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 70
    .line 71
    .line 72
    move-result-object p2

    .line 73
    :goto_2
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 74
    .line 75
    .line 76
    move-result p3

    .line 77
    if-eqz p3, :cond_6

    .line 78
    .line 79
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    move-result-object p3

    .line 83
    check-cast p3, Lv5/e;

    .line 84
    .line 85
    iget-object v2, p3, Lv5/e;->m:Ljava/lang/Object;

    .line 86
    .line 87
    check-cast v2, Le5/a;

    .line 88
    .line 89
    iget-object p3, p3, Lv5/e;->n:Ljava/lang/Object;

    .line 90
    .line 91
    check-cast p3, Le5/a;

    .line 92
    .line 93
    const v3, 0x7f0c0054

    .line 94
    .line 95
    .line 96
    invoke-virtual {p1, v3, v0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    const v4, 0x7f090144

    .line 101
    .line 102
    .line 103
    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 104
    .line 105
    .line 106
    move-result-object v4

    .line 107
    check-cast v4, Landroid/widget/FrameLayout;

    .line 108
    .line 109
    const v5, 0x7f090202

    .line 110
    .line 111
    .line 112
    invoke-virtual {v3, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 113
    .line 114
    .line 115
    move-result-object v5

    .line 116
    check-cast v5, Landroid/widget/FrameLayout;

    .line 117
    .line 118
    new-instance v6, Lv5/e;

    .line 119
    .line 120
    invoke-direct {v6, v2, v4}, Lv5/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    new-instance v2, Lv5/e;

    .line 124
    .line 125
    invoke-direct {v2, p3, v5}, Lv5/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    const/4 p3, 0x2

    .line 129
    new-array p3, p3, [Lv5/e;

    .line 130
    .line 131
    aput-object v6, p3, v1

    .line 132
    .line 133
    const/4 v4, 0x1

    .line 134
    aput-object v2, p3, v4

    .line 135
    .line 136
    invoke-static {p3}, Lw5/k;->L([Ljava/lang/Object;)Ljava/util/List;

    .line 137
    .line 138
    .line 139
    move-result-object p3

    .line 140
    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 141
    .line 142
    .line 143
    move-result-object p3

    .line 144
    :goto_3
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 145
    .line 146
    .line 147
    move-result v2

    .line 148
    if-eqz v2, :cond_4

    .line 149
    .line 150
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    move-result-object v2

    .line 154
    check-cast v2, Lv5/e;

    .line 155
    .line 156
    iget-object v5, v2, Lv5/e;->m:Ljava/lang/Object;

    .line 157
    .line 158
    check-cast v5, Le5/a;

    .line 159
    .line 160
    iget-object v2, v2, Lv5/e;->n:Ljava/lang/Object;

    .line 161
    .line 162
    check-cast v2, Landroid/widget/FrameLayout;

    .line 163
    .line 164
    if-nez v5, :cond_3

    .line 165
    .line 166
    goto :goto_3

    .line 167
    :cond_3
    new-instance v6, Landroid/view/ContextThemeWrapper;

    .line 168
    .line 169
    invoke-virtual {p0}, Lz3/d;->P()Lcom/topjohnwu/magisk/ui/MainActivity;

    .line 170
    .line 171
    .line 172
    move-result-object v7

    .line 173
    iget v8, v5, Le5/a;->n:I

    .line 174
    .line 175
    invoke-direct {v6, v7, v8}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    .line 176
    .line 177
    .line 178
    invoke-static {v6}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    .line 179
    .line 180
    .line 181
    move-result-object v6

    .line 182
    sget v7, Lp4/t0;->K:I

    .line 183
    .line 184
    const v7, 0x7f0c0053

    .line 185
    .line 186
    .line 187
    invoke-static {v6, v7, v2, v4}, Lb1/d;->b(Landroid/view/LayoutInflater;ILandroid/view/ViewGroup;Z)Lb1/w;

    .line 188
    .line 189
    .line 190
    move-result-object v2

    .line 191
    check-cast v2, Lp4/t0;

    .line 192
    .line 193
    iget-object v6, p0, Lcom/topjohnwu/magisk/ui/theme/ThemeFragment;->k0:Ljava/lang/Object;

    .line 194
    .line 195
    invoke-interface {v6}, Lv5/c;->getValue()Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object v6

    .line 199
    check-cast v6, Le5/b;

    .line 200
    .line 201
    const/16 v7, 0x2c

    .line 202
    .line 203
    invoke-virtual {v2, v7, v6}, Lb1/w;->r(ILjava/lang/Object;)Z

    .line 204
    .line 205
    .line 206
    const/16 v6, 0x28

    .line 207
    .line 208
    invoke-virtual {v2, v6, v5}, Lb1/w;->r(ILjava/lang/Object;)Z

    .line 209
    .line 210
    .line 211
    invoke-virtual {p0}, Lh1/y;->p()Lh1/z0;

    .line 212
    .line 213
    .line 214
    move-result-object v5

    .line 215
    invoke-virtual {v2, v5}, Lb1/w;->q(Lk1/p;)V

    .line 216
    .line 217
    .line 218
    goto :goto_3

    .line 219
    :cond_4
    iget-object p3, p0, Lz3/d;->i0:Lb1/w;

    .line 220
    .line 221
    if-eqz p3, :cond_5

    .line 222
    .line 223
    goto :goto_4

    .line 224
    :cond_5
    move-object p3, v0

    .line 225
    :goto_4
    check-cast p3, Lp4/x;

    .line 226
    .line 227
    iget-object p3, p3, Lp4/x;->J:Landroid/widget/LinearLayout;

    .line 228
    .line 229
    invoke-virtual {p3, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 230
    .line 231
    .line 232
    goto/16 :goto_2

    .line 233
    .line 234
    :cond_6
    iget-object p1, p0, Lz3/d;->i0:Lb1/w;

    .line 235
    .line 236
    if-eqz p1, :cond_7

    .line 237
    .line 238
    move-object v0, p1

    .line 239
    :cond_7
    check-cast v0, Lp4/x;

    .line 240
    .line 241
    iget-object p1, v0, Lb1/w;->q:Landroid/view/View;

    .line 242
    .line 243
    return-object p1
    .line 244
.end method
