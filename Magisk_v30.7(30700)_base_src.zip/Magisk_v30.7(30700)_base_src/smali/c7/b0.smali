.class public final Lc7/b0;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# instance fields
.field public A:I

.field public B:J

.field public C:Laa/b;

.field public D:Lg7/c;

.field public a:Lc7/q;

.field public b:Laa/b;

.field public final c:Ljava/util/ArrayList;

.field public final d:Ljava/util/ArrayList;

.field public e:La4/a;

.field public f:Z

.field public g:Z

.field public h:Lc7/b;

.field public i:Z

.field public j:Z

.field public k:Lc7/b;

.field public l:Lc7/h;

.field public m:Lc7/r;

.field public n:Ljava/net/ProxySelector;

.field public o:Lc7/b;

.field public p:Ljavax/net/SocketFactory;

.field public q:Ljavax/net/ssl/SSLSocketFactory;

.field public r:Ljavax/net/ssl/X509TrustManager;

.field public s:Ljava/util/List;

.field public t:Ljava/util/List;

.field public u:Lr7/c;

.field public v:Lc7/k;

.field public w:Lo2/b;

.field public x:I

.field public y:I

.field public z:I


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lc7/q;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    invoke-direct {v0, v1}, Lc7/q;-><init>(I)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lc7/b0;->a:Lc7/q;

    .line 11
    .line 12
    new-instance v0, Ljava/util/ArrayList;

    .line 13
    .line 14
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lc7/b0;->c:Ljava/util/ArrayList;

    .line 18
    .line 19
    new-instance v0, Ljava/util/ArrayList;

    .line 20
    .line 21
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object v0, p0, Lc7/b0;->d:Ljava/util/ArrayList;

    .line 25
    .line 26
    sget-object v0, Le7/g;->a:Ljava/util/TimeZone;

    .line 27
    .line 28
    new-instance v0, La4/a;

    .line 29
    .line 30
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 31
    .line 32
    .line 33
    iput-object v0, p0, Lc7/b0;->e:La4/a;

    .line 34
    .line 35
    const/4 v0, 0x1

    .line 36
    iput-boolean v0, p0, Lc7/b0;->f:Z

    .line 37
    .line 38
    iput-boolean v0, p0, Lc7/b0;->g:Z

    .line 39
    .line 40
    sget-object v1, Lc7/b;->m:Lc7/b;

    .line 41
    .line 42
    iput-object v1, p0, Lc7/b0;->h:Lc7/b;

    .line 43
    .line 44
    iput-boolean v0, p0, Lc7/b0;->i:Z

    .line 45
    .line 46
    iput-boolean v0, p0, Lc7/b0;->j:Z

    .line 47
    .line 48
    sget-object v0, Lc7/b;->n:Lc7/b;

    .line 49
    .line 50
    iput-object v0, p0, Lc7/b0;->k:Lc7/b;

    .line 51
    .line 52
    sget-object v0, Lc7/r;->a:Lc7/b;

    .line 53
    .line 54
    iput-object v0, p0, Lc7/b0;->m:Lc7/r;

    .line 55
    .line 56
    iput-object v1, p0, Lc7/b0;->o:Lc7/b;

    .line 57
    .line 58
    invoke-static {}, Ljavax/net/SocketFactory;->getDefault()Ljavax/net/SocketFactory;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    iput-object v0, p0, Lc7/b0;->p:Ljavax/net/SocketFactory;

    .line 63
    .line 64
    sget-object v0, Lc7/c0;->F:Ljava/util/List;

    .line 65
    .line 66
    iput-object v0, p0, Lc7/b0;->s:Ljava/util/List;

    .line 67
    .line 68
    sget-object v0, Lc7/c0;->E:Ljava/util/List;

    .line 69
    .line 70
    iput-object v0, p0, Lc7/b0;->t:Ljava/util/List;

    .line 71
    .line 72
    sget-object v0, Lr7/c;->a:Lr7/c;

    .line 73
    .line 74
    iput-object v0, p0, Lc7/b0;->u:Lr7/c;

    .line 75
    .line 76
    sget-object v0, Lc7/k;->c:Lc7/k;

    .line 77
    .line 78
    iput-object v0, p0, Lc7/b0;->v:Lc7/k;

    .line 79
    .line 80
    const/16 v0, 0x2710

    .line 81
    .line 82
    iput v0, p0, Lc7/b0;->x:I

    .line 83
    .line 84
    iput v0, p0, Lc7/b0;->y:I

    .line 85
    .line 86
    iput v0, p0, Lc7/b0;->z:I

    .line 87
    .line 88
    const v0, 0xea60

    .line 89
    .line 90
    .line 91
    iput v0, p0, Lc7/b0;->A:I

    .line 92
    .line 93
    const-wide/16 v0, 0x400

    .line 94
    .line 95
    iput-wide v0, p0, Lc7/b0;->B:J

    .line 96
    .line 97
    return-void
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
.end method
