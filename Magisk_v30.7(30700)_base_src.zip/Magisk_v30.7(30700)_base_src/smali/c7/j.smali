.class public interface abstract Lc7/j;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# virtual methods
.method public abstract c(Ljava/io/IOException;)V
.end method

.method public abstract i(Lc7/k0;)V
.end method
