.class public final Lc4/g;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# instance fields
.field public final a:Lcom/topjohnwu/magisk/core/data/SuLogDatabase;

.field public final b:J

.field public final c:Lcom/topjohnwu/magisk/core/data/SuLogDatabase;

.field public final d:Ln3/f;


# direct methods
.method public constructor <init>(Lcom/topjohnwu/magisk/core/data/SuLogDatabase;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lc4/g;->a:Lcom/topjohnwu/magisk/core/data/SuLogDatabase;

    .line 5
    .line 6
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const/4 v1, 0x3

    .line 11
    const/4 v2, -0x2

    .line 12
    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->add(II)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeInMillis()J

    .line 16
    .line 17
    .line 18
    move-result-wide v0

    .line 19
    iput-wide v0, p0, Lc4/g;->b:J

    .line 20
    .line 21
    iput-object p1, p0, Lc4/g;->c:Lcom/topjohnwu/magisk/core/data/SuLogDatabase;

    .line 22
    .line 23
    new-instance p1, Ln3/f;

    .line 24
    .line 25
    const/4 v0, 0x4

    .line 26
    invoke-direct {p1, v0}, Ln3/f;-><init>(I)V

    .line 27
    .line 28
    .line 29
    iput-object p1, p0, Lc4/g;->d:Ln3/f;

    .line 30
    .line 31
    return-void
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method


# virtual methods
.method public final a(Lb6/c;)Ljava/lang/Object;
    .locals 8

    .line 1
    instance-of v0, p1, Lc4/d;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Lc4/d;

    .line 7
    .line 8
    iget v1, v0, Lc4/d;->r:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Lc4/d;->r:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, Lc4/d;

    .line 21
    .line 22
    invoke-direct {v0, p0, p1}, Lc4/d;-><init>(Lc4/g;Lb6/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p1, v0, Lc4/d;->p:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, Lc4/d;->r:I

    .line 28
    .line 29
    const/4 v2, 0x0

    .line 30
    const/4 v3, 0x2

    .line 31
    const/4 v4, 0x1

    .line 32
    sget-object v5, La6/a;->m:La6/a;

    .line 33
    .line 34
    if-eqz v1, :cond_3

    .line 35
    .line 36
    if-eq v1, v4, :cond_2

    .line 37
    .line 38
    if-ne v1, v3, :cond_1

    .line 39
    .line 40
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    return-object p1

    .line 44
    :cond_1
    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 45
    .line 46
    invoke-static {p1}, Lq0/b;->m(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    const/4 p1, 0x0

    .line 50
    return-object p1

    .line 51
    :cond_2
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    goto :goto_2

    .line 55
    :cond_3
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    iput v4, v0, Lc4/d;->r:I

    .line 59
    .line 60
    new-instance p1, Lc4/f;

    .line 61
    .line 62
    iget-wide v6, p0, Lc4/g;->b:J

    .line 63
    .line 64
    invoke-direct {p1, v6, v7}, Lc4/f;-><init>(J)V

    .line 65
    .line 66
    .line 67
    iget-object v1, p0, Lc4/g;->c:Lcom/topjohnwu/magisk/core/data/SuLogDatabase;

    .line 68
    .line 69
    invoke-static {v1, v2, v4, p1, v0}, Lx1/r;->Q(Lcom/topjohnwu/magisk/core/data/SuLogDatabase;ZZLj6/l;Lb6/c;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    if-ne p1, v5, :cond_4

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_4
    sget-object p1, Lv5/k;->a:Lv5/k;

    .line 77
    .line 78
    :goto_1
    if-ne p1, v5, :cond_5

    .line 79
    .line 80
    goto :goto_3

    .line 81
    :cond_5
    :goto_2
    iput v3, v0, Lc4/d;->r:I

    .line 82
    .line 83
    new-instance p1, Lc4/e;

    .line 84
    .line 85
    const/4 v1, 0x0

    .line 86
    invoke-direct {p1, v1}, Lc4/e;-><init>(I)V

    .line 87
    .line 88
    .line 89
    iget-object v1, p0, Lc4/g;->c:Lcom/topjohnwu/magisk/core/data/SuLogDatabase;

    .line 90
    .line 91
    invoke-static {v1, v4, v2, p1, v0}, Lx1/r;->Q(Lcom/topjohnwu/magisk/core/data/SuLogDatabase;ZZLj6/l;Lb6/c;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    if-ne p1, v5, :cond_6

    .line 96
    .line 97
    :goto_3
    return-object v5

    .line 98
    :cond_6
    return-object p1
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method
