.class public interface abstract Lc4/b;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# virtual methods
.method public abstract a(Ljava/lang/String;Lz5/d;)Ljava/lang/Object;
    .param p1    # Ljava/lang/String;
        .annotation runtime Lma/y;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lz5/d<",
            "-",
            "Lc7/m0;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation runtime Lma/f;
    .end annotation

    .annotation runtime Lma/w;
    .end annotation
.end method

.method public abstract b(Ljava/lang/String;Lz5/d;)Ljava/lang/Object;
    .param p1    # Ljava/lang/String;
        .annotation runtime Lma/y;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lz5/d<",
            "-",
            "Lcom/topjohnwu/magisk/core/model/UpdateJson;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation runtime Lma/f;
    .end annotation
.end method

.method public abstract c(Ljava/lang/String;Lz5/d;)Ljava/lang/Object;
    .param p1    # Ljava/lang/String;
        .annotation runtime Lma/y;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lz5/d<",
            "-",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation runtime Lma/f;
    .end annotation
.end method

.method public abstract d(Ljava/lang/String;Lz5/d;)Ljava/lang/Object;
    .param p1    # Ljava/lang/String;
        .annotation runtime Lma/y;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lz5/d<",
            "-",
            "Lcom/topjohnwu/magisk/core/model/ModuleJson;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation runtime Lma/f;
    .end annotation
.end method
