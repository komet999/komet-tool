.class public final Lc4/i;
.super Lw1/c0;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# instance fields
.field public final synthetic d:Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;


# direct methods
.method public constructor <init>(Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;)V
    .locals 2

    .line 1
    iput-object p1, p0, Lc4/i;->d:Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;

    .line 2
    .line 3
    const-string p1, "40a17e1202bf2defdedb4a5de17db440"

    .line 4
    .line 5
    const-string v0, "fcd1081e5756a69420178fe3426c5125"

    .line 6
    .line 7
    const/4 v1, 0x2

    .line 8
    invoke-direct {p0, v1, p1, v0}, Lw1/c0;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    return-void
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method


# virtual methods
.method public final a(Le2/a;)V
    .locals 1

    .line 1
    const-string v0, "CREATE TABLE IF NOT EXISTS `logs` (`fromUid` INTEGER NOT NULL, `toUid` INTEGER NOT NULL, `fromPid` INTEGER NOT NULL, `packageName` TEXT NOT NULL, `appName` TEXT NOT NULL, `command` TEXT NOT NULL, `action` INTEGER NOT NULL, `target` INTEGER NOT NULL, `context` TEXT NOT NULL, `gids` TEXT NOT NULL, `time` INTEGER NOT NULL, `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL)"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lx1/r;->q(Le2/a;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    const-string v0, "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)"

    .line 7
    .line 8
    invoke-static {p1, v0}, Lx1/r;->q(Le2/a;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v0, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, \'40a17e1202bf2defdedb4a5de17db440\')"

    .line 12
    .line 13
    invoke-static {p1, v0}, Lx1/r;->q(Le2/a;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-void
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method

.method public final c(Le2/a;)V
    .locals 1

    .line 1
    const-string v0, "DROP TABLE IF EXISTS `logs`"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lx1/r;->q(Le2/a;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method

.method public final r()V
    .locals 0

    .line 1
    return-void
    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final s(Le2/a;)V
    .locals 5

    .line 1
    iget-object v0, p0, Lc4/i;->d:Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;

    .line 2
    .line 3
    iget-object v0, v0, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->f:Lx1/g;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    move-object v0, v1

    .line 9
    :cond_0
    iget-object v2, v0, Lx1/g;->c:Lx1/e0;

    .line 10
    .line 11
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    const-string v3, "PRAGMA query_only"

    .line 15
    .line 16
    invoke-interface {p1, v3}, Le2/a;->N(Ljava/lang/String;)Le2/c;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    :try_start_0
    invoke-interface {v3}, Le2/c;->E()Z

    .line 21
    .line 22
    .line 23
    invoke-interface {v3}, Le2/c;->y()Z

    .line 24
    .line 25
    .line 26
    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    .line 27
    invoke-static {v3, v1}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 28
    .line 29
    .line 30
    if-nez v4, :cond_2

    .line 31
    .line 32
    const-string v1, "PRAGMA temp_store = MEMORY"

    .line 33
    .line 34
    invoke-static {p1, v1}, Lx1/r;->q(Le2/a;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    const-string v1, "PRAGMA recursive_triggers = 1"

    .line 38
    .line 39
    invoke-static {p1, v1}, Lx1/r;->q(Le2/a;Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    const-string v1, "DROP TABLE IF EXISTS room_table_modification_log"

    .line 43
    .line 44
    invoke-static {p1, v1}, Lx1/r;->q(Le2/a;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    iget-boolean v1, v2, Lx1/e0;->d:Z

    .line 48
    .line 49
    if-eqz v1, :cond_1

    .line 50
    .line 51
    const-string v1, "CREATE TEMP TABLE IF NOT EXISTS room_table_modification_log (table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)"

    .line 52
    .line 53
    invoke-static {p1, v1}, Lx1/r;->q(Le2/a;Ljava/lang/String;)V

    .line 54
    .line 55
    .line 56
    goto :goto_0

    .line 57
    :cond_1
    const-string v1, "CREATE TEMP TABLE IF NOT EXISTS room_table_modification_log (table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)"

    .line 58
    .line 59
    const-string v3, "TEMP"

    .line 60
    .line 61
    const-string v4, ""

    .line 62
    .line 63
    invoke-static {v1, v3, v4}, Lr6/p;->N(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    invoke-static {p1, v1}, Lx1/r;->q(Le2/a;Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    :goto_0
    iget-object p1, v2, Lx1/e0;->h:Lx1/l;

    .line 71
    .line 72
    iget-object v1, p1, Lx1/l;->a:Ljava/util/concurrent/locks/ReentrantLock;

    .line 73
    .line 74
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 75
    .line 76
    .line 77
    const/4 v2, 0x1

    .line 78
    :try_start_1
    iput-boolean v2, p1, Lx1/l;->d:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 79
    .line 80
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 81
    .line 82
    .line 83
    goto :goto_1

    .line 84
    :catchall_0
    move-exception p1

    .line 85
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 86
    .line 87
    .line 88
    throw p1

    .line 89
    :cond_2
    :goto_1
    iget-object p1, v0, Lx1/g;->j:Ljava/lang/Object;

    .line 90
    .line 91
    monitor-enter p1

    .line 92
    :try_start_2
    iget-object v1, v0, Lx1/g;->i:Lx1/j;

    .line 93
    .line 94
    if-eqz v1, :cond_4

    .line 95
    .line 96
    iget-object v0, v0, Lx1/g;->h:Landroid/content/Intent;

    .line 97
    .line 98
    if-eqz v0, :cond_3

    .line 99
    .line 100
    invoke-virtual {v1, v0}, Lx1/j;->a(Landroid/content/Intent;)V

    .line 101
    .line 102
    .line 103
    goto :goto_2

    .line 104
    :catchall_1
    move-exception v0

    .line 105
    goto :goto_3

    .line 106
    :cond_3
    const-string v0, "Required value was null."

    .line 107
    .line 108
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 109
    .line 110
    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    throw v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 114
    :cond_4
    :goto_2
    monitor-exit p1

    .line 115
    return-void

    .line 116
    :goto_3
    monitor-exit p1

    .line 117
    throw v0

    .line 118
    :catchall_2
    move-exception p1

    .line 119
    :try_start_3
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    .line 120
    :catchall_3
    move-exception v0

    .line 121
    invoke-static {v3, p1}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 122
    .line 123
    .line 124
    throw v0
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method

.method public final t()V
    .locals 0

    .line 1
    return-void
    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final u(Le2/a;)V
    .locals 4

    .line 1
    invoke-static {}, Lo/r3;->q()Lx5/c;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "SELECT name FROM sqlite_master WHERE type = \'trigger\'"

    .line 6
    .line 7
    invoke-interface {p1, v1}, Le2/a;->N(Ljava/lang/String;)Le2/c;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    :goto_0
    :try_start_0
    invoke-interface {v1}, Le2/c;->E()Z

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    const/4 v3, 0x0

    .line 16
    if-eqz v2, :cond_0

    .line 17
    .line 18
    invoke-interface {v1, v3}, Le2/c;->e(I)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    invoke-virtual {v0, v2}, Lx5/c;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    .line 24
    .line 25
    goto :goto_0

    .line 26
    :catchall_0
    move-exception p1

    .line 27
    goto :goto_2

    .line 28
    :cond_0
    const/4 v2, 0x0

    .line 29
    invoke-static {v1, v2}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 30
    .line 31
    .line 32
    invoke-static {v0}, Lo/r3;->g(Lx5/c;)Lx5/c;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-virtual {v0, v3}, Lx5/c;->listIterator(I)Ljava/util/ListIterator;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    :cond_1
    :goto_1
    move-object v1, v0

    .line 41
    check-cast v1, Lx5/a;

    .line 42
    .line 43
    invoke-virtual {v1}, Lx5/a;->hasNext()Z

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    if-eqz v2, :cond_2

    .line 48
    .line 49
    invoke-virtual {v1}, Lx5/a;->next()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    check-cast v1, Ljava/lang/String;

    .line 54
    .line 55
    const-string v2, "room_fts_content_sync_"

    .line 56
    .line 57
    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 58
    .line 59
    .line 60
    move-result v2

    .line 61
    if-eqz v2, :cond_1

    .line 62
    .line 63
    const-string v2, "DROP TRIGGER IF EXISTS "

    .line 64
    .line 65
    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    invoke-static {p1, v1}, Lx1/r;->q(Le2/a;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    goto :goto_1

    .line 73
    :cond_2
    return-void

    .line 74
    :goto_2
    :try_start_1
    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 75
    :catchall_1
    move-exception v0

    .line 76
    invoke-static {v1, p1}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 77
    .line 78
    .line 79
    throw v0
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method

.method public final v(Le2/a;)Lb4/j;
    .locals 31

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 4
    .line 5
    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 6
    .line 7
    .line 8
    new-instance v2, Lb2/g;

    .line 9
    .line 10
    const/4 v7, 0x0

    .line 11
    const/4 v8, 0x1

    .line 12
    const-string v3, "fromUid"

    .line 13
    .line 14
    const-string v4, "INTEGER"

    .line 15
    .line 16
    const/4 v5, 0x1

    .line 17
    const/4 v6, 0x0

    .line 18
    invoke-direct/range {v2 .. v8}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 19
    .line 20
    .line 21
    const-string v3, "fromUid"

    .line 22
    .line 23
    invoke-interface {v1, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    new-instance v4, Lb2/g;

    .line 27
    .line 28
    const/4 v9, 0x0

    .line 29
    const/4 v10, 0x1

    .line 30
    const-string v5, "toUid"

    .line 31
    .line 32
    const-string v6, "INTEGER"

    .line 33
    .line 34
    const/4 v7, 0x1

    .line 35
    const/4 v8, 0x0

    .line 36
    invoke-direct/range {v4 .. v10}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 37
    .line 38
    .line 39
    const-string v2, "toUid"

    .line 40
    .line 41
    invoke-interface {v1, v2, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    new-instance v5, Lb2/g;

    .line 45
    .line 46
    const/4 v10, 0x0

    .line 47
    const/4 v11, 0x1

    .line 48
    const-string v6, "fromPid"

    .line 49
    .line 50
    const-string v7, "INTEGER"

    .line 51
    .line 52
    const/4 v8, 0x1

    .line 53
    const/4 v9, 0x0

    .line 54
    invoke-direct/range {v5 .. v11}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 55
    .line 56
    .line 57
    const-string v2, "fromPid"

    .line 58
    .line 59
    invoke-interface {v1, v2, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    new-instance v6, Lb2/g;

    .line 63
    .line 64
    const/4 v11, 0x0

    .line 65
    const/4 v12, 0x1

    .line 66
    const-string v7, "packageName"

    .line 67
    .line 68
    const-string v8, "TEXT"

    .line 69
    .line 70
    const/4 v9, 0x1

    .line 71
    const/4 v10, 0x0

    .line 72
    invoke-direct/range {v6 .. v12}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 73
    .line 74
    .line 75
    const-string v2, "packageName"

    .line 76
    .line 77
    invoke-interface {v1, v2, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    new-instance v7, Lb2/g;

    .line 81
    .line 82
    const/4 v12, 0x0

    .line 83
    const/4 v13, 0x1

    .line 84
    const-string v8, "appName"

    .line 85
    .line 86
    const-string v9, "TEXT"

    .line 87
    .line 88
    const/4 v10, 0x1

    .line 89
    const/4 v11, 0x0

    .line 90
    invoke-direct/range {v7 .. v13}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 91
    .line 92
    .line 93
    const-string v2, "appName"

    .line 94
    .line 95
    invoke-interface {v1, v2, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    new-instance v8, Lb2/g;

    .line 99
    .line 100
    const/4 v13, 0x0

    .line 101
    const/4 v14, 0x1

    .line 102
    const-string v9, "command"

    .line 103
    .line 104
    const-string v10, "TEXT"

    .line 105
    .line 106
    const/4 v11, 0x1

    .line 107
    const/4 v12, 0x0

    .line 108
    invoke-direct/range {v8 .. v14}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 109
    .line 110
    .line 111
    const-string v2, "command"

    .line 112
    .line 113
    invoke-interface {v1, v2, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    new-instance v9, Lb2/g;

    .line 117
    .line 118
    const/4 v14, 0x0

    .line 119
    const/4 v15, 0x1

    .line 120
    const-string v10, "action"

    .line 121
    .line 122
    const-string v11, "INTEGER"

    .line 123
    .line 124
    const/4 v12, 0x1

    .line 125
    const/4 v13, 0x0

    .line 126
    invoke-direct/range {v9 .. v15}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 127
    .line 128
    .line 129
    const-string v2, "action"

    .line 130
    .line 131
    invoke-interface {v1, v2, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    new-instance v10, Lb2/g;

    .line 135
    .line 136
    const/4 v15, 0x0

    .line 137
    const/16 v16, 0x1

    .line 138
    .line 139
    const-string v11, "target"

    .line 140
    .line 141
    const-string v12, "INTEGER"

    .line 142
    .line 143
    const/4 v13, 0x1

    .line 144
    const/4 v14, 0x0

    .line 145
    invoke-direct/range {v10 .. v16}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 146
    .line 147
    .line 148
    const-string v2, "target"

    .line 149
    .line 150
    invoke-interface {v1, v2, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 151
    .line 152
    .line 153
    new-instance v3, Lb2/g;

    .line 154
    .line 155
    const/4 v8, 0x0

    .line 156
    const/4 v9, 0x1

    .line 157
    const-string v4, "context"

    .line 158
    .line 159
    const-string v5, "TEXT"

    .line 160
    .line 161
    const/4 v6, 0x1

    .line 162
    const/4 v7, 0x0

    .line 163
    invoke-direct/range {v3 .. v9}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 164
    .line 165
    .line 166
    const-string v2, "context"

    .line 167
    .line 168
    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    new-instance v4, Lb2/g;

    .line 172
    .line 173
    const/4 v9, 0x0

    .line 174
    const/4 v10, 0x1

    .line 175
    const-string v5, "gids"

    .line 176
    .line 177
    const-string v6, "TEXT"

    .line 178
    .line 179
    const/4 v7, 0x1

    .line 180
    const/4 v8, 0x0

    .line 181
    invoke-direct/range {v4 .. v10}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 182
    .line 183
    .line 184
    const-string v2, "gids"

    .line 185
    .line 186
    invoke-interface {v1, v2, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 187
    .line 188
    .line 189
    new-instance v5, Lb2/g;

    .line 190
    .line 191
    const/4 v10, 0x0

    .line 192
    const/4 v11, 0x1

    .line 193
    const-string v6, "time"

    .line 194
    .line 195
    const-string v7, "INTEGER"

    .line 196
    .line 197
    const/4 v8, 0x1

    .line 198
    const/4 v9, 0x0

    .line 199
    invoke-direct/range {v5 .. v11}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 200
    .line 201
    .line 202
    const-string v2, "time"

    .line 203
    .line 204
    invoke-interface {v1, v2, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    new-instance v6, Lb2/g;

    .line 208
    .line 209
    const/4 v11, 0x0

    .line 210
    const/4 v12, 0x1

    .line 211
    const-string v7, "id"

    .line 212
    .line 213
    const-string v8, "INTEGER"

    .line 214
    .line 215
    const/4 v9, 0x1

    .line 216
    const/4 v10, 0x1

    .line 217
    invoke-direct/range {v6 .. v12}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 218
    .line 219
    .line 220
    const-string v2, "id"

    .line 221
    .line 222
    invoke-interface {v1, v2, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 223
    .line 224
    .line 225
    new-instance v3, Ljava/util/LinkedHashSet;

    .line 226
    .line 227
    invoke-direct {v3}, Ljava/util/LinkedHashSet;-><init>()V

    .line 228
    .line 229
    .line 230
    new-instance v4, Ljava/util/LinkedHashSet;

    .line 231
    .line 232
    invoke-direct {v4}, Ljava/util/LinkedHashSet;-><init>()V

    .line 233
    .line 234
    .line 235
    new-instance v5, Lb2/j;

    .line 236
    .line 237
    invoke-direct {v5, v1, v3, v4}, Lb2/j;-><init>(Ljava/util/Map;Ljava/util/AbstractSet;Ljava/util/AbstractSet;)V

    .line 238
    .line 239
    .line 240
    const-string v1, "PRAGMA table_info(`logs`)"

    .line 241
    .line 242
    invoke-interface {v0, v1}, Le2/a;->N(Ljava/lang/String;)Le2/c;

    .line 243
    .line 244
    .line 245
    move-result-object v1

    .line 246
    :try_start_0
    invoke-interface {v1}, Le2/c;->E()Z

    .line 247
    .line 248
    .line 249
    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 250
    const-wide/16 v6, 0x0

    .line 251
    .line 252
    const-string v4, "name"

    .line 253
    .line 254
    const/4 v10, 0x0

    .line 255
    if-nez v3, :cond_0

    .line 256
    .line 257
    :try_start_1
    sget-object v3, Lw5/r;->m:Lw5/r;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 258
    .line 259
    invoke-static {v1, v10}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 260
    .line 261
    .line 262
    move-wide/from16 v23, v6

    .line 263
    .line 264
    goto/16 :goto_4

    .line 265
    .line 266
    :catchall_0
    move-exception v0

    .line 267
    move-object v2, v0

    .line 268
    goto/16 :goto_f

    .line 269
    .line 270
    :cond_0
    :try_start_2
    invoke-static {v1, v4}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 271
    .line 272
    .line 273
    move-result v3

    .line 274
    const-string v11, "type"

    .line 275
    .line 276
    invoke-static {v1, v11}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 277
    .line 278
    .line 279
    move-result v11

    .line 280
    const-string v12, "notnull"

    .line 281
    .line 282
    invoke-static {v1, v12}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 283
    .line 284
    .line 285
    move-result v12

    .line 286
    const-string v13, "pk"

    .line 287
    .line 288
    invoke-static {v1, v13}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 289
    .line 290
    .line 291
    move-result v13

    .line 292
    const-string v14, "dflt_value"

    .line 293
    .line 294
    invoke-static {v1, v14}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 295
    .line 296
    .line 297
    move-result v14

    .line 298
    new-instance v15, Lx5/f;

    .line 299
    .line 300
    invoke-direct {v15}, Lx5/f;-><init>()V

    .line 301
    .line 302
    .line 303
    :goto_0
    invoke-interface {v1, v3}, Le2/c;->e(I)Ljava/lang/String;

    .line 304
    .line 305
    .line 306
    move-result-object v17

    .line 307
    invoke-interface {v1, v11}, Le2/c;->e(I)Ljava/lang/String;

    .line 308
    .line 309
    .line 310
    move-result-object v18

    .line 311
    invoke-interface {v1, v12}, Le2/c;->getLong(I)J

    .line 312
    .line 313
    .line 314
    move-result-wide v19

    .line 315
    cmp-long v16, v19, v6

    .line 316
    .line 317
    if-eqz v16, :cond_1

    .line 318
    .line 319
    const/16 v19, 0x1

    .line 320
    .line 321
    :goto_1
    move-wide/from16 v23, v6

    .line 322
    .line 323
    goto :goto_2

    .line 324
    :cond_1
    const/16 v19, 0x0

    .line 325
    .line 326
    goto :goto_1

    .line 327
    :goto_2
    invoke-interface {v1, v13}, Le2/c;->getLong(I)J

    .line 328
    .line 329
    .line 330
    move-result-wide v6

    .line 331
    long-to-int v6, v6

    .line 332
    invoke-interface {v1, v14}, Le2/c;->isNull(I)Z

    .line 333
    .line 334
    .line 335
    move-result v7

    .line 336
    if-eqz v7, :cond_2

    .line 337
    .line 338
    move-object/from16 v21, v10

    .line 339
    .line 340
    goto :goto_3

    .line 341
    :cond_2
    invoke-interface {v1, v14}, Le2/c;->e(I)Ljava/lang/String;

    .line 342
    .line 343
    .line 344
    move-result-object v7

    .line 345
    move-object/from16 v21, v7

    .line 346
    .line 347
    :goto_3
    new-instance v16, Lb2/g;

    .line 348
    .line 349
    const/16 v22, 0x2

    .line 350
    .line 351
    move/from16 v20, v6

    .line 352
    .line 353
    invoke-direct/range {v16 .. v22}, Lb2/g;-><init>(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/String;I)V

    .line 354
    .line 355
    .line 356
    move-object/from16 v7, v16

    .line 357
    .line 358
    move-object/from16 v6, v17

    .line 359
    .line 360
    invoke-virtual {v15, v6, v7}, Lx5/f;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 361
    .line 362
    .line 363
    invoke-interface {v1}, Le2/c;->E()Z

    .line 364
    .line 365
    .line 366
    move-result v6

    .line 367
    if-nez v6, :cond_f

    .line 368
    .line 369
    invoke-virtual {v15}, Lx5/f;->b()Lx5/f;

    .line 370
    .line 371
    .line 372
    move-result-object v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 373
    invoke-static {v1, v10}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 374
    .line 375
    .line 376
    :goto_4
    const-string v1, "PRAGMA foreign_key_list(`logs`)"

    .line 377
    .line 378
    invoke-interface {v0, v1}, Le2/a;->N(Ljava/lang/String;)Le2/c;

    .line 379
    .line 380
    .line 381
    move-result-object v1

    .line 382
    :try_start_3
    invoke-static {v1, v2}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 383
    .line 384
    .line 385
    move-result v2

    .line 386
    const-string v6, "seq"

    .line 387
    .line 388
    invoke-static {v1, v6}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 389
    .line 390
    .line 391
    move-result v6

    .line 392
    const-string v7, "table"

    .line 393
    .line 394
    invoke-static {v1, v7}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 395
    .line 396
    .line 397
    move-result v7

    .line 398
    const-string v11, "on_delete"

    .line 399
    .line 400
    invoke-static {v1, v11}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 401
    .line 402
    .line 403
    move-result v11

    .line 404
    const-string v12, "on_update"

    .line 405
    .line 406
    invoke-static {v1, v12}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 407
    .line 408
    .line 409
    move-result v12

    .line 410
    invoke-static {v1}, Lx1/r;->T(Le2/c;)Ljava/util/List;

    .line 411
    .line 412
    .line 413
    move-result-object v13

    .line 414
    invoke-interface {v1}, Le2/c;->reset()V

    .line 415
    .line 416
    .line 417
    new-instance v14, Lx5/i;

    .line 418
    .line 419
    invoke-direct {v14}, Lx5/i;-><init>()V

    .line 420
    .line 421
    .line 422
    :goto_5
    invoke-interface {v1}, Le2/c;->E()Z

    .line 423
    .line 424
    .line 425
    move-result v15

    .line 426
    if-eqz v15, :cond_7

    .line 427
    .line 428
    invoke-interface {v1, v6}, Le2/c;->getLong(I)J

    .line 429
    .line 430
    .line 431
    move-result-wide v15

    .line 432
    cmp-long v15, v15, v23

    .line 433
    .line 434
    if-eqz v15, :cond_3

    .line 435
    .line 436
    goto :goto_5

    .line 437
    :cond_3
    invoke-interface {v1, v2}, Le2/c;->getLong(I)J

    .line 438
    .line 439
    .line 440
    move-result-wide v8

    .line 441
    long-to-int v8, v8

    .line 442
    new-instance v9, Ljava/util/ArrayList;

    .line 443
    .line 444
    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 445
    .line 446
    .line 447
    new-instance v15, Ljava/util/ArrayList;

    .line 448
    .line 449
    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    .line 450
    .line 451
    .line 452
    new-instance v10, Ljava/util/ArrayList;

    .line 453
    .line 454
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 455
    .line 456
    .line 457
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 458
    .line 459
    .line 460
    move-result-object v19

    .line 461
    :goto_6
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->hasNext()Z

    .line 462
    .line 463
    .line 464
    move-result v20

    .line 465
    if-eqz v20, :cond_5

    .line 466
    .line 467
    move/from16 v20, v2

    .line 468
    .line 469
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 470
    .line 471
    .line 472
    move-result-object v2

    .line 473
    move/from16 v21, v6

    .line 474
    .line 475
    move-object v6, v2

    .line 476
    check-cast v6, Lb2/e;

    .line 477
    .line 478
    iget v6, v6, Lb2/e;->m:I

    .line 479
    .line 480
    if-ne v6, v8, :cond_4

    .line 481
    .line 482
    invoke-virtual {v10, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 483
    .line 484
    .line 485
    :cond_4
    move/from16 v2, v20

    .line 486
    .line 487
    move/from16 v6, v21

    .line 488
    .line 489
    goto :goto_6

    .line 490
    :catchall_1
    move-exception v0

    .line 491
    move-object v2, v0

    .line 492
    goto/16 :goto_e

    .line 493
    .line 494
    :cond_5
    move/from16 v20, v2

    .line 495
    .line 496
    move/from16 v21, v6

    .line 497
    .line 498
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 499
    .line 500
    .line 501
    move-result v2

    .line 502
    const/4 v6, 0x0

    .line 503
    :goto_7
    if-ge v6, v2, :cond_6

    .line 504
    .line 505
    invoke-virtual {v10, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 506
    .line 507
    .line 508
    move-result-object v8

    .line 509
    add-int/lit8 v6, v6, 0x1

    .line 510
    .line 511
    check-cast v8, Lb2/e;

    .line 512
    .line 513
    move/from16 v19, v2

    .line 514
    .line 515
    iget-object v2, v8, Lb2/e;->o:Ljava/lang/String;

    .line 516
    .line 517
    invoke-virtual {v9, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 518
    .line 519
    .line 520
    iget-object v2, v8, Lb2/e;->p:Ljava/lang/String;

    .line 521
    .line 522
    invoke-virtual {v15, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 523
    .line 524
    .line 525
    move/from16 v2, v19

    .line 526
    .line 527
    goto :goto_7

    .line 528
    :cond_6
    new-instance v25, Lb2/h;

    .line 529
    .line 530
    invoke-interface {v1, v7}, Le2/c;->e(I)Ljava/lang/String;

    .line 531
    .line 532
    .line 533
    move-result-object v26

    .line 534
    invoke-interface {v1, v11}, Le2/c;->e(I)Ljava/lang/String;

    .line 535
    .line 536
    .line 537
    move-result-object v27

    .line 538
    invoke-interface {v1, v12}, Le2/c;->e(I)Ljava/lang/String;

    .line 539
    .line 540
    .line 541
    move-result-object v28

    .line 542
    move-object/from16 v29, v9

    .line 543
    .line 544
    move-object/from16 v30, v15

    .line 545
    .line 546
    invoke-direct/range {v25 .. v30}, Lb2/h;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    .line 547
    .line 548
    .line 549
    move-object/from16 v2, v25

    .line 550
    .line 551
    invoke-virtual {v14, v2}, Lx5/i;->add(Ljava/lang/Object;)Z

    .line 552
    .line 553
    .line 554
    move/from16 v2, v20

    .line 555
    .line 556
    move/from16 v6, v21

    .line 557
    .line 558
    const/4 v10, 0x0

    .line 559
    goto/16 :goto_5

    .line 560
    .line 561
    :cond_7
    invoke-static {v14}, Lo3/b;->d(Lx5/i;)Lx5/i;

    .line 562
    .line 563
    .line 564
    move-result-object v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 565
    const/4 v6, 0x0

    .line 566
    invoke-static {v1, v6}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 567
    .line 568
    .line 569
    const-string v1, "PRAGMA index_list(`logs`)"

    .line 570
    .line 571
    invoke-interface {v0, v1}, Le2/a;->N(Ljava/lang/String;)Le2/c;

    .line 572
    .line 573
    .line 574
    move-result-object v1

    .line 575
    :try_start_4
    invoke-static {v1, v4}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 576
    .line 577
    .line 578
    move-result v4

    .line 579
    const-string v6, "origin"

    .line 580
    .line 581
    invoke-static {v1, v6}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 582
    .line 583
    .line 584
    move-result v6

    .line 585
    const-string v7, "unique"

    .line 586
    .line 587
    invoke-static {v1, v7}, Lo7/g;->g(Le2/c;Ljava/lang/String;)I

    .line 588
    .line 589
    .line 590
    move-result v7

    .line 591
    const/4 v8, -0x1

    .line 592
    if-eq v4, v8, :cond_8

    .line 593
    .line 594
    if-eq v6, v8, :cond_8

    .line 595
    .line 596
    if-ne v7, v8, :cond_9

    .line 597
    .line 598
    :cond_8
    const/4 v6, 0x0

    .line 599
    goto :goto_b

    .line 600
    :cond_9
    new-instance v8, Lx5/i;

    .line 601
    .line 602
    invoke-direct {v8}, Lx5/i;-><init>()V

    .line 603
    .line 604
    .line 605
    :goto_8
    invoke-interface {v1}, Le2/c;->E()Z

    .line 606
    .line 607
    .line 608
    move-result v9

    .line 609
    if-eqz v9, :cond_d

    .line 610
    .line 611
    invoke-interface {v1, v6}, Le2/c;->e(I)Ljava/lang/String;

    .line 612
    .line 613
    .line 614
    move-result-object v9

    .line 615
    const-string v10, "c"

    .line 616
    .line 617
    invoke-virtual {v10, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 618
    .line 619
    .line 620
    move-result v9

    .line 621
    if-nez v9, :cond_a

    .line 622
    .line 623
    goto :goto_8

    .line 624
    :cond_a
    invoke-interface {v1, v4}, Le2/c;->e(I)Ljava/lang/String;

    .line 625
    .line 626
    .line 627
    move-result-object v9

    .line 628
    invoke-interface {v1, v7}, Le2/c;->getLong(I)J

    .line 629
    .line 630
    .line 631
    move-result-wide v10

    .line 632
    const-wide/16 v12, 0x1

    .line 633
    .line 634
    cmp-long v10, v10, v12

    .line 635
    .line 636
    if-nez v10, :cond_b

    .line 637
    .line 638
    const/4 v10, 0x1

    .line 639
    goto :goto_9

    .line 640
    :cond_b
    const/4 v10, 0x0

    .line 641
    :goto_9
    invoke-static {v0, v9, v10}, Lx1/r;->V(Le2/a;Ljava/lang/String;Z)Lb2/i;

    .line 642
    .line 643
    .line 644
    move-result-object v9
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 645
    if-nez v9, :cond_c

    .line 646
    .line 647
    const/4 v10, 0x0

    .line 648
    invoke-static {v1, v10}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 649
    .line 650
    .line 651
    :goto_a
    const/4 v6, 0x0

    .line 652
    goto :goto_c

    .line 653
    :cond_c
    :try_start_5
    invoke-virtual {v8, v9}, Lx5/i;->add(Ljava/lang/Object;)Z

    .line 654
    .line 655
    .line 656
    goto :goto_8

    .line 657
    :catchall_2
    move-exception v0

    .line 658
    move-object v2, v0

    .line 659
    goto :goto_d

    .line 660
    :cond_d
    invoke-static {v8}, Lo3/b;->d(Lx5/i;)Lx5/i;

    .line 661
    .line 662
    .line 663
    move-result-object v0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    .line 664
    const/4 v6, 0x0

    .line 665
    invoke-static {v1, v6}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 666
    .line 667
    .line 668
    move-object v6, v0

    .line 669
    goto :goto_c

    .line 670
    :goto_b
    invoke-static {v1, v6}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 671
    .line 672
    .line 673
    goto :goto_a

    .line 674
    :goto_c
    new-instance v0, Lb2/j;

    .line 675
    .line 676
    invoke-direct {v0, v3, v2, v6}, Lb2/j;-><init>(Ljava/util/Map;Ljava/util/AbstractSet;Ljava/util/AbstractSet;)V

    .line 677
    .line 678
    .line 679
    invoke-virtual {v5, v0}, Lb2/j;->equals(Ljava/lang/Object;)Z

    .line 680
    .line 681
    .line 682
    move-result v1

    .line 683
    if-nez v1, :cond_e

    .line 684
    .line 685
    new-instance v1, Lb4/j;

    .line 686
    .line 687
    new-instance v2, Ljava/lang/StringBuilder;

    .line 688
    .line 689
    const-string v3, "logs(com.topjohnwu.magisk.core.model.su.SuLog).\n Expected:\n"

    .line 690
    .line 691
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 692
    .line 693
    .line 694
    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 695
    .line 696
    .line 697
    const-string v3, "\n Found:\n"

    .line 698
    .line 699
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 700
    .line 701
    .line 702
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 703
    .line 704
    .line 705
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 706
    .line 707
    .line 708
    move-result-object v0

    .line 709
    const/4 v6, 0x0

    .line 710
    invoke-direct {v1, v0, v6}, Lb4/j;-><init>(Ljava/lang/String;Z)V

    .line 711
    .line 712
    .line 713
    return-object v1

    .line 714
    :cond_e
    new-instance v0, Lb4/j;

    .line 715
    .line 716
    const/4 v7, 0x1

    .line 717
    const/4 v10, 0x0

    .line 718
    invoke-direct {v0, v10, v7}, Lb4/j;-><init>(Ljava/lang/String;Z)V

    .line 719
    .line 720
    .line 721
    return-object v0

    .line 722
    :goto_d
    :try_start_6
    throw v2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 723
    :catchall_3
    move-exception v0

    .line 724
    invoke-static {v1, v2}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 725
    .line 726
    .line 727
    throw v0

    .line 728
    :goto_e
    :try_start_7
    throw v2
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    .line 729
    :catchall_4
    move-exception v0

    .line 730
    invoke-static {v1, v2}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 731
    .line 732
    .line 733
    throw v0

    .line 734
    :cond_f
    move-wide/from16 v6, v23

    .line 735
    .line 736
    goto/16 :goto_0

    .line 737
    .line 738
    :goto_f
    :try_start_8
    throw v2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_5

    .line 739
    :catchall_5
    move-exception v0

    .line 740
    invoke-static {v1, v2}, La/a;->n(Le2/c;Ljava/lang/Throwable;)V

    .line 741
    .line 742
    .line 743
    throw v0
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
.end method
