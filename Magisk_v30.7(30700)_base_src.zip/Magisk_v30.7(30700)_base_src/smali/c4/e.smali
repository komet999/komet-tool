.class public final synthetic Lc4/e;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Lj6/l;


# instance fields
.field public final synthetic m:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, Lc4/e;->m:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method


# virtual methods
.method public final j(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 29

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    iget v2, v1, Lc4/e;->m:I

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const/4 v4, 0x1

    .line 9
    sget-object v5, Lv5/k;->a:Lv5/k;

    .line 10
    .line 11
    const/4 v6, 0x0

    .line 12
    packed-switch v2, :pswitch_data_0

    .line 13
    .line 14
    .line 15
    check-cast v0, Lz7/f0;

    .line 16
    .line 17
    invoke-static {v0}, Lcom/topjohnwu/magisk/test/Environment;->a(Lz7/f0;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    return-object v0

    .line 26
    :pswitch_0
    check-cast v0, Lp1/v;

    .line 27
    .line 28
    iget-object v0, v0, Lp1/v;->n:Lo/p;

    .line 29
    .line 30
    iget v0, v0, Lo/p;->a:I

    .line 31
    .line 32
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    return-object v0

    .line 37
    :pswitch_1
    check-cast v0, Lp1/v;

    .line 38
    .line 39
    iget-object v2, v0, Lp1/v;->o:Lp1/x;

    .line 40
    .line 41
    if-eqz v2, :cond_0

    .line 42
    .line 43
    iget-object v3, v2, Lp1/x;->s:Ln3/b0;

    .line 44
    .line 45
    iget v3, v3, Ln3/b0;->a:I

    .line 46
    .line 47
    iget-object v0, v0, Lp1/v;->n:Lo/p;

    .line 48
    .line 49
    iget v0, v0, Lo/p;->a:I

    .line 50
    .line 51
    if-ne v3, v0, :cond_0

    .line 52
    .line 53
    move-object v6, v2

    .line 54
    :cond_0
    return-object v6

    .line 55
    :pswitch_2
    check-cast v0, Lp1/v;

    .line 56
    .line 57
    iget-object v2, v0, Lp1/v;->o:Lp1/x;

    .line 58
    .line 59
    if-eqz v2, :cond_1

    .line 60
    .line 61
    iget-object v3, v2, Lp1/x;->s:Ln3/b0;

    .line 62
    .line 63
    iget v3, v3, Ln3/b0;->a:I

    .line 64
    .line 65
    iget-object v0, v0, Lp1/v;->n:Lo/p;

    .line 66
    .line 67
    iget v0, v0, Lo/p;->a:I

    .line 68
    .line 69
    if-ne v3, v0, :cond_1

    .line 70
    .line 71
    move-object v6, v2

    .line 72
    :cond_1
    return-object v6

    .line 73
    :pswitch_3
    check-cast v0, Lm1/b;

    .line 74
    .line 75
    new-instance v2, Ls1/b;

    .line 76
    .line 77
    invoke-static {v0}, Lk1/g0;->b(Lm1/b;)Lk1/e0;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    invoke-direct {v2, v0}, Ls1/b;-><init>(Lk1/e0;)V

    .line 82
    .line 83
    .line 84
    return-object v2

    .line 85
    :pswitch_4
    check-cast v0, Ljava/lang/String;

    .line 86
    .line 87
    invoke-static {v0}, Lr6/i;->X(Ljava/lang/CharSequence;)Z

    .line 88
    .line 89
    .line 90
    move-result v2

    .line 91
    const-string v3, "    "

    .line 92
    .line 93
    if-eqz v2, :cond_2

    .line 94
    .line 95
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 96
    .line 97
    .line 98
    move-result v2

    .line 99
    const/4 v4, 0x4

    .line 100
    if-ge v2, v4, :cond_3

    .line 101
    .line 102
    move-object v0, v3

    .line 103
    goto :goto_0

    .line 104
    :cond_2
    invoke-virtual {v3, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    :cond_3
    :goto_0
    return-object v0

    .line 109
    :pswitch_5
    check-cast v0, Lq3/k;

    .line 110
    .line 111
    return-object v5

    .line 112
    :pswitch_6
    check-cast v0, Lm1/b;

    .line 113
    .line 114
    new-instance v0, Lr1/g$a;

    .line 115
    .line 116
    invoke-direct {v0}, Lr1/g$a;-><init>()V

    .line 117
    .line 118
    .line 119
    :pswitch_7
    return-object v0

    .line 120
    :pswitch_8
    if-nez v0, :cond_4

    .line 121
    .line 122
    move v3, v4

    .line 123
    :cond_4
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    return-object v0

    .line 128
    :pswitch_9
    check-cast v0, Landroid/view/View;

    .line 129
    .line 130
    const v2, 0x7f0901ac

    .line 131
    .line 132
    .line 133
    invoke-virtual {v0, v2}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object v0

    .line 137
    instance-of v2, v0, Ljava/lang/ref/WeakReference;

    .line 138
    .line 139
    if-eqz v2, :cond_5

    .line 140
    .line 141
    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 142
    .line 143
    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    move-object v6, v0

    .line 148
    check-cast v6, Lp1/z;

    .line 149
    .line 150
    goto :goto_1

    .line 151
    :cond_5
    instance-of v2, v0, Lp1/z;

    .line 152
    .line 153
    if-eqz v2, :cond_6

    .line 154
    .line 155
    move-object v6, v0

    .line 156
    check-cast v6, Lp1/z;

    .line 157
    .line 158
    :cond_6
    :goto_1
    return-object v6

    .line 159
    :pswitch_a
    check-cast v0, Landroid/view/View;

    .line 160
    .line 161
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    instance-of v2, v0, Landroid/view/View;

    .line 166
    .line 167
    if-eqz v2, :cond_7

    .line 168
    .line 169
    move-object v6, v0

    .line 170
    check-cast v6, Landroid/view/View;

    .line 171
    .line 172
    :cond_7
    return-object v6

    .line 173
    :pswitch_b
    check-cast v0, Lp1/v;

    .line 174
    .line 175
    instance-of v2, v0, Lp1/x;

    .line 176
    .line 177
    if-eqz v2, :cond_8

    .line 178
    .line 179
    check-cast v0, Lp1/x;

    .line 180
    .line 181
    iget-object v2, v0, Lp1/x;->s:Ln3/b0;

    .line 182
    .line 183
    iget v2, v2, Ln3/b0;->a:I

    .line 184
    .line 185
    invoke-virtual {v0, v2}, Lp1/x;->j(I)Lp1/v;

    .line 186
    .line 187
    .line 188
    move-result-object v6

    .line 189
    :cond_8
    return-object v6

    .line 190
    :pswitch_c
    check-cast v0, Lp1/v;

    .line 191
    .line 192
    iget-object v0, v0, Lp1/v;->o:Lp1/x;

    .line 193
    .line 194
    return-object v0

    .line 195
    :pswitch_d
    check-cast v0, Landroid/content/Context;

    .line 196
    .line 197
    instance-of v2, v0, Landroid/app/Activity;

    .line 198
    .line 199
    if-eqz v2, :cond_9

    .line 200
    .line 201
    move-object v6, v0

    .line 202
    check-cast v6, Landroid/app/Activity;

    .line 203
    .line 204
    :cond_9
    return-object v6

    .line 205
    :pswitch_e
    check-cast v0, Landroid/content/Context;

    .line 206
    .line 207
    instance-of v2, v0, Landroid/content/ContextWrapper;

    .line 208
    .line 209
    if-eqz v2, :cond_a

    .line 210
    .line 211
    check-cast v0, Landroid/content/ContextWrapper;

    .line 212
    .line 213
    goto :goto_2

    .line 214
    :cond_a
    move-object v0, v6

    .line 215
    :goto_2
    if-eqz v0, :cond_b

    .line 216
    .line 217
    invoke-virtual {v0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 218
    .line 219
    .line 220
    move-result-object v6

    .line 221
    :cond_b
    return-object v6

    .line 222
    :pswitch_f
    check-cast v0, Lm1/b;

    .line 223
    .line 224
    new-instance v0, Lp1/l;

    .line 225
    .line 226
    invoke-direct {v0}, Lp1/l;-><init>()V

    .line 227
    .line 228
    .line 229
    return-object v0

    .line 230
    :pswitch_10
    check-cast v0, Landroid/content/Context;

    .line 231
    .line 232
    instance-of v2, v0, Landroid/content/ContextWrapper;

    .line 233
    .line 234
    if-eqz v2, :cond_c

    .line 235
    .line 236
    check-cast v0, Landroid/content/ContextWrapper;

    .line 237
    .line 238
    invoke-virtual {v0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 239
    .line 240
    .line 241
    move-result-object v6

    .line 242
    :cond_c
    return-object v6

    .line 243
    :pswitch_11
    check-cast v0, Landroid/content/Context;

    .line 244
    .line 245
    instance-of v2, v0, Landroid/content/ContextWrapper;

    .line 246
    .line 247
    if-eqz v2, :cond_d

    .line 248
    .line 249
    check-cast v0, Landroid/content/ContextWrapper;

    .line 250
    .line 251
    invoke-virtual {v0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 252
    .line 253
    .line 254
    move-result-object v6

    .line 255
    :cond_d
    return-object v6

    .line 256
    :pswitch_12
    check-cast v0, Lz7/f0;

    .line 257
    .line 258
    invoke-virtual {v0}, Lz7/f0;->isDirectory()Z

    .line 259
    .line 260
    .line 261
    move-result v2

    .line 262
    if-nez v2, :cond_e

    .line 263
    .line 264
    invoke-virtual {v0}, Lz7/f0;->getName()Ljava/lang/String;

    .line 265
    .line 266
    .line 267
    move-result-object v0

    .line 268
    sget-object v2, La4/h;->a:Ljava/lang/String;

    .line 269
    .line 270
    sget-object v2, Landroid/os/Build;->SUPPORTED_ABIS:[Ljava/lang/String;

    .line 271
    .line 272
    aget-object v2, v2, v3

    .line 273
    .line 274
    new-instance v5, Ljava/lang/StringBuilder;

    .line 275
    .line 276
    const-string v6, "lib/"

    .line 277
    .line 278
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 279
    .line 280
    .line 281
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 282
    .line 283
    .line 284
    const-string v2, "/"

    .line 285
    .line 286
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 287
    .line 288
    .line 289
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 290
    .line 291
    .line 292
    move-result-object v2

    .line 293
    invoke-virtual {v0, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 294
    .line 295
    .line 296
    move-result v0

    .line 297
    if-eqz v0, :cond_e

    .line 298
    .line 299
    move v3, v4

    .line 300
    :cond_e
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 301
    .line 302
    .line 303
    move-result-object v0

    .line 304
    return-object v0

    .line 305
    :pswitch_13
    check-cast v0, Landroid/content/DialogInterface;

    .line 306
    .line 307
    return-object v5

    .line 308
    :pswitch_14
    check-cast v0, Landroid/content/DialogInterface;

    .line 309
    .line 310
    sget v0, Lg5/f;->u:I

    .line 311
    .line 312
    return-object v5

    .line 313
    :pswitch_15
    check-cast v0, Landroid/app/Notification$Builder;

    .line 314
    .line 315
    return-object v5

    .line 316
    :pswitch_16
    check-cast v0, Le7/b;

    .line 317
    .line 318
    new-instance v2, Ljava/lang/StringBuilder;

    .line 319
    .line 320
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 321
    .line 322
    .line 323
    iget-object v3, v0, Le7/b;->m:Lk6/e;

    .line 324
    .line 325
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 326
    .line 327
    .line 328
    const/16 v3, 0x3d

    .line 329
    .line 330
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 331
    .line 332
    .line 333
    iget-object v0, v0, Le7/b;->n:Ljava/lang/Object;

    .line 334
    .line 335
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 336
    .line 337
    .line 338
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 339
    .line 340
    .line 341
    move-result-object v0

    .line 342
    return-object v0

    .line 343
    :pswitch_17
    check-cast v0, Le7/b;

    .line 344
    .line 345
    iget-object v0, v0, Le7/b;->o:La/a;

    .line 346
    .line 347
    instance-of v2, v0, Le7/b;

    .line 348
    .line 349
    if-eqz v2, :cond_f

    .line 350
    .line 351
    move-object v6, v0

    .line 352
    check-cast v6, Le7/b;

    .line 353
    .line 354
    :cond_f
    return-object v6

    .line 355
    :pswitch_18
    instance-of v2, v0, Ljava/lang/Boolean;

    .line 356
    .line 357
    if-eqz v2, :cond_11

    .line 358
    .line 359
    check-cast v0, Ljava/lang/Boolean;

    .line 360
    .line 361
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 362
    .line 363
    .line 364
    move-result v0

    .line 365
    if-eqz v0, :cond_10

    .line 366
    .line 367
    const-string v0, "1"

    .line 368
    .line 369
    goto :goto_3

    .line 370
    :cond_10
    const-string v0, "0"

    .line 371
    .line 372
    goto :goto_3

    .line 373
    :cond_11
    instance-of v2, v0, Ljava/lang/Number;

    .line 374
    .line 375
    if-eqz v2, :cond_12

    .line 376
    .line 377
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 378
    .line 379
    .line 380
    move-result-object v0

    .line 381
    goto :goto_3

    .line 382
    :cond_12
    instance-of v2, v0, Ld4/a;

    .line 383
    .line 384
    if-eqz v2, :cond_13

    .line 385
    .line 386
    check-cast v0, Ld4/a;

    .line 387
    .line 388
    iget-object v0, v0, Ld4/a;->a:Ljava/lang/String;

    .line 389
    .line 390
    goto :goto_3

    .line 391
    :cond_13
    new-instance v2, Ljava/lang/StringBuilder;

    .line 392
    .line 393
    const-string v3, "\""

    .line 394
    .line 395
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 396
    .line 397
    .line 398
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 399
    .line 400
    .line 401
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 402
    .line 403
    .line 404
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 405
    .line 406
    .line 407
    move-result-object v0

    .line 408
    :goto_3
    return-object v0

    .line 409
    :pswitch_19
    check-cast v0, Lc5/a;

    .line 410
    .line 411
    iget-object v0, v0, Lc5/a;->p:Ljava/lang/String;

    .line 412
    .line 413
    return-object v0

    .line 414
    :pswitch_1a
    check-cast v0, Lc5/a;

    .line 415
    .line 416
    iget-object v0, v0, Lc5/a;->s:Ljava/lang/String;

    .line 417
    .line 418
    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 419
    .line 420
    invoke-virtual {v0, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 421
    .line 422
    .line 423
    move-result-object v0

    .line 424
    return-object v0

    .line 425
    :pswitch_1b
    check-cast v0, Ljava/lang/Float;

    .line 426
    .line 427
    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    .line 428
    .line 429
    .line 430
    move-result v0

    .line 431
    float-to-int v0, v0

    .line 432
    if-eq v0, v4, :cond_16

    .line 433
    .line 434
    const/4 v2, 0x2

    .line 435
    if-eq v0, v2, :cond_15

    .line 436
    .line 437
    const/4 v2, 0x3

    .line 438
    if-eq v0, v2, :cond_14

    .line 439
    .line 440
    goto :goto_4

    .line 441
    :cond_14
    const v0, 0x7f11004f

    .line 442
    .line 443
    .line 444
    goto :goto_5

    .line 445
    :cond_15
    const v0, 0x7f110115

    .line 446
    .line 447
    .line 448
    goto :goto_5

    .line 449
    :cond_16
    :goto_4
    const v0, 0x7f110036

    .line 450
    .line 451
    .line 452
    :goto_5
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 453
    .line 454
    .line 455
    move-result-object v0

    .line 456
    return-object v0

    .line 457
    :pswitch_1c
    const-string v2, "SELECT * FROM logs ORDER BY time DESC"

    .line 458
    .line 459
    check-cast v0, Le2/a;

    .line 460
    .line 461
    invoke-interface {v0, v2}, Le2/a;->N(Ljava/lang/String;)Le2/c;

    .line 462
    .line 463
    .line 464
    move-result-object v2

    .line 465
    :try_start_0
    const-string v0, "fromUid"

    .line 466
    .line 467
    invoke-static {v2, v0}, Lo7/g;->w(Le2/c;Ljava/lang/String;)I

    .line 468
    .line 469
    .line 470
    move-result v0

    .line 471
    const-string v3, "toUid"

    .line 472
    .line 473
    invoke-static {v2, v3}, Lo7/g;->w(Le2/c;Ljava/lang/String;)I

    .line 474
    .line 475
    .line 476
    move-result v3

    .line 477
    const-string v4, "fromPid"

    .line 478
    .line 479
    invoke-static {v2, v4}, Lo7/g;->w(Le2/c;Ljava/lang/String;)I

    .line 480
    .line 481
    .line 482
    move-result v4

    .line 483
    const-string v5, "packageName"

    .line 484
    .line 485
    invoke-static {v2, v5}, Lo7/g;->w(Le2/c;Ljava/lang/String;)I

    .line 486
    .line 487
    .line 488
    move-result v5

    .line 489
    const-string v6, "appName"

    .line 490
    .line 491
    invoke-static {v2, v6}, Lo7/g;->w(Le2/c;Ljava/lang/String;)I

    .line 492
    .line 493
    .line 494
    move-result v6

    .line 495
    const-string v7, "command"

    .line 496
    .line 497
    invoke-static {v2, v7}, Lo7/g;->w(Le2/c;Ljava/lang/String;)I

    .line 498
    .line 499
    .line 500
    move-result v7

    .line 501
    const-string v8, "action"

    .line 502
    .line 503
    invoke-static {v2, v8}, Lo7/g;->w(Le2/c;Ljava/lang/String;)I

    .line 504
    .line 505
    .line 506
    move-result v8

    .line 507
    const-string v9, "target"

    .line 508
    .line 509
    invoke-static {v2, v9}, Lo7/g;->w(Le2/c;Ljava/lang/String;)I

    .line 510
    .line 511
    .line 512
    move-result v9

    .line 513
    const-string v10, "context"

    .line 514
    .line 515
    invoke-static {v2, v10}, Lo7/g;->w(Le2/c;Ljava/lang/String;)I

    .line 516
    .line 517
    .line 518
    move-result v10

    .line 519
    const-string v11, "gids"

    .line 520
    .line 521
    invoke-static {v2, v11}, Lo7/g;->w(Le2/c;Ljava/lang/String;)I

    .line 522
    .line 523
    .line 524
    move-result v11

    .line 525
    const-string v12, "time"

    .line 526
    .line 527
    invoke-static {v2, v12}, Lo7/g;->w(Le2/c;Ljava/lang/String;)I

    .line 528
    .line 529
    .line 530
    move-result v12

    .line 531
    const-string v13, "id"

    .line 532
    .line 533
    invoke-static {v2, v13}, Lo7/g;->w(Le2/c;Ljava/lang/String;)I

    .line 534
    .line 535
    .line 536
    move-result v13

    .line 537
    new-instance v14, Ljava/util/ArrayList;

    .line 538
    .line 539
    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    .line 540
    .line 541
    .line 542
    :goto_6
    invoke-interface {v2}, Le2/c;->E()Z

    .line 543
    .line 544
    .line 545
    move-result v15

    .line 546
    if-eqz v15, :cond_17

    .line 547
    .line 548
    move-object/from16 p1, v14

    .line 549
    .line 550
    invoke-interface {v2, v0}, Le2/c;->getLong(I)J

    .line 551
    .line 552
    .line 553
    move-result-wide v14

    .line 554
    long-to-int v14, v14

    .line 555
    move v15, v0

    .line 556
    invoke-interface {v2, v3}, Le2/c;->getLong(I)J

    .line 557
    .line 558
    .line 559
    move-result-wide v0

    .line 560
    long-to-int v0, v0

    .line 561
    move/from16 v18, v0

    .line 562
    .line 563
    invoke-interface {v2, v4}, Le2/c;->getLong(I)J

    .line 564
    .line 565
    .line 566
    move-result-wide v0

    .line 567
    long-to-int v0, v0

    .line 568
    invoke-interface {v2, v5}, Le2/c;->e(I)Ljava/lang/String;

    .line 569
    .line 570
    .line 571
    move-result-object v20

    .line 572
    invoke-interface {v2, v6}, Le2/c;->e(I)Ljava/lang/String;

    .line 573
    .line 574
    .line 575
    move-result-object v21

    .line 576
    invoke-interface {v2, v7}, Le2/c;->e(I)Ljava/lang/String;

    .line 577
    .line 578
    .line 579
    move-result-object v22

    .line 580
    move/from16 v19, v0

    .line 581
    .line 582
    invoke-interface {v2, v8}, Le2/c;->getLong(I)J

    .line 583
    .line 584
    .line 585
    move-result-wide v0

    .line 586
    long-to-int v0, v0

    .line 587
    move/from16 v23, v0

    .line 588
    .line 589
    invoke-interface {v2, v9}, Le2/c;->getLong(I)J

    .line 590
    .line 591
    .line 592
    move-result-wide v0

    .line 593
    long-to-int v0, v0

    .line 594
    invoke-interface {v2, v10}, Le2/c;->e(I)Ljava/lang/String;

    .line 595
    .line 596
    .line 597
    move-result-object v25

    .line 598
    invoke-interface {v2, v11}, Le2/c;->e(I)Ljava/lang/String;

    .line 599
    .line 600
    .line 601
    move-result-object v26

    .line 602
    invoke-interface {v2, v12}, Le2/c;->getLong(I)J

    .line 603
    .line 604
    .line 605
    move-result-wide v27

    .line 606
    new-instance v16, Lj4/a;

    .line 607
    .line 608
    move/from16 v24, v0

    .line 609
    .line 610
    move/from16 v17, v14

    .line 611
    .line 612
    invoke-direct/range {v16 .. v28}, Lj4/a;-><init>(IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;J)V

    .line 613
    .line 614
    .line 615
    move-object/from16 v0, v16

    .line 616
    .line 617
    move v1, v3

    .line 618
    move v14, v4

    .line 619
    invoke-interface {v2, v13}, Le2/c;->getLong(I)J

    .line 620
    .line 621
    .line 622
    move-result-wide v3

    .line 623
    long-to-int v3, v3

    .line 624
    iput v3, v0, Lj4/a;->l:I

    .line 625
    .line 626
    move-object/from16 v3, p1

    .line 627
    .line 628
    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 629
    .line 630
    .line 631
    move v4, v14

    .line 632
    move v0, v15

    .line 633
    move-object v14, v3

    .line 634
    move v3, v1

    .line 635
    move-object/from16 v1, p0

    .line 636
    .line 637
    goto :goto_6

    .line 638
    :catchall_0
    move-exception v0

    .line 639
    goto :goto_7

    .line 640
    :cond_17
    move-object v3, v14

    .line 641
    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    .line 642
    .line 643
    .line 644
    return-object v3

    .line 645
    :goto_7
    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    .line 646
    .line 647
    .line 648
    throw v0

    .line 649
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
    .line 749
    .line 750
    .line 751
    .line 752
    .line 753
    .line 754
    .line 755
    .line 756
    .line 757
    .line 758
    .line 759
    .line 760
    .line 761
    .line 762
    .line 763
    .line 764
    .line 765
    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    .line 778
    .line 779
    .line 780
    .line 781
    .line 782
    .line 783
    .line 784
    .line 785
    .line 786
    .line 787
    .line 788
    .line 789
    .line 790
    .line 791
    .line 792
    .line 793
    .line 794
    .line 795
    .line 796
    .line 797
    .line 798
    .line 799
    .line 800
    .line 801
    .line 802
    .line 803
    .line 804
    .line 805
    .line 806
    .line 807
    .line 808
    .line 809
    .line 810
    .line 811
    .line 812
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
.end method
