.class public interface abstract Lc4/a;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# virtual methods
.method public abstract a(Ljava/lang/String;Ljava/lang/String;IILz5/d;)Ljava/lang/Object;
    .param p1    # Ljava/lang/String;
        .annotation runtime Lma/s;
            value = "owner"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Lma/s;
            value = "repo"
        .end annotation
    .end param
    .param p3    # I
        .annotation runtime Lma/t;
            value = "per_page"
        .end annotation
    .end param
    .param p4    # I
        .annotation runtime Lma/t;
            value = "page"
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "II",
            "Lz5/d<",
            "-",
            "Lja/t0<",
            "Ljava/util/List<",
            "Lcom/topjohnwu/magisk/core/model/Release;",
            ">;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation runtime Lma/f;
        value = "/repos/{owner}/{repo}/releases"
    .end annotation

    .annotation runtime Lma/k;
        value = {
            "Accept: application/vnd.github+json"
        }
    .end annotation
.end method

.method public abstract b(Ljava/lang/String;Ljava/lang/String;Lz5/d;)Ljava/lang/Object;
    .param p1    # Ljava/lang/String;
        .annotation runtime Lma/s;
            value = "owner"
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation runtime Lma/s;
            value = "repo"
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lz5/d<",
            "-",
            "Lcom/topjohnwu/magisk/core/model/Release;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation runtime Lma/f;
        value = "/repos/{owner}/{repo}/releases/latest"
    .end annotation

    .annotation runtime Lma/k;
        value = {
            "Accept: application/vnd.github+json"
        }
    .end annotation
.end method
