.class public final Lb8/b;
.super La8/a;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# instance fields
.field public A:I

.field public B:I

.field public C:I

.field public D:I

.field public E:I

.field public F:I

.field public G:C

.field public H:Lb8/a;

.field public n:I

.field public o:I

.field public p:I

.field public q:Z

.field public final r:Lb8/c;

.field public s:I

.field public t:Lh8/a;

.field public u:I

.field public v:I

.field public w:I

.field public x:I

.field public y:I

.field public z:I


# direct methods
.method public constructor <init>(Ljava/io/FilterInputStream;)V
    .locals 5

    .line 1
    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lb8/c;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    const/4 v1, -0x1

    .line 10
    iput v1, v0, Lb8/c;->a:I

    .line 11
    .line 12
    iput-object v0, p0, Lb8/b;->r:Lb8/c;

    .line 13
    .line 14
    const/4 v0, 0x1

    .line 15
    iput v0, p0, Lb8/b;->u:I

    .line 16
    .line 17
    new-instance v0, Lh8/a;

    .line 18
    .line 19
    sget-object v1, Ljava/lang/System;->in:Ljava/io/InputStream;

    .line 20
    .line 21
    if-ne p1, v1, :cond_0

    .line 22
    .line 23
    new-instance v1, Ln8/c;

    .line 24
    .line 25
    invoke-direct {v1, p1}, Ln8/e;-><init>(Ljava/io/FilterInputStream;)V

    .line 26
    .line 27
    .line 28
    move-object p1, v1

    .line 29
    :cond_0
    sget-object v1, Ljava/nio/ByteOrder;->BIG_ENDIAN:Ljava/nio/ByteOrder;

    .line 30
    .line 31
    invoke-direct {v0, p1, v1}, Lh8/a;-><init>(Ljava/io/InputStream;Ljava/nio/ByteOrder;)V

    .line 32
    .line 33
    .line 34
    iput-object v0, p0, Lb8/b;->t:Lh8/a;

    .line 35
    .line 36
    iget-object p1, p0, Lb8/b;->t:Lh8/a;

    .line 37
    .line 38
    if-eqz p1, :cond_3

    .line 39
    .line 40
    const/4 v0, 0x0

    .line 41
    const/16 v1, 0x8

    .line 42
    .line 43
    invoke-virtual {p1, v1}, Lh8/a;->f(I)J

    .line 44
    .line 45
    .line 46
    move-result-wide v2

    .line 47
    long-to-int p1, v2

    .line 48
    iget-object v2, p0, Lb8/b;->t:Lh8/a;

    .line 49
    .line 50
    invoke-virtual {v2, v1}, Lh8/a;->f(I)J

    .line 51
    .line 52
    .line 53
    move-result-wide v2

    .line 54
    long-to-int v2, v2

    .line 55
    iget-object v3, p0, Lb8/b;->t:Lh8/a;

    .line 56
    .line 57
    invoke-virtual {v3, v1}, Lh8/a;->f(I)J

    .line 58
    .line 59
    .line 60
    move-result-wide v3

    .line 61
    long-to-int v3, v3

    .line 62
    const/16 v4, 0x42

    .line 63
    .line 64
    if-ne p1, v4, :cond_2

    .line 65
    .line 66
    const/16 p1, 0x5a

    .line 67
    .line 68
    if-ne v2, p1, :cond_2

    .line 69
    .line 70
    const/16 p1, 0x68

    .line 71
    .line 72
    if-ne v3, p1, :cond_2

    .line 73
    .line 74
    iget-object p1, p0, Lb8/b;->t:Lh8/a;

    .line 75
    .line 76
    invoke-virtual {p1, v1}, Lh8/a;->f(I)J

    .line 77
    .line 78
    .line 79
    move-result-wide v1

    .line 80
    long-to-int p1, v1

    .line 81
    const/16 v1, 0x31

    .line 82
    .line 83
    if-lt p1, v1, :cond_1

    .line 84
    .line 85
    const/16 v1, 0x39

    .line 86
    .line 87
    if-gt p1, v1, :cond_1

    .line 88
    .line 89
    add-int/lit8 p1, p1, -0x30

    .line 90
    .line 91
    iput p1, p0, Lb8/b;->p:I

    .line 92
    .line 93
    iput v0, p0, Lb8/b;->x:I

    .line 94
    .line 95
    goto :goto_0

    .line 96
    :cond_1
    const-string p1, "BZip2 block size is invalid"

    .line 97
    .line 98
    invoke-static {p1}, Lq0/b;->o(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    goto :goto_0

    .line 102
    :cond_2
    new-instance p1, Ljava/io/IOException;

    .line 103
    .line 104
    const-string v0, "Stream is not in the BZip2 format"

    .line 105
    .line 106
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    throw p1

    .line 110
    :cond_3
    const-string p1, "No InputStream"

    .line 111
    .line 112
    invoke-static {p1}, Lq0/b;->o(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    :goto_0
    invoke-virtual {p0}, Lb8/b;->A()V

    .line 116
    .line 117
    .line 118
    return-void
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method

.method public static l(Lh8/a;I)I
    .locals 2

    .line 1
    invoke-virtual {p0, p1}, Lh8/a;->f(I)J

    .line 2
    .line 3
    .line 4
    move-result-wide p0

    .line 5
    const-wide/16 v0, 0x0

    .line 6
    .line 7
    cmp-long v0, p0, v0

    .line 8
    .line 9
    if-ltz v0, :cond_0

    .line 10
    .line 11
    long-to-int p0, p0

    .line 12
    return p0

    .line 13
    :cond_0
    const-string p0, "Unexpected end of stream"

    .line 14
    .line 15
    invoke-static {p0}, Lq0/b;->o(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    const/4 p0, 0x0

    .line 19
    return p0
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method

.method public static u(IILjava/lang/String;)V
    .locals 1

    .line 1
    const-string v0, "Corrupted input, "

    .line 2
    .line 3
    if-ltz p0, :cond_1

    .line 4
    .line 5
    if-ge p0, p1, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    const-string p0, " value too big"

    .line 9
    .line 10
    invoke-static {v0, p2, p0}, Lb/m;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    invoke-static {p0}, Lq0/b;->o(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :cond_1
    const-string p0, " value negative"

    .line 19
    .line 20
    invoke-static {v0, p2, p0}, Lb/m;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    invoke-static {p0}, Lq0/b;->o(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    return-void
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
.end method


# virtual methods
.method public final A()V
    .locals 39

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Lb8/b;->t:Lh8/a;

    .line 4
    .line 5
    const/16 v2, 0x8

    .line 6
    .line 7
    invoke-static {v1, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    int-to-char v3, v3

    .line 12
    invoke-static {v1, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 13
    .line 14
    .line 15
    move-result v4

    .line 16
    int-to-char v4, v4

    .line 17
    invoke-static {v1, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 18
    .line 19
    .line 20
    move-result v5

    .line 21
    int-to-char v5, v5

    .line 22
    invoke-static {v1, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 23
    .line 24
    .line 25
    move-result v6

    .line 26
    int-to-char v6, v6

    .line 27
    invoke-static {v1, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 28
    .line 29
    .line 30
    move-result v7

    .line 31
    int-to-char v7, v7

    .line 32
    invoke-static {v1, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    int-to-char v2, v2

    .line 37
    const/16 v8, 0x17

    .line 38
    .line 39
    const/16 v9, 0x20

    .line 40
    .line 41
    const/4 v10, 0x0

    .line 42
    if-ne v3, v8, :cond_2

    .line 43
    .line 44
    const/16 v11, 0x72

    .line 45
    .line 46
    if-ne v4, v11, :cond_2

    .line 47
    .line 48
    const/16 v11, 0x45

    .line 49
    .line 50
    if-ne v5, v11, :cond_2

    .line 51
    .line 52
    const/16 v11, 0x38

    .line 53
    .line 54
    if-ne v6, v11, :cond_2

    .line 55
    .line 56
    const/16 v11, 0x50

    .line 57
    .line 58
    if-ne v7, v11, :cond_2

    .line 59
    .line 60
    const/16 v11, 0x90

    .line 61
    .line 62
    if-eq v2, v11, :cond_0

    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_0
    iget-object v1, v0, Lb8/b;->t:Lh8/a;

    .line 66
    .line 67
    invoke-static {v1, v9}, Lb8/b;->l(Lh8/a;I)I

    .line 68
    .line 69
    .line 70
    move-result v1

    .line 71
    iput v1, v0, Lb8/b;->w:I

    .line 72
    .line 73
    iput v10, v0, Lb8/b;->u:I

    .line 74
    .line 75
    const/4 v2, 0x0

    .line 76
    iput-object v2, v0, Lb8/b;->H:Lb8/a;

    .line 77
    .line 78
    iget v2, v0, Lb8/b;->x:I

    .line 79
    .line 80
    if-ne v1, v2, :cond_1

    .line 81
    .line 82
    return-void

    .line 83
    :cond_1
    const-string v1, "BZip2 CRC error"

    .line 84
    .line 85
    invoke-static {v1}, Lq0/b;->o(Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    return-void

    .line 89
    :cond_2
    :goto_0
    const/16 v11, 0x31

    .line 90
    .line 91
    if-ne v3, v11, :cond_32

    .line 92
    .line 93
    const/16 v3, 0x41

    .line 94
    .line 95
    if-ne v4, v3, :cond_32

    .line 96
    .line 97
    const/16 v3, 0x59

    .line 98
    .line 99
    if-ne v5, v3, :cond_32

    .line 100
    .line 101
    const/16 v4, 0x26

    .line 102
    .line 103
    if-ne v6, v4, :cond_32

    .line 104
    .line 105
    const/16 v4, 0x53

    .line 106
    .line 107
    if-ne v7, v4, :cond_32

    .line 108
    .line 109
    if-ne v2, v3, :cond_32

    .line 110
    .line 111
    invoke-static {v1, v9}, Lb8/b;->l(Lh8/a;I)I

    .line 112
    .line 113
    .line 114
    move-result v2

    .line 115
    iput v2, v0, Lb8/b;->v:I

    .line 116
    .line 117
    const/4 v2, 0x1

    .line 118
    invoke-static {v1, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 119
    .line 120
    .line 121
    move-result v1

    .line 122
    if-ne v1, v2, :cond_3

    .line 123
    .line 124
    move v1, v2

    .line 125
    goto :goto_1

    .line 126
    :cond_3
    move v1, v10

    .line 127
    :goto_1
    iput-boolean v1, v0, Lb8/b;->q:Z

    .line 128
    .line 129
    iget-object v1, v0, Lb8/b;->H:Lb8/a;

    .line 130
    .line 131
    if-nez v1, :cond_4

    .line 132
    .line 133
    new-instance v1, Lb8/a;

    .line 134
    .line 135
    iget v3, v0, Lb8/b;->p:I

    .line 136
    .line 137
    invoke-direct {v1, v3}, Lb8/a;-><init>(I)V

    .line 138
    .line 139
    .line 140
    iput-object v1, v0, Lb8/b;->H:Lb8/a;

    .line 141
    .line 142
    :cond_4
    iget-object v1, v0, Lb8/b;->t:Lh8/a;

    .line 143
    .line 144
    const/16 v3, 0x18

    .line 145
    .line 146
    invoke-static {v1, v3}, Lb8/b;->l(Lh8/a;I)I

    .line 147
    .line 148
    .line 149
    move-result v3

    .line 150
    iput v3, v0, Lb8/b;->o:I

    .line 151
    .line 152
    iget-object v3, v0, Lb8/b;->t:Lh8/a;

    .line 153
    .line 154
    iget-object v4, v0, Lb8/b;->H:Lb8/a;

    .line 155
    .line 156
    iget-object v5, v4, Lb8/a;->a:[Z

    .line 157
    .line 158
    iget-object v6, v4, Lb8/a;->m:[B

    .line 159
    .line 160
    iget-object v7, v4, Lb8/a;->c:[B

    .line 161
    .line 162
    iget-object v12, v4, Lb8/a;->d:[B

    .line 163
    .line 164
    move v13, v10

    .line 165
    move v14, v13

    .line 166
    :goto_2
    const/16 v15, 0x10

    .line 167
    .line 168
    if-ge v13, v15, :cond_6

    .line 169
    .line 170
    invoke-static {v3, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 171
    .line 172
    .line 173
    move-result v15

    .line 174
    if-eqz v15, :cond_5

    .line 175
    .line 176
    shl-int v15, v2, v13

    .line 177
    .line 178
    or-int/2addr v14, v15

    .line 179
    :cond_5
    add-int/lit8 v13, v13, 0x1

    .line 180
    .line 181
    goto :goto_2

    .line 182
    :cond_6
    invoke-static {v5, v10}, Ljava/util/Arrays;->fill([ZZ)V

    .line 183
    .line 184
    .line 185
    move v13, v10

    .line 186
    :goto_3
    if-ge v13, v15, :cond_9

    .line 187
    .line 188
    shl-int v16, v2, v13

    .line 189
    .line 190
    and-int v16, v14, v16

    .line 191
    .line 192
    if-eqz v16, :cond_8

    .line 193
    .line 194
    shl-int/lit8 v16, v13, 0x4

    .line 195
    .line 196
    move v9, v10

    .line 197
    :goto_4
    if-ge v9, v15, :cond_8

    .line 198
    .line 199
    invoke-static {v3, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 200
    .line 201
    .line 202
    move-result v18

    .line 203
    if-eqz v18, :cond_7

    .line 204
    .line 205
    add-int v18, v16, v9

    .line 206
    .line 207
    aput-boolean v2, v5, v18

    .line 208
    .line 209
    :cond_7
    add-int/lit8 v9, v9, 0x1

    .line 210
    .line 211
    goto :goto_4

    .line 212
    :cond_8
    add-int/lit8 v13, v13, 0x1

    .line 213
    .line 214
    const/16 v9, 0x20

    .line 215
    .line 216
    goto :goto_3

    .line 217
    :cond_9
    iget-object v5, v0, Lb8/b;->H:Lb8/a;

    .line 218
    .line 219
    iget-object v9, v5, Lb8/a;->a:[Z

    .line 220
    .line 221
    iget-object v5, v5, Lb8/a;->b:[B

    .line 222
    .line 223
    move v13, v10

    .line 224
    move v14, v13

    .line 225
    :goto_5
    const/16 v11, 0x100

    .line 226
    .line 227
    if-ge v13, v11, :cond_b

    .line 228
    .line 229
    aget-boolean v11, v9, v13

    .line 230
    .line 231
    if-eqz v11, :cond_a

    .line 232
    .line 233
    add-int/lit8 v11, v14, 0x1

    .line 234
    .line 235
    move/from16 v18, v10

    .line 236
    .line 237
    int-to-byte v10, v13

    .line 238
    aput-byte v10, v5, v14

    .line 239
    .line 240
    move v14, v11

    .line 241
    goto :goto_6

    .line 242
    :cond_a
    move/from16 v18, v10

    .line 243
    .line 244
    :goto_6
    add-int/lit8 v13, v13, 0x1

    .line 245
    .line 246
    move/from16 v10, v18

    .line 247
    .line 248
    goto :goto_5

    .line 249
    :cond_b
    move/from16 v18, v10

    .line 250
    .line 251
    iput v14, v0, Lb8/b;->s:I

    .line 252
    .line 253
    add-int/lit8 v14, v14, 0x2

    .line 254
    .line 255
    const/4 v5, 0x3

    .line 256
    invoke-static {v3, v5}, Lb8/b;->l(Lh8/a;I)I

    .line 257
    .line 258
    .line 259
    move-result v5

    .line 260
    const/16 v9, 0xf

    .line 261
    .line 262
    invoke-static {v3, v9}, Lb8/b;->l(Lh8/a;I)I

    .line 263
    .line 264
    .line 265
    move-result v9

    .line 266
    if-ltz v9, :cond_31

    .line 267
    .line 268
    const/16 v10, 0x103

    .line 269
    .line 270
    const-string v13, "alphaSize"

    .line 271
    .line 272
    invoke-static {v14, v10, v13}, Lb8/b;->u(IILjava/lang/String;)V

    .line 273
    .line 274
    .line 275
    const/4 v10, 0x7

    .line 276
    const-string v13, "nGroups"

    .line 277
    .line 278
    invoke-static {v5, v10, v13}, Lb8/b;->u(IILjava/lang/String;)V

    .line 279
    .line 280
    .line 281
    move/from16 v10, v18

    .line 282
    .line 283
    :goto_7
    const/16 v13, 0x4652

    .line 284
    .line 285
    if-ge v10, v9, :cond_e

    .line 286
    .line 287
    move/from16 v15, v18

    .line 288
    .line 289
    :goto_8
    invoke-static {v3, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 290
    .line 291
    .line 292
    move-result v20

    .line 293
    if-eqz v20, :cond_c

    .line 294
    .line 295
    add-int/lit8 v15, v15, 0x1

    .line 296
    .line 297
    goto :goto_8

    .line 298
    :cond_c
    if-ge v10, v13, :cond_d

    .line 299
    .line 300
    int-to-byte v13, v15

    .line 301
    aput-byte v13, v12, v10

    .line 302
    .line 303
    :cond_d
    add-int/lit8 v10, v10, 0x1

    .line 304
    .line 305
    const/16 v15, 0x10

    .line 306
    .line 307
    goto :goto_7

    .line 308
    :cond_e
    invoke-static {v9, v13}, Ljava/lang/Math;->min(II)I

    .line 309
    .line 310
    .line 311
    move-result v9

    .line 312
    move v10, v5

    .line 313
    :goto_9
    const/4 v15, -0x1

    .line 314
    add-int/2addr v10, v15

    .line 315
    if-ltz v10, :cond_f

    .line 316
    .line 317
    int-to-byte v15, v10

    .line 318
    aput-byte v15, v6, v10

    .line 319
    .line 320
    goto :goto_9

    .line 321
    :cond_f
    move/from16 v20, v15

    .line 322
    .line 323
    move/from16 v10, v18

    .line 324
    .line 325
    :goto_a
    const/4 v15, 0x6

    .line 326
    if-ge v10, v9, :cond_11

    .line 327
    .line 328
    aget-byte v13, v12, v10

    .line 329
    .line 330
    and-int/lit16 v13, v13, 0xff

    .line 331
    .line 332
    const-string v11, "selectorMtf"

    .line 333
    .line 334
    invoke-static {v13, v15, v11}, Lb8/b;->u(IILjava/lang/String;)V

    .line 335
    .line 336
    .line 337
    aget-byte v11, v6, v13

    .line 338
    .line 339
    :goto_b
    if-lez v13, :cond_10

    .line 340
    .line 341
    add-int/lit8 v15, v13, -0x1

    .line 342
    .line 343
    aget-byte v15, v6, v15

    .line 344
    .line 345
    aput-byte v15, v6, v13

    .line 346
    .line 347
    add-int/lit8 v13, v13, -0x1

    .line 348
    .line 349
    goto :goto_b

    .line 350
    :cond_10
    aput-byte v11, v6, v18

    .line 351
    .line 352
    aput-byte v11, v7, v10

    .line 353
    .line 354
    add-int/lit8 v10, v10, 0x1

    .line 355
    .line 356
    const/16 v11, 0x100

    .line 357
    .line 358
    const/16 v13, 0x4652

    .line 359
    .line 360
    goto :goto_a

    .line 361
    :cond_11
    iget-object v4, v4, Lb8/a;->l:[[C

    .line 362
    .line 363
    move/from16 v6, v18

    .line 364
    .line 365
    :goto_c
    if-ge v6, v5, :cond_15

    .line 366
    .line 367
    const/4 v7, 0x5

    .line 368
    invoke-static {v3, v7}, Lb8/b;->l(Lh8/a;I)I

    .line 369
    .line 370
    .line 371
    move-result v7

    .line 372
    aget-object v9, v4, v6

    .line 373
    .line 374
    move/from16 v10, v18

    .line 375
    .line 376
    :goto_d
    if-ge v10, v14, :cond_14

    .line 377
    .line 378
    :goto_e
    invoke-static {v3, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 379
    .line 380
    .line 381
    move-result v11

    .line 382
    if-eqz v11, :cond_13

    .line 383
    .line 384
    invoke-static {v3, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 385
    .line 386
    .line 387
    move-result v11

    .line 388
    if-eqz v11, :cond_12

    .line 389
    .line 390
    move/from16 v11, v20

    .line 391
    .line 392
    goto :goto_f

    .line 393
    :cond_12
    move v11, v2

    .line 394
    :goto_f
    add-int/2addr v7, v11

    .line 395
    goto :goto_e

    .line 396
    :cond_13
    int-to-char v11, v7

    .line 397
    aput-char v11, v9, v10

    .line 398
    .line 399
    add-int/lit8 v10, v10, 0x1

    .line 400
    .line 401
    goto :goto_d

    .line 402
    :cond_14
    add-int/lit8 v6, v6, 0x1

    .line 403
    .line 404
    goto :goto_c

    .line 405
    :cond_15
    iget-object v3, v0, Lb8/b;->H:Lb8/a;

    .line 406
    .line 407
    iget-object v4, v3, Lb8/a;->l:[[C

    .line 408
    .line 409
    iget-object v6, v3, Lb8/a;->i:[I

    .line 410
    .line 411
    iget-object v7, v3, Lb8/a;->f:[[I

    .line 412
    .line 413
    iget-object v9, v3, Lb8/a;->g:[[I

    .line 414
    .line 415
    iget-object v3, v3, Lb8/a;->h:[[I

    .line 416
    .line 417
    move/from16 v10, v18

    .line 418
    .line 419
    :goto_10
    if-ge v10, v5, :cond_21

    .line 420
    .line 421
    aget-object v12, v4, v10

    .line 422
    .line 423
    move/from16 v23, v2

    .line 424
    .line 425
    move/from16 v22, v14

    .line 426
    .line 427
    move/from16 v13, v18

    .line 428
    .line 429
    const/16 v2, 0x20

    .line 430
    .line 431
    :goto_11
    add-int/lit8 v22, v22, -0x1

    .line 432
    .line 433
    if-ltz v22, :cond_18

    .line 434
    .line 435
    aget-char v15, v12, v22

    .line 436
    .line 437
    if-le v15, v13, :cond_16

    .line 438
    .line 439
    move v13, v15

    .line 440
    :cond_16
    if-ge v15, v2, :cond_17

    .line 441
    .line 442
    move v2, v15

    .line 443
    :cond_17
    const/4 v15, 0x6

    .line 444
    goto :goto_11

    .line 445
    :cond_18
    aget-object v12, v7, v10

    .line 446
    .line 447
    aget-object v15, v9, v10

    .line 448
    .line 449
    aget-object v22, v3, v10

    .line 450
    .line 451
    aget-object v25, v4, v10

    .line 452
    .line 453
    move v8, v2

    .line 454
    move/from16 v26, v18

    .line 455
    .line 456
    :goto_12
    if-gt v8, v13, :cond_1b

    .line 457
    .line 458
    move/from16 v11, v18

    .line 459
    .line 460
    :goto_13
    if-ge v11, v14, :cond_1a

    .line 461
    .line 462
    move/from16 v29, v2

    .line 463
    .line 464
    aget-char v2, v25, v11

    .line 465
    .line 466
    if-ne v2, v8, :cond_19

    .line 467
    .line 468
    add-int/lit8 v2, v26, 0x1

    .line 469
    .line 470
    aput v11, v22, v26

    .line 471
    .line 472
    move/from16 v26, v2

    .line 473
    .line 474
    :cond_19
    add-int/lit8 v11, v11, 0x1

    .line 475
    .line 476
    move/from16 v2, v29

    .line 477
    .line 478
    goto :goto_13

    .line 479
    :cond_1a
    move/from16 v29, v2

    .line 480
    .line 481
    add-int/lit8 v8, v8, 0x1

    .line 482
    .line 483
    goto :goto_12

    .line 484
    :cond_1b
    move/from16 v29, v2

    .line 485
    .line 486
    const/16 v2, 0x17

    .line 487
    .line 488
    :goto_14
    add-int/lit8 v2, v2, -0x1

    .line 489
    .line 490
    if-lez v2, :cond_1c

    .line 491
    .line 492
    aput v18, v15, v2

    .line 493
    .line 494
    aput v18, v12, v2

    .line 495
    .line 496
    goto :goto_14

    .line 497
    :cond_1c
    move/from16 v2, v18

    .line 498
    .line 499
    :goto_15
    if-ge v2, v14, :cond_1d

    .line 500
    .line 501
    aget-char v8, v25, v2

    .line 502
    .line 503
    const-string v11, "length"

    .line 504
    .line 505
    move/from16 v22, v2

    .line 506
    .line 507
    const/16 v2, 0x102

    .line 508
    .line 509
    invoke-static {v8, v2, v11}, Lb8/b;->u(IILjava/lang/String;)V

    .line 510
    .line 511
    .line 512
    add-int/lit8 v8, v8, 0x1

    .line 513
    .line 514
    aget v2, v15, v8

    .line 515
    .line 516
    add-int/lit8 v2, v2, 0x1

    .line 517
    .line 518
    aput v2, v15, v8

    .line 519
    .line 520
    add-int/lit8 v2, v22, 0x1

    .line 521
    .line 522
    goto :goto_15

    .line 523
    :cond_1d
    aget v2, v15, v18

    .line 524
    .line 525
    move/from16 v8, v23

    .line 526
    .line 527
    const/16 v11, 0x17

    .line 528
    .line 529
    :goto_16
    if-ge v8, v11, :cond_1e

    .line 530
    .line 531
    aget v22, v15, v8

    .line 532
    .line 533
    add-int v2, v2, v22

    .line 534
    .line 535
    aput v2, v15, v8

    .line 536
    .line 537
    add-int/lit8 v8, v8, 0x1

    .line 538
    .line 539
    goto :goto_16

    .line 540
    :cond_1e
    aget v2, v15, v29

    .line 541
    .line 542
    move/from16 v8, v18

    .line 543
    .line 544
    move/from16 v11, v29

    .line 545
    .line 546
    :goto_17
    if-gt v11, v13, :cond_1f

    .line 547
    .line 548
    add-int/lit8 v22, v11, 0x1

    .line 549
    .line 550
    aget v25, v15, v22

    .line 551
    .line 552
    sub-int v2, v25, v2

    .line 553
    .line 554
    add-int/2addr v2, v8

    .line 555
    add-int/lit8 v8, v2, -0x1

    .line 556
    .line 557
    aput v8, v12, v11

    .line 558
    .line 559
    shl-int/lit8 v8, v2, 0x1

    .line 560
    .line 561
    move/from16 v11, v22

    .line 562
    .line 563
    move/from16 v2, v25

    .line 564
    .line 565
    goto :goto_17

    .line 566
    :cond_1f
    add-int/lit8 v2, v29, 0x1

    .line 567
    .line 568
    :goto_18
    if-gt v2, v13, :cond_20

    .line 569
    .line 570
    add-int/lit8 v8, v2, -0x1

    .line 571
    .line 572
    aget v8, v12, v8

    .line 573
    .line 574
    add-int/lit8 v8, v8, 0x1

    .line 575
    .line 576
    shl-int/lit8 v8, v8, 0x1

    .line 577
    .line 578
    aget v11, v15, v2

    .line 579
    .line 580
    sub-int/2addr v8, v11

    .line 581
    aput v8, v15, v2

    .line 582
    .line 583
    add-int/lit8 v2, v2, 0x1

    .line 584
    .line 585
    goto :goto_18

    .line 586
    :cond_20
    aput v29, v6, v10

    .line 587
    .line 588
    add-int/lit8 v10, v10, 0x1

    .line 589
    .line 590
    move/from16 v2, v23

    .line 591
    .line 592
    const/16 v8, 0x17

    .line 593
    .line 594
    const/4 v15, 0x6

    .line 595
    goto/16 :goto_10

    .line 596
    .line 597
    :cond_21
    move/from16 v23, v2

    .line 598
    .line 599
    iget-object v2, v0, Lb8/b;->H:Lb8/a;

    .line 600
    .line 601
    iget-object v3, v2, Lb8/a;->o:[B

    .line 602
    .line 603
    iget-object v4, v2, Lb8/a;->e:[I

    .line 604
    .line 605
    iget-object v5, v2, Lb8/a;->c:[B

    .line 606
    .line 607
    iget-object v6, v2, Lb8/a;->b:[B

    .line 608
    .line 609
    iget-object v7, v2, Lb8/a;->k:[C

    .line 610
    .line 611
    iget-object v8, v2, Lb8/a;->i:[I

    .line 612
    .line 613
    iget-object v9, v2, Lb8/a;->f:[[I

    .line 614
    .line 615
    iget-object v10, v2, Lb8/a;->g:[[I

    .line 616
    .line 617
    iget-object v2, v2, Lb8/a;->h:[[I

    .line 618
    .line 619
    iget v11, v0, Lb8/b;->p:I

    .line 620
    .line 621
    const v12, 0x186a0

    .line 622
    .line 623
    .line 624
    mul-int/2addr v11, v12

    .line 625
    const/16 v12, 0x100

    .line 626
    .line 627
    :goto_19
    add-int/lit8 v12, v12, -0x1

    .line 628
    .line 629
    if-ltz v12, :cond_22

    .line 630
    .line 631
    int-to-char v13, v12

    .line 632
    aput-char v13, v7, v12

    .line 633
    .line 634
    aput v18, v4, v12

    .line 635
    .line 636
    goto :goto_19

    .line 637
    :cond_22
    iget v12, v0, Lb8/b;->s:I

    .line 638
    .line 639
    add-int/lit8 v12, v12, 0x1

    .line 640
    .line 641
    iget-object v13, v0, Lb8/b;->H:Lb8/a;

    .line 642
    .line 643
    iget-object v14, v13, Lb8/a;->c:[B

    .line 644
    .line 645
    aget-byte v14, v14, v18

    .line 646
    .line 647
    and-int/lit16 v14, v14, 0xff

    .line 648
    .line 649
    const-string v15, "zt"

    .line 650
    .line 651
    move-object/from16 v17, v2

    .line 652
    .line 653
    const/4 v2, 0x6

    .line 654
    invoke-static {v14, v2, v15}, Lb8/b;->u(IILjava/lang/String;)V

    .line 655
    .line 656
    .line 657
    iget-object v2, v13, Lb8/a;->f:[[I

    .line 658
    .line 659
    aget-object v2, v2, v14

    .line 660
    .line 661
    move-object/from16 v22, v2

    .line 662
    .line 663
    iget-object v2, v13, Lb8/a;->i:[I

    .line 664
    .line 665
    aget v2, v2, v14

    .line 666
    .line 667
    move-object/from16 v25, v4

    .line 668
    .line 669
    const-string v4, "zn"

    .line 670
    .line 671
    move-object/from16 v26, v5

    .line 672
    .line 673
    const/16 v5, 0x102

    .line 674
    .line 675
    invoke-static {v2, v5, v4}, Lb8/b;->u(IILjava/lang/String;)V

    .line 676
    .line 677
    .line 678
    iget-object v5, v0, Lb8/b;->t:Lh8/a;

    .line 679
    .line 680
    invoke-static {v5, v2}, Lb8/b;->l(Lh8/a;I)I

    .line 681
    .line 682
    .line 683
    move-result v5

    .line 684
    move/from16 v27, v2

    .line 685
    .line 686
    :goto_1a
    aget v2, v22, v27

    .line 687
    .line 688
    if-le v5, v2, :cond_23

    .line 689
    .line 690
    add-int/lit8 v2, v27, 0x1

    .line 691
    .line 692
    move/from16 v29, v5

    .line 693
    .line 694
    const/16 v5, 0x102

    .line 695
    .line 696
    invoke-static {v2, v5, v4}, Lb8/b;->u(IILjava/lang/String;)V

    .line 697
    .line 698
    .line 699
    shl-int/lit8 v5, v29, 0x1

    .line 700
    .line 701
    move/from16 v27, v2

    .line 702
    .line 703
    iget-object v2, v0, Lb8/b;->t:Lh8/a;

    .line 704
    .line 705
    move/from16 v29, v5

    .line 706
    .line 707
    move/from16 v5, v23

    .line 708
    .line 709
    invoke-static {v2, v5}, Lb8/b;->l(Lh8/a;I)I

    .line 710
    .line 711
    .line 712
    move-result v2

    .line 713
    or-int v5, v29, v2

    .line 714
    .line 715
    const/16 v23, 0x1

    .line 716
    .line 717
    goto :goto_1a

    .line 718
    :cond_23
    move/from16 v29, v5

    .line 719
    .line 720
    iget-object v2, v13, Lb8/a;->g:[[I

    .line 721
    .line 722
    aget-object v2, v2, v14

    .line 723
    .line 724
    aget v2, v2, v27

    .line 725
    .line 726
    sub-int v5, v29, v2

    .line 727
    .line 728
    const-string v2, "zvec"

    .line 729
    .line 730
    move-object/from16 v22, v6

    .line 731
    .line 732
    const/16 v6, 0x102

    .line 733
    .line 734
    invoke-static {v5, v6, v2}, Lb8/b;->u(IILjava/lang/String;)V

    .line 735
    .line 736
    .line 737
    iget-object v6, v13, Lb8/a;->h:[[I

    .line 738
    .line 739
    aget-object v6, v6, v14

    .line 740
    .line 741
    aget v5, v6, v5

    .line 742
    .line 743
    aget-byte v6, v26, v18

    .line 744
    .line 745
    and-int/lit16 v6, v6, 0xff

    .line 746
    .line 747
    const/4 v13, 0x6

    .line 748
    invoke-static {v6, v13, v15}, Lb8/b;->u(IILjava/lang/String;)V

    .line 749
    .line 750
    .line 751
    aget-object v13, v10, v6

    .line 752
    .line 753
    aget-object v14, v9, v6

    .line 754
    .line 755
    aget-object v27, v17, v6

    .line 756
    .line 757
    aget v6, v8, v6

    .line 758
    .line 759
    move/from16 v30, v6

    .line 760
    .line 761
    move/from16 v6, v20

    .line 762
    .line 763
    move-object/from16 v29, v27

    .line 764
    .line 765
    const/16 v31, 0x31

    .line 766
    .line 767
    move/from16 v27, v18

    .line 768
    .line 769
    :goto_1b
    if-eq v5, v12, :cond_30

    .line 770
    .line 771
    move-object/from16 v32, v8

    .line 772
    .line 773
    const-string v8, "groupNo"

    .line 774
    .line 775
    move-object/from16 v33, v9

    .line 776
    .line 777
    const-string v9, "yy"

    .line 778
    .line 779
    move-object/from16 v34, v10

    .line 780
    .line 781
    const-string v10, " exceeds "

    .line 782
    .line 783
    move/from16 v35, v12

    .line 784
    .line 785
    if-eqz v5, :cond_24

    .line 786
    .line 787
    const/4 v12, 0x1

    .line 788
    if-ne v5, v12, :cond_25

    .line 789
    .line 790
    :cond_24
    move-object/from16 v36, v13

    .line 791
    .line 792
    const/16 v13, 0x10

    .line 793
    .line 794
    goto/16 :goto_22

    .line 795
    .line 796
    :cond_25
    add-int/lit8 v6, v6, 0x1

    .line 797
    .line 798
    if-ge v6, v11, :cond_2a

    .line 799
    .line 800
    const/16 v10, 0x101

    .line 801
    .line 802
    const-string v12, "nextSym"

    .line 803
    .line 804
    invoke-static {v5, v10, v12}, Lb8/b;->u(IILjava/lang/String;)V

    .line 805
    .line 806
    .line 807
    add-int/lit8 v10, v5, -0x1

    .line 808
    .line 809
    aget-char v12, v7, v10

    .line 810
    .line 811
    move-object/from16 v36, v13

    .line 812
    .line 813
    const/16 v13, 0x100

    .line 814
    .line 815
    invoke-static {v12, v13, v9}, Lb8/b;->u(IILjava/lang/String;)V

    .line 816
    .line 817
    .line 818
    aget-byte v9, v22, v12

    .line 819
    .line 820
    and-int/lit16 v13, v9, 0xff

    .line 821
    .line 822
    aget v37, v25, v13

    .line 823
    .line 824
    const/16 v23, 0x1

    .line 825
    .line 826
    add-int/lit8 v37, v37, 0x1

    .line 827
    .line 828
    aput v37, v25, v13

    .line 829
    .line 830
    aput-byte v9, v3, v6

    .line 831
    .line 832
    const/16 v13, 0x10

    .line 833
    .line 834
    if-gt v5, v13, :cond_27

    .line 835
    .line 836
    :goto_1c
    if-lez v10, :cond_26

    .line 837
    .line 838
    add-int/lit8 v5, v10, -0x1

    .line 839
    .line 840
    aget-char v9, v7, v5

    .line 841
    .line 842
    aput-char v9, v7, v10

    .line 843
    .line 844
    move v10, v5

    .line 845
    goto :goto_1c

    .line 846
    :cond_26
    move/from16 v5, v18

    .line 847
    .line 848
    goto :goto_1d

    .line 849
    :cond_27
    move/from16 v5, v18

    .line 850
    .line 851
    const/4 v9, 0x1

    .line 852
    invoke-static {v7, v5, v7, v9, v10}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 853
    .line 854
    .line 855
    :goto_1d
    aput-char v12, v7, v5

    .line 856
    .line 857
    if-nez v31, :cond_28

    .line 858
    .line 859
    add-int/lit8 v5, v27, 0x1

    .line 860
    .line 861
    const/16 v9, 0x4652

    .line 862
    .line 863
    invoke-static {v5, v9, v8}, Lb8/b;->u(IILjava/lang/String;)V

    .line 864
    .line 865
    .line 866
    aget-byte v8, v26, v5

    .line 867
    .line 868
    and-int/lit16 v8, v8, 0xff

    .line 869
    .line 870
    const/4 v9, 0x6

    .line 871
    invoke-static {v8, v9, v15}, Lb8/b;->u(IILjava/lang/String;)V

    .line 872
    .line 873
    .line 874
    aget-object v9, v34, v8

    .line 875
    .line 876
    aget-object v10, v33, v8

    .line 877
    .line 878
    aget-object v12, v17, v8

    .line 879
    .line 880
    aget v8, v32, v8

    .line 881
    .line 882
    move/from16 v27, v5

    .line 883
    .line 884
    move-object/from16 v36, v9

    .line 885
    .line 886
    move-object v14, v10

    .line 887
    move-object/from16 v29, v12

    .line 888
    .line 889
    const/16 v31, 0x31

    .line 890
    .line 891
    :goto_1e
    const/16 v5, 0x102

    .line 892
    .line 893
    goto :goto_1f

    .line 894
    :cond_28
    add-int/lit8 v31, v31, -0x1

    .line 895
    .line 896
    move/from16 v8, v30

    .line 897
    .line 898
    goto :goto_1e

    .line 899
    :goto_1f
    invoke-static {v8, v5, v4}, Lb8/b;->u(IILjava/lang/String;)V

    .line 900
    .line 901
    .line 902
    invoke-static {v1, v8}, Lb8/b;->l(Lh8/a;I)I

    .line 903
    .line 904
    .line 905
    move-result v9

    .line 906
    move v10, v8

    .line 907
    :goto_20
    aget v12, v14, v10

    .line 908
    .line 909
    if-le v9, v12, :cond_29

    .line 910
    .line 911
    add-int/lit8 v10, v10, 0x1

    .line 912
    .line 913
    invoke-static {v10, v5, v4}, Lb8/b;->u(IILjava/lang/String;)V

    .line 914
    .line 915
    .line 916
    shl-int/lit8 v9, v9, 0x1

    .line 917
    .line 918
    const/4 v12, 0x1

    .line 919
    invoke-static {v1, v12}, Lb8/b;->l(Lh8/a;I)I

    .line 920
    .line 921
    .line 922
    move-result v19

    .line 923
    or-int v9, v9, v19

    .line 924
    .line 925
    goto :goto_20

    .line 926
    :cond_29
    aget v10, v36, v10

    .line 927
    .line 928
    sub-int/2addr v9, v10

    .line 929
    invoke-static {v9, v5, v2}, Lb8/b;->u(IILjava/lang/String;)V

    .line 930
    .line 931
    .line 932
    aget v5, v29, v9

    .line 933
    .line 934
    move/from16 v30, v8

    .line 935
    .line 936
    move-object/from16 v8, v32

    .line 937
    .line 938
    move-object/from16 v9, v33

    .line 939
    .line 940
    move-object/from16 v10, v34

    .line 941
    .line 942
    move/from16 v12, v35

    .line 943
    .line 944
    move-object/from16 v13, v36

    .line 945
    .line 946
    :goto_21
    const/16 v18, 0x0

    .line 947
    .line 948
    goto/16 :goto_1b

    .line 949
    .line 950
    :cond_2a
    const-string v1, "Block overrun in MTF, "

    .line 951
    .line 952
    invoke-static {v6, v11, v1, v10}, Lb/m;->g(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 953
    .line 954
    .line 955
    move-result-object v1

    .line 956
    invoke-static {v1}, Lq0/b;->o(Ljava/lang/String;)V

    .line 957
    .line 958
    .line 959
    return-void

    .line 960
    :goto_22
    move/from16 v13, v20

    .line 961
    .line 962
    const/4 v12, 0x1

    .line 963
    :goto_23
    if-nez v5, :cond_2b

    .line 964
    .line 965
    add-int/2addr v13, v12

    .line 966
    move-object/from16 v37, v7

    .line 967
    .line 968
    goto :goto_24

    .line 969
    :cond_2b
    move-object/from16 v37, v7

    .line 970
    .line 971
    const/4 v7, 0x1

    .line 972
    if-ne v5, v7, :cond_2e

    .line 973
    .line 974
    shl-int/lit8 v5, v12, 0x1

    .line 975
    .line 976
    add-int/2addr v13, v5

    .line 977
    :goto_24
    if-nez v31, :cond_2c

    .line 978
    .line 979
    add-int/lit8 v5, v27, 0x1

    .line 980
    .line 981
    const/16 v7, 0x4652

    .line 982
    .line 983
    invoke-static {v5, v7, v8}, Lb8/b;->u(IILjava/lang/String;)V

    .line 984
    .line 985
    .line 986
    aget-byte v14, v26, v5

    .line 987
    .line 988
    and-int/lit16 v14, v14, 0xff

    .line 989
    .line 990
    const/4 v7, 0x6

    .line 991
    invoke-static {v14, v7, v15}, Lb8/b;->u(IILjava/lang/String;)V

    .line 992
    .line 993
    .line 994
    aget-object v36, v34, v14

    .line 995
    .line 996
    aget-object v24, v33, v14

    .line 997
    .line 998
    aget-object v29, v17, v14

    .line 999
    .line 1000
    aget v30, v32, v14

    .line 1001
    .line 1002
    move/from16 v27, v5

    .line 1003
    .line 1004
    move-object/from16 v14, v24

    .line 1005
    .line 1006
    const/16 v31, 0x31

    .line 1007
    .line 1008
    :goto_25
    move/from16 v5, v30

    .line 1009
    .line 1010
    const/16 v7, 0x102

    .line 1011
    .line 1012
    goto :goto_26

    .line 1013
    :cond_2c
    const/4 v7, 0x6

    .line 1014
    add-int/lit8 v31, v31, -0x1

    .line 1015
    .line 1016
    goto :goto_25

    .line 1017
    :goto_26
    invoke-static {v5, v7, v4}, Lb8/b;->u(IILjava/lang/String;)V

    .line 1018
    .line 1019
    .line 1020
    invoke-static {v1, v5}, Lb8/b;->l(Lh8/a;I)I

    .line 1021
    .line 1022
    .line 1023
    move-result v28

    .line 1024
    move/from16 v30, v5

    .line 1025
    .line 1026
    move/from16 v7, v28

    .line 1027
    .line 1028
    move/from16 v28, v30

    .line 1029
    .line 1030
    :goto_27
    aget v5, v14, v28

    .line 1031
    .line 1032
    if-le v7, v5, :cond_2d

    .line 1033
    .line 1034
    add-int/lit8 v5, v28, 0x1

    .line 1035
    .line 1036
    move/from16 v38, v7

    .line 1037
    .line 1038
    const/16 v7, 0x102

    .line 1039
    .line 1040
    invoke-static {v5, v7, v4}, Lb8/b;->u(IILjava/lang/String;)V

    .line 1041
    .line 1042
    .line 1043
    shl-int/lit8 v28, v38, 0x1

    .line 1044
    .line 1045
    const/4 v7, 0x1

    .line 1046
    invoke-static {v1, v7}, Lb8/b;->l(Lh8/a;I)I

    .line 1047
    .line 1048
    .line 1049
    move-result v38

    .line 1050
    or-int v7, v28, v38

    .line 1051
    .line 1052
    move/from16 v28, v5

    .line 1053
    .line 1054
    goto :goto_27

    .line 1055
    :cond_2d
    move/from16 v38, v7

    .line 1056
    .line 1057
    aget v5, v36, v28

    .line 1058
    .line 1059
    sub-int v7, v38, v5

    .line 1060
    .line 1061
    const/16 v5, 0x102

    .line 1062
    .line 1063
    invoke-static {v7, v5, v2}, Lb8/b;->u(IILjava/lang/String;)V

    .line 1064
    .line 1065
    .line 1066
    aget v7, v29, v7

    .line 1067
    .line 1068
    shl-int/lit8 v12, v12, 0x1

    .line 1069
    .line 1070
    move v5, v7

    .line 1071
    move-object/from16 v7, v37

    .line 1072
    .line 1073
    goto :goto_23

    .line 1074
    :cond_2e
    const/16 v28, 0x102

    .line 1075
    .line 1076
    iget-object v7, v0, Lb8/b;->H:Lb8/a;

    .line 1077
    .line 1078
    iget-object v7, v7, Lb8/a;->o:[B

    .line 1079
    .line 1080
    array-length v7, v7

    .line 1081
    const-string v8, "s"

    .line 1082
    .line 1083
    invoke-static {v13, v7, v8}, Lb8/b;->u(IILjava/lang/String;)V

    .line 1084
    .line 1085
    .line 1086
    const/16 v18, 0x0

    .line 1087
    .line 1088
    aget-char v7, v37, v18

    .line 1089
    .line 1090
    const/16 v8, 0x100

    .line 1091
    .line 1092
    invoke-static {v7, v8, v9}, Lb8/b;->u(IILjava/lang/String;)V

    .line 1093
    .line 1094
    .line 1095
    aget-byte v7, v22, v7

    .line 1096
    .line 1097
    and-int/lit16 v9, v7, 0xff

    .line 1098
    .line 1099
    aget v12, v25, v9

    .line 1100
    .line 1101
    add-int/lit8 v21, v13, 0x1

    .line 1102
    .line 1103
    add-int v21, v21, v12

    .line 1104
    .line 1105
    aput v21, v25, v9

    .line 1106
    .line 1107
    add-int/lit8 v6, v6, 0x1

    .line 1108
    .line 1109
    add-int v9, v6, v13

    .line 1110
    .line 1111
    iget-object v12, v0, Lb8/b;->H:Lb8/a;

    .line 1112
    .line 1113
    iget-object v12, v12, Lb8/a;->o:[B

    .line 1114
    .line 1115
    array-length v12, v12

    .line 1116
    const-string v13, "lastShadow"

    .line 1117
    .line 1118
    invoke-static {v9, v12, v13}, Lb8/b;->u(IILjava/lang/String;)V

    .line 1119
    .line 1120
    .line 1121
    add-int/lit8 v12, v9, 0x1

    .line 1122
    .line 1123
    invoke-static {v3, v6, v12, v7}, Ljava/util/Arrays;->fill([BIIB)V

    .line 1124
    .line 1125
    .line 1126
    if-ge v9, v11, :cond_2f

    .line 1127
    .line 1128
    move v6, v9

    .line 1129
    move-object/from16 v8, v32

    .line 1130
    .line 1131
    move-object/from16 v9, v33

    .line 1132
    .line 1133
    move-object/from16 v10, v34

    .line 1134
    .line 1135
    move/from16 v12, v35

    .line 1136
    .line 1137
    move-object/from16 v13, v36

    .line 1138
    .line 1139
    move-object/from16 v7, v37

    .line 1140
    .line 1141
    goto/16 :goto_21

    .line 1142
    .line 1143
    :cond_2f
    const-string v1, "Block overrun while expanding RLE in MTF, "

    .line 1144
    .line 1145
    invoke-static {v9, v11, v1, v10}, Lb/m;->g(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1146
    .line 1147
    .line 1148
    move-result-object v1

    .line 1149
    invoke-static {v1}, Lq0/b;->o(Ljava/lang/String;)V

    .line 1150
    .line 1151
    .line 1152
    return-void

    .line 1153
    :cond_30
    iput v6, v0, Lb8/b;->n:I

    .line 1154
    .line 1155
    iget-object v1, v0, Lb8/b;->r:Lb8/c;

    .line 1156
    .line 1157
    move/from16 v2, v20

    .line 1158
    .line 1159
    iput v2, v1, Lb8/c;->a:I

    .line 1160
    .line 1161
    const/4 v7, 0x1

    .line 1162
    iput v7, v0, Lb8/b;->u:I

    .line 1163
    .line 1164
    return-void

    .line 1165
    :cond_31
    const-string v1, "Corrupted input, nSelectors value negative"

    .line 1166
    .line 1167
    invoke-static {v1}, Lq0/b;->o(Ljava/lang/String;)V

    .line 1168
    .line 1169
    .line 1170
    return-void

    .line 1171
    :cond_32
    move v5, v10

    .line 1172
    iput v5, v0, Lb8/b;->u:I

    .line 1173
    .line 1174
    const-string v1, "Bad block header"

    .line 1175
    .line 1176
    invoke-static {v1}, Lq0/b;->o(Ljava/lang/String;)V

    .line 1177
    .line 1178
    .line 1179
    return-void
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
    .line 2155
    .line 2156
    .line 2157
    .line 2158
    .line 2159
    .line 2160
    .line 2161
    .line 2162
    .line 2163
    .line 2164
    .line 2165
    .line 2166
    .line 2167
    .line 2168
    .line 2169
    .line 2170
    .line 2171
    .line 2172
    .line 2173
    .line 2174
    .line 2175
    .line 2176
    .line 2177
    .line 2178
    .line 2179
    .line 2180
    .line 2181
    .line 2182
    .line 2183
    .line 2184
    .line 2185
    .line 2186
    .line 2187
    .line 2188
    .line 2189
    .line 2190
    .line 2191
    .line 2192
    .line 2193
    .line 2194
    .line 2195
    .line 2196
    .line 2197
    .line 2198
    .line 2199
    .line 2200
    .line 2201
    .line 2202
    .line 2203
    .line 2204
    .line 2205
    .line 2206
    .line 2207
    .line 2208
    .line 2209
    .line 2210
    .line 2211
    .line 2212
    .line 2213
    .line 2214
    .line 2215
    .line 2216
    .line 2217
    .line 2218
    .line 2219
    .line 2220
    .line 2221
    .line 2222
    .line 2223
    .line 2224
    .line 2225
    .line 2226
    .line 2227
    .line 2228
    .line 2229
    .line 2230
    .line 2231
    .line 2232
    .line 2233
    .line 2234
    .line 2235
    .line 2236
    .line 2237
    .line 2238
    .line 2239
    .line 2240
    .line 2241
    .line 2242
    .line 2243
    .line 2244
    .line 2245
    .line 2246
    .line 2247
    .line 2248
    .line 2249
    .line 2250
    .line 2251
    .line 2252
    .line 2253
    .line 2254
    .line 2255
    .line 2256
    .line 2257
    .line 2258
    .line 2259
    .line 2260
    .line 2261
    .line 2262
    .line 2263
    .line 2264
    .line 2265
    .line 2266
    .line 2267
    .line 2268
    .line 2269
    .line 2270
    .line 2271
    .line 2272
    .line 2273
    .line 2274
    .line 2275
    .line 2276
    .line 2277
    .line 2278
    .line 2279
    .line 2280
    .line 2281
    .line 2282
    .line 2283
    .line 2284
    .line 2285
    .line 2286
    .line 2287
    .line 2288
    .line 2289
    .line 2290
    .line 2291
    .line 2292
    .line 2293
    .line 2294
    .line 2295
    .line 2296
    .line 2297
    .line 2298
    .line 2299
    .line 2300
    .line 2301
    .line 2302
    .line 2303
    .line 2304
    .line 2305
    .line 2306
    .line 2307
    .line 2308
    .line 2309
    .line 2310
    .line 2311
    .line 2312
    .line 2313
    .line 2314
.end method

.method public final H()I
    .locals 7

    .line 1
    iget v0, p0, Lb8/b;->u:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const-string v2, "su_tPos"

    .line 5
    .line 6
    const/4 v3, 0x4

    .line 7
    const/4 v4, 0x1

    .line 8
    packed-switch v0, :pswitch_data_0

    .line 9
    .line 10
    .line 11
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 14
    .line 15
    .line 16
    throw v0

    .line 17
    :pswitch_0
    invoke-virtual {p0}, Lb8/b;->R()I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    return v0

    .line 22
    :pswitch_1
    iget v0, p0, Lb8/b;->z:I

    .line 23
    .line 24
    iget v5, p0, Lb8/b;->A:I

    .line 25
    .line 26
    if-eq v0, v5, :cond_0

    .line 27
    .line 28
    iput v4, p0, Lb8/b;->y:I

    .line 29
    .line 30
    invoke-virtual {p0}, Lb8/b;->Q()I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    return v0

    .line 35
    :cond_0
    iget v0, p0, Lb8/b;->y:I

    .line 36
    .line 37
    add-int/2addr v0, v4

    .line 38
    iput v0, p0, Lb8/b;->y:I

    .line 39
    .line 40
    if-lt v0, v3, :cond_1

    .line 41
    .line 42
    iget v0, p0, Lb8/b;->F:I

    .line 43
    .line 44
    iget-object v3, p0, Lb8/b;->H:Lb8/a;

    .line 45
    .line 46
    iget-object v3, v3, Lb8/a;->o:[B

    .line 47
    .line 48
    array-length v3, v3

    .line 49
    invoke-static {v0, v3, v2}, Lb8/b;->u(IILjava/lang/String;)V

    .line 50
    .line 51
    .line 52
    iget-object v0, p0, Lb8/b;->H:Lb8/a;

    .line 53
    .line 54
    iget-object v2, v0, Lb8/a;->o:[B

    .line 55
    .line 56
    iget v3, p0, Lb8/b;->F:I

    .line 57
    .line 58
    aget-byte v2, v2, v3

    .line 59
    .line 60
    and-int/lit16 v2, v2, 0xff

    .line 61
    .line 62
    int-to-char v2, v2

    .line 63
    iput-char v2, p0, Lb8/b;->G:C

    .line 64
    .line 65
    iget-object v0, v0, Lb8/a;->n:[I

    .line 66
    .line 67
    aget v0, v0, v3

    .line 68
    .line 69
    iput v0, p0, Lb8/b;->F:I

    .line 70
    .line 71
    iput v1, p0, Lb8/b;->C:I

    .line 72
    .line 73
    invoke-virtual {p0}, Lb8/b;->R()I

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    return v0

    .line 78
    :cond_1
    invoke-virtual {p0}, Lb8/b;->Q()I

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    return v0

    .line 83
    :pswitch_2
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 84
    .line 85
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 86
    .line 87
    .line 88
    throw v0

    .line 89
    :pswitch_3
    invoke-virtual {p0}, Lb8/b;->T()I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    return v0

    .line 94
    :pswitch_4
    iget v0, p0, Lb8/b;->z:I

    .line 95
    .line 96
    iget v5, p0, Lb8/b;->A:I

    .line 97
    .line 98
    const/4 v6, 0x2

    .line 99
    if-eq v0, v5, :cond_2

    .line 100
    .line 101
    iput v6, p0, Lb8/b;->u:I

    .line 102
    .line 103
    iput v4, p0, Lb8/b;->y:I

    .line 104
    .line 105
    invoke-virtual {p0}, Lb8/b;->S()I

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    return v0

    .line 110
    :cond_2
    iget v0, p0, Lb8/b;->y:I

    .line 111
    .line 112
    add-int/2addr v0, v4

    .line 113
    iput v0, p0, Lb8/b;->y:I

    .line 114
    .line 115
    if-ge v0, v3, :cond_3

    .line 116
    .line 117
    iput v6, p0, Lb8/b;->u:I

    .line 118
    .line 119
    invoke-virtual {p0}, Lb8/b;->S()I

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    return v0

    .line 124
    :cond_3
    iget-object v0, p0, Lb8/b;->H:Lb8/a;

    .line 125
    .line 126
    iget-object v5, v0, Lb8/a;->o:[B

    .line 127
    .line 128
    iget v6, p0, Lb8/b;->F:I

    .line 129
    .line 130
    aget-byte v5, v5, v6

    .line 131
    .line 132
    and-int/lit16 v5, v5, 0xff

    .line 133
    .line 134
    int-to-char v5, v5

    .line 135
    iput-char v5, p0, Lb8/b;->G:C

    .line 136
    .line 137
    iget-object v0, v0, Lb8/a;->n:[I

    .line 138
    .line 139
    array-length v0, v0

    .line 140
    invoke-static {v6, v0, v2}, Lb8/b;->u(IILjava/lang/String;)V

    .line 141
    .line 142
    .line 143
    iget-object v0, p0, Lb8/b;->H:Lb8/a;

    .line 144
    .line 145
    iget-object v0, v0, Lb8/a;->n:[I

    .line 146
    .line 147
    iget v2, p0, Lb8/b;->F:I

    .line 148
    .line 149
    aget v0, v0, v2

    .line 150
    .line 151
    iput v0, p0, Lb8/b;->F:I

    .line 152
    .line 153
    iget v0, p0, Lb8/b;->D:I

    .line 154
    .line 155
    if-nez v0, :cond_4

    .line 156
    .line 157
    iget v0, p0, Lb8/b;->E:I

    .line 158
    .line 159
    sget-object v2, Lb8/d;->a:[I

    .line 160
    .line 161
    aget v2, v2, v0

    .line 162
    .line 163
    sub-int/2addr v2, v4

    .line 164
    iput v2, p0, Lb8/b;->D:I

    .line 165
    .line 166
    add-int/2addr v0, v4

    .line 167
    iput v0, p0, Lb8/b;->E:I

    .line 168
    .line 169
    const/16 v2, 0x200

    .line 170
    .line 171
    if-ne v0, v2, :cond_5

    .line 172
    .line 173
    iput v1, p0, Lb8/b;->E:I

    .line 174
    .line 175
    goto :goto_0

    .line 176
    :cond_4
    sub-int/2addr v0, v4

    .line 177
    iput v0, p0, Lb8/b;->D:I

    .line 178
    .line 179
    :cond_5
    :goto_0
    iput v1, p0, Lb8/b;->C:I

    .line 180
    .line 181
    iput v3, p0, Lb8/b;->u:I

    .line 182
    .line 183
    iget v0, p0, Lb8/b;->D:I

    .line 184
    .line 185
    if-ne v0, v4, :cond_6

    .line 186
    .line 187
    iget-char v0, p0, Lb8/b;->G:C

    .line 188
    .line 189
    xor-int/2addr v0, v4

    .line 190
    int-to-char v0, v0

    .line 191
    iput-char v0, p0, Lb8/b;->G:C

    .line 192
    .line 193
    :cond_6
    invoke-virtual {p0}, Lb8/b;->T()I

    .line 194
    .line 195
    .line 196
    move-result v0

    .line 197
    return v0

    .line 198
    :pswitch_5
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 199
    .line 200
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 201
    .line 202
    .line 203
    throw v0

    .line 204
    :pswitch_6
    invoke-virtual {p0}, Lb8/b;->P()I

    .line 205
    .line 206
    .line 207
    move-result v0

    .line 208
    return v0

    .line 209
    :pswitch_7
    const/4 v0, -0x1

    .line 210
    return v0

    .line 211
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
.end method

.method public final P()I
    .locals 11

    .line 1
    iget v0, p0, Lb8/b;->u:I

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    iget-object v0, p0, Lb8/b;->H:Lb8/a;

    .line 6
    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    goto :goto_2

    .line 10
    :cond_0
    iget-object v1, v0, Lb8/a;->j:[I

    .line 11
    .line 12
    iget v2, p0, Lb8/b;->n:I

    .line 13
    .line 14
    const/4 v3, 0x1

    .line 15
    add-int/2addr v2, v3

    .line 16
    iget-object v4, v0, Lb8/a;->n:[I

    .line 17
    .line 18
    if-eqz v4, :cond_1

    .line 19
    .line 20
    array-length v5, v4

    .line 21
    if-ge v5, v2, :cond_2

    .line 22
    .line 23
    :cond_1
    new-array v4, v2, [I

    .line 24
    .line 25
    iput-object v4, v0, Lb8/a;->n:[I

    .line 26
    .line 27
    :cond_2
    iget-object v5, v0, Lb8/a;->o:[B

    .line 28
    .line 29
    const/4 v6, 0x0

    .line 30
    aput v6, v1, v6

    .line 31
    .line 32
    iget-object v0, v0, Lb8/a;->e:[I

    .line 33
    .line 34
    const/16 v7, 0x100

    .line 35
    .line 36
    invoke-static {v0, v6, v1, v3, v7}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 37
    .line 38
    .line 39
    aget v0, v1, v6

    .line 40
    .line 41
    :goto_0
    if-gt v3, v7, :cond_3

    .line 42
    .line 43
    aget v8, v1, v3

    .line 44
    .line 45
    add-int/2addr v0, v8

    .line 46
    aput v0, v1, v3

    .line 47
    .line 48
    add-int/lit8 v3, v3, 0x1

    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_3
    iget v0, p0, Lb8/b;->n:I

    .line 52
    .line 53
    move v3, v6

    .line 54
    :goto_1
    if-gt v3, v0, :cond_4

    .line 55
    .line 56
    aget-byte v8, v5, v3

    .line 57
    .line 58
    and-int/lit16 v8, v8, 0xff

    .line 59
    .line 60
    aget v9, v1, v8

    .line 61
    .line 62
    add-int/lit8 v10, v9, 0x1

    .line 63
    .line 64
    aput v10, v1, v8

    .line 65
    .line 66
    const-string v8, "tt index"

    .line 67
    .line 68
    invoke-static {v9, v2, v8}, Lb8/b;->u(IILjava/lang/String;)V

    .line 69
    .line 70
    .line 71
    aput v3, v4, v9

    .line 72
    .line 73
    add-int/lit8 v3, v3, 0x1

    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_4
    iget v0, p0, Lb8/b;->o:I

    .line 77
    .line 78
    if-ltz v0, :cond_6

    .line 79
    .line 80
    array-length v1, v4

    .line 81
    if-ge v0, v1, :cond_6

    .line 82
    .line 83
    aget v0, v4, v0

    .line 84
    .line 85
    iput v0, p0, Lb8/b;->F:I

    .line 86
    .line 87
    iput v6, p0, Lb8/b;->y:I

    .line 88
    .line 89
    iput v6, p0, Lb8/b;->B:I

    .line 90
    .line 91
    iput v7, p0, Lb8/b;->z:I

    .line 92
    .line 93
    iget-boolean v0, p0, Lb8/b;->q:Z

    .line 94
    .line 95
    if-eqz v0, :cond_5

    .line 96
    .line 97
    iput v6, p0, Lb8/b;->D:I

    .line 98
    .line 99
    iput v6, p0, Lb8/b;->E:I

    .line 100
    .line 101
    invoke-virtual {p0}, Lb8/b;->S()I

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    return v0

    .line 106
    :cond_5
    invoke-virtual {p0}, Lb8/b;->Q()I

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    return v0

    .line 111
    :cond_6
    const-string v0, "Stream corrupted"

    .line 112
    .line 113
    invoke-static {v0}, Lq0/b;->o(Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    const/4 v0, 0x0

    .line 117
    return v0

    .line 118
    :cond_7
    :goto_2
    const/4 v0, -0x1

    .line 119
    return v0
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
.end method

.method public final Q()I
    .locals 4

    .line 1
    iget v0, p0, Lb8/b;->B:I

    .line 2
    .line 3
    iget v1, p0, Lb8/b;->n:I

    .line 4
    .line 5
    if-gt v0, v1, :cond_0

    .line 6
    .line 7
    iget v0, p0, Lb8/b;->z:I

    .line 8
    .line 9
    iput v0, p0, Lb8/b;->A:I

    .line 10
    .line 11
    iget-object v0, p0, Lb8/b;->H:Lb8/a;

    .line 12
    .line 13
    iget-object v1, v0, Lb8/a;->o:[B

    .line 14
    .line 15
    iget v2, p0, Lb8/b;->F:I

    .line 16
    .line 17
    aget-byte v1, v1, v2

    .line 18
    .line 19
    and-int/lit16 v1, v1, 0xff

    .line 20
    .line 21
    iput v1, p0, Lb8/b;->z:I

    .line 22
    .line 23
    iget-object v0, v0, Lb8/a;->n:[I

    .line 24
    .line 25
    array-length v0, v0

    .line 26
    const-string v3, "su_tPos"

    .line 27
    .line 28
    invoke-static {v2, v0, v3}, Lb8/b;->u(IILjava/lang/String;)V

    .line 29
    .line 30
    .line 31
    iget-object v0, p0, Lb8/b;->H:Lb8/a;

    .line 32
    .line 33
    iget-object v0, v0, Lb8/a;->n:[I

    .line 34
    .line 35
    iget v2, p0, Lb8/b;->F:I

    .line 36
    .line 37
    aget v0, v0, v2

    .line 38
    .line 39
    iput v0, p0, Lb8/b;->F:I

    .line 40
    .line 41
    iget v0, p0, Lb8/b;->B:I

    .line 42
    .line 43
    add-int/lit8 v0, v0, 0x1

    .line 44
    .line 45
    iput v0, p0, Lb8/b;->B:I

    .line 46
    .line 47
    const/4 v0, 0x6

    .line 48
    iput v0, p0, Lb8/b;->u:I

    .line 49
    .line 50
    iget-object v0, p0, Lb8/b;->r:Lb8/c;

    .line 51
    .line 52
    invoke-virtual {v0, v1}, Lb8/c;->a(I)V

    .line 53
    .line 54
    .line 55
    return v1

    .line 56
    :cond_0
    const/4 v0, 0x5

    .line 57
    iput v0, p0, Lb8/b;->u:I

    .line 58
    .line 59
    invoke-virtual {p0}, Lb8/b;->z()V

    .line 60
    .line 61
    .line 62
    invoke-virtual {p0}, Lb8/b;->A()V

    .line 63
    .line 64
    .line 65
    invoke-virtual {p0}, Lb8/b;->P()I

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    return v0
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
.end method

.method public final R()I
    .locals 2

    .line 1
    iget v0, p0, Lb8/b;->C:I

    .line 2
    .line 3
    iget-char v1, p0, Lb8/b;->G:C

    .line 4
    .line 5
    if-ge v0, v1, :cond_0

    .line 6
    .line 7
    iget v0, p0, Lb8/b;->z:I

    .line 8
    .line 9
    iget-object v1, p0, Lb8/b;->r:Lb8/c;

    .line 10
    .line 11
    invoke-virtual {v1, v0}, Lb8/c;->a(I)V

    .line 12
    .line 13
    .line 14
    iget v1, p0, Lb8/b;->C:I

    .line 15
    .line 16
    add-int/lit8 v1, v1, 0x1

    .line 17
    .line 18
    iput v1, p0, Lb8/b;->C:I

    .line 19
    .line 20
    const/4 v1, 0x7

    .line 21
    iput v1, p0, Lb8/b;->u:I

    .line 22
    .line 23
    return v0

    .line 24
    :cond_0
    iget v0, p0, Lb8/b;->B:I

    .line 25
    .line 26
    add-int/lit8 v0, v0, 0x1

    .line 27
    .line 28
    iput v0, p0, Lb8/b;->B:I

    .line 29
    .line 30
    const/4 v0, 0x0

    .line 31
    iput v0, p0, Lb8/b;->y:I

    .line 32
    .line 33
    invoke-virtual {p0}, Lb8/b;->Q()I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    return v0
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final S()I
    .locals 5

    .line 1
    iget v0, p0, Lb8/b;->B:I

    .line 2
    .line 3
    iget v1, p0, Lb8/b;->n:I

    .line 4
    .line 5
    if-gt v0, v1, :cond_3

    .line 6
    .line 7
    iget v0, p0, Lb8/b;->z:I

    .line 8
    .line 9
    iput v0, p0, Lb8/b;->A:I

    .line 10
    .line 11
    iget-object v0, p0, Lb8/b;->H:Lb8/a;

    .line 12
    .line 13
    iget-object v1, v0, Lb8/a;->o:[B

    .line 14
    .line 15
    iget v2, p0, Lb8/b;->F:I

    .line 16
    .line 17
    aget-byte v1, v1, v2

    .line 18
    .line 19
    and-int/lit16 v1, v1, 0xff

    .line 20
    .line 21
    iget-object v0, v0, Lb8/a;->n:[I

    .line 22
    .line 23
    array-length v0, v0

    .line 24
    const-string v3, "su_tPos"

    .line 25
    .line 26
    invoke-static {v2, v0, v3}, Lb8/b;->u(IILjava/lang/String;)V

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, Lb8/b;->H:Lb8/a;

    .line 30
    .line 31
    iget-object v0, v0, Lb8/a;->n:[I

    .line 32
    .line 33
    iget v2, p0, Lb8/b;->F:I

    .line 34
    .line 35
    aget v0, v0, v2

    .line 36
    .line 37
    iput v0, p0, Lb8/b;->F:I

    .line 38
    .line 39
    iget v0, p0, Lb8/b;->D:I

    .line 40
    .line 41
    const/4 v2, 0x0

    .line 42
    const/4 v3, 0x1

    .line 43
    if-nez v0, :cond_0

    .line 44
    .line 45
    iget v0, p0, Lb8/b;->E:I

    .line 46
    .line 47
    sget-object v4, Lb8/d;->a:[I

    .line 48
    .line 49
    aget v4, v4, v0

    .line 50
    .line 51
    sub-int/2addr v4, v3

    .line 52
    iput v4, p0, Lb8/b;->D:I

    .line 53
    .line 54
    add-int/2addr v0, v3

    .line 55
    iput v0, p0, Lb8/b;->E:I

    .line 56
    .line 57
    const/16 v4, 0x200

    .line 58
    .line 59
    if-ne v0, v4, :cond_1

    .line 60
    .line 61
    iput v2, p0, Lb8/b;->E:I

    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_0
    sub-int/2addr v0, v3

    .line 65
    iput v0, p0, Lb8/b;->D:I

    .line 66
    .line 67
    :cond_1
    :goto_0
    iget v0, p0, Lb8/b;->D:I

    .line 68
    .line 69
    if-ne v0, v3, :cond_2

    .line 70
    .line 71
    move v2, v3

    .line 72
    :cond_2
    xor-int v0, v1, v2

    .line 73
    .line 74
    iput v0, p0, Lb8/b;->z:I

    .line 75
    .line 76
    iget v1, p0, Lb8/b;->B:I

    .line 77
    .line 78
    add-int/2addr v1, v3

    .line 79
    iput v1, p0, Lb8/b;->B:I

    .line 80
    .line 81
    const/4 v1, 0x3

    .line 82
    iput v1, p0, Lb8/b;->u:I

    .line 83
    .line 84
    iget-object v1, p0, Lb8/b;->r:Lb8/c;

    .line 85
    .line 86
    invoke-virtual {v1, v0}, Lb8/c;->a(I)V

    .line 87
    .line 88
    .line 89
    return v0

    .line 90
    :cond_3
    invoke-virtual {p0}, Lb8/b;->z()V

    .line 91
    .line 92
    .line 93
    invoke-virtual {p0}, Lb8/b;->A()V

    .line 94
    .line 95
    .line 96
    invoke-virtual {p0}, Lb8/b;->P()I

    .line 97
    .line 98
    .line 99
    move-result v0

    .line 100
    return v0
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
.end method

.method public final T()I
    .locals 2

    .line 1
    iget v0, p0, Lb8/b;->C:I

    .line 2
    .line 3
    iget-char v1, p0, Lb8/b;->G:C

    .line 4
    .line 5
    if-ge v0, v1, :cond_0

    .line 6
    .line 7
    iget-object v0, p0, Lb8/b;->r:Lb8/c;

    .line 8
    .line 9
    iget v1, p0, Lb8/b;->z:I

    .line 10
    .line 11
    invoke-virtual {v0, v1}, Lb8/c;->a(I)V

    .line 12
    .line 13
    .line 14
    iget v0, p0, Lb8/b;->C:I

    .line 15
    .line 16
    add-int/lit8 v0, v0, 0x1

    .line 17
    .line 18
    iput v0, p0, Lb8/b;->C:I

    .line 19
    .line 20
    iget v0, p0, Lb8/b;->z:I

    .line 21
    .line 22
    return v0

    .line 23
    :cond_0
    const/4 v0, 0x2

    .line 24
    iput v0, p0, Lb8/b;->u:I

    .line 25
    .line 26
    iget v0, p0, Lb8/b;->B:I

    .line 27
    .line 28
    add-int/lit8 v0, v0, 0x1

    .line 29
    .line 30
    iput v0, p0, Lb8/b;->B:I

    .line 31
    .line 32
    const/4 v0, 0x0

    .line 33
    iput v0, p0, Lb8/b;->y:I

    .line 34
    .line 35
    invoke-virtual {p0}, Lb8/b;->S()I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    return v0
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final close()V
    .locals 2

    .line 1
    iget-object v0, p0, Lb8/b;->t:Lh8/a;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    :try_start_0
    invoke-virtual {v0}, Lh8/a;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 7
    .line 8
    .line 9
    iput-object v1, p0, Lb8/b;->H:Lb8/a;

    .line 10
    .line 11
    iput-object v1, p0, Lb8/b;->t:Lh8/a;

    .line 12
    .line 13
    return-void

    .line 14
    :catchall_0
    move-exception v0

    .line 15
    iput-object v1, p0, Lb8/b;->H:Lb8/a;

    .line 16
    .line 17
    iput-object v1, p0, Lb8/b;->t:Lh8/a;

    .line 18
    .line 19
    throw v0

    .line 20
    :cond_0
    return-void
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final read()I
    .locals 3

    .line 118
    iget-object v0, p0, Lb8/b;->t:Lh8/a;

    if-eqz v0, :cond_1

    .line 119
    invoke-virtual {p0}, Lb8/b;->H()I

    move-result v0

    if-gez v0, :cond_0

    const/4 v1, -0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    :goto_0
    int-to-long v1, v1

    .line 120
    invoke-virtual {p0, v1, v2}, La8/a;->f(J)V

    return v0

    .line 121
    :cond_1
    const-string v0, "Stream closed"

    invoke-static {v0}, Lq0/b;->o(Ljava/lang/String;)V

    const/4 v0, 0x0

    return v0
.end method

.method public final read([BII)I
    .locals 5

    .line 1
    const-string v0, ") < 0."

    .line 2
    .line 3
    const-string v1, "offs("

    .line 4
    .line 5
    if-ltz p2, :cond_6

    .line 6
    .line 7
    if-ltz p3, :cond_5

    .line 8
    .line 9
    add-int v0, p2, p3

    .line 10
    .line 11
    array-length v2, p1

    .line 12
    if-gt v0, v2, :cond_4

    .line 13
    .line 14
    iget-object v1, p0, Lb8/b;->t:Lh8/a;

    .line 15
    .line 16
    if-eqz v1, :cond_3

    .line 17
    .line 18
    if-nez p3, :cond_0

    .line 19
    .line 20
    const/4 p1, 0x0

    .line 21
    return p1

    .line 22
    :cond_0
    move p3, p2

    .line 23
    :goto_0
    if-ge p3, v0, :cond_1

    .line 24
    .line 25
    invoke-virtual {p0}, Lb8/b;->H()I

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    if-ltz v1, :cond_1

    .line 30
    .line 31
    add-int/lit8 v2, p3, 0x1

    .line 32
    .line 33
    int-to-byte v1, v1

    .line 34
    aput-byte v1, p1, p3

    .line 35
    .line 36
    const/4 p3, 0x1

    .line 37
    int-to-long v3, p3

    .line 38
    invoke-virtual {p0, v3, v4}, La8/a;->f(J)V

    .line 39
    .line 40
    .line 41
    move p3, v2

    .line 42
    goto :goto_0

    .line 43
    :cond_1
    if-ne p3, p2, :cond_2

    .line 44
    .line 45
    const/4 p1, -0x1

    .line 46
    return p1

    .line 47
    :cond_2
    sub-int/2addr p3, p2

    .line 48
    return p3

    .line 49
    :cond_3
    const-string p1, "Stream closed"

    .line 50
    .line 51
    invoke-static {p1}, Lq0/b;->o(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    const/4 p1, 0x0

    .line 55
    return p1

    .line 56
    :cond_4
    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    .line 57
    .line 58
    array-length p1, p1

    .line 59
    new-instance v2, Ljava/lang/StringBuilder;

    .line 60
    .line 61
    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 65
    .line 66
    .line 67
    const-string p2, ") + len("

    .line 68
    .line 69
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    const-string p2, ") > dest.length("

    .line 76
    .line 77
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    const-string p1, ")."

    .line 84
    .line 85
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 86
    .line 87
    .line 88
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object p1

    .line 92
    invoke-direct {v0, p1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    throw v0

    .line 96
    :cond_5
    new-instance p1, Ljava/lang/IndexOutOfBoundsException;

    .line 97
    .line 98
    const-string p2, "len("

    .line 99
    .line 100
    invoke-static {p3, p2, v0}, Lb/m;->i(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object p2

    .line 104
    invoke-direct {p1, p2}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    throw p1

    .line 108
    :cond_6
    new-instance p1, Ljava/lang/IndexOutOfBoundsException;

    .line 109
    .line 110
    invoke-static {p2, v1, v0}, Lb/m;->i(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object p2

    .line 114
    invoke-direct {p1, p2}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    throw p1
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
.end method

.method public final z()V
    .locals 3

    .line 1
    iget-object v0, p0, Lb8/b;->r:Lb8/c;

    .line 2
    .line 3
    iget v0, v0, Lb8/c;->a:I

    .line 4
    .line 5
    not-int v0, v0

    .line 6
    iget v1, p0, Lb8/b;->v:I

    .line 7
    .line 8
    if-ne v1, v0, :cond_0

    .line 9
    .line 10
    iget v1, p0, Lb8/b;->x:I

    .line 11
    .line 12
    shl-int/lit8 v2, v1, 0x1

    .line 13
    .line 14
    ushr-int/lit8 v1, v1, 0x1f

    .line 15
    .line 16
    or-int/2addr v1, v2

    .line 17
    xor-int/2addr v0, v1

    .line 18
    iput v0, p0, Lb8/b;->x:I

    .line 19
    .line 20
    return-void

    .line 21
    :cond_0
    iget v0, p0, Lb8/b;->w:I

    .line 22
    .line 23
    shl-int/lit8 v2, v0, 0x1

    .line 24
    .line 25
    ushr-int/lit8 v0, v0, 0x1f

    .line 26
    .line 27
    or-int/2addr v0, v2

    .line 28
    xor-int/2addr v0, v1

    .line 29
    iput v0, p0, Lb8/b;->x:I

    .line 30
    .line 31
    const-string v0, "BZip2 CRC error"

    .line 32
    .line 33
    invoke-static {v0}, Lq0/b;->o(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    return-void
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method
