.class public interface abstract Lc2/e;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Lk1/p;


# virtual methods
.method public abstract a()Laa/e;
.end method
