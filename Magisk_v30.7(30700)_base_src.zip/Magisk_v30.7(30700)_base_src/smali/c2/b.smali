.class public final Lc2/b;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Lk1/n;


# instance fields
.field public final synthetic m:I

.field public final n:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, Lc2/b;->m:I

    .line 2
    .line 3
    iput-object p2, p0, Lc2/b;->n:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method


# virtual methods
.method public final f(Lk1/p;Lk1/k;)V
    .locals 9

    .line 1
    iget v0, p0, Lc2/b;->m:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lc2/b;->n:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Lr1/d;

    .line 9
    .line 10
    sget-object v1, Lr1/c;->a:[I

    .line 11
    .line 12
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 13
    .line 14
    .line 15
    move-result p2

    .line 16
    aget p2, v1, p2

    .line 17
    .line 18
    const/4 v1, 0x1

    .line 19
    const/4 v2, 0x0

    .line 20
    if-eq p2, v1, :cond_c

    .line 21
    .line 22
    const/4 v1, 0x2

    .line 23
    const/4 v3, 0x0

    .line 24
    if-eq p2, v1, :cond_9

    .line 25
    .line 26
    const/4 v1, 0x3

    .line 27
    if-eq p2, v1, :cond_4

    .line 28
    .line 29
    const/4 v1, 0x4

    .line 30
    if-eq p2, v1, :cond_0

    .line 31
    .line 32
    goto/16 :goto_4

    .line 33
    .line 34
    :cond_0
    check-cast p1, Lh1/t;

    .line 35
    .line 36
    invoke-virtual {v0}, Lp1/l0;->b()Lp1/k;

    .line 37
    .line 38
    .line 39
    move-result-object p2

    .line 40
    iget-object p2, p2, Lp1/k;->f:Lv4/i;

    .line 41
    .line 42
    iget-object p2, p2, Lv4/i;->n:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast p2, Lw6/s;

    .line 45
    .line 46
    invoke-virtual {p2}, Lw6/s;->g()Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    check-cast p2, Ljava/lang/Iterable;

    .line 51
    .line 52
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 53
    .line 54
    .line 55
    move-result-object p2

    .line 56
    :cond_1
    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 57
    .line 58
    .line 59
    move-result v1

    .line 60
    if-eqz v1, :cond_2

    .line 61
    .line 62
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    move-object v2, v1

    .line 67
    check-cast v2, Lp1/h;

    .line 68
    .line 69
    iget-object v2, v2, Lp1/h;->r:Ljava/lang/String;

    .line 70
    .line 71
    iget-object v4, p1, Lh1/y;->M:Ljava/lang/String;

    .line 72
    .line 73
    invoke-static {v2, v4}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    move-result v2

    .line 77
    if-eqz v2, :cond_1

    .line 78
    .line 79
    move-object v3, v1

    .line 80
    goto :goto_0

    .line 81
    :cond_2
    check-cast v3, Lp1/h;

    .line 82
    .line 83
    if-eqz v3, :cond_3

    .line 84
    .line 85
    invoke-virtual {v0}, Lp1/l0;->b()Lp1/k;

    .line 86
    .line 87
    .line 88
    move-result-object p2

    .line 89
    invoke-virtual {p2, v3}, Lp1/k;->b(Lp1/h;)V

    .line 90
    .line 91
    .line 92
    :cond_3
    iget-object p1, p1, Lh1/y;->b0:Lk1/r;

    .line 93
    .line 94
    invoke-virtual {p1, p0}, Lk1/r;->f(Lk1/o;)V

    .line 95
    .line 96
    .line 97
    goto/16 :goto_4

    .line 98
    .line 99
    :cond_4
    check-cast p1, Lh1/t;

    .line 100
    .line 101
    iget-object p2, p1, Lh1/t;->t0:Lb/q;

    .line 102
    .line 103
    if-eqz p2, :cond_8

    .line 104
    .line 105
    invoke-virtual {p2}, Landroid/app/Dialog;->isShowing()Z

    .line 106
    .line 107
    .line 108
    move-result p2

    .line 109
    if-nez p2, :cond_10

    .line 110
    .line 111
    invoke-virtual {v0}, Lp1/l0;->b()Lp1/k;

    .line 112
    .line 113
    .line 114
    move-result-object p2

    .line 115
    iget-object p2, p2, Lp1/k;->e:Lv4/i;

    .line 116
    .line 117
    iget-object p2, p2, Lv4/i;->n:Ljava/lang/Object;

    .line 118
    .line 119
    check-cast p2, Lw6/s;

    .line 120
    .line 121
    invoke-virtual {p2}, Lw6/s;->g()Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object p2

    .line 125
    check-cast p2, Ljava/util/List;

    .line 126
    .line 127
    invoke-interface {p2}, Ljava/util/List;->size()I

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    invoke-interface {p2, v1}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    :cond_5
    invoke-interface {v1}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 136
    .line 137
    .line 138
    move-result v3

    .line 139
    if-eqz v3, :cond_6

    .line 140
    .line 141
    invoke-interface {v1}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v3

    .line 145
    check-cast v3, Lp1/h;

    .line 146
    .line 147
    iget-object v3, v3, Lp1/h;->r:Ljava/lang/String;

    .line 148
    .line 149
    iget-object v4, p1, Lh1/y;->M:Ljava/lang/String;

    .line 150
    .line 151
    invoke-static {v3, v4}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 152
    .line 153
    .line 154
    move-result v3

    .line 155
    if-eqz v3, :cond_5

    .line 156
    .line 157
    invoke-interface {v1}, Ljava/util/ListIterator;->nextIndex()I

    .line 158
    .line 159
    .line 160
    move-result v1

    .line 161
    goto :goto_1

    .line 162
    :cond_6
    const/4 v1, -0x1

    .line 163
    :goto_1
    invoke-static {p2, v1}, Lw5/j;->W(Ljava/util/List;I)Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v3

    .line 167
    check-cast v3, Lp1/h;

    .line 168
    .line 169
    invoke-static {p2}, Lw5/j;->b0(Ljava/util/List;)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object p2

    .line 173
    invoke-static {p2, v3}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    move-result p2

    .line 177
    if-nez p2, :cond_7

    .line 178
    .line 179
    new-instance p2, Ljava/lang/StringBuilder;

    .line 180
    .line 181
    const-string v4, "Dialog "

    .line 182
    .line 183
    invoke-direct {p2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 187
    .line 188
    .line 189
    const-string p1, " was dismissed while it was not the top of the back stack, popping all dialogs above this dismissed dialog"

    .line 190
    .line 191
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 192
    .line 193
    .line 194
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object p1

    .line 198
    const-string p2, "DialogFragmentNavigator"

    .line 199
    .line 200
    invoke-static {p2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 201
    .line 202
    .line 203
    :cond_7
    if-eqz v3, :cond_10

    .line 204
    .line 205
    invoke-virtual {v0, v1, v3, v2}, Lr1/d;->l(ILp1/h;Z)V

    .line 206
    .line 207
    .line 208
    goto/16 :goto_4

    .line 209
    .line 210
    :cond_8
    const-string p2, "DialogFragment "

    .line 211
    .line 212
    const-string v0, " does not have a Dialog."

    .line 213
    .line 214
    invoke-static {p1, v0, p2}, La4/a;->l(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    .line 215
    .line 216
    .line 217
    goto/16 :goto_4

    .line 218
    .line 219
    :cond_9
    check-cast p1, Lh1/t;

    .line 220
    .line 221
    invoke-virtual {v0}, Lp1/l0;->b()Lp1/k;

    .line 222
    .line 223
    .line 224
    move-result-object p2

    .line 225
    iget-object p2, p2, Lp1/k;->f:Lv4/i;

    .line 226
    .line 227
    iget-object p2, p2, Lv4/i;->n:Ljava/lang/Object;

    .line 228
    .line 229
    check-cast p2, Lw6/s;

    .line 230
    .line 231
    invoke-virtual {p2}, Lw6/s;->g()Ljava/lang/Object;

    .line 232
    .line 233
    .line 234
    move-result-object p2

    .line 235
    check-cast p2, Ljava/lang/Iterable;

    .line 236
    .line 237
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 238
    .line 239
    .line 240
    move-result-object p2

    .line 241
    :cond_a
    :goto_2
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 242
    .line 243
    .line 244
    move-result v1

    .line 245
    if-eqz v1, :cond_b

    .line 246
    .line 247
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object v1

    .line 251
    move-object v2, v1

    .line 252
    check-cast v2, Lp1/h;

    .line 253
    .line 254
    iget-object v2, v2, Lp1/h;->r:Ljava/lang/String;

    .line 255
    .line 256
    iget-object v4, p1, Lh1/y;->M:Ljava/lang/String;

    .line 257
    .line 258
    invoke-static {v2, v4}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 259
    .line 260
    .line 261
    move-result v2

    .line 262
    if-eqz v2, :cond_a

    .line 263
    .line 264
    move-object v3, v1

    .line 265
    goto :goto_2

    .line 266
    :cond_b
    check-cast v3, Lp1/h;

    .line 267
    .line 268
    if-eqz v3, :cond_10

    .line 269
    .line 270
    invoke-virtual {v0}, Lp1/l0;->b()Lp1/k;

    .line 271
    .line 272
    .line 273
    move-result-object p1

    .line 274
    invoke-virtual {p1, v3}, Lp1/k;->b(Lp1/h;)V

    .line 275
    .line 276
    .line 277
    goto :goto_4

    .line 278
    :cond_c
    check-cast p1, Lh1/t;

    .line 279
    .line 280
    invoke-virtual {v0}, Lp1/l0;->b()Lp1/k;

    .line 281
    .line 282
    .line 283
    move-result-object p2

    .line 284
    iget-object p2, p2, Lp1/k;->e:Lv4/i;

    .line 285
    .line 286
    iget-object p2, p2, Lv4/i;->n:Ljava/lang/Object;

    .line 287
    .line 288
    check-cast p2, Lw6/s;

    .line 289
    .line 290
    invoke-virtual {p2}, Lw6/s;->g()Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    move-result-object p2

    .line 294
    check-cast p2, Ljava/lang/Iterable;

    .line 295
    .line 296
    instance-of v0, p2, Ljava/util/Collection;

    .line 297
    .line 298
    if-eqz v0, :cond_d

    .line 299
    .line 300
    move-object v0, p2

    .line 301
    check-cast v0, Ljava/util/Collection;

    .line 302
    .line 303
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 304
    .line 305
    .line 306
    move-result v0

    .line 307
    if-eqz v0, :cond_d

    .line 308
    .line 309
    goto :goto_3

    .line 310
    :cond_d
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 311
    .line 312
    .line 313
    move-result-object p2

    .line 314
    :cond_e
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 315
    .line 316
    .line 317
    move-result v0

    .line 318
    if-eqz v0, :cond_f

    .line 319
    .line 320
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 321
    .line 322
    .line 323
    move-result-object v0

    .line 324
    check-cast v0, Lp1/h;

    .line 325
    .line 326
    iget-object v0, v0, Lp1/h;->r:Ljava/lang/String;

    .line 327
    .line 328
    iget-object v1, p1, Lh1/y;->M:Ljava/lang/String;

    .line 329
    .line 330
    invoke-static {v0, v1}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 331
    .line 332
    .line 333
    move-result v0

    .line 334
    if-eqz v0, :cond_e

    .line 335
    .line 336
    goto :goto_4

    .line 337
    :cond_f
    :goto_3
    invoke-virtual {p1, v2, v2}, Lh1/t;->P(ZZ)V

    .line 338
    .line 339
    .line 340
    :cond_10
    :goto_4
    return-void

    .line 341
    :pswitch_0
    sget-object v0, Lk1/k;->ON_CREATE:Lk1/k;

    .line 342
    .line 343
    if-ne p2, v0, :cond_11

    .line 344
    .line 345
    invoke-interface {p1}, Lk1/p;->i()Lk1/r;

    .line 346
    .line 347
    .line 348
    move-result-object p1

    .line 349
    invoke-virtual {p1, p0}, Lk1/r;->f(Lk1/o;)V

    .line 350
    .line 351
    .line 352
    iget-object p1, p0, Lc2/b;->n:Ljava/lang/Object;

    .line 353
    .line 354
    check-cast p1, Lk1/h0;

    .line 355
    .line 356
    invoke-virtual {p1}, Lk1/h0;->b()V

    .line 357
    .line 358
    .line 359
    goto :goto_5

    .line 360
    :cond_11
    const-string p1, "Next event must be ON_CREATE, it was "

    .line 361
    .line 362
    invoke-static {p2, p1}, La4/a;->m(Ljava/lang/Object;Ljava/lang/String;)V

    .line 363
    .line 364
    .line 365
    :goto_5
    return-void

    .line 366
    :pswitch_1
    new-instance p1, Ljava/util/HashMap;

    .line 367
    .line 368
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 369
    .line 370
    .line 371
    iget-object p1, p0, Lc2/b;->n:Ljava/lang/Object;

    .line 372
    .line 373
    check-cast p1, [Lk1/e;

    .line 374
    .line 375
    array-length p2, p1

    .line 376
    const/4 v0, 0x0

    .line 377
    const/4 v1, 0x0

    .line 378
    if-gtz p2, :cond_13

    .line 379
    .line 380
    array-length p2, p1

    .line 381
    if-gtz p2, :cond_12

    .line 382
    .line 383
    return-void

    .line 384
    :cond_12
    aget-object p1, p1, v1

    .line 385
    .line 386
    throw v0

    .line 387
    :cond_13
    aget-object p1, p1, v1

    .line 388
    .line 389
    throw v0

    .line 390
    :pswitch_2
    sget-object p1, Lk1/k;->ON_STOP:Lk1/k;

    .line 391
    .line 392
    if-ne p2, p1, :cond_14

    .line 393
    .line 394
    iget-object p1, p0, Lc2/b;->n:Ljava/lang/Object;

    .line 395
    .line 396
    check-cast p1, Lh1/y;

    .line 397
    .line 398
    iget-object p1, p1, Lh1/y;->T:Landroid/view/View;

    .line 399
    .line 400
    if-eqz p1, :cond_14

    .line 401
    .line 402
    invoke-virtual {p1}, Landroid/view/View;->cancelPendingInputEvents()V

    .line 403
    .line 404
    .line 405
    :cond_14
    return-void

    .line 406
    :pswitch_3
    iget-object p1, p0, Lc2/b;->n:Ljava/lang/Object;

    .line 407
    .line 408
    check-cast p1, Lh/i;

    .line 409
    .line 410
    iget-object p2, p1, Lb/o;->q:Lk1/p0;

    .line 411
    .line 412
    if-nez p2, :cond_16

    .line 413
    .line 414
    invoke-virtual {p1}, Landroid/app/Activity;->getLastNonConfigurationInstance()Ljava/lang/Object;

    .line 415
    .line 416
    .line 417
    move-result-object p2

    .line 418
    check-cast p2, Lb/i;

    .line 419
    .line 420
    if-eqz p2, :cond_15

    .line 421
    .line 422
    iget-object p2, p2, Lb/i;->a:Lk1/p0;

    .line 423
    .line 424
    iput-object p2, p1, Lb/o;->q:Lk1/p0;

    .line 425
    .line 426
    :cond_15
    iget-object p2, p1, Lb/o;->q:Lk1/p0;

    .line 427
    .line 428
    if-nez p2, :cond_16

    .line 429
    .line 430
    new-instance p2, Lk1/p0;

    .line 431
    .line 432
    invoke-direct {p2}, Lk1/p0;-><init>()V

    .line 433
    .line 434
    .line 435
    iput-object p2, p1, Lb/o;->q:Lk1/p0;

    .line 436
    .line 437
    :cond_16
    iget-object p1, p1, Lf0/g;->m:Lk1/r;

    .line 438
    .line 439
    invoke-virtual {p1, p0}, Lk1/r;->f(Lk1/o;)V

    .line 440
    .line 441
    .line 442
    return-void

    .line 443
    :pswitch_4
    iget-object v0, p0, Lc2/b;->n:Ljava/lang/Object;

    .line 444
    .line 445
    check-cast v0, Lc2/e;

    .line 446
    .line 447
    sget-object v1, Lk1/k;->ON_CREATE:Lk1/k;

    .line 448
    .line 449
    if-ne p2, v1, :cond_21

    .line 450
    .line 451
    invoke-interface {p1}, Lk1/p;->i()Lk1/r;

    .line 452
    .line 453
    .line 454
    move-result-object p1

    .line 455
    invoke-virtual {p1, p0}, Lk1/r;->f(Lk1/o;)V

    .line 456
    .line 457
    .line 458
    invoke-interface {v0}, Lc2/e;->a()Laa/e;

    .line 459
    .line 460
    .line 461
    move-result-object p1

    .line 462
    const-string p2, "androidx.savedstate.Restarter"

    .line 463
    .line 464
    invoke-virtual {p1, p2}, Laa/e;->r(Ljava/lang/String;)Landroid/os/Bundle;

    .line 465
    .line 466
    .line 467
    move-result-object p1

    .line 468
    if-nez p1, :cond_17

    .line 469
    .line 470
    goto/16 :goto_9

    .line 471
    .line 472
    :cond_17
    const-string p2, "classes_to_restore"

    .line 473
    .line 474
    invoke-virtual {p1, p2}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 475
    .line 476
    .line 477
    move-result-object p1

    .line 478
    if-eqz p1, :cond_1f

    .line 479
    .line 480
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 481
    .line 482
    .line 483
    move-result p2

    .line 484
    const/4 v1, 0x0

    .line 485
    move v2, v1

    .line 486
    :cond_18
    :goto_6
    if-ge v2, p2, :cond_20

    .line 487
    .line 488
    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 489
    .line 490
    .line 491
    move-result-object v3

    .line 492
    add-int/lit8 v2, v2, 0x1

    .line 493
    .line 494
    check-cast v3, Ljava/lang/String;

    .line 495
    .line 496
    const-string v4, "Class "

    .line 497
    .line 498
    :try_start_0
    const-class v5, Lc2/b;

    .line 499
    .line 500
    invoke-virtual {v5}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 501
    .line 502
    .line 503
    move-result-object v5

    .line 504
    invoke-static {v3, v1, v5}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    .line 505
    .line 506
    .line 507
    move-result-object v5

    .line 508
    const-class v6, Lc2/c;

    .line 509
    .line 510
    invoke-virtual {v5, v6}, Ljava/lang/Class;->asSubclass(Ljava/lang/Class;)Ljava/lang/Class;

    .line 511
    .line 512
    .line 513
    move-result-object v5
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_2

    .line 514
    const/4 v6, 0x0

    .line 515
    :try_start_1
    invoke-virtual {v5, v6}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 516
    .line 517
    .line 518
    move-result-object v4
    :try_end_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1 .. :try_end_1} :catch_1

    .line 519
    const/4 v5, 0x1

    .line 520
    invoke-virtual {v4, v5}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 521
    .line 522
    .line 523
    :try_start_2
    invoke-virtual {v4, v6}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 524
    .line 525
    .line 526
    move-result-object v4

    .line 527
    check-cast v4, Lc2/c;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 528
    .line 529
    check-cast v4, Lk1/g;

    .line 530
    .line 531
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 532
    .line 533
    .line 534
    instance-of v3, v0, Lk1/q0;

    .line 535
    .line 536
    if-eqz v3, :cond_1e

    .line 537
    .line 538
    move-object v3, v0

    .line 539
    check-cast v3, Lk1/q0;

    .line 540
    .line 541
    invoke-interface {v3}, Lk1/q0;->h()Lk1/p0;

    .line 542
    .line 543
    .line 544
    move-result-object v3

    .line 545
    invoke-interface {v0}, Lc2/e;->a()Laa/e;

    .line 546
    .line 547
    .line 548
    move-result-object v4

    .line 549
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 550
    .line 551
    .line 552
    iget-object v3, v3, Lk1/p0;->a:Ljava/util/LinkedHashMap;

    .line 553
    .line 554
    new-instance v5, Ljava/util/HashSet;

    .line 555
    .line 556
    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    .line 557
    .line 558
    .line 559
    move-result-object v6

    .line 560
    invoke-direct {v5, v6}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 561
    .line 562
    .line 563
    invoke-virtual {v5}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 564
    .line 565
    .line 566
    move-result-object v5

    .line 567
    :cond_19
    :goto_7
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 568
    .line 569
    .line 570
    move-result v6

    .line 571
    if-eqz v6, :cond_1d

    .line 572
    .line 573
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 574
    .line 575
    .line 576
    move-result-object v6

    .line 577
    check-cast v6, Ljava/lang/String;

    .line 578
    .line 579
    invoke-virtual {v3, v6}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 580
    .line 581
    .line 582
    move-result-object v6

    .line 583
    check-cast v6, Lk1/m0;

    .line 584
    .line 585
    if-nez v6, :cond_1a

    .line 586
    .line 587
    goto :goto_7

    .line 588
    :cond_1a
    invoke-interface {v0}, Lk1/p;->i()Lk1/r;

    .line 589
    .line 590
    .line 591
    move-result-object v7

    .line 592
    const-string v8, "androidx.lifecycle.savedstate.vm.tag"

    .line 593
    .line 594
    invoke-virtual {v6, v8}, Lk1/m0;->g(Ljava/lang/String;)Ljava/lang/AutoCloseable;

    .line 595
    .line 596
    .line 597
    move-result-object v6

    .line 598
    check-cast v6, Lk1/f0;

    .line 599
    .line 600
    if-eqz v6, :cond_19

    .line 601
    .line 602
    iget-boolean v8, v6, Lk1/f0;->o:Z

    .line 603
    .line 604
    if-nez v8, :cond_19

    .line 605
    .line 606
    invoke-virtual {v6, v4, v7}, Lk1/f0;->l(Laa/e;Lk1/r;)V

    .line 607
    .line 608
    .line 609
    iget-object v6, v7, Lk1/r;->d:Lk1/l;

    .line 610
    .line 611
    sget-object v8, Lk1/l;->n:Lk1/l;

    .line 612
    .line 613
    if-eq v6, v8, :cond_1c

    .line 614
    .line 615
    sget-object v8, Lk1/l;->p:Lk1/l;

    .line 616
    .line 617
    invoke-virtual {v6, v8}, Lk1/l;->a(Lk1/l;)Z

    .line 618
    .line 619
    .line 620
    move-result v6

    .line 621
    if-eqz v6, :cond_1b

    .line 622
    .line 623
    goto :goto_8

    .line 624
    :cond_1b
    new-instance v6, Lk1/h;

    .line 625
    .line 626
    invoke-direct {v6, v4, v7}, Lk1/h;-><init>(Laa/e;Lk1/r;)V

    .line 627
    .line 628
    .line 629
    invoke-virtual {v7, v6}, Lk1/r;->a(Lk1/o;)V

    .line 630
    .line 631
    .line 632
    goto :goto_7

    .line 633
    :cond_1c
    :goto_8
    invoke-virtual {v4}, Laa/e;->S()V

    .line 634
    .line 635
    .line 636
    goto :goto_7

    .line 637
    :cond_1d
    new-instance v5, Ljava/util/HashSet;

    .line 638
    .line 639
    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    .line 640
    .line 641
    .line 642
    move-result-object v3

    .line 643
    invoke-direct {v5, v3}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 644
    .line 645
    .line 646
    invoke-virtual {v5}, Ljava/util/HashSet;->isEmpty()Z

    .line 647
    .line 648
    .line 649
    move-result v3

    .line 650
    if-nez v3, :cond_18

    .line 651
    .line 652
    invoke-virtual {v4}, Laa/e;->S()V

    .line 653
    .line 654
    .line 655
    goto/16 :goto_6

    .line 656
    .line 657
    :cond_1e
    const-string p1, "Internal error: OnRecreation should be registered only on components that implement ViewModelStoreOwner. Received owner: "

    .line 658
    .line 659
    invoke-static {v0, p1}, La4/a;->m(Ljava/lang/Object;Ljava/lang/String;)V

    .line 660
    .line 661
    .line 662
    goto :goto_9

    .line 663
    :catch_0
    move-exception p1

    .line 664
    new-instance p2, Ljava/lang/RuntimeException;

    .line 665
    .line 666
    const-string v0, "Failed to instantiate "

    .line 667
    .line 668
    invoke-static {v0, v3}, Lb/m;->k(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 669
    .line 670
    .line 671
    move-result-object v0

    .line 672
    invoke-direct {p2, v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 673
    .line 674
    .line 675
    throw p2

    .line 676
    :catch_1
    move-exception p1

    .line 677
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 678
    .line 679
    invoke-virtual {v5}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 680
    .line 681
    .line 682
    move-result-object v0

    .line 683
    new-instance v1, Ljava/lang/StringBuilder;

    .line 684
    .line 685
    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 686
    .line 687
    .line 688
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 689
    .line 690
    .line 691
    const-string v0, " must have default constructor in order to be automatically recreated"

    .line 692
    .line 693
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 694
    .line 695
    .line 696
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 697
    .line 698
    .line 699
    move-result-object v0

    .line 700
    invoke-direct {p2, v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 701
    .line 702
    .line 703
    throw p2

    .line 704
    :catch_2
    move-exception p1

    .line 705
    new-instance p2, Ljava/lang/RuntimeException;

    .line 706
    .line 707
    const-string v0, " wasn\'t found"

    .line 708
    .line 709
    invoke-static {v4, v3, v0}, Lb/m;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 710
    .line 711
    .line 712
    move-result-object v0

    .line 713
    invoke-direct {p2, v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 714
    .line 715
    .line 716
    throw p2

    .line 717
    :cond_1f
    const-string p1, "SavedState with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\""

    .line 718
    .line 719
    invoke-static {p1}, Lq0/b;->m(Ljava/lang/String;)V

    .line 720
    .line 721
    .line 722
    :cond_20
    :goto_9
    return-void

    .line 723
    :cond_21
    new-instance p1, Ljava/lang/AssertionError;

    .line 724
    .line 725
    const-string p2, "Next event must be ON_CREATE"

    .line 726
    .line 727
    invoke-direct {p1, p2}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 728
    .line 729
    .line 730
    throw p1

    .line 731
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
.end method
