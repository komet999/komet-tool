.class public final Lb5/b0;
.super Lz3/f;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# instance fields
.field public final p:Ljava/util/ArrayList;

.field public final q:Landroid/util/SparseArray;


# direct methods
.method public constructor <init>()V
    .locals 12

    .line 1
    invoke-direct {p0}, Lz3/f;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, La4/d;->m:La4/d;

    .line 5
    .line 6
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    const-string v2, "com.topjohnwu.magisk"

    .line 11
    .line 12
    invoke-static {v1, v2}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    sget-object v2, Lo4/k;->a:Lo4/j;

    .line 17
    .line 18
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    sget-object v2, Lo4/j;->d:Lv5/i;

    .line 22
    .line 23
    invoke-virtual {v2}, Lv5/i;->getValue()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    check-cast v2, Ljava/lang/Boolean;

    .line 28
    .line 29
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    if-eqz v2, :cond_0

    .line 34
    .line 35
    sget-object v2, Lb5/b;->w:Lb5/b;

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_0
    sget-object v2, Lb5/r;->q:Lb5/r;

    .line 39
    .line 40
    :goto_0
    const/4 v3, 0x3

    .line 41
    new-array v4, v3, [Lb5/g;

    .line 42
    .line 43
    sget-object v5, Lb5/c;->s:Lb5/c;

    .line 44
    .line 45
    const/4 v6, 0x0

    .line 46
    aput-object v5, v4, v6

    .line 47
    .line 48
    sget-object v5, Lb5/b;->E:Lb5/b;

    .line 49
    .line 50
    const/4 v7, 0x1

    .line 51
    aput-object v5, v4, v7

    .line 52
    .line 53
    const/4 v5, 0x2

    .line 54
    aput-object v2, v4, v5

    .line 55
    .line 56
    invoke-static {v4}, Lw5/k;->M([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    invoke-static {}, La4/f;->a()Z

    .line 61
    .line 62
    .line 63
    move-result v4

    .line 64
    if-eqz v4, :cond_1

    .line 65
    .line 66
    invoke-static {v0}, Lf5/d;->p(Landroid/content/Context;)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_1

    .line 71
    .line 72
    sget-object v0, Lb5/b;->q:Lb5/b;

    .line 73
    .line 74
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    :cond_1
    const/4 v0, 0x7

    .line 78
    new-array v4, v0, [Lb5/g;

    .line 79
    .line 80
    sget-object v8, Lb5/c;->q:Lb5/c;

    .line 81
    .line 82
    aput-object v8, v4, v6

    .line 83
    .line 84
    sget-object v8, Lb5/d0;->q:Lb5/d0;

    .line 85
    .line 86
    aput-object v8, v4, v7

    .line 87
    .line 88
    sget-object v8, Lb5/e0;->q:Lb5/e0;

    .line 89
    .line 90
    aput-object v8, v4, v5

    .line 91
    .line 92
    sget-object v8, Lb5/o;->q:Lb5/o;

    .line 93
    .line 94
    aput-object v8, v4, v3

    .line 95
    .line 96
    sget-object v8, Lb5/f0;->q:Lb5/f0;

    .line 97
    .line 98
    const/4 v9, 0x4

    .line 99
    aput-object v8, v4, v9

    .line 100
    .line 101
    sget-object v8, Lb5/p;->q:Lb5/p;

    .line 102
    .line 103
    const/4 v10, 0x5

    .line 104
    aput-object v8, v4, v10

    .line 105
    .line 106
    sget-object v8, Lb5/u;->q:Lb5/u;

    .line 107
    .line 108
    const/4 v11, 0x6

    .line 109
    aput-object v8, v4, v11

    .line 110
    .line 111
    invoke-static {v4}, Lw5/k;->L([Ljava/lang/Object;)Ljava/util/List;

    .line 112
    .line 113
    .line 114
    move-result-object v4

    .line 115
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 116
    .line 117
    .line 118
    sget-object v4, La4/n;->h:La4/k;

    .line 119
    .line 120
    iget-boolean v4, v4, La4/k;->e:Z

    .line 121
    .line 122
    if-eqz v4, :cond_3

    .line 123
    .line 124
    sget v4, La4/h;->b:I

    .line 125
    .line 126
    if-nez v4, :cond_3

    .line 127
    .line 128
    if-nez v1, :cond_2

    .line 129
    .line 130
    sget-object v1, Lb5/b;->y:Lb5/b;

    .line 131
    .line 132
    :goto_1
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    goto :goto_2

    .line 136
    :cond_2
    sget-object v1, Lb5/q;->q:Lb5/q;

    .line 137
    .line 138
    goto :goto_1

    .line 139
    :cond_3
    :goto_2
    sget-object v1, La4/n;->h:La4/k;

    .line 140
    .line 141
    iget-boolean v1, v1, La4/k;->e:Z

    .line 142
    .line 143
    if-eqz v1, :cond_5

    .line 144
    .line 145
    new-array v1, v5, [Lb5/g;

    .line 146
    .line 147
    sget-object v4, Lb5/c;->u:Lb5/c;

    .line 148
    .line 149
    aput-object v4, v1, v6

    .line 150
    .line 151
    sget-object v4, Lb5/b;->B:Lb5/b;

    .line 152
    .line 153
    aput-object v4, v1, v7

    .line 154
    .line 155
    invoke-static {v1}, Lw5/k;->L([Ljava/lang/Object;)Ljava/util/List;

    .line 156
    .line 157
    .line 158
    move-result-object v1

    .line 159
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 160
    .line 161
    .line 162
    sget-object v1, La4/n;->h:La4/k;

    .line 163
    .line 164
    iget v1, v1, La4/k;->c:I

    .line 165
    .line 166
    const/16 v4, 0x5dc0

    .line 167
    .line 168
    if-ge v1, v4, :cond_4

    .line 169
    .line 170
    rem-int/lit8 v1, v1, 0x64

    .line 171
    .line 172
    if-eqz v1, :cond_5

    .line 173
    .line 174
    :cond_4
    new-array v1, v3, [Lb5/g;

    .line 175
    .line 176
    sget-object v4, Lb5/g0;->q:Lb5/g0;

    .line 177
    .line 178
    aput-object v4, v1, v6

    .line 179
    .line 180
    sget-object v4, Lb5/n;->q:Lb5/n;

    .line 181
    .line 182
    aput-object v4, v1, v7

    .line 183
    .line 184
    sget-object v4, Lb5/b;->t:Lb5/b;

    .line 185
    .line 186
    aput-object v4, v1, v5

    .line 187
    .line 188
    invoke-static {v1}, Lw5/k;->L([Ljava/lang/Object;)Ljava/util/List;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 193
    .line 194
    .line 195
    :cond_5
    sget-object v1, La4/n;->a:La4/n;

    .line 196
    .line 197
    invoke-static {}, La4/n;->b()Z

    .line 198
    .line 199
    .line 200
    move-result v1

    .line 201
    if-eqz v1, :cond_9

    .line 202
    .line 203
    sget-object v1, Lb5/c0;->q:Lb5/c0;

    .line 204
    .line 205
    const/16 v4, 0x9

    .line 206
    .line 207
    new-array v4, v4, [Lb5/g;

    .line 208
    .line 209
    sget-object v8, Lb5/c;->w:Lb5/c;

    .line 210
    .line 211
    aput-object v8, v4, v6

    .line 212
    .line 213
    aput-object v1, v4, v7

    .line 214
    .line 215
    sget-object v6, Lb5/d;->q:Lb5/d;

    .line 216
    .line 217
    aput-object v6, v4, v5

    .line 218
    .line 219
    sget-object v5, Lb5/a;->q:Lb5/a;

    .line 220
    .line 221
    aput-object v5, v4, v3

    .line 222
    .line 223
    sget-object v3, Lb5/t;->q:Lb5/t;

    .line 224
    .line 225
    aput-object v3, v4, v9

    .line 226
    .line 227
    sget-object v3, Lb5/s;->q:Lb5/s;

    .line 228
    .line 229
    aput-object v3, v4, v10

    .line 230
    .line 231
    sget-object v3, Lb5/e;->q:Lb5/e;

    .line 232
    .line 233
    aput-object v3, v4, v11

    .line 234
    .line 235
    sget-object v3, Lb5/w;->q:Lb5/w;

    .line 236
    .line 237
    aput-object v3, v4, v0

    .line 238
    .line 239
    sget-object v0, Lb5/z;->q:Lb5/z;

    .line 240
    .line 241
    const/16 v3, 0x8

    .line 242
    .line 243
    aput-object v0, v4, v3

    .line 244
    .line 245
    invoke-static {v4}, Lw5/k;->L([Ljava/lang/Object;)Ljava/util/List;

    .line 246
    .line 247
    .line 248
    move-result-object v0

    .line 249
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 250
    .line 251
    .line 252
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 253
    .line 254
    const/16 v3, 0x1a

    .line 255
    .line 256
    if-ge v0, v3, :cond_6

    .line 257
    .line 258
    sget-object v3, Lb5/v;->q:Lb5/v;

    .line 259
    .line 260
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 261
    .line 262
    .line 263
    :cond_6
    const/16 v3, 0x1f

    .line 264
    .line 265
    if-lt v0, v3, :cond_7

    .line 266
    .line 267
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 268
    .line 269
    .line 270
    :cond_7
    sget-object v0, La4/n;->h:La4/k;

    .line 271
    .line 272
    iget v0, v0, La4/k;->c:I

    .line 273
    .line 274
    const/16 v1, 0x7594

    .line 275
    .line 276
    if-ge v0, v1, :cond_8

    .line 277
    .line 278
    rem-int/lit8 v0, v0, 0x64

    .line 279
    .line 280
    if-eqz v0, :cond_9

    .line 281
    .line 282
    :cond_8
    sget-object v0, Lb5/y;->q:Lb5/y;

    .line 283
    .line 284
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 285
    .line 286
    .line 287
    :cond_9
    iput-object v2, p0, Lb5/b0;->p:Ljava/util/ArrayList;

    .line 288
    .line 289
    new-instance v0, Landroid/util/SparseArray;

    .line 290
    .line 291
    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    .line 292
    .line 293
    .line 294
    const/16 v1, 0xe

    .line 295
    .line 296
    invoke-virtual {v0, v1, p0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 297
    .line 298
    .line 299
    iput-object v0, p0, Lb5/b0;->q:Landroid/util/SparseArray;

    .line 300
    .line 301
    return-void
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
.end method


# virtual methods
.method public final p(Landroid/view/View;Lb5/g;)V
    .locals 5

    .line 1
    sget-object v0, Lb5/b;->E:Lb5/b;

    .line 2
    .line 3
    invoke-virtual {p2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    new-instance p1, Lp1/a;

    .line 10
    .line 11
    const p2, 0x7f090059

    .line 12
    .line 13
    .line 14
    invoke-direct {p1, p2}, Lp1/a;-><init>(I)V

    .line 15
    .line 16
    .line 17
    invoke-static {p0, p1}, Lz3/f;->i(Lz3/f;Lp1/w;)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_0
    sget-object v0, Lb5/b;->w:Lb5/b;

    .line 22
    .line 23
    invoke-virtual {p2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    const/4 v1, 0x0

    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    invoke-static {p1}, Lf5/d;->c(Landroid/view/View;)Landroid/app/Activity;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    sget-object p2, Lo4/k;->a:Lo4/j;

    .line 35
    .line 36
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    new-instance p2, Landroid/content/Intent;

    .line 40
    .line 41
    sget-object v0, La4/d;->m:La4/d;

    .line 42
    .line 43
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    const-string v2, "package"

    .line 48
    .line 49
    invoke-static {v2, v0, v1}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    const-string v1, "android.settings.APP_LOCALE_SETTINGS"

    .line 54
    .line 55
    invoke-direct {p2, v1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p1, p2}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 59
    .line 60
    .line 61
    return-void

    .line 62
    :cond_1
    sget-object v0, Lb5/b;->q:Lb5/b;

    .line 63
    .line 64
    invoke-virtual {p2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    if-eqz v0, :cond_2

    .line 69
    .line 70
    new-instance p1, Lr4/a;

    .line 71
    .line 72
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 73
    .line 74
    .line 75
    invoke-virtual {p0, p1}, Lz3/f;->m(Lz3/j;)V

    .line 76
    .line 77
    .line 78
    return-void

    .line 79
    :cond_2
    sget-object v0, Lb5/b;->B:Lb5/b;

    .line 80
    .line 81
    invoke-virtual {p2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    const/4 v2, 0x2

    .line 86
    const/4 v3, 0x3

    .line 87
    if-eqz v0, :cond_3

    .line 88
    .line 89
    invoke-static {p0}, Lk1/g0;->f(Lk1/m0;)Ln1/a;

    .line 90
    .line 91
    .line 92
    move-result-object p1

    .line 93
    new-instance p2, Lb5/a0;

    .line 94
    .line 95
    const/4 v0, 0x0

    .line 96
    invoke-direct {p2, v2, v1, v0}, Lb5/a0;-><init>(ILz5/d;I)V

    .line 97
    .line 98
    .line 99
    invoke-static {p1, v1, p2, v3}, Lt6/t;->g(Lt6/s;Lz5/h;Lj6/p;I)Lt6/z0;

    .line 100
    .line 101
    .line 102
    return-void

    .line 103
    :cond_3
    sget-object v0, Lb5/b;->t:Lb5/b;

    .line 104
    .line 105
    invoke-virtual {p2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-eqz v0, :cond_4

    .line 110
    .line 111
    new-instance p1, Lp1/a;

    .line 112
    .line 113
    const p2, 0x7f090058

    .line 114
    .line 115
    .line 116
    invoke-direct {p1, p2}, Lp1/a;-><init>(I)V

    .line 117
    .line 118
    .line 119
    invoke-static {p0, p1}, Lz3/f;->i(Lz3/f;Lp1/w;)V

    .line 120
    .line 121
    .line 122
    return-void

    .line 123
    :cond_4
    sget-object v0, Lb5/d0;->q:Lb5/d0;

    .line 124
    .line 125
    invoke-virtual {p2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    if-eqz v0, :cond_5

    .line 130
    .line 131
    sget-object p2, Lb5/e0;->q:Lb5/e0;

    .line 132
    .line 133
    invoke-virtual {p2}, Lb5/e0;->p()V

    .line 134
    .line 135
    .line 136
    iget-boolean v0, p2, Lb5/g;->n:Z

    .line 137
    .line 138
    if-eqz v0, :cond_8

    .line 139
    .line 140
    sget-object v0, La4/g;->a:La4/g;

    .line 141
    .line 142
    invoke-virtual {v0}, La4/g;->b()Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    invoke-static {v0}, Lr6/i;->X(Ljava/lang/CharSequence;)Z

    .line 147
    .line 148
    .line 149
    move-result v0

    .line 150
    if-eqz v0, :cond_8

    .line 151
    .line 152
    invoke-virtual {p2, p1, p0}, Lb5/i;->o(Landroid/view/View;Lb5/b0;)V

    .line 153
    .line 154
    .line 155
    return-void

    .line 156
    :cond_5
    instance-of v0, p2, Lb5/q;

    .line 157
    .line 158
    if-eqz v0, :cond_6

    .line 159
    .line 160
    invoke-static {p0}, Lk1/g0;->f(Lk1/m0;)Ln1/a;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    new-instance v4, La4/p;

    .line 165
    .line 166
    invoke-direct {v4, p1, p2, v1, v2}, La4/p;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lz5/d;I)V

    .line 167
    .line 168
    .line 169
    invoke-static {v0, v1, v4, v3}, Lt6/t;->g(Lt6/s;Lz5/h;Lj6/p;I)Lt6/z0;

    .line 170
    .line 171
    .line 172
    return-void

    .line 173
    :cond_6
    sget-object v0, Lb5/b;->y:Lb5/b;

    .line 174
    .line 175
    invoke-virtual {p2, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 176
    .line 177
    .line 178
    move-result v0

    .line 179
    if-eqz v0, :cond_7

    .line 180
    .line 181
    invoke-static {p0}, Lk1/g0;->f(Lk1/m0;)Ln1/a;

    .line 182
    .line 183
    .line 184
    move-result-object p2

    .line 185
    new-instance v0, La5/r;

    .line 186
    .line 187
    const/4 v2, 0x1

    .line 188
    invoke-direct {v0, p1, v1, v2}, La5/r;-><init>(Ljava/lang/Object;Lz5/d;I)V

    .line 189
    .line 190
    .line 191
    invoke-static {p2, v1, v0, v3}, Lt6/t;->g(Lt6/s;Lz5/h;Lj6/p;I)Lt6/z0;

    .line 192
    .line 193
    .line 194
    return-void

    .line 195
    :cond_7
    sget-object p1, Lb5/g0;->q:Lb5/g0;

    .line 196
    .line 197
    invoke-virtual {p2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 198
    .line 199
    .line 200
    move-result p1

    .line 201
    if-eqz p1, :cond_8

    .line 202
    .line 203
    sget-object p1, La4/g;->a:La4/g;

    .line 204
    .line 205
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 206
    .line 207
    .line 208
    sget-object p2, La4/g;->s:Laa/b;

    .line 209
    .line 210
    sget-object v0, La4/g;->b:[Lp6/b;

    .line 211
    .line 212
    const/16 v1, 0xc

    .line 213
    .line 214
    aget-object v0, v0, v1

    .line 215
    .line 216
    invoke-virtual {p2, p1, v0}, Laa/b;->r(La4/g;Lp6/b;)Ljava/lang/Boolean;

    .line 217
    .line 218
    .line 219
    move-result-object p1

    .line 220
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 221
    .line 222
    .line 223
    move-result p1

    .line 224
    sget-boolean p2, La4/n;->n:Z

    .line 225
    .line 226
    if-eq p1, p2, :cond_8

    .line 227
    .line 228
    new-instance p1, Lr4/g;

    .line 229
    .line 230
    const p2, 0x7f110103

    .line 231
    .line 232
    .line 233
    invoke-direct {p1, p2}, Lr4/g;-><init>(I)V

    .line 234
    .line 235
    .line 236
    invoke-virtual {p0, p1}, Lz3/f;->m(Lz3/j;)V

    .line 237
    .line 238
    .line 239
    :cond_8
    return-void
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
    .line 657
    .line 658
    .line 659
    .line 660
    .line 661
    .line 662
    .line 663
    .line 664
    .line 665
    .line 666
    .line 667
    .line 668
    .line 669
    .line 670
    .line 671
    .line 672
    .line 673
    .line 674
    .line 675
    .line 676
    .line 677
    .line 678
    .line 679
    .line 680
    .line 681
    .line 682
    .line 683
    .line 684
    .line 685
    .line 686
    .line 687
    .line 688
    .line 689
    .line 690
    .line 691
    .line 692
    .line 693
    .line 694
    .line 695
    .line 696
    .line 697
    .line 698
    .line 699
    .line 700
    .line 701
    .line 702
    .line 703
    .line 704
    .line 705
    .line 706
    .line 707
    .line 708
    .line 709
    .line 710
    .line 711
    .line 712
    .line 713
    .line 714
    .line 715
    .line 716
    .line 717
    .line 718
    .line 719
    .line 720
    .line 721
    .line 722
    .line 723
    .line 724
    .line 725
    .line 726
    .line 727
    .line 728
    .line 729
    .line 730
    .line 731
    .line 732
    .line 733
    .line 734
    .line 735
    .line 736
    .line 737
    .line 738
    .line 739
    .line 740
    .line 741
    .line 742
    .line 743
    .line 744
    .line 745
    .line 746
    .line 747
    .line 748
.end method

.method public final q(Lb5/g;Lj6/a;)V
    .locals 1

    .line 1
    sget-object v0, Lb5/p;->q:Lb5/p;

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    new-instance p1, Lz3/e;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-direct {p1, p0, p2, v0}, Lz3/e;-><init>(Lb5/b0;Lj6/a;I)V

    .line 13
    .line 14
    .line 15
    const-string p2, "android.permission.WRITE_EXTERNAL_STORAGE"

    .line 16
    .line 17
    invoke-virtual {p0, p2, p1}, Lz3/f;->o(Ljava/lang/String;Lj6/l;)V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_0
    sget-object v0, Lb5/f0;->q:Lb5/f0;

    .line 22
    .line 23
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_1

    .line 28
    .line 29
    new-instance p1, Lz3/e;

    .line 30
    .line 31
    const/4 v0, 0x1

    .line 32
    invoke-direct {p1, p0, p2, v0}, Lz3/e;-><init>(Lb5/b0;Lj6/a;I)V

    .line 33
    .line 34
    .line 35
    const-string p2, "android.permission.POST_NOTIFICATIONS"

    .line 36
    .line 37
    invoke-virtual {p0, p2, p1}, Lz3/f;->o(Ljava/lang/String;Lj6/l;)V

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :cond_1
    sget-object v0, Lb5/d;->q:Lb5/d;

    .line 42
    .line 43
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_2

    .line 48
    .line 49
    new-instance p1, Lr4/b;

    .line 50
    .line 51
    const/4 v0, 0x0

    .line 52
    invoke-direct {p1, v0, p2}, Lr4/b;-><init>(ILjava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {p0, p1}, Lz3/f;->m(Lz3/j;)V

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :cond_2
    sget-object v0, Lb5/e;->q:Lb5/e;

    .line 60
    .line 61
    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result p1

    .line 65
    if-eqz p1, :cond_4

    .line 66
    .line 67
    sget-object p1, La4/g;->a:La4/g;

    .line 68
    .line 69
    invoke-virtual {p1}, La4/g;->d()Z

    .line 70
    .line 71
    .line 72
    move-result p1

    .line 73
    if-eqz p1, :cond_3

    .line 74
    .line 75
    new-instance p1, Lr4/b;

    .line 76
    .line 77
    const/4 v0, 0x0

    .line 78
    invoke-direct {p1, v0, p2}, Lr4/b;-><init>(ILjava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    invoke-virtual {p0, p1}, Lz3/f;->m(Lz3/j;)V

    .line 82
    .line 83
    .line 84
    return-void

    .line 85
    :cond_3
    invoke-interface {p2}, Lj6/a;->b()Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    return-void

    .line 89
    :cond_4
    invoke-interface {p2}, Lj6/a;->b()Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    return-void
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method
