.class public final Lb5/g0;
.super Lb5/i;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# static fields
.field public static final q:Lb5/g0;

.field public static final r:Lf5/f;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lb5/g0;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, Lb5/i;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lb5/g0;->q:Lb5/g0;

    .line 8
    .line 9
    new-instance v0, Lf5/f;

    .line 10
    .line 11
    const v1, 0x7f110196

    .line 12
    .line 13
    .line 14
    invoke-direct {v0, v1}, Lf5/f;-><init>(I)V

    .line 15
    .line 16
    .line 17
    sput-object v0, Lb5/g0;->r:Lf5/f;

    .line 18
    .line 19
    return-void
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method


# virtual methods
.method public final i()Lf5/i;
    .locals 4

    .line 1
    sget-object v0, La4/g;->a:La4/g;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget-object v1, La4/g;->s:Laa/b;

    .line 7
    .line 8
    sget-object v2, La4/g;->b:[Lp6/b;

    .line 9
    .line 10
    const/16 v3, 0xc

    .line 11
    .line 12
    aget-object v2, v2, v3

    .line 13
    .line 14
    invoke-virtual {v1, v0, v2}, Laa/b;->r(La4/g;Lp6/b;)Ljava/lang/Boolean;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    sget-boolean v1, La4/n;->n:Z

    .line 23
    .line 24
    if-eq v0, v1, :cond_0

    .line 25
    .line 26
    new-instance v0, Lf5/f;

    .line 27
    .line 28
    const v1, 0x7f110103

    .line 29
    .line 30
    .line 31
    invoke-direct {v0, v1}, Lf5/f;-><init>(I)V

    .line 32
    .line 33
    .line 34
    return-object v0

    .line 35
    :cond_0
    new-instance v0, Lf5/f;

    .line 36
    .line 37
    const v1, 0x7f11015c

    .line 38
    .line 39
    .line 40
    invoke-direct {v0, v1}, Lf5/f;-><init>(I)V

    .line 41
    .line 42
    .line 43
    return-object v0
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final l()Lf5/f;
    .locals 1

    .line 1
    sget-object v0, Lb5/g0;->r:Lf5/f;

    .line 2
    .line 3
    return-object v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final m()Ljava/lang/Object;
    .locals 4

    .line 1
    sget-object v0, La4/g;->a:La4/g;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget-object v1, La4/g;->s:Laa/b;

    .line 7
    .line 8
    sget-object v2, La4/g;->b:[Lp6/b;

    .line 9
    .line 10
    const/16 v3, 0xc

    .line 11
    .line 12
    aget-object v2, v2, v3

    .line 13
    .line 14
    invoke-virtual {v1, v0, v2}, Laa/b;->r(La4/g;Lp6/b;)Ljava/lang/Boolean;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    return-object v0
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final r(Ljava/lang/Object;)V
    .locals 4

    .line 1
    check-cast p1, Ljava/lang/Boolean;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    sget-object v0, La4/g;->a:La4/g;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    sget-object v1, La4/g;->s:Laa/b;

    .line 13
    .line 14
    sget-object v2, La4/g;->b:[Lp6/b;

    .line 15
    .line 16
    const/16 v3, 0xc

    .line 17
    .line 18
    aget-object v2, v2, v3

    .line 19
    .line 20
    iget-object v1, v1, Laa/b;->m:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v1, Li0/d;

    .line 23
    .line 24
    invoke-virtual {v1, v0, v2, p1}, Li0/d;->j(La4/g;Lp6/b;I)V

    .line 25
    .line 26
    .line 27
    const/16 p1, 0x8

    .line 28
    .line 29
    invoke-static {p0, p1}, Lb/m;->c(Lp4/x0;I)V

    .line 30
    .line 31
    .line 32
    return-void
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method
