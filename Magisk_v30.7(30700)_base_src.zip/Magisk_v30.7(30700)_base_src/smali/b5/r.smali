.class public final Lb5/r;
.super Lb5/l;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# static fields
.field public static final q:Lb5/r;

.field public static final r:Lf5/f;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lb5/r;

    .line 2
    .line 3
    invoke-direct {v0}, Lb5/l;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lb5/r;->q:Lb5/r;

    .line 7
    .line 8
    new-instance v0, Lf5/f;

    .line 9
    .line 10
    const v1, 0x7f11006c

    .line 11
    .line 12
    .line 13
    invoke-direct {v0, v1}, Lf5/f;-><init>(I)V

    .line 14
    .line 15
    .line 16
    sput-object v0, Lb5/r;->r:Lf5/f;

    .line 17
    .line 18
    return-void
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method


# virtual methods
.method public final l()Lf5/f;
    .locals 1

    .line 1
    sget-object v0, Lb5/r;->r:Lf5/f;

    .line 2
    .line 3
    return-object v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final m()Ljava/lang/Object;
    .locals 5

    .line 1
    sget-object v0, Lo4/k;->a:Lo4/j;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget-object v0, Lo4/j;->b:Lv5/i;

    .line 7
    .line 8
    invoke-virtual {v0}, Lv5/i;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Lo4/h;

    .line 13
    .line 14
    iget-object v0, v0, Lo4/h;->b:[Ljava/lang/String;

    .line 15
    .line 16
    sget-object v1, La4/g;->a:La4/g;

    .line 17
    .line 18
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 19
    .line 20
    .line 21
    sget-object v2, La4/g;->m:Lk4/t;

    .line 22
    .line 23
    sget-object v3, La4/g;->b:[Lp6/b;

    .line 24
    .line 25
    const/4 v4, 0x6

    .line 26
    aget-object v3, v3, v4

    .line 27
    .line 28
    invoke-virtual {v2, v1, v3}, Lk4/t;->u0(La4/g;Lp6/b;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    invoke-static {v0, v1}, Lw5/i;->j0([Ljava/lang/Object;Ljava/lang/Object;)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    return-object v0
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final r(Ljava/lang/Object;)V
    .locals 5

    .line 1
    check-cast p1, Ljava/lang/Number;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    sget-object v0, La4/g;->a:La4/g;

    .line 8
    .line 9
    sget-object v1, Lo4/k;->a:Lo4/j;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    sget-object v2, Lo4/j;->b:Lv5/i;

    .line 15
    .line 16
    invoke-virtual {v2}, Lv5/i;->getValue()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    check-cast v2, Lo4/h;

    .line 21
    .line 22
    iget-object v2, v2, Lo4/h;->b:[Ljava/lang/String;

    .line 23
    .line 24
    aget-object p1, v2, p1

    .line 25
    .line 26
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    sget-object v2, La4/g;->m:Lk4/t;

    .line 30
    .line 31
    sget-object v3, La4/g;->b:[Lp6/b;

    .line 32
    .line 33
    const/4 v4, 0x6

    .line 34
    aget-object v3, v3, v4

    .line 35
    .line 36
    invoke-virtual {v2, v0, v3, p1}, Lk4/t;->v0(La4/g;Lp6/b;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    invoke-static {}, Lo4/j;->c()Lo4/k;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-interface {v0, p1}, Lo4/k;->b(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    return-void
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method

.method public final s(Landroid/content/res/Resources;)[Ljava/lang/String;
    .locals 0

    .line 1
    sget-object p1, Lo4/k;->a:Lo4/j;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget-object p1, Lo4/j;->b:Lv5/i;

    .line 7
    .line 8
    invoke-virtual {p1}, Lv5/i;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Lo4/h;

    .line 13
    .line 14
    iget-object p1, p1, Lo4/h;->a:[Ljava/lang/String;

    .line 15
    .line 16
    return-object p1
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method

.method public final t(Landroid/content/res/Resources;)[Ljava/lang/String;
    .locals 0

    .line 1
    sget-object p1, Lo4/k;->a:Lo4/j;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    sget-object p1, Lo4/j;->b:Lv5/i;

    .line 7
    .line 8
    invoke-virtual {p1}, Lv5/i;->getValue()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    check-cast p1, Lo4/h;

    .line 13
    .line 14
    iget-object p1, p1, Lo4/h;->a:[Ljava/lang/String;

    .line 15
    .line 16
    return-object p1
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method
