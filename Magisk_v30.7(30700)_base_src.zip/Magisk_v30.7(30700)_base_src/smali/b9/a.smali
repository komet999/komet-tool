.class public interface abstract Lb9/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:Lr8/o;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lr8/o;

    .line 2
    .line 3
    const-string v1, "1.2.410.200004.1.4"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lr8/o;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    new-instance v0, Lr8/o;

    .line 9
    .line 10
    const-string v1, "1.2.410.200004.1.7"

    .line 11
    .line 12
    invoke-direct {v0, v1}, Lr8/o;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    new-instance v0, Lr8/o;

    .line 16
    .line 17
    const-string v1, "1.2.410.200004.1.15"

    .line 18
    .line 19
    invoke-direct {v0, v1}, Lr8/o;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    new-instance v0, Lr8/o;

    .line 23
    .line 24
    const-string v1, "1.2.410.200004.7.1.1.1"

    .line 25
    .line 26
    invoke-direct {v0, v1}, Lr8/o;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    sput-object v0, Lb9/a;->a:Lr8/o;

    .line 30
    .line 31
    return-void
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method
