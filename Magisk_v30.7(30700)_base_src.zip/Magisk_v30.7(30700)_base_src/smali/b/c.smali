.class public final synthetic Lb/c;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic m:I

.field public final synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 13
    iput p1, p0, Lb/c;->m:I

    iput-object p2, p0, Lb/c;->n:Ljava/lang/Object;

    iput-object p3, p0, Lb/c;->o:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Laa/e;Lja/i;Ljava/lang/Throwable;)V
    .locals 0

    .line 1
    const/16 p1, 0xb

    .line 2
    .line 3
    iput p1, p0, Lb/c;->m:I

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p2, p0, Lb/c;->n:Ljava/lang/Object;

    .line 9
    .line 10
    iput-object p3, p0, Lb/c;->o:Ljava/lang/Object;

    .line 11
    .line 12
    return-void
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 1
    iget v0, p0, Lb/c;->m:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Landroid/widget/TextView;

    .line 9
    .line 10
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Landroid/widget/ImageView;

    .line 13
    .line 14
    invoke-virtual {v0}, Landroid/widget/TextView;->getLayout()Landroid/text/Layout;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    const/4 v2, 0x0

    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    invoke-virtual {v0, v2}, Landroid/text/Layout;->getEllipsisCount(I)I

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_0

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    iput v2, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 33
    .line 34
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    iput v2, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 39
    .line 40
    invoke-virtual {v1}, Landroid/view/View;->requestLayout()V

    .line 41
    .line 42
    .line 43
    :goto_0
    return-void

    .line 44
    :pswitch_0
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v0, Ljava/lang/Runnable;

    .line 47
    .line 48
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 49
    .line 50
    check-cast v1, Lh/m;

    .line 51
    .line 52
    :try_start_0
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 53
    .line 54
    .line 55
    invoke-virtual {v1}, Lh/m;->b()V

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :catchall_0
    move-exception v0

    .line 60
    invoke-virtual {v1}, Lh/m;->b()V

    .line 61
    .line 62
    .line 63
    throw v0

    .line 64
    :pswitch_1
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 65
    .line 66
    check-cast v0, Lja/i;

    .line 67
    .line 68
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 69
    .line 70
    check-cast v1, Ljava/lang/Throwable;

    .line 71
    .line 72
    invoke-interface {v0, v1}, Lja/i;->j(Ljava/lang/Throwable;)V

    .line 73
    .line 74
    .line 75
    return-void

    .line 76
    :pswitch_2
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 77
    .line 78
    check-cast v0, Lj5/f0;

    .line 79
    .line 80
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v1, Landroid/content/ServiceConnection;

    .line 83
    .line 84
    iget-object v0, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v0, Lj5/h0;

    .line 87
    .line 88
    iget-object v0, v0, Lj5/h0;->a:Lj5/i0;

    .line 89
    .line 90
    iget-object v0, v0, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 91
    .line 92
    check-cast v0, Landroid/content/ComponentName;

    .line 93
    .line 94
    invoke-interface {v1, v0}, Landroid/content/ServiceConnection;->onServiceDisconnected(Landroid/content/ComponentName;)V

    .line 95
    .line 96
    .line 97
    return-void

    .line 98
    :pswitch_3
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast v0, Landroid/content/ServiceConnection;

    .line 101
    .line 102
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 103
    .line 104
    check-cast v1, Lj5/i0;

    .line 105
    .line 106
    invoke-static {v0, v1}, Lj5/k0;->a(Landroid/content/ServiceConnection;Lj5/i0;)V

    .line 107
    .line 108
    .line 109
    return-void

    .line 110
    :pswitch_4
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 111
    .line 112
    check-cast v0, Li5/c;

    .line 113
    .line 114
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 115
    .line 116
    check-cast v1, Lj5/w0;

    .line 117
    .line 118
    invoke-interface {v0, v1}, Li5/c;->a(Lj5/w0;)V

    .line 119
    .line 120
    .line 121
    return-void

    .line 122
    :pswitch_5
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 123
    .line 124
    check-cast v0, Ljava/util/concurrent/Executor;

    .line 125
    .line 126
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 127
    .line 128
    check-cast v1, Li5/c;

    .line 129
    .line 130
    :try_start_1
    invoke-static {}, Lj5/r;->c()Lj5/w0;

    .line 131
    .line 132
    .line 133
    move-result-object v2

    .line 134
    if-nez v0, :cond_1

    .line 135
    .line 136
    invoke-interface {v1, v2}, Li5/c;->a(Lj5/w0;)V

    .line 137
    .line 138
    .line 139
    goto :goto_1

    .line 140
    :cond_1
    new-instance v3, Lb/c;

    .line 141
    .line 142
    const/16 v4, 0x8

    .line 143
    .line 144
    invoke-direct {v3, v4, v1, v2}, Lb/c;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 145
    .line 146
    .line 147
    invoke-interface {v0, v3}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_1
    .catch Li5/b; {:try_start_1 .. :try_end_1} :catch_0

    .line 148
    .line 149
    .line 150
    :catch_0
    :goto_1
    return-void

    .line 151
    :pswitch_6
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 152
    .line 153
    check-cast v0, Lj5/x;

    .line 154
    .line 155
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 156
    .line 157
    check-cast v1, Lj5/a0;

    .line 158
    .line 159
    iget-object v0, v0, Lj5/x;->e:Li5/d;

    .line 160
    .line 161
    invoke-interface {v0, v1}, Li5/d;->l(Lj5/a0;)V

    .line 162
    .line 163
    .line 164
    return-void

    .line 165
    :pswitch_7
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 166
    .line 167
    check-cast v0, Li5/a;

    .line 168
    .line 169
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 170
    .line 171
    invoke-virtual {v0, v1}, Li5/a;->a(Ljava/lang/Object;)V

    .line 172
    .line 173
    .line 174
    return-void

    .line 175
    :pswitch_8
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 176
    .line 177
    check-cast v0, Li0/b;

    .line 178
    .line 179
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 180
    .line 181
    check-cast v1, Landroid/graphics/Typeface;

    .line 182
    .line 183
    invoke-virtual {v0, v1}, Li0/b;->i(Landroid/graphics/Typeface;)V

    .line 184
    .line 185
    .line 186
    return-void

    .line 187
    :pswitch_9
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 188
    .line 189
    check-cast v0, Lh/m;

    .line 190
    .line 191
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 192
    .line 193
    check-cast v1, Ljava/lang/Runnable;

    .line 194
    .line 195
    :try_start_2
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 196
    .line 197
    .line 198
    invoke-virtual {v0}, Lh/m;->b()V

    .line 199
    .line 200
    .line 201
    return-void

    .line 202
    :catchall_1
    move-exception v1

    .line 203
    invoke-virtual {v0}, Lh/m;->b()V

    .line 204
    .line 205
    .line 206
    throw v1

    .line 207
    :pswitch_a
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 208
    .line 209
    check-cast v0, Landroid/content/Context;

    .line 210
    .line 211
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 212
    .line 213
    check-cast v1, Ljava/lang/String;

    .line 214
    .line 215
    const/4 v2, 0x0

    .line 216
    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 217
    .line 218
    .line 219
    move-result-object v0

    .line 220
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 221
    .line 222
    .line 223
    return-void

    .line 224
    :pswitch_b
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 225
    .line 226
    check-cast v0, Lb4/j;

    .line 227
    .line 228
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 229
    .line 230
    check-cast v1, Landroid/os/Bundle;

    .line 231
    .line 232
    const/4 v2, 0x1

    .line 233
    sput-boolean v2, Lb4/j;->o:Z

    .line 234
    .line 235
    invoke-static {}, La4/f;->a()Z

    .line 236
    .line 237
    .line 238
    move-result v3

    .line 239
    if-eqz v3, :cond_2

    .line 240
    .line 241
    iget-object v0, v0, Lb4/j;->n:Ljava/lang/Object;

    .line 242
    .line 243
    check-cast v0, Lcom/topjohnwu/magisk/ui/MainActivity;

    .line 244
    .line 245
    invoke-static {v0}, Lb4/c;->i(Landroid/app/Activity;)V

    .line 246
    .line 247
    .line 248
    goto :goto_2

    .line 249
    :cond_2
    iget-object v3, v0, Lb4/j;->n:Ljava/lang/Object;

    .line 250
    .line 251
    check-cast v3, Lcom/topjohnwu/magisk/ui/MainActivity;

    .line 252
    .line 253
    iget-object v3, v3, Lf0/g;->m:Lk1/r;

    .line 254
    .line 255
    iget-object v3, v3, Lk1/r;->d:Lk1/l;

    .line 256
    .line 257
    sget-object v4, Lk1/l;->p:Lk1/l;

    .line 258
    .line 259
    invoke-virtual {v3, v4}, Lk1/l;->a(Lk1/l;)Z

    .line 260
    .line 261
    .line 262
    move-result v3

    .line 263
    if-eqz v3, :cond_3

    .line 264
    .line 265
    invoke-virtual {v0, v1}, Lb4/j;->d(Landroid/os/Bundle;)V

    .line 266
    .line 267
    .line 268
    goto :goto_2

    .line 269
    :cond_3
    iput-boolean v2, v0, Lb4/j;->m:Z

    .line 270
    .line 271
    :goto_2
    return-void

    .line 272
    :pswitch_c
    iget-object v0, p0, Lb/c;->n:Ljava/lang/Object;

    .line 273
    .line 274
    check-cast v0, Lh/i;

    .line 275
    .line 276
    iget-object v1, p0, Lb/c;->o:Ljava/lang/Object;

    .line 277
    .line 278
    check-cast v1, Lb/e0;

    .line 279
    .line 280
    iget-object v2, v0, Lf0/g;->m:Lk1/r;

    .line 281
    .line 282
    new-instance v3, Lb/e;

    .line 283
    .line 284
    const/4 v4, 0x0

    .line 285
    invoke-direct {v3, v4, v1, v0}, Lb/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 286
    .line 287
    .line 288
    invoke-virtual {v2, v3}, Lk1/r;->a(Lk1/o;)V

    .line 289
    .line 290
    .line 291
    return-void

    .line 292
    nop

    .line 293
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
.end method
