.class public final synthetic Lb/a0;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Lj6/a;


# instance fields
.field public final synthetic m:I

.field public final synthetic n:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, Lb/a0;->m:I

    .line 2
    .line 3
    iput-object p2, p0, Lb/a0;->n:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method


# virtual methods
.method public final b()Ljava/lang/Object;
    .locals 37

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, Lb/a0;->m:I

    .line 4
    .line 5
    const/4 v3, 0x4

    .line 6
    const/4 v4, -0x1

    .line 7
    const-string v5, ""

    .line 8
    .line 9
    sget-object v6, Lv5/k;->a:Lv5/k;

    .line 10
    .line 11
    const/4 v9, 0x0

    .line 12
    iget-object v11, v1, Lb/a0;->n:Ljava/lang/Object;

    .line 13
    .line 14
    packed-switch v0, :pswitch_data_0

    .line 15
    .line 16
    .line 17
    check-cast v11, Lcom/topjohnwu/magisk/ui/MainActivity;

    .line 18
    .line 19
    iget-object v0, v11, Lh/i;->F:Laa/b;

    .line 20
    .line 21
    iget-object v0, v0, Laa/b;->m:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lh1/a0;

    .line 24
    .line 25
    iget-object v0, v0, Lh1/a0;->p:Lh1/r0;

    .line 26
    .line 27
    iget v2, v11, Lcom/topjohnwu/magisk/ui/MainActivity;->Q:I

    .line 28
    .line 29
    invoke-virtual {v0, v2}, Lh1/q0;->C(I)Lh1/y;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    check-cast v0, Landroidx/navigation/fragment/NavHostFragment;

    .line 34
    .line 35
    return-object v0

    .line 36
    :pswitch_0
    check-cast v11, Lz1/q;

    .line 37
    .line 38
    iget-object v0, v11, Lz1/q;->m:Le2/b;

    .line 39
    .line 40
    iget-object v2, v11, Lz1/q;->n:Ljava/lang/String;

    .line 41
    .line 42
    invoke-interface {v0, v2}, Le2/b;->b(Ljava/lang/String;)Le2/a;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    return-object v0

    .line 47
    :pswitch_1
    check-cast v11, Lv3/d;

    .line 48
    .line 49
    const-string v0, ":memory:"

    .line 50
    .line 51
    invoke-virtual {v11, v0}, Lv3/d;->b(Ljava/lang/String;)Le2/a;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    return-object v0

    .line 56
    :pswitch_2
    check-cast v11, Lx1/g;

    .line 57
    .line 58
    iget-object v0, v11, Lx1/g;->a:Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;

    .line 59
    .line 60
    invoke-virtual {v0}, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->g()Z

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    if-eqz v2, :cond_1

    .line 65
    .line 66
    invoke-virtual {v0}, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->i()Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_0

    .line 71
    .line 72
    goto :goto_0

    .line 73
    :cond_0
    move v8, v9

    .line 74
    goto :goto_1

    .line 75
    :cond_1
    :goto_0
    const/4 v8, 0x1

    .line 76
    :goto_1
    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    return-object v0

    .line 81
    :pswitch_3
    check-cast v11, Lu7/h;

    .line 82
    .line 83
    iget-object v0, v11, Lu7/h;->n:Ljava/lang/ClassLoader;

    .line 84
    .line 85
    iget-object v2, v11, Lu7/h;->o:Lt7/t;

    .line 86
    .line 87
    invoke-virtual {v0, v5}, Ljava/lang/ClassLoader;->getResources(Ljava/lang/String;)Ljava/util/Enumeration;

    .line 88
    .line 89
    .line 90
    move-result-object v5

    .line 91
    invoke-static {v5}, Ljava/util/Collections;->list(Ljava/util/Enumeration;)Ljava/util/ArrayList;

    .line 92
    .line 93
    .line 94
    move-result-object v5

    .line 95
    new-instance v6, Ljava/util/ArrayList;

    .line 96
    .line 97
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 101
    .line 102
    .line 103
    move-result v7

    .line 104
    move v11, v9

    .line 105
    :cond_2
    :goto_2
    if-ge v11, v7, :cond_4

    .line 106
    .line 107
    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v12

    .line 111
    add-int/lit8 v11, v11, 0x1

    .line 112
    .line 113
    check-cast v12, Ljava/net/URL;

    .line 114
    .line 115
    invoke-virtual {v12}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object v13

    .line 119
    const-string v14, "file"

    .line 120
    .line 121
    invoke-static {v13, v14}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 122
    .line 123
    .line 124
    move-result v13

    .line 125
    if-nez v13, :cond_3

    .line 126
    .line 127
    const/4 v13, 0x0

    .line 128
    goto :goto_3

    .line 129
    :cond_3
    sget-object v13, Lt7/x;->n:Ljava/lang/String;

    .line 130
    .line 131
    new-instance v13, Ljava/io/File;

    .line 132
    .line 133
    invoke-virtual {v12}, Ljava/net/URL;->toURI()Ljava/net/URI;

    .line 134
    .line 135
    .line 136
    move-result-object v12

    .line 137
    invoke-direct {v13, v12}, Ljava/io/File;-><init>(Ljava/net/URI;)V

    .line 138
    .line 139
    .line 140
    invoke-static {v13}, Lq4/b;->j(Ljava/io/File;)Lt7/x;

    .line 141
    .line 142
    .line 143
    move-result-object v12

    .line 144
    new-instance v13, Lv5/e;

    .line 145
    .line 146
    invoke-direct {v13, v2, v12}, Lv5/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 147
    .line 148
    .line 149
    :goto_3
    if-eqz v13, :cond_2

    .line 150
    .line 151
    invoke-virtual {v6, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 152
    .line 153
    .line 154
    goto :goto_2

    .line 155
    :cond_4
    const-string v5, "META-INF/MANIFEST.MF"

    .line 156
    .line 157
    invoke-virtual {v0, v5}, Ljava/lang/ClassLoader;->getResources(Ljava/lang/String;)Ljava/util/Enumeration;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    invoke-static {v0}, Ljava/util/Collections;->list(Ljava/util/Enumeration;)Ljava/util/ArrayList;

    .line 162
    .line 163
    .line 164
    move-result-object v5

    .line 165
    new-instance v7, Ljava/util/ArrayList;

    .line 166
    .line 167
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 168
    .line 169
    .line 170
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 171
    .line 172
    .line 173
    move-result v11

    .line 174
    :goto_4
    if-ge v9, v11, :cond_18

    .line 175
    .line 176
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    add-int/lit8 v9, v9, 0x1

    .line 181
    .line 182
    check-cast v0, Ljava/net/URL;

    .line 183
    .line 184
    invoke-virtual {v0}, Ljava/net/URL;->toString()Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    move-result-object v12

    .line 188
    const-string v0, "jar:file:"

    .line 189
    .line 190
    invoke-virtual {v12, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 191
    .line 192
    .line 193
    move-result v0

    .line 194
    if-nez v0, :cond_5

    .line 195
    .line 196
    :goto_5
    move/from16 v16, v3

    .line 197
    .line 198
    move-object/from16 v18, v5

    .line 199
    .line 200
    move/from16 v30, v9

    .line 201
    .line 202
    move/from16 v28, v11

    .line 203
    .line 204
    const/4 v10, 0x0

    .line 205
    goto/16 :goto_17

    .line 206
    .line 207
    :cond_5
    invoke-static {v12}, Lr6/i;->R(Ljava/lang/CharSequence;)I

    .line 208
    .line 209
    .line 210
    move-result v14

    .line 211
    invoke-static {v12}, Lb/m;->v(Ljava/lang/Object;)Z

    .line 212
    .line 213
    .line 214
    move-result v0

    .line 215
    const-string v13, "!"

    .line 216
    .line 217
    if-nez v0, :cond_6

    .line 218
    .line 219
    const/4 v15, 0x0

    .line 220
    const/16 v17, 0x1

    .line 221
    .line 222
    const/16 v16, 0x0

    .line 223
    .line 224
    invoke-static/range {v12 .. v17}, Lr6/i;->T(Ljava/lang/CharSequence;Ljava/lang/CharSequence;IIZZ)I

    .line 225
    .line 226
    .line 227
    move-result v0

    .line 228
    goto :goto_6

    .line 229
    :cond_6
    invoke-virtual {v12, v13, v14}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;I)I

    .line 230
    .line 231
    .line 232
    move-result v0

    .line 233
    :goto_6
    if-ne v0, v4, :cond_7

    .line 234
    .line 235
    goto :goto_5

    .line 236
    :cond_7
    sget-object v13, Lt7/x;->n:Ljava/lang/String;

    .line 237
    .line 238
    new-instance v13, Ljava/io/File;

    .line 239
    .line 240
    invoke-virtual {v12, v3, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 241
    .line 242
    .line 243
    move-result-object v0

    .line 244
    invoke-static {v0}, Ljava/net/URI;->create(Ljava/lang/String;)Ljava/net/URI;

    .line 245
    .line 246
    .line 247
    move-result-object v0

    .line 248
    invoke-direct {v13, v0}, Ljava/io/File;-><init>(Ljava/net/URI;)V

    .line 249
    .line 250
    .line 251
    invoke-static {v13}, Lq4/b;->j(Ljava/io/File;)Lt7/x;

    .line 252
    .line 253
    .line 254
    move-result-object v12

    .line 255
    const-string v0, "not a zip: size="

    .line 256
    .line 257
    invoke-virtual {v2, v12}, Lt7/t;->Q(Lt7/x;)Lt7/s;

    .line 258
    .line 259
    .line 260
    move-result-object v13

    .line 261
    :try_start_0
    invoke-virtual {v13}, Lt7/s;->size()J

    .line 262
    .line 263
    .line 264
    move-result-wide v14

    .line 265
    move/from16 v16, v3

    .line 266
    .line 267
    const/16 v3, 0x16

    .line 268
    .line 269
    move-object/from16 v18, v5

    .line 270
    .line 271
    int-to-long v4, v3

    .line 272
    sub-long/2addr v14, v4

    .line 273
    const-wide/16 v3, 0x0

    .line 274
    .line 275
    cmp-long v5, v14, v3

    .line 276
    .line 277
    if-ltz v5, :cond_17

    .line 278
    .line 279
    const-wide/32 v19, 0x10000

    .line 280
    .line 281
    .line 282
    move v5, v11

    .line 283
    sub-long v10, v14, v19

    .line 284
    .line 285
    invoke-static {v10, v11, v3, v4}, Ljava/lang/Math;->max(JJ)J

    .line 286
    .line 287
    .line 288
    move-result-wide v10

    .line 289
    :goto_7
    invoke-virtual {v13, v14, v15}, Lt7/s;->f(J)Lt7/j;

    .line 290
    .line 291
    .line 292
    move-result-object v0

    .line 293
    move-wide/from16 v19, v3

    .line 294
    .line 295
    new-instance v3, Lt7/a0;

    .line 296
    .line 297
    invoke-direct {v3, v0}, Lt7/a0;-><init>(Lt7/g0;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_6

    .line 298
    .line 299
    .line 300
    :try_start_1
    invoke-virtual {v3}, Lt7/a0;->p()I

    .line 301
    .line 302
    .line 303
    move-result v0

    .line 304
    const v4, 0x6054b50

    .line 305
    .line 306
    .line 307
    if-ne v0, v4, :cond_15

    .line 308
    .line 309
    invoke-virtual {v3}, Lt7/a0;->t()S

    .line 310
    .line 311
    .line 312
    move-result v0

    .line 313
    const v4, 0xffff

    .line 314
    .line 315
    .line 316
    and-int/2addr v0, v4

    .line 317
    invoke-virtual {v3}, Lt7/a0;->t()S

    .line 318
    .line 319
    .line 320
    move-result v10

    .line 321
    and-int/2addr v10, v4

    .line 322
    invoke-virtual {v3}, Lt7/a0;->t()S

    .line 323
    .line 324
    .line 325
    move-result v11

    .line 326
    and-int/2addr v11, v4

    .line 327
    move/from16 v22, v4

    .line 328
    .line 329
    move/from16 v28, v5

    .line 330
    .line 331
    int-to-long v4, v11

    .line 332
    invoke-virtual {v3}, Lt7/a0;->t()S

    .line 333
    .line 334
    .line 335
    move-result v11
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_b

    .line 336
    and-int v11, v11, v22

    .line 337
    .line 338
    move/from16 v30, v9

    .line 339
    .line 340
    int-to-long v8, v11

    .line 341
    cmp-long v8, v4, v8

    .line 342
    .line 343
    const-string v9, "unsupported zip: spanned"

    .line 344
    .line 345
    if-nez v8, :cond_14

    .line 346
    .line 347
    if-nez v0, :cond_14

    .line 348
    .line 349
    if-nez v10, :cond_14

    .line 350
    .line 351
    const-wide/16 v10, 0x4

    .line 352
    .line 353
    :try_start_2
    invoke-virtual {v3, v10, v11}, Lt7/a0;->skip(J)V

    .line 354
    .line 355
    .line 356
    invoke-virtual {v3}, Lt7/a0;->p()I

    .line 357
    .line 358
    .line 359
    move-result v0

    .line 360
    int-to-long v10, v0

    .line 361
    const-wide v23, 0xffffffffL

    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    and-long v25, v10, v23

    .line 367
    .line 368
    invoke-virtual {v3}, Lt7/a0;->t()S

    .line 369
    .line 370
    .line 371
    move-result v0

    .line 372
    and-int v36, v0, v22

    .line 373
    .line 374
    new-instance v22, Lu7/f;

    .line 375
    .line 376
    move-wide/from16 v23, v4

    .line 377
    .line 378
    move/from16 v27, v36

    .line 379
    .line 380
    invoke-direct/range {v22 .. v27}, Lu7/f;-><init>(JJI)V

    .line 381
    .line 382
    .line 383
    move/from16 v0, v27

    .line 384
    .line 385
    int-to-long v4, v0

    .line 386
    invoke-virtual {v3, v4, v5}, Lt7/a0;->z(J)Ljava/lang/String;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_b

    .line 387
    .line 388
    .line 389
    :try_start_3
    invoke-virtual {v3}, Lt7/a0;->close()V

    .line 390
    .line 391
    .line 392
    const/16 v3, 0x14

    .line 393
    .line 394
    int-to-long v3, v3

    .line 395
    sub-long/2addr v14, v3

    .line 396
    cmp-long v3, v14, v19

    .line 397
    .line 398
    if-lez v3, :cond_d

    .line 399
    .line 400
    invoke-virtual {v13, v14, v15}, Lt7/s;->f(J)Lt7/j;

    .line 401
    .line 402
    .line 403
    move-result-object v3

    .line 404
    new-instance v4, Lt7/a0;

    .line 405
    .line 406
    invoke-direct {v4, v3}, Lt7/a0;-><init>(Lt7/g0;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_6

    .line 407
    .line 408
    .line 409
    :try_start_4
    invoke-virtual {v4}, Lt7/a0;->p()I

    .line 410
    .line 411
    .line 412
    move-result v3

    .line 413
    const v5, 0x7064b50

    .line 414
    .line 415
    .line 416
    if-ne v3, v5, :cond_c

    .line 417
    .line 418
    invoke-virtual {v4}, Lt7/a0;->p()I

    .line 419
    .line 420
    .line 421
    move-result v3

    .line 422
    invoke-virtual {v4}, Lt7/a0;->u()J

    .line 423
    .line 424
    .line 425
    move-result-wide v10

    .line 426
    invoke-virtual {v4}, Lt7/a0;->p()I

    .line 427
    .line 428
    .line 429
    move-result v5

    .line 430
    const/4 v8, 0x1

    .line 431
    if-ne v5, v8, :cond_b

    .line 432
    .line 433
    if-nez v3, :cond_b

    .line 434
    .line 435
    invoke-virtual {v13, v10, v11}, Lt7/s;->f(J)Lt7/j;

    .line 436
    .line 437
    .line 438
    move-result-object v3

    .line 439
    new-instance v5, Lt7/a0;

    .line 440
    .line 441
    invoke-direct {v5, v3}, Lt7/a0;-><init>(Lt7/g0;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 442
    .line 443
    .line 444
    :try_start_5
    invoke-virtual {v5}, Lt7/a0;->p()I

    .line 445
    .line 446
    .line 447
    move-result v3

    .line 448
    const v8, 0x6064b50

    .line 449
    .line 450
    .line 451
    if-ne v3, v8, :cond_9

    .line 452
    .line 453
    const-wide/16 v10, 0xc

    .line 454
    .line 455
    invoke-virtual {v5, v10, v11}, Lt7/a0;->skip(J)V

    .line 456
    .line 457
    .line 458
    invoke-virtual {v5}, Lt7/a0;->p()I

    .line 459
    .line 460
    .line 461
    move-result v3

    .line 462
    invoke-virtual {v5}, Lt7/a0;->p()I

    .line 463
    .line 464
    .line 465
    move-result v8

    .line 466
    invoke-virtual {v5}, Lt7/a0;->u()J

    .line 467
    .line 468
    .line 469
    move-result-wide v32

    .line 470
    invoke-virtual {v5}, Lt7/a0;->u()J

    .line 471
    .line 472
    .line 473
    move-result-wide v10

    .line 474
    cmp-long v10, v32, v10

    .line 475
    .line 476
    if-nez v10, :cond_8

    .line 477
    .line 478
    if-nez v3, :cond_8

    .line 479
    .line 480
    if-nez v8, :cond_8

    .line 481
    .line 482
    const-wide/16 v8, 0x8

    .line 483
    .line 484
    invoke-virtual {v5, v8, v9}, Lt7/a0;->skip(J)V

    .line 485
    .line 486
    .line 487
    invoke-virtual {v5}, Lt7/a0;->u()J

    .line 488
    .line 489
    .line 490
    move-result-wide v34

    .line 491
    new-instance v31, Lu7/f;

    .line 492
    .line 493
    move/from16 v36, v0

    .line 494
    .line 495
    invoke-direct/range {v31 .. v36}, Lu7/f;-><init>(JJI)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 496
    .line 497
    .line 498
    :try_start_6
    invoke-virtual {v5}, Lt7/a0;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 499
    .line 500
    .line 501
    const/4 v0, 0x0

    .line 502
    goto :goto_8

    .line 503
    :catchall_0
    move-exception v0

    .line 504
    :goto_8
    move-object/from16 v22, v31

    .line 505
    .line 506
    goto :goto_c

    .line 507
    :cond_8
    :try_start_7
    new-instance v0, Ljava/io/IOException;

    .line 508
    .line 509
    invoke-direct {v0, v9}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 510
    .line 511
    .line 512
    throw v0

    .line 513
    :goto_9
    move-object v3, v0

    .line 514
    goto :goto_a

    .line 515
    :cond_9
    new-instance v0, Ljava/io/IOException;

    .line 516
    .line 517
    new-instance v9, Ljava/lang/StringBuilder;

    .line 518
    .line 519
    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    .line 520
    .line 521
    .line 522
    const-string v10, "bad zip: expected "

    .line 523
    .line 524
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 525
    .line 526
    .line 527
    invoke-static {v8}, Lu7/b;->d(I)Ljava/lang/String;

    .line 528
    .line 529
    .line 530
    move-result-object v8

    .line 531
    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 532
    .line 533
    .line 534
    const-string v8, " but was "

    .line 535
    .line 536
    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 537
    .line 538
    .line 539
    invoke-static {v3}, Lu7/b;->d(I)Ljava/lang/String;

    .line 540
    .line 541
    .line 542
    move-result-object v3

    .line 543
    invoke-virtual {v9, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 544
    .line 545
    .line 546
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 547
    .line 548
    .line 549
    move-result-object v3

    .line 550
    invoke-direct {v0, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 551
    .line 552
    .line 553
    throw v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 554
    :catchall_1
    move-exception v0

    .line 555
    goto :goto_9

    .line 556
    :goto_a
    :try_start_8
    invoke-virtual {v5}, Lt7/a0;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_2

    .line 557
    .line 558
    .line 559
    goto :goto_b

    .line 560
    :catchall_2
    move-exception v0

    .line 561
    :try_start_9
    invoke-static {v3, v0}, Lo2/b;->c(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 562
    .line 563
    .line 564
    :goto_b
    move-object v0, v3

    .line 565
    :goto_c
    if-nez v0, :cond_a

    .line 566
    .line 567
    goto :goto_d

    .line 568
    :cond_a
    throw v0

    .line 569
    :catchall_3
    move-exception v0

    .line 570
    move-object v3, v0

    .line 571
    goto :goto_e

    .line 572
    :cond_b
    new-instance v0, Ljava/io/IOException;

    .line 573
    .line 574
    invoke-direct {v0, v9}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 575
    .line 576
    .line 577
    throw v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    .line 578
    :cond_c
    :goto_d
    :try_start_a
    invoke-virtual {v4}, Lt7/a0;->close()V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    .line 579
    .line 580
    .line 581
    const/4 v0, 0x0

    .line 582
    goto :goto_10

    .line 583
    :catchall_4
    move-exception v0

    .line 584
    goto :goto_10

    .line 585
    :goto_e
    :try_start_b
    invoke-virtual {v4}, Lt7/a0;->close()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    .line 586
    .line 587
    .line 588
    goto :goto_f

    .line 589
    :catchall_5
    move-exception v0

    .line 590
    :try_start_c
    invoke-static {v3, v0}, Lo2/b;->c(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 591
    .line 592
    .line 593
    :goto_f
    move-object v0, v3

    .line 594
    :goto_10
    if-nez v0, :cond_e

    .line 595
    .line 596
    :cond_d
    move-object/from16 v0, v22

    .line 597
    .line 598
    goto :goto_11

    .line 599
    :cond_e
    throw v0

    .line 600
    :catchall_6
    move-exception v0

    .line 601
    move-object v2, v0

    .line 602
    goto/16 :goto_19

    .line 603
    .line 604
    :goto_11
    new-instance v3, Ljava/util/ArrayList;

    .line 605
    .line 606
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 607
    .line 608
    .line 609
    iget-wide v4, v0, Lu7/f;->b:J

    .line 610
    .line 611
    invoke-virtual {v13, v4, v5}, Lt7/s;->f(J)Lt7/j;

    .line 612
    .line 613
    .line 614
    move-result-object v4

    .line 615
    new-instance v5, Lt7/a0;

    .line 616
    .line 617
    invoke-direct {v5, v4}, Lt7/a0;-><init>(Lt7/g0;)V
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_6

    .line 618
    .line 619
    .line 620
    :try_start_d
    iget-wide v8, v0, Lu7/f;->a:J

    .line 621
    .line 622
    :goto_12
    cmp-long v4, v19, v8

    .line 623
    .line 624
    if-gez v4, :cond_11

    .line 625
    .line 626
    invoke-static {v5}, Lu7/b;->e(Lt7/a0;)Lu7/j;

    .line 627
    .line 628
    .line 629
    move-result-object v4

    .line 630
    iget-wide v10, v4, Lu7/j;->h:J

    .line 631
    .line 632
    iget-wide v14, v0, Lu7/f;->b:J

    .line 633
    .line 634
    cmp-long v10, v10, v14

    .line 635
    .line 636
    if-gez v10, :cond_10

    .line 637
    .line 638
    sget-object v10, Lu7/h;->q:Lt7/x;

    .line 639
    .line 640
    iget-object v10, v4, Lu7/j;->a:Lt7/x;

    .line 641
    .line 642
    invoke-static {v10}, Lq4/b;->g(Lt7/x;)Z

    .line 643
    .line 644
    .line 645
    move-result v10

    .line 646
    if-eqz v10, :cond_f

    .line 647
    .line 648
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 649
    .line 650
    .line 651
    goto :goto_13

    .line 652
    :catchall_7
    move-exception v0

    .line 653
    move-object v4, v0

    .line 654
    goto :goto_14

    .line 655
    :cond_f
    :goto_13
    const-wide/16 v10, 0x1

    .line 656
    .line 657
    add-long v19, v19, v10

    .line 658
    .line 659
    goto :goto_12

    .line 660
    :cond_10
    new-instance v0, Ljava/io/IOException;

    .line 661
    .line 662
    const-string v4, "bad zip: local file header offset >= central directory offset"

    .line 663
    .line 664
    invoke-direct {v0, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 665
    .line 666
    .line 667
    throw v0
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_7

    .line 668
    :cond_11
    :try_start_e
    invoke-virtual {v5}, Lt7/a0;->close()V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_8

    .line 669
    .line 670
    .line 671
    const/4 v0, 0x0

    .line 672
    goto :goto_16

    .line 673
    :catchall_8
    move-exception v0

    .line 674
    goto :goto_16

    .line 675
    :goto_14
    :try_start_f
    invoke-virtual {v5}, Lt7/a0;->close()V
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_9

    .line 676
    .line 677
    .line 678
    goto :goto_15

    .line 679
    :catchall_9
    move-exception v0

    .line 680
    :try_start_10
    invoke-static {v4, v0}, Lo2/b;->c(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 681
    .line 682
    .line 683
    :goto_15
    move-object v0, v4

    .line 684
    :goto_16
    if-nez v0, :cond_13

    .line 685
    .line 686
    invoke-static {v3}, Lu7/b;->b(Ljava/util/ArrayList;)Ljava/util/LinkedHashMap;

    .line 687
    .line 688
    .line 689
    move-result-object v0

    .line 690
    new-instance v3, Lt7/j0;

    .line 691
    .line 692
    invoke-direct {v3, v12, v2, v0}, Lt7/j0;-><init>(Lt7/x;Lt7/t;Ljava/util/LinkedHashMap;)V
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_6

    .line 693
    .line 694
    .line 695
    :try_start_11
    invoke-virtual {v13}, Lt7/s;->close()V
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_a

    .line 696
    .line 697
    .line 698
    :catchall_a
    sget-object v0, Lu7/h;->q:Lt7/x;

    .line 699
    .line 700
    new-instance v4, Lv5/e;

    .line 701
    .line 702
    invoke-direct {v4, v3, v0}, Lv5/e;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 703
    .line 704
    .line 705
    move-object v10, v4

    .line 706
    :goto_17
    if-eqz v10, :cond_12

    .line 707
    .line 708
    invoke-virtual {v7, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 709
    .line 710
    .line 711
    :cond_12
    move/from16 v3, v16

    .line 712
    .line 713
    move-object/from16 v5, v18

    .line 714
    .line 715
    move/from16 v11, v28

    .line 716
    .line 717
    move/from16 v9, v30

    .line 718
    .line 719
    const/4 v4, -0x1

    .line 720
    goto/16 :goto_4

    .line 721
    .line 722
    :cond_13
    :try_start_12
    throw v0
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_6

    .line 723
    :catchall_b
    move-exception v0

    .line 724
    goto :goto_18

    .line 725
    :cond_14
    :try_start_13
    new-instance v0, Ljava/io/IOException;

    .line 726
    .line 727
    invoke-direct {v0, v9}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 728
    .line 729
    .line 730
    throw v0
    :try_end_13
    .catchall {:try_start_13 .. :try_end_13} :catchall_b

    .line 731
    :cond_15
    move/from16 v28, v5

    .line 732
    .line 733
    move/from16 v30, v9

    .line 734
    .line 735
    :try_start_14
    invoke-virtual {v3}, Lt7/a0;->close()V

    .line 736
    .line 737
    .line 738
    const-wide/16 v3, -0x1

    .line 739
    .line 740
    add-long/2addr v14, v3

    .line 741
    cmp-long v0, v14, v10

    .line 742
    .line 743
    if-ltz v0, :cond_16

    .line 744
    .line 745
    move-wide/from16 v3, v19

    .line 746
    .line 747
    move/from16 v5, v28

    .line 748
    .line 749
    move/from16 v9, v30

    .line 750
    .line 751
    goto/16 :goto_7

    .line 752
    .line 753
    :cond_16
    new-instance v0, Ljava/io/IOException;

    .line 754
    .line 755
    const-string v2, "not a zip: end of central directory signature not found"

    .line 756
    .line 757
    invoke-direct {v0, v2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 758
    .line 759
    .line 760
    throw v0

    .line 761
    :goto_18
    invoke-virtual {v3}, Lt7/a0;->close()V

    .line 762
    .line 763
    .line 764
    throw v0

    .line 765
    :cond_17
    new-instance v2, Ljava/io/IOException;

    .line 766
    .line 767
    new-instance v3, Ljava/lang/StringBuilder;

    .line 768
    .line 769
    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 770
    .line 771
    .line 772
    invoke-virtual {v13}, Lt7/s;->size()J

    .line 773
    .line 774
    .line 775
    move-result-wide v4

    .line 776
    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 777
    .line 778
    .line 779
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 780
    .line 781
    .line 782
    move-result-object v0

    .line 783
    invoke-direct {v2, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 784
    .line 785
    .line 786
    throw v2
    :try_end_14
    .catchall {:try_start_14 .. :try_end_14} :catchall_6

    .line 787
    :goto_19
    :try_start_15
    invoke-virtual {v13}, Lt7/s;->close()V
    :try_end_15
    .catchall {:try_start_15 .. :try_end_15} :catchall_c

    .line 788
    .line 789
    .line 790
    goto :goto_1a

    .line 791
    :catchall_c
    move-exception v0

    .line 792
    invoke-static {v2, v0}, Lo2/b;->c(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 793
    .line 794
    .line 795
    :goto_1a
    throw v2

    .line 796
    :cond_18
    invoke-static {v6, v7}, Lw5/j;->d0(Ljava/util/Collection;Ljava/lang/Iterable;)Ljava/util/ArrayList;

    .line 797
    .line 798
    .line 799
    move-result-object v0

    .line 800
    return-object v0

    .line 801
    :pswitch_4
    check-cast v11, Ljava/lang/String;

    .line 802
    .line 803
    new-instance v0, Lp1/q;

    .line 804
    .line 805
    const/4 v2, 0x0

    .line 806
    invoke-direct {v0, v11, v2, v2}, Lp1/q;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 807
    .line 808
    .line 809
    return-object v0

    .line 810
    :pswitch_5
    check-cast v11, Landroidx/navigation/fragment/NavHostFragment;

    .line 811
    .line 812
    iget-object v0, v11, Lh1/y;->H:Lh1/a0;

    .line 813
    .line 814
    if-nez v0, :cond_19

    .line 815
    .line 816
    const/4 v0, 0x0

    .line 817
    goto :goto_1b

    .line 818
    :cond_19
    iget-object v0, v0, Lh1/a0;->n:Lh/i;

    .line 819
    .line 820
    :goto_1b
    if-eqz v0, :cond_32

    .line 821
    .line 822
    new-instance v3, Lp1/z;

    .line 823
    .line 824
    invoke-direct {v3, v0}, Lp1/z;-><init>(Landroid/content/Context;)V

    .line 825
    .line 826
    .line 827
    iget-object v4, v3, Lp1/z;->b:Ls1/h;

    .line 828
    .line 829
    iget-object v6, v4, Ls1/h;->q:Ld2/a;

    .line 830
    .line 831
    iget-object v8, v4, Ls1/h;->r:Lp1/m0;

    .line 832
    .line 833
    iget-object v10, v4, Ls1/h;->m:Lk1/p;

    .line 834
    .line 835
    invoke-virtual {v11, v10}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 836
    .line 837
    .line 838
    move-result v10

    .line 839
    if-eqz v10, :cond_1a

    .line 840
    .line 841
    goto :goto_1c

    .line 842
    :cond_1a
    iget-object v10, v4, Ls1/h;->m:Lk1/p;

    .line 843
    .line 844
    if-eqz v10, :cond_1b

    .line 845
    .line 846
    invoke-interface {v10}, Lk1/p;->i()Lk1/r;

    .line 847
    .line 848
    .line 849
    move-result-object v10

    .line 850
    if-eqz v10, :cond_1b

    .line 851
    .line 852
    invoke-virtual {v10, v6}, Lk1/r;->f(Lk1/o;)V

    .line 853
    .line 854
    .line 855
    :cond_1b
    iput-object v11, v4, Ls1/h;->m:Lk1/p;

    .line 856
    .line 857
    iget-object v10, v11, Lh1/y;->b0:Lk1/r;

    .line 858
    .line 859
    invoke-virtual {v10, v6}, Lk1/r;->a(Lk1/o;)V

    .line 860
    .line 861
    .line 862
    :goto_1c
    invoke-virtual {v11}, Lh1/y;->h()Lk1/p0;

    .line 863
    .line 864
    .line 865
    move-result-object v6

    .line 866
    iget-object v10, v4, Ls1/h;->n:Lp1/l;

    .line 867
    .line 868
    invoke-static {v6}, Lo/r3;->t(Lk1/p0;)Lp1/l;

    .line 869
    .line 870
    .line 871
    move-result-object v12

    .line 872
    invoke-static {v10, v12}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 873
    .line 874
    .line 875
    move-result v10

    .line 876
    if-eqz v10, :cond_1c

    .line 877
    .line 878
    goto :goto_1d

    .line 879
    :cond_1c
    iget-object v10, v4, Ls1/h;->f:Lw5/h;

    .line 880
    .line 881
    invoke-virtual {v10}, Lw5/h;->isEmpty()Z

    .line 882
    .line 883
    .line 884
    move-result v10

    .line 885
    if-eqz v10, :cond_31

    .line 886
    .line 887
    invoke-static {v6}, Lo/r3;->t(Lk1/p0;)Lp1/l;

    .line 888
    .line 889
    .line 890
    move-result-object v6

    .line 891
    iput-object v6, v4, Ls1/h;->n:Lp1/l;

    .line 892
    .line 893
    :goto_1d
    new-instance v6, Lr1/d;

    .line 894
    .line 895
    invoke-virtual {v11}, Lh1/y;->L()Landroid/content/Context;

    .line 896
    .line 897
    .line 898
    move-result-object v10

    .line 899
    invoke-virtual {v11}, Lh1/y;->m()Lh1/q0;

    .line 900
    .line 901
    .line 902
    move-result-object v12

    .line 903
    invoke-direct {v6, v10, v12}, Lr1/d;-><init>(Landroid/content/Context;Lh1/q0;)V

    .line 904
    .line 905
    .line 906
    invoke-virtual {v8, v6}, Lp1/m0;->a(Lp1/l0;)V

    .line 907
    .line 908
    .line 909
    new-instance v6, Lr1/g;

    .line 910
    .line 911
    invoke-virtual {v11}, Lh1/y;->L()Landroid/content/Context;

    .line 912
    .line 913
    .line 914
    move-result-object v10

    .line 915
    invoke-virtual {v11}, Lh1/y;->m()Lh1/q0;

    .line 916
    .line 917
    .line 918
    move-result-object v12

    .line 919
    iget v13, v11, Lh1/y;->K:I

    .line 920
    .line 921
    if-eqz v13, :cond_1d

    .line 922
    .line 923
    const/4 v14, -0x1

    .line 924
    if-eq v13, v14, :cond_1d

    .line 925
    .line 926
    goto :goto_1e

    .line 927
    :cond_1d
    const v13, 0x7f0901ad

    .line 928
    .line 929
    .line 930
    :goto_1e
    invoke-direct {v6, v10, v12, v13}, Lr1/g;-><init>(Landroid/content/Context;Lh1/q0;I)V

    .line 931
    .line 932
    .line 933
    invoke-virtual {v8, v6}, Lp1/m0;->a(Lp1/l0;)V

    .line 934
    .line 935
    .line 936
    iget-object v6, v11, Lh1/y;->e0:Laa/e;

    .line 937
    .line 938
    iget-object v6, v6, Laa/e;->o:Ljava/lang/Object;

    .line 939
    .line 940
    check-cast v6, Laa/e;

    .line 941
    .line 942
    const-string v8, "android-support-nav:fragment:navControllerState"

    .line 943
    .line 944
    invoke-virtual {v6, v8}, Laa/e;->r(Ljava/lang/String;)Landroid/os/Bundle;

    .line 945
    .line 946
    .line 947
    move-result-object v6

    .line 948
    if-eqz v6, :cond_2b

    .line 949
    .line 950
    invoke-virtual {v0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    .line 951
    .line 952
    .line 953
    move-result-object v0

    .line 954
    invoke-virtual {v6, v0}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    .line 955
    .line 956
    .line 957
    iget-object v0, v4, Ls1/h;->l:Ljava/util/LinkedHashMap;

    .line 958
    .line 959
    const-string v10, "android-support-nav:controller:navigatorState"

    .line 960
    .line 961
    invoke-virtual {v6, v10}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 962
    .line 963
    .line 964
    move-result v12

    .line 965
    if-eqz v12, :cond_1f

    .line 966
    .line 967
    invoke-virtual {v6, v10}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 968
    .line 969
    .line 970
    move-result-object v12

    .line 971
    if-eqz v12, :cond_1e

    .line 972
    .line 973
    goto :goto_1f

    .line 974
    :cond_1e
    invoke-static {v10}, La/a;->K(Ljava/lang/String;)V

    .line 975
    .line 976
    .line 977
    const/16 v21, 0x0

    .line 978
    .line 979
    throw v21

    .line 980
    :cond_1f
    const/4 v12, 0x0

    .line 981
    :goto_1f
    iput-object v12, v4, Ls1/h;->d:Landroid/os/Bundle;

    .line 982
    .line 983
    const-string v10, "android-support-nav:controller:backStack"

    .line 984
    .line 985
    invoke-virtual {v6, v10}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 986
    .line 987
    .line 988
    move-result v12

    .line 989
    if-eqz v12, :cond_20

    .line 990
    .line 991
    invoke-static {v10, v6}, Lx1/r;->z(Ljava/lang/String;Landroid/os/Bundle;)Ljava/util/ArrayList;

    .line 992
    .line 993
    .line 994
    move-result-object v10

    .line 995
    new-array v12, v9, [Landroid/os/Bundle;

    .line 996
    .line 997
    invoke-interface {v10, v12}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 998
    .line 999
    .line 1000
    move-result-object v10

    .line 1001
    check-cast v10, [Landroid/os/Bundle;

    .line 1002
    .line 1003
    goto :goto_20

    .line 1004
    :cond_20
    const/4 v10, 0x0

    .line 1005
    :goto_20
    iput-object v10, v4, Ls1/h;->e:[Landroid/os/Bundle;

    .line 1006
    .line 1007
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->clear()V

    .line 1008
    .line 1009
    .line 1010
    const-string v10, "android-support-nav:controller:backStackDestIds"

    .line 1011
    .line 1012
    invoke-virtual {v6, v10}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 1013
    .line 1014
    .line 1015
    move-result v12

    .line 1016
    if-eqz v12, :cond_24

    .line 1017
    .line 1018
    const-string v12, "android-support-nav:controller:backStackIds"

    .line 1019
    .line 1020
    invoke-virtual {v6, v12}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 1021
    .line 1022
    .line 1023
    move-result v13

    .line 1024
    if-eqz v13, :cond_24

    .line 1025
    .line 1026
    invoke-virtual {v6, v10}, Landroid/os/BaseBundle;->getIntArray(Ljava/lang/String;)[I

    .line 1027
    .line 1028
    .line 1029
    move-result-object v13

    .line 1030
    if-eqz v13, :cond_23

    .line 1031
    .line 1032
    invoke-virtual {v6, v12}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 1033
    .line 1034
    .line 1035
    move-result-object v10

    .line 1036
    if-eqz v10, :cond_22

    .line 1037
    .line 1038
    array-length v12, v13

    .line 1039
    move v14, v9

    .line 1040
    move v15, v14

    .line 1041
    :goto_21
    if-ge v14, v12, :cond_24

    .line 1042
    .line 1043
    aget v16, v13, v14

    .line 1044
    .line 1045
    add-int/lit8 v17, v15, 0x1

    .line 1046
    .line 1047
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1048
    .line 1049
    .line 1050
    move-result-object v2

    .line 1051
    iget-object v7, v4, Ls1/h;->k:Ljava/util/LinkedHashMap;

    .line 1052
    .line 1053
    invoke-interface {v10, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1054
    .line 1055
    .line 1056
    move-result-object v9

    .line 1057
    invoke-static {v9, v5}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1058
    .line 1059
    .line 1060
    move-result v9

    .line 1061
    if-nez v9, :cond_21

    .line 1062
    .line 1063
    invoke-interface {v10, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1064
    .line 1065
    .line 1066
    move-result-object v9

    .line 1067
    check-cast v9, Ljava/lang/String;

    .line 1068
    .line 1069
    goto :goto_22

    .line 1070
    :cond_21
    const/4 v9, 0x0

    .line 1071
    :goto_22
    invoke-interface {v7, v2, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1072
    .line 1073
    .line 1074
    add-int/lit8 v14, v14, 0x1

    .line 1075
    .line 1076
    move/from16 v15, v17

    .line 1077
    .line 1078
    const/4 v9, 0x0

    .line 1079
    goto :goto_21

    .line 1080
    :cond_22
    invoke-static {v12}, La/a;->K(Ljava/lang/String;)V

    .line 1081
    .line 1082
    .line 1083
    const/16 v21, 0x0

    .line 1084
    .line 1085
    throw v21

    .line 1086
    :cond_23
    const/16 v21, 0x0

    .line 1087
    .line 1088
    invoke-static {v10}, La/a;->K(Ljava/lang/String;)V

    .line 1089
    .line 1090
    .line 1091
    throw v21

    .line 1092
    :cond_24
    const-string v2, "android-support-nav:controller:backStackStates"

    .line 1093
    .line 1094
    invoke-virtual {v6, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 1095
    .line 1096
    .line 1097
    move-result v5

    .line 1098
    if-eqz v5, :cond_28

    .line 1099
    .line 1100
    invoke-virtual {v6, v2}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 1101
    .line 1102
    .line 1103
    move-result-object v5

    .line 1104
    if-eqz v5, :cond_27

    .line 1105
    .line 1106
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 1107
    .line 1108
    .line 1109
    move-result v2

    .line 1110
    const/4 v7, 0x0

    .line 1111
    :goto_23
    if-ge v7, v2, :cond_28

    .line 1112
    .line 1113
    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1114
    .line 1115
    .line 1116
    move-result-object v9

    .line 1117
    add-int/lit8 v7, v7, 0x1

    .line 1118
    .line 1119
    check-cast v9, Ljava/lang/String;

    .line 1120
    .line 1121
    new-instance v10, Ljava/lang/StringBuilder;

    .line 1122
    .line 1123
    const-string v12, "android-support-nav:controller:backStackStates:"

    .line 1124
    .line 1125
    invoke-direct {v10, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1126
    .line 1127
    .line 1128
    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1129
    .line 1130
    .line 1131
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1132
    .line 1133
    .line 1134
    move-result-object v10

    .line 1135
    invoke-virtual {v6, v10}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 1136
    .line 1137
    .line 1138
    move-result v10

    .line 1139
    if-eqz v10, :cond_26

    .line 1140
    .line 1141
    new-instance v10, Ljava/lang/StringBuilder;

    .line 1142
    .line 1143
    invoke-direct {v10, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1144
    .line 1145
    .line 1146
    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1147
    .line 1148
    .line 1149
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1150
    .line 1151
    .line 1152
    move-result-object v10

    .line 1153
    invoke-static {v10, v6}, Lx1/r;->z(Ljava/lang/String;Landroid/os/Bundle;)Ljava/util/ArrayList;

    .line 1154
    .line 1155
    .line 1156
    move-result-object v10

    .line 1157
    new-instance v12, Lw5/h;

    .line 1158
    .line 1159
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 1160
    .line 1161
    .line 1162
    move-result v13

    .line 1163
    invoke-direct {v12, v13}, Lw5/h;-><init>(I)V

    .line 1164
    .line 1165
    .line 1166
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 1167
    .line 1168
    .line 1169
    move-result v13

    .line 1170
    const/4 v14, 0x0

    .line 1171
    :goto_24
    if-ge v14, v13, :cond_25

    .line 1172
    .line 1173
    invoke-virtual {v10, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1174
    .line 1175
    .line 1176
    move-result-object v15

    .line 1177
    add-int/lit8 v14, v14, 0x1

    .line 1178
    .line 1179
    check-cast v15, Landroid/os/Bundle;

    .line 1180
    .line 1181
    new-instance v1, Lp1/i;

    .line 1182
    .line 1183
    invoke-direct {v1, v15}, Lp1/i;-><init>(Landroid/os/Bundle;)V

    .line 1184
    .line 1185
    .line 1186
    invoke-virtual {v12, v1}, Lw5/h;->addLast(Ljava/lang/Object;)V

    .line 1187
    .line 1188
    .line 1189
    move-object/from16 v1, p0

    .line 1190
    .line 1191
    goto :goto_24

    .line 1192
    :cond_25
    invoke-interface {v0, v9, v12}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1193
    .line 1194
    .line 1195
    :cond_26
    move-object/from16 v1, p0

    .line 1196
    .line 1197
    goto :goto_23

    .line 1198
    :cond_27
    invoke-static {v2}, La/a;->K(Ljava/lang/String;)V

    .line 1199
    .line 1200
    .line 1201
    const/16 v21, 0x0

    .line 1202
    .line 1203
    throw v21

    .line 1204
    :cond_28
    const-string v0, "android-support-nav:controller:deepLinkHandled"

    .line 1205
    .line 1206
    const/4 v1, 0x0

    .line 1207
    invoke-virtual {v6, v0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    .line 1208
    .line 1209
    .line 1210
    move-result v2

    .line 1211
    if-nez v2, :cond_29

    .line 1212
    .line 1213
    const/4 v1, 0x1

    .line 1214
    invoke-virtual {v6, v0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    .line 1215
    .line 1216
    .line 1217
    move-result v0

    .line 1218
    if-ne v0, v1, :cond_29

    .line 1219
    .line 1220
    const/4 v0, 0x0

    .line 1221
    goto :goto_25

    .line 1222
    :cond_29
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1223
    .line 1224
    .line 1225
    move-result-object v0

    .line 1226
    :goto_25
    if-eqz v0, :cond_2a

    .line 1227
    .line 1228
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1229
    .line 1230
    .line 1231
    move-result v0

    .line 1232
    goto :goto_26

    .line 1233
    :cond_2a
    const/4 v0, 0x0

    .line 1234
    :goto_26
    iput-boolean v0, v3, Lp1/z;->e:Z

    .line 1235
    .line 1236
    :cond_2b
    iget-object v0, v11, Lh1/y;->e0:Laa/e;

    .line 1237
    .line 1238
    iget-object v0, v0, Laa/e;->o:Ljava/lang/Object;

    .line 1239
    .line 1240
    check-cast v0, Laa/e;

    .line 1241
    .line 1242
    new-instance v1, Lh1/f0;

    .line 1243
    .line 1244
    const/4 v2, 0x2

    .line 1245
    invoke-direct {v1, v2, v3}, Lh1/f0;-><init>(ILjava/lang/Object;)V

    .line 1246
    .line 1247
    .line 1248
    invoke-virtual {v0, v8, v1}, Laa/e;->R(Ljava/lang/String;Lc2/d;)V

    .line 1249
    .line 1250
    .line 1251
    iget-object v0, v11, Lh1/y;->e0:Laa/e;

    .line 1252
    .line 1253
    iget-object v0, v0, Laa/e;->o:Ljava/lang/Object;

    .line 1254
    .line 1255
    check-cast v0, Laa/e;

    .line 1256
    .line 1257
    const-string v1, "android-support-nav:fragment:graphId"

    .line 1258
    .line 1259
    invoke-virtual {v0, v1}, Laa/e;->r(Ljava/lang/String;)Landroid/os/Bundle;

    .line 1260
    .line 1261
    .line 1262
    move-result-object v0

    .line 1263
    if-eqz v0, :cond_2c

    .line 1264
    .line 1265
    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 1266
    .line 1267
    .line 1268
    move-result v0

    .line 1269
    iput v0, v11, Landroidx/navigation/fragment/NavHostFragment;->k0:I

    .line 1270
    .line 1271
    :cond_2c
    iget-object v0, v11, Lh1/y;->e0:Laa/e;

    .line 1272
    .line 1273
    iget-object v0, v0, Laa/e;->o:Ljava/lang/Object;

    .line 1274
    .line 1275
    check-cast v0, Laa/e;

    .line 1276
    .line 1277
    new-instance v2, Lh1/f0;

    .line 1278
    .line 1279
    const/4 v5, 0x3

    .line 1280
    invoke-direct {v2, v5, v11}, Lh1/f0;-><init>(ILjava/lang/Object;)V

    .line 1281
    .line 1282
    .line 1283
    invoke-virtual {v0, v1, v2}, Laa/e;->R(Ljava/lang/String;Lc2/d;)V

    .line 1284
    .line 1285
    .line 1286
    iget v0, v11, Landroidx/navigation/fragment/NavHostFragment;->k0:I

    .line 1287
    .line 1288
    iget-object v2, v3, Lp1/z;->h:Lv5/i;

    .line 1289
    .line 1290
    if-eqz v0, :cond_2e

    .line 1291
    .line 1292
    invoke-virtual {v2}, Lv5/i;->getValue()Ljava/lang/Object;

    .line 1293
    .line 1294
    .line 1295
    move-result-object v1

    .line 1296
    check-cast v1, Lp1/a0;

    .line 1297
    .line 1298
    invoke-virtual {v1, v0}, Lp1/a0;->b(I)Lp1/x;

    .line 1299
    .line 1300
    .line 1301
    move-result-object v0

    .line 1302
    const/4 v2, 0x0

    .line 1303
    invoke-virtual {v4, v0, v2}, Ls1/h;->o(Lp1/x;Landroid/os/Bundle;)V

    .line 1304
    .line 1305
    .line 1306
    :cond_2d
    :goto_27
    move-object v10, v3

    .line 1307
    goto :goto_2b

    .line 1308
    :cond_2e
    iget-object v0, v11, Lh1/y;->r:Landroid/os/Bundle;

    .line 1309
    .line 1310
    if-eqz v0, :cond_2f

    .line 1311
    .line 1312
    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 1313
    .line 1314
    .line 1315
    move-result v9

    .line 1316
    goto :goto_28

    .line 1317
    :cond_2f
    const/4 v9, 0x0

    .line 1318
    :goto_28
    if-eqz v0, :cond_30

    .line 1319
    .line 1320
    const-string v1, "android-support-nav:fragment:startDestinationArgs"

    .line 1321
    .line 1322
    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    .line 1323
    .line 1324
    .line 1325
    move-result-object v10

    .line 1326
    goto :goto_29

    .line 1327
    :cond_30
    const/4 v10, 0x0

    .line 1328
    :goto_29
    if-eqz v9, :cond_2d

    .line 1329
    .line 1330
    invoke-virtual {v2}, Lv5/i;->getValue()Ljava/lang/Object;

    .line 1331
    .line 1332
    .line 1333
    move-result-object v0

    .line 1334
    check-cast v0, Lp1/a0;

    .line 1335
    .line 1336
    invoke-virtual {v0, v9}, Lp1/a0;->b(I)Lp1/x;

    .line 1337
    .line 1338
    .line 1339
    move-result-object v0

    .line 1340
    invoke-virtual {v4, v0, v10}, Ls1/h;->o(Lp1/x;Landroid/os/Bundle;)V

    .line 1341
    .line 1342
    .line 1343
    goto :goto_27

    .line 1344
    :cond_31
    const-string v0, "ViewModelStore should be set before setGraph call"

    .line 1345
    .line 1346
    invoke-static {v0}, Lq0/b;->m(Ljava/lang/String;)V

    .line 1347
    .line 1348
    .line 1349
    :goto_2a
    const/4 v10, 0x0

    .line 1350
    goto :goto_2b

    .line 1351
    :cond_32
    const-string v0, "NavController cannot be created before the fragment is attached"

    .line 1352
    .line 1353
    invoke-static {v0}, Lq0/b;->m(Ljava/lang/String;)V

    .line 1354
    .line 1355
    .line 1356
    goto :goto_2a

    .line 1357
    :goto_2b
    return-object v10

    .line 1358
    :pswitch_6
    return-object v11

    .line 1359
    :pswitch_7
    check-cast v11, Lp4/d1;

    .line 1360
    .line 1361
    new-instance v0, Lp4/b1;

    .line 1362
    .line 1363
    invoke-direct {v0, v11}, Lp4/b1;-><init>(Lp4/d1;)V

    .line 1364
    .line 1365
    .line 1366
    return-object v0

    .line 1367
    :pswitch_8
    check-cast v11, Landroidx/recyclerview/widget/RecyclerView;

    .line 1368
    .line 1369
    invoke-static {v11}, Lo3/b;->S(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 1370
    .line 1371
    .line 1372
    return-object v6

    .line 1373
    :pswitch_9
    check-cast v11, Lk7/o;

    .line 1374
    .line 1375
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1376
    .line 1377
    .line 1378
    :try_start_16
    iget-object v0, v11, Lk7/o;->I:Lk7/x;
    :try_end_16
    .catch Ljava/io/IOException; {:try_start_16 .. :try_end_16} :catch_1

    .line 1379
    .line 1380
    const/4 v1, 0x0

    .line 1381
    const/4 v2, 0x2

    .line 1382
    :try_start_17
    invoke-virtual {v0, v2, v1, v1}, Lk7/x;->H(IIZ)V
    :try_end_17
    .catch Ljava/io/IOException; {:try_start_17 .. :try_end_17} :catch_0

    .line 1383
    .line 1384
    .line 1385
    goto :goto_2d

    .line 1386
    :catch_0
    move-exception v0

    .line 1387
    goto :goto_2c

    .line 1388
    :catch_1
    move-exception v0

    .line 1389
    const/4 v2, 0x2

    .line 1390
    :goto_2c
    invoke-virtual {v11, v2, v2, v0}, Lk7/o;->f(IILjava/io/IOException;)V

    .line 1391
    .line 1392
    .line 1393
    :goto_2d
    return-object v6

    .line 1394
    :pswitch_a
    check-cast v11, Lk1/q0;

    .line 1395
    .line 1396
    invoke-static {v11}, Lk1/g0;->e(Lk1/q0;)Lk1/i0;

    .line 1397
    .line 1398
    .line 1399
    move-result-object v0

    .line 1400
    return-object v0

    .line 1401
    :pswitch_b
    check-cast v11, Lg2/g;

    .line 1402
    .line 1403
    new-instance v0, Lg2/f;

    .line 1404
    .line 1405
    iget-object v1, v11, Lg2/g;->m:Landroid/content/Context;

    .line 1406
    .line 1407
    iget-object v2, v11, Lg2/g;->n:Ljava/lang/String;

    .line 1408
    .line 1409
    new-instance v3, Laa/b;

    .line 1410
    .line 1411
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 1412
    .line 1413
    .line 1414
    const/4 v4, 0x0

    .line 1415
    iput-object v4, v3, Laa/b;->m:Ljava/lang/Object;

    .line 1416
    .line 1417
    iget-object v4, v11, Lg2/g;->o:Lca/a;

    .line 1418
    .line 1419
    invoke-direct {v0, v1, v2, v3, v4}, Lg2/f;-><init>(Landroid/content/Context;Ljava/lang/String;Laa/b;Lca/a;)V

    .line 1420
    .line 1421
    .line 1422
    iget-boolean v1, v11, Lg2/g;->q:Z

    .line 1423
    .line 1424
    invoke-virtual {v0, v1}, Landroid/database/sqlite/SQLiteOpenHelper;->setWriteAheadLoggingEnabled(Z)V

    .line 1425
    .line 1426
    .line 1427
    return-object v0

    .line 1428
    :pswitch_c
    check-cast v11, Lq4/h;

    .line 1429
    .line 1430
    invoke-virtual {v11}, Lq4/h;->f()Ljava/lang/String;

    .line 1431
    .line 1432
    .line 1433
    move-result-object v0

    .line 1434
    invoke-static {v0}, Lb3/c;->c(Ljava/lang/String;)Lo4/n;

    .line 1435
    .line 1436
    .line 1437
    move-result-object v0

    .line 1438
    invoke-interface {v0}, Lo4/n;->a()Landroid/net/Uri;

    .line 1439
    .line 1440
    .line 1441
    move-result-object v0

    .line 1442
    return-object v0

    .line 1443
    :pswitch_d
    check-cast v11, Lf4/j;

    .line 1444
    .line 1445
    invoke-virtual {v11}, Lf4/j;->f()Ljava/lang/String;

    .line 1446
    .line 1447
    .line 1448
    move-result-object v0

    .line 1449
    const-string v1, ".apk"

    .line 1450
    .line 1451
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 1452
    .line 1453
    .line 1454
    move-result-object v0

    .line 1455
    invoke-static {v0}, Lb3/c;->c(Ljava/lang/String;)Lo4/n;

    .line 1456
    .line 1457
    .line 1458
    move-result-object v0

    .line 1459
    invoke-interface {v0}, Lo4/n;->a()Landroid/net/Uri;

    .line 1460
    .line 1461
    .line 1462
    move-result-object v0

    .line 1463
    return-object v0

    .line 1464
    :pswitch_e
    move/from16 v16, v3

    .line 1465
    .line 1466
    check-cast v11, Lc7/c0;

    .line 1467
    .line 1468
    new-instance v0, Lc7/v;

    .line 1469
    .line 1470
    invoke-direct {v0}, Lc7/v;-><init>()V

    .line 1471
    .line 1472
    .line 1473
    const-string v1, "https://cloudflare-dns.com/dns-query"

    .line 1474
    .line 1475
    const/4 v2, 0x0

    .line 1476
    invoke-virtual {v0, v2, v1}, Lc7/v;->d(Lc7/w;Ljava/lang/String;)V

    .line 1477
    .line 1478
    .line 1479
    invoke-virtual {v0}, Lc7/v;->b()Lc7/w;

    .line 1480
    .line 1481
    .line 1482
    move-result-object v0

    .line 1483
    const-string v1, "162.159.36.1"

    .line 1484
    .line 1485
    invoke-static {v1}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 1486
    .line 1487
    .line 1488
    move-result-object v1

    .line 1489
    const-string v2, "162.159.46.1"

    .line 1490
    .line 1491
    invoke-static {v2}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 1492
    .line 1493
    .line 1494
    move-result-object v2

    .line 1495
    const-string v3, "1.1.1.1"

    .line 1496
    .line 1497
    invoke-static {v3}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 1498
    .line 1499
    .line 1500
    move-result-object v3

    .line 1501
    const-string v4, "1.0.0.1"

    .line 1502
    .line 1503
    invoke-static {v4}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 1504
    .line 1505
    .line 1506
    move-result-object v4

    .line 1507
    const-string v5, "2606:4700:4700::1111"

    .line 1508
    .line 1509
    invoke-static {v5}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 1510
    .line 1511
    .line 1512
    move-result-object v5

    .line 1513
    const-string v6, "2606:4700:4700::1001"

    .line 1514
    .line 1515
    invoke-static {v6}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 1516
    .line 1517
    .line 1518
    move-result-object v6

    .line 1519
    const-string v7, "2606:4700:4700::0064"

    .line 1520
    .line 1521
    invoke-static {v7}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 1522
    .line 1523
    .line 1524
    move-result-object v7

    .line 1525
    const-string v8, "2606:4700:4700::6400"

    .line 1526
    .line 1527
    invoke-static {v8}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    .line 1528
    .line 1529
    .line 1530
    move-result-object v8

    .line 1531
    const/16 v9, 0x8

    .line 1532
    .line 1533
    new-array v9, v9, [Ljava/net/InetAddress;

    .line 1534
    .line 1535
    const/16 v20, 0x0

    .line 1536
    .line 1537
    aput-object v1, v9, v20

    .line 1538
    .line 1539
    const/16 v29, 0x1

    .line 1540
    .line 1541
    aput-object v2, v9, v29

    .line 1542
    .line 1543
    const/16 v19, 0x2

    .line 1544
    .line 1545
    aput-object v3, v9, v19

    .line 1546
    .line 1547
    const/16 v18, 0x3

    .line 1548
    .line 1549
    aput-object v4, v9, v18

    .line 1550
    .line 1551
    aput-object v5, v9, v16

    .line 1552
    .line 1553
    const/4 v1, 0x5

    .line 1554
    aput-object v6, v9, v1

    .line 1555
    .line 1556
    const/4 v1, 0x6

    .line 1557
    aput-object v7, v9, v1

    .line 1558
    .line 1559
    const/4 v1, 0x7

    .line 1560
    aput-object v8, v9, v1

    .line 1561
    .line 1562
    invoke-static {v9}, Lw5/k;->L([Ljava/lang/Object;)Ljava/util/List;

    .line 1563
    .line 1564
    .line 1565
    move-result-object v2

    .line 1566
    new-instance v3, Lc7/b0;

    .line 1567
    .line 1568
    invoke-direct {v3}, Lc7/b0;-><init>()V

    .line 1569
    .line 1570
    .line 1571
    iget-object v4, v11, Lc7/c0;->a:Lc7/q;

    .line 1572
    .line 1573
    iput-object v4, v3, Lc7/b0;->a:Lc7/q;

    .line 1574
    .line 1575
    iget-object v4, v11, Lc7/c0;->D:Laa/b;

    .line 1576
    .line 1577
    iput-object v4, v3, Lc7/b0;->b:Laa/b;

    .line 1578
    .line 1579
    iget-object v4, v3, Lc7/b0;->c:Ljava/util/ArrayList;

    .line 1580
    .line 1581
    iget-object v5, v11, Lc7/c0;->b:Ljava/util/List;

    .line 1582
    .line 1583
    invoke-static {v5, v4}, Lw5/j;->S(Ljava/lang/Iterable;Ljava/util/AbstractCollection;)V

    .line 1584
    .line 1585
    .line 1586
    iget-object v4, v3, Lc7/b0;->d:Ljava/util/ArrayList;

    .line 1587
    .line 1588
    iget-object v5, v11, Lc7/c0;->c:Ljava/util/List;

    .line 1589
    .line 1590
    invoke-static {v5, v4}, Lw5/j;->S(Ljava/lang/Iterable;Ljava/util/AbstractCollection;)V

    .line 1591
    .line 1592
    .line 1593
    iget-object v4, v11, Lc7/c0;->d:La4/a;

    .line 1594
    .line 1595
    iput-object v4, v3, Lc7/b0;->e:La4/a;

    .line 1596
    .line 1597
    iget-boolean v4, v11, Lc7/c0;->e:Z

    .line 1598
    .line 1599
    iput-boolean v4, v3, Lc7/b0;->f:Z

    .line 1600
    .line 1601
    iget-boolean v4, v11, Lc7/c0;->f:Z

    .line 1602
    .line 1603
    iput-boolean v4, v3, Lc7/b0;->g:Z

    .line 1604
    .line 1605
    iget-object v4, v11, Lc7/c0;->g:Lc7/b;

    .line 1606
    .line 1607
    iput-object v4, v3, Lc7/b0;->h:Lc7/b;

    .line 1608
    .line 1609
    iget-boolean v4, v11, Lc7/c0;->h:Z

    .line 1610
    .line 1611
    iput-boolean v4, v3, Lc7/b0;->i:Z

    .line 1612
    .line 1613
    iget-boolean v4, v11, Lc7/c0;->i:Z

    .line 1614
    .line 1615
    iput-boolean v4, v3, Lc7/b0;->j:Z

    .line 1616
    .line 1617
    iget-object v4, v11, Lc7/c0;->j:Lc7/b;

    .line 1618
    .line 1619
    iput-object v4, v3, Lc7/b0;->k:Lc7/b;

    .line 1620
    .line 1621
    iget-object v4, v11, Lc7/c0;->k:Lc7/h;

    .line 1622
    .line 1623
    iput-object v4, v3, Lc7/b0;->l:Lc7/h;

    .line 1624
    .line 1625
    iget-object v4, v11, Lc7/c0;->l:Lc7/r;

    .line 1626
    .line 1627
    iput-object v4, v3, Lc7/b0;->m:Lc7/r;

    .line 1628
    .line 1629
    iget-object v5, v11, Lc7/c0;->m:Ljava/net/ProxySelector;

    .line 1630
    .line 1631
    iput-object v5, v3, Lc7/b0;->n:Ljava/net/ProxySelector;

    .line 1632
    .line 1633
    iget-object v5, v11, Lc7/c0;->n:Lc7/b;

    .line 1634
    .line 1635
    iput-object v5, v3, Lc7/b0;->o:Lc7/b;

    .line 1636
    .line 1637
    iget-object v5, v11, Lc7/c0;->o:Ljavax/net/SocketFactory;

    .line 1638
    .line 1639
    iput-object v5, v3, Lc7/b0;->p:Ljavax/net/SocketFactory;

    .line 1640
    .line 1641
    iget-object v5, v11, Lc7/c0;->p:Ljavax/net/ssl/SSLSocketFactory;

    .line 1642
    .line 1643
    iput-object v5, v3, Lc7/b0;->q:Ljavax/net/ssl/SSLSocketFactory;

    .line 1644
    .line 1645
    iget-object v5, v11, Lc7/c0;->q:Ljavax/net/ssl/X509TrustManager;

    .line 1646
    .line 1647
    iput-object v5, v3, Lc7/b0;->r:Ljavax/net/ssl/X509TrustManager;

    .line 1648
    .line 1649
    iget-object v5, v11, Lc7/c0;->r:Ljava/util/List;

    .line 1650
    .line 1651
    iput-object v5, v3, Lc7/b0;->s:Ljava/util/List;

    .line 1652
    .line 1653
    iget-object v5, v11, Lc7/c0;->s:Ljava/util/List;

    .line 1654
    .line 1655
    iput-object v5, v3, Lc7/b0;->t:Ljava/util/List;

    .line 1656
    .line 1657
    iget-object v5, v11, Lc7/c0;->t:Lr7/c;

    .line 1658
    .line 1659
    iput-object v5, v3, Lc7/b0;->u:Lr7/c;

    .line 1660
    .line 1661
    iget-object v5, v11, Lc7/c0;->u:Lc7/k;

    .line 1662
    .line 1663
    iput-object v5, v3, Lc7/b0;->v:Lc7/k;

    .line 1664
    .line 1665
    iget-object v5, v11, Lc7/c0;->v:Lo2/b;

    .line 1666
    .line 1667
    iput-object v5, v3, Lc7/b0;->w:Lo2/b;

    .line 1668
    .line 1669
    iget v5, v11, Lc7/c0;->w:I

    .line 1670
    .line 1671
    iput v5, v3, Lc7/b0;->x:I

    .line 1672
    .line 1673
    iget v5, v11, Lc7/c0;->x:I

    .line 1674
    .line 1675
    iput v5, v3, Lc7/b0;->y:I

    .line 1676
    .line 1677
    iget v5, v11, Lc7/c0;->y:I

    .line 1678
    .line 1679
    iput v5, v3, Lc7/b0;->z:I

    .line 1680
    .line 1681
    iget v5, v11, Lc7/c0;->z:I

    .line 1682
    .line 1683
    iput v5, v3, Lc7/b0;->A:I

    .line 1684
    .line 1685
    iget-wide v5, v11, Lc7/c0;->A:J

    .line 1686
    .line 1687
    iput-wide v5, v3, Lc7/b0;->B:J

    .line 1688
    .line 1689
    iget-object v5, v11, Lc7/c0;->B:Laa/b;

    .line 1690
    .line 1691
    iput-object v5, v3, Lc7/b0;->C:Laa/b;

    .line 1692
    .line 1693
    iget-object v5, v11, Lc7/c0;->C:Lg7/c;

    .line 1694
    .line 1695
    iput-object v5, v3, Lc7/b0;->D:Lg7/c;

    .line 1696
    .line 1697
    sget-object v5, Ld7/a;->o:Lc7/y;

    .line 1698
    .line 1699
    new-instance v5, Laa/e;

    .line 1700
    .line 1701
    iget-object v6, v0, Lc7/w;->d:Ljava/lang/String;

    .line 1702
    .line 1703
    invoke-direct {v5, v1, v6, v2}, Laa/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 1704
    .line 1705
    .line 1706
    invoke-virtual {v5, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 1707
    .line 1708
    .line 1709
    move-result v1

    .line 1710
    if-nez v1, :cond_33

    .line 1711
    .line 1712
    const/4 v2, 0x0

    .line 1713
    iput-object v2, v3, Lc7/b0;->C:Laa/b;

    .line 1714
    .line 1715
    :cond_33
    iput-object v5, v3, Lc7/b0;->m:Lc7/r;

    .line 1716
    .line 1717
    new-instance v1, Lc7/c0;

    .line 1718
    .line 1719
    invoke-direct {v1, v3}, Lc7/c0;-><init>(Lc7/b0;)V

    .line 1720
    .line 1721
    .line 1722
    new-instance v2, Ld7/a;

    .line 1723
    .line 1724
    invoke-direct {v2, v1, v0}, Ld7/a;-><init>(Lc7/c0;Lc7/w;)V

    .line 1725
    .line 1726
    .line 1727
    return-object v2

    .line 1728
    :pswitch_f
    check-cast v11, Ld5/f;

    .line 1729
    .line 1730
    const/4 v2, 0x2

    .line 1731
    invoke-virtual {v11, v2}, Ld5/f;->p(I)V

    .line 1732
    .line 1733
    .line 1734
    return-object v6

    .line 1735
    :pswitch_10
    check-cast v11, Ljava/util/List;

    .line 1736
    .line 1737
    return-object v11

    .line 1738
    :pswitch_11
    check-cast v11, Lj6/a;

    .line 1739
    .line 1740
    :try_start_18
    invoke-interface {v11}, Lj6/a;->b()Ljava/lang/Object;

    .line 1741
    .line 1742
    .line 1743
    move-result-object v0

    .line 1744
    check-cast v0, Ljava/util/List;
    :try_end_18
    .catch Ljavax/net/ssl/SSLPeerUnverifiedException; {:try_start_18 .. :try_end_18} :catch_2

    .line 1745
    .line 1746
    goto :goto_2e

    .line 1747
    :catch_2
    sget-object v0, Lw5/q;->m:Lw5/q;

    .line 1748
    .line 1749
    :goto_2e
    return-object v0

    .line 1750
    :pswitch_12
    check-cast v11, Lcom/topjohnwu/magisk/core/data/SuLogDatabase_Impl;

    .line 1751
    .line 1752
    new-instance v0, Lc4/g;

    .line 1753
    .line 1754
    invoke-direct {v0, v11}, Lc4/g;-><init>(Lcom/topjohnwu/magisk/core/data/SuLogDatabase;)V

    .line 1755
    .line 1756
    .line 1757
    return-object v0

    .line 1758
    :pswitch_13
    check-cast v11, Lc2/e;

    .line 1759
    .line 1760
    invoke-interface {v11}, Lk1/p;->i()Lk1/r;

    .line 1761
    .line 1762
    .line 1763
    move-result-object v0

    .line 1764
    new-instance v1, Lc2/b;

    .line 1765
    .line 1766
    const/4 v2, 0x0

    .line 1767
    invoke-direct {v1, v2, v11}, Lc2/b;-><init>(ILjava/lang/Object;)V

    .line 1768
    .line 1769
    .line 1770
    invoke-virtual {v0, v1}, Lk1/r;->a(Lk1/o;)V

    .line 1771
    .line 1772
    .line 1773
    return-object v6

    .line 1774
    :pswitch_14
    check-cast v11, Lb/e0;

    .line 1775
    .line 1776
    new-instance v0, Lb/c0;

    .line 1777
    .line 1778
    invoke-direct {v0, v11}, Lb/c0;-><init>(Lb/e0;)V

    .line 1779
    .line 1780
    .line 1781
    return-object v0

    .line 1782
    nop

    .line 1783
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
    .line 2155
    .line 2156
    .line 2157
    .line 2158
    .line 2159
    .line 2160
    .line 2161
    .line 2162
    .line 2163
    .line 2164
    .line 2165
    .line 2166
    .line 2167
    .line 2168
    .line 2169
    .line 2170
    .line 2171
    .line 2172
    .line 2173
    .line 2174
    .line 2175
    .line 2176
    .line 2177
    .line 2178
    .line 2179
    .line 2180
    .line 2181
    .line 2182
    .line 2183
    .line 2184
    .line 2185
    .line 2186
    .line 2187
    .line 2188
    .line 2189
    .line 2190
    .line 2191
    .line 2192
    .line 2193
    .line 2194
    .line 2195
    .line 2196
    .line 2197
    .line 2198
    .line 2199
    .line 2200
    .line 2201
    .line 2202
    .line 2203
    .line 2204
    .line 2205
    .line 2206
    .line 2207
    .line 2208
    .line 2209
    .line 2210
    .line 2211
    .line 2212
    .line 2213
    .line 2214
    .line 2215
    .line 2216
    .line 2217
    .line 2218
    .line 2219
    .line 2220
    .line 2221
    .line 2222
    .line 2223
    .line 2224
    .line 2225
    .line 2226
    .line 2227
    .line 2228
    .line 2229
    .line 2230
    .line 2231
    .line 2232
    .line 2233
    .line 2234
    .line 2235
    .line 2236
    .line 2237
    .line 2238
    .line 2239
    .line 2240
    .line 2241
    .line 2242
    .line 2243
    .line 2244
    .line 2245
    .line 2246
    .line 2247
    .line 2248
    .line 2249
    .line 2250
    .line 2251
    .line 2252
    .line 2253
    .line 2254
    .line 2255
    .line 2256
    .line 2257
    .line 2258
    .line 2259
    .line 2260
    .line 2261
    .line 2262
    .line 2263
    .line 2264
    .line 2265
    .line 2266
    .line 2267
    .line 2268
    .line 2269
    .line 2270
    .line 2271
    .line 2272
    .line 2273
    .line 2274
    .line 2275
    .line 2276
    .line 2277
    .line 2278
    .line 2279
    .line 2280
    .line 2281
    .line 2282
    .line 2283
    .line 2284
    .line 2285
    .line 2286
    .line 2287
    .line 2288
    .line 2289
    .line 2290
    .line 2291
    .line 2292
    .line 2293
    .line 2294
    .line 2295
    .line 2296
    .line 2297
    .line 2298
    .line 2299
    .line 2300
    .line 2301
    .line 2302
    .line 2303
    .line 2304
    .line 2305
    .line 2306
    .line 2307
    .line 2308
    .line 2309
    .line 2310
    .line 2311
    .line 2312
    .line 2313
    .line 2314
.end method
