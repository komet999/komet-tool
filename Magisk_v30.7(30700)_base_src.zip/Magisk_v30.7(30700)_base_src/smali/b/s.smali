.class public final synthetic Lb/s;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Lj6/a;


# instance fields
.field public final synthetic m:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 9
    iput p1, p0, Lb/s;->m:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lx1/g;)V
    .locals 0

    .line 1
    const/16 p1, 0x17

    .line 2
    .line 3
    iput p1, p0, Lb/s;->m:I

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method


# virtual methods
.method public final b()Ljava/lang/Object;
    .locals 51

    move-object/from16 v1, p0

    iget v0, v1, Lb/s;->m:I

    const/16 v3, 0x2e

    const/16 v4, 0x19

    const/16 v5, 0xb

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    packed-switch v0, :pswitch_data_0

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object v0

    :pswitch_0
    sget-object v0, Lv5/k;->a:Lv5/k;

    return-object v0

    .line 1
    :pswitch_1
    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    .line 2
    new-instance v2, Lc4/e;

    invoke-direct {v2, v4}, Lc4/e;-><init>(I)V

    .line 3
    const-class v4, Ls1/b;

    invoke-static {v4}, Lk6/q;->a(Ljava/lang/Class;)Lk6/e;

    move-result-object v4

    .line 4
    invoke-interface {v0, v4}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_0

    .line 5
    new-instance v3, Lm1/e;

    invoke-direct {v3, v4, v2}, Lm1/e;-><init>(Lk6/e;Lj6/l;)V

    invoke-interface {v0, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    .line 7
    new-instance v12, Lm1/c;

    .line 8
    new-array v2, v11, [Lm1/e;

    invoke-interface {v0, v2}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    .line 9
    check-cast v0, [Lm1/e;

    array-length v2, v0

    invoke-static {v0, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lm1/e;

    invoke-direct {v12, v11, v0}, Lm1/c;-><init>(ILjava/lang/Object;)V

    goto :goto_0

    .line 10
    :cond_0
    const-string v0, "A `initializer` with the same `clazz` has already been added: "

    .line 11
    invoke-virtual {v4}, Lk6/e;->a()Ljava/lang/String;

    move-result-object v2

    .line 12
    invoke-static {v3, v2, v0}, La4/a;->h(ILjava/lang/Object;Ljava/lang/String;)V

    :goto_0
    return-object v12

    .line 13
    :pswitch_2
    new-instance v0, Lk1/j0;

    invoke-direct {v0}, Lk1/j0;-><init>()V

    return-object v0

    .line 14
    :pswitch_3
    sget-object v0, Lo4/j;->a:Lo4/j;

    .line 15
    sget-object v0, Lo4/j;->b:Lv5/i;

    invoke-virtual {v0}, Lv5/i;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lo4/h;

    .line 16
    sget-object v0, Lo4/j;->d:Lv5/i;

    invoke-virtual {v0}, Lv5/i;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 17
    new-instance v0, Lo4/g;

    invoke-direct {v0}, Lo4/g;-><init>()V

    goto :goto_1

    .line 18
    :cond_1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x17

    if-gt v0, v2, :cond_2

    .line 19
    new-instance v0, Lo4/e;

    invoke-direct {v0}, Lo4/e;-><init>()V

    goto :goto_1

    .line 20
    :cond_2
    new-instance v0, Lo4/f;

    invoke-direct {v0}, Lo4/f;-><init>()V

    :goto_1
    return-object v0

    .line 21
    :pswitch_4
    sget-object v0, Lo4/j;->a:Lo4/j;

    .line 22
    invoke-static {}, La4/f;->a()Z

    move-result v0

    if-eqz v0, :cond_3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x22

    if-lt v0, v2, :cond_4

    goto :goto_2

    :cond_3
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x21

    if-lt v0, v2, :cond_4

    .line 23
    :goto_2
    new-instance v0, Landroid/content/Intent;

    .line 24
    sget-object v2, La4/d;->m:La4/d;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const-string v4, "package"

    invoke-static {v4, v3, v12}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    .line 25
    const-string v4, "android.settings.APP_LOCALE_SETTINGS"

    invoke-direct {v0, v4, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 26
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    move-result-object v0

    if-eqz v0, :cond_4

    goto :goto_3

    :cond_4
    move v10, v11

    .line 27
    :goto_3
    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    :pswitch_5
    invoke-static {}, Lo4/j;->b()Landroid/app/LocaleConfig;

    move-result-object v0

    return-object v0

    :pswitch_6
    invoke-static {}, Lo4/j;->a()Lo4/h;

    move-result-object v0

    return-object v0

    .line 28
    :pswitch_7
    sget-object v0, La4/g;->a:La4/g;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    sget-object v2, La4/g;->r:Lk4/a;

    sget-object v3, La4/g;->b:[Lp6/b;

    aget-object v3, v3, v5

    invoke-virtual {v2, v0, v3}, Lk4/a;->u0(La4/g;Lp6/b;)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_6

    .line 30
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    const-string v2, "abcdefghijklmnopqrstuvwxyz"

    invoke-virtual {v2, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    const-string v3, "0123456789"

    .line 31
    invoke-static {v2, v0, v3}, Lb/m;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 32
    new-instance v2, Ljava/security/SecureRandom;

    invoke-direct {v2}, Ljava/security/SecureRandom;-><init>()V

    .line 33
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "magisk_patched-30700_"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    :goto_4
    if-ge v10, v6, :cond_5

    .line 34
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    invoke-virtual {v2, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    invoke-virtual {v0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v10, v10, 0x1

    goto :goto_4

    .line 35
    :cond_5
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_5

    .line 36
    :cond_6
    const-string v0, "magisk_patched"

    :goto_5
    return-object v0

    .line 37
    :pswitch_8
    sget-object v0, La4/d;->m:La4/d;

    .line 38
    const-class v2, Landroid/app/NotificationManager;

    .line 39
    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    .line 40
    check-cast v0, Landroid/app/NotificationManager;

    return-object v0

    .line 41
    :pswitch_9
    sget-object v0, Lj$/time/format/FormatStyle;->SHORT:Lj$/time/format/FormatStyle;

    invoke-static {v0}, Lj$/time/format/DateTimeFormatter;->ofLocalizedDate(Lj$/time/format/FormatStyle;)Lj$/time/format/DateTimeFormatter;

    move-result-object v0

    invoke-static {}, Lj$/time/ZoneId;->systemDefault()Lj$/time/ZoneId;

    move-result-object v2

    invoke-virtual {v0, v2}, Lj$/time/format/DateTimeFormatter;->withZone(Lj$/time/ZoneId;)Lj$/time/format/DateTimeFormatter;

    move-result-object v0

    return-object v0

    .line 42
    :pswitch_a
    sget-object v0, Lj$/time/format/FormatStyle;->MEDIUM:Lj$/time/format/FormatStyle;

    invoke-static {v0}, Lj$/time/format/DateTimeFormatter;->ofLocalizedDateTime(Lj$/time/format/FormatStyle;)Lj$/time/format/DateTimeFormatter;

    move-result-object v0

    invoke-static {}, Lj$/time/ZoneId;->systemDefault()Lj$/time/ZoneId;

    move-result-object v2

    invoke-virtual {v0, v2}, Lj$/time/format/DateTimeFormatter;->withZone(Lj$/time/ZoneId;)Lj$/time/format/DateTimeFormatter;

    move-result-object v0

    return-object v0

    .line 43
    :pswitch_b
    const-string v0, "yyyy-MM-dd\'T\'HH.mm.ss"

    invoke-static {v0}, Lj$/time/format/DateTimeFormatter;->ofPattern(Ljava/lang/String;)Lj$/time/format/DateTimeFormatter;

    move-result-object v0

    invoke-static {}, Lj$/time/ZoneId;->systemDefault()Lj$/time/ZoneId;

    move-result-object v2

    invoke-virtual {v0, v2}, Lj$/time/format/DateTimeFormatter;->withZone(Lj$/time/ZoneId;)Lj$/time/format/DateTimeFormatter;

    move-result-object v0

    return-object v0

    .line 44
    :pswitch_c
    :try_start_0
    sget-object v0, Lg2/c;->o:Ljava/lang/Object;

    .line 45
    invoke-interface {v0}, Lv5/c;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/reflect/Method;

    if-eqz v0, :cond_7

    .line 46
    invoke-virtual {v0}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object v0

    if-eqz v0, :cond_7

    .line 47
    const-string v2, "beginTransaction"

    .line 48
    new-array v3, v7, [Ljava/lang/Class;

    sget-object v4, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v4, v3, v11

    const-class v5, Landroid/database/sqlite/SQLiteTransactionListener;

    aput-object v5, v3, v10

    aput-object v4, v3, v8

    const-class v4, Landroid/os/CancellationSignal;

    aput-object v4, v3, v9

    .line 49
    invoke-virtual {v0, v2, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v12
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_7
    return-object v12

    .line 50
    :pswitch_d
    :try_start_1
    const-class v0, Landroid/database/sqlite/SQLiteDatabase;

    const-string v2, "getThreadSession"

    invoke-virtual {v0, v2, v12}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    .line 51
    invoke-virtual {v0, v10}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    move-object v12, v0

    :catchall_1
    return-object v12

    .line 52
    :pswitch_e
    new-instance v0, Lk4/r;

    .line 53
    sget-object v2, Le4/b;->i:Lv5/i;

    invoke-virtual {v2}, Lv5/i;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lja/v0;

    .line 54
    const-string v4, "https://example.com/"

    .line 55
    invoke-virtual {v3, v4}, Lja/v0;->a(Ljava/lang/String;)V

    .line 56
    invoke-virtual {v3}, Lja/v0;->b()Lc7/e0;

    move-result-object v3

    .line 57
    const-class v4, Lc4/b;

    invoke-virtual {v3, v4}, Lc7/e0;->c(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v3

    .line 58
    check-cast v3, Lc4/b;

    .line 59
    invoke-virtual {v2}, Lv5/i;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lja/v0;

    .line 60
    const-string v4, "https://api.github.com/"

    .line 61
    invoke-virtual {v2, v4}, Lja/v0;->a(Ljava/lang/String;)V

    .line 62
    invoke-virtual {v2}, Lja/v0;->b()Lc7/e0;

    move-result-object v2

    .line 63
    const-class v4, Lc4/a;

    invoke-virtual {v2, v4}, Lc7/e0;->c(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v2

    .line 64
    check-cast v2, Lc4/a;

    .line 65
    invoke-direct {v0, v3, v2}, Lk4/r;-><init>(Lc4/b;Lc4/a;)V

    return-object v0

    .line 66
    :pswitch_f
    sget-object v0, La4/d;->m:La4/d;

    .line 67
    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3, v9}, Ljava/util/ArrayList;-><init>(I)V

    .line 68
    sget-object v13, Landroid/widget/TextView$BufferType;->SPANNABLE:Landroid/widget/TextView$BufferType;

    .line 69
    new-instance v13, Lo5/c;

    invoke-direct {v13}, Lo5/c;-><init>()V

    .line 70
    invoke-virtual {v3, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 71
    new-instance v13, La4/a;

    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    .line 72
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v14

    if-nez v14, :cond_12

    .line 73
    new-instance v14, Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v15

    invoke-direct {v14, v15}, Ljava/util/ArrayList;-><init>(I)V

    .line 74
    new-instance v15, Ljava/util/HashSet;

    invoke-direct {v15, v9}, Ljava/util/HashSet;-><init>(I)V

    .line 75
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v12

    move v4, v11

    :goto_6
    if-ge v4, v12, :cond_b

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v18

    add-int/lit8 v4, v4, 0x1

    move-object/from16 v8, v18

    check-cast v8, Lo5/c;

    .line 76
    invoke-virtual {v14, v8}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v18

    if-nez v18, :cond_a

    .line 77
    invoke-virtual {v15, v8}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v18

    if-nez v18, :cond_9

    .line 78
    invoke-virtual {v15, v8}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 79
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    invoke-virtual {v15, v8}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 81
    invoke-virtual {v14, v8}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v18

    if-nez v18, :cond_a

    .line 82
    const-class v5, Lo5/c;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v5, v2}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v2

    if-eqz v2, :cond_8

    .line 83
    invoke-virtual {v14, v11, v8}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    goto :goto_8

    .line 84
    :cond_8
    invoke-virtual {v14, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_8

    .line 85
    :cond_9
    const-string v0, "Cyclic dependency chain found: "

    invoke-static {v15, v0}, La4/a;->p(Ljava/lang/Object;Ljava/lang/String;)V

    :goto_7
    const/4 v12, 0x0

    goto/16 :goto_a

    :cond_a
    :goto_8
    const/16 v5, 0xb

    const/4 v8, 0x2

    goto :goto_6

    .line 86
    :cond_b
    new-instance v2, Lc7/q;

    invoke-direct {v2, v9}, Lc7/q;-><init>(I)V

    .line 87
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 88
    new-instance v3, Lo5/f;

    .line 89
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    const/16 v4, 0x8

    int-to-float v5, v4

    mul-float/2addr v5, v0

    const/high16 v8, 0x3f000000    # 0.5f

    add-float/2addr v5, v8

    float-to-int v5, v5

    .line 90
    iput v5, v3, Lo5/f;->d:I

    const/16 v5, 0x18

    int-to-float v5, v5

    mul-float/2addr v5, v0

    add-float/2addr v5, v8

    float-to-int v5, v5

    .line 91
    iput v5, v3, Lo5/f;->a:I

    int-to-float v5, v7

    mul-float/2addr v5, v0

    add-float/2addr v5, v8

    float-to-int v5, v5

    .line 92
    iput v5, v3, Lo5/f;->b:I

    int-to-float v12, v10

    mul-float/2addr v12, v0

    add-float/2addr v12, v8

    float-to-int v0, v12

    .line 93
    iput v0, v3, Lo5/f;->c:I

    .line 94
    iput v0, v3, Lo5/f;->e:I

    .line 95
    iput v5, v3, Lo5/f;->f:I

    .line 96
    new-instance v0, Lo/u3;

    .line 97
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 98
    new-instance v5, Ln5/c;

    invoke-direct {v5, v11}, Ln5/c;-><init>(I)V

    .line 99
    new-instance v8, Ljava/util/HashMap;

    invoke-direct {v8, v9}, Ljava/util/HashMap;-><init>(I)V

    .line 100
    invoke-virtual {v14}, Ljava/util/ArrayList;->size()I

    move-result v12

    move v15, v11

    :goto_9
    const/4 v7, 0x7

    if-ge v15, v12, :cond_c

    invoke-virtual {v14, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v22

    add-int/lit8 v15, v15, 0x1

    move-object/from16 v9, v22

    check-cast v9, Lo5/c;

    .line 101
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 102
    new-instance v10, Lo5/b;

    invoke-direct {v10, v9}, Lo5/b;-><init>(Lo5/c;)V

    const-class v9, Lfa/v;

    invoke-virtual {v5, v9, v10}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 103
    new-instance v9, Lo5/a;

    .line 104
    invoke-direct {v9, v6}, Lo5/a;-><init>(I)V

    .line 105
    const-class v10, Lfa/u;

    invoke-virtual {v5, v10, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 106
    new-instance v9, Lo5/a;

    .line 107
    invoke-direct {v9, v7}, Lo5/a;-><init>(I)V

    .line 108
    const-class v6, Lfa/e;

    invoke-virtual {v5, v6, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 109
    new-instance v9, Lo5/a;

    .line 110
    invoke-direct {v9, v4}, Lo5/a;-><init>(I)V

    .line 111
    const-class v4, Lfa/b;

    invoke-virtual {v5, v4, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 112
    new-instance v9, Lo5/a;

    const/16 v7, 0x9

    .line 113
    invoke-direct {v9, v7}, Lo5/a;-><init>(I)V

    .line 114
    const-class v7, Lfa/d;

    invoke-virtual {v5, v7, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 115
    new-instance v9, Lo5/a;

    const/16 v11, 0xa

    .line 116
    invoke-direct {v9, v11}, Lo5/a;-><init>(I)V

    .line 117
    const-class v11, Lfa/f;

    invoke-virtual {v5, v11, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 118
    new-instance v9, Lo5/a;

    const/16 v1, 0xb

    .line 119
    invoke-direct {v9, v1}, Lo5/a;-><init>(I)V

    .line 120
    const-class v1, Lfa/l;

    invoke-virtual {v5, v1, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 121
    new-instance v9, Lo5/a;

    move/from16 v28, v12

    const/16 v12, 0xc

    .line 122
    invoke-direct {v9, v12}, Lo5/a;-><init>(I)V

    .line 123
    const-class v12, Lfa/k;

    invoke-virtual {v5, v12, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 124
    new-instance v9, Lo5/a;

    const/16 v12, 0xe

    .line 125
    invoke-direct {v9, v12}, Lo5/a;-><init>(I)V

    .line 126
    const-class v12, Lfa/c;

    invoke-virtual {v5, v12, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 127
    new-instance v9, Lo5/a;

    const/16 v12, 0xe

    .line 128
    invoke-direct {v9, v12}, Lo5/a;-><init>(I)V

    .line 129
    const-class v12, Lfa/r;

    invoke-virtual {v5, v12, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 130
    new-instance v9, Lo5/a;

    const/16 v12, 0xd

    .line 131
    invoke-direct {v9, v12}, Lo5/a;-><init>(I)V

    .line 132
    const-class v12, Lfa/p;

    invoke-virtual {v5, v12, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 133
    new-instance v9, Lo5/a;

    move-object/from16 v29, v14

    const/4 v14, 0x0

    .line 134
    invoke-direct {v9, v14}, Lo5/a;-><init>(I)V

    .line 135
    const-class v14, Lfa/w;

    invoke-virtual {v5, v14, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 136
    new-instance v9, Lo5/a;

    move/from16 v30, v15

    const/4 v15, 0x1

    .line 137
    invoke-direct {v9, v15}, Lo5/a;-><init>(I)V

    .line 138
    const-class v15, Lfa/h;

    invoke-virtual {v5, v15, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 139
    new-instance v9, Lo5/a;

    move-object/from16 v31, v13

    const/4 v13, 0x2

    .line 140
    invoke-direct {v9, v13}, Lo5/a;-><init>(I)V

    .line 141
    const-class v13, Lfa/t;

    invoke-virtual {v5, v13, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 142
    new-instance v9, Lo5/a;

    const/4 v13, 0x3

    .line 143
    invoke-direct {v9, v13}, Lo5/a;-><init>(I)V

    .line 144
    const-class v13, Lfa/g;

    invoke-virtual {v5, v13, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 145
    new-instance v9, Lo5/a;

    const/4 v13, 0x4

    .line 146
    invoke-direct {v9, v13}, Lo5/a;-><init>(I)V

    .line 147
    const-class v13, Lfa/s;

    invoke-virtual {v5, v13, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 148
    new-instance v9, Lo5/a;

    const/4 v13, 0x5

    .line 149
    invoke-direct {v9, v13}, Lo5/a;-><init>(I)V

    .line 150
    const-class v13, Lfa/m;

    invoke-virtual {v5, v13, v9}, Ln5/c;->a(Ljava/lang/Class;Ln5/b;)V

    .line 151
    new-instance v9, Lp5/a;

    move-object/from16 v32, v2

    const/4 v2, 0x1

    .line 152
    invoke-direct {v9, v2}, Lp5/a;-><init>(I)V

    .line 153
    new-instance v2, Lp5/a;

    move-object/from16 v33, v5

    const/4 v5, 0x7

    .line 154
    invoke-direct {v2, v5}, Lp5/a;-><init>(I)V

    .line 155
    invoke-virtual {v8, v10, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 156
    new-instance v2, Lp5/a;

    const/4 v5, 0x3

    .line 157
    invoke-direct {v2, v5}, Lp5/a;-><init>(I)V

    .line 158
    invoke-virtual {v8, v6, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 159
    new-instance v2, Lp5/a;

    const/4 v5, 0x0

    .line 160
    invoke-direct {v2, v5}, Lp5/a;-><init>(I)V

    .line 161
    invoke-virtual {v8, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 162
    new-instance v2, Lp5/a;

    const/4 v4, 0x2

    .line 163
    invoke-direct {v2, v4}, Lp5/a;-><init>(I)V

    .line 164
    invoke-virtual {v8, v7, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 165
    invoke-virtual {v8, v11, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 166
    invoke-virtual {v8, v1, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 167
    new-instance v1, Lp5/a;

    const/4 v2, 0x6

    .line 168
    invoke-direct {v1, v2}, Lp5/a;-><init>(I)V

    .line 169
    invoke-virtual {v8, v12, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 170
    new-instance v1, Lp5/a;

    const/4 v2, 0x4

    .line 171
    invoke-direct {v1, v2}, Lp5/a;-><init>(I)V

    .line 172
    invoke-virtual {v8, v15, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 173
    new-instance v1, Lp5/a;

    const/4 v2, 0x5

    .line 174
    invoke-direct {v1, v2}, Lp5/a;-><init>(I)V

    .line 175
    invoke-virtual {v8, v13, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 176
    new-instance v1, Lp5/a;

    const/16 v2, 0x8

    .line 177
    invoke-direct {v1, v2}, Lp5/a;-><init>(I)V

    .line 178
    invoke-virtual {v8, v14, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object/from16 v1, p0

    move v4, v2

    move/from16 v12, v28

    move-object/from16 v14, v29

    move/from16 v15, v30

    move-object/from16 v13, v31

    move-object/from16 v2, v32

    move-object/from16 v5, v33

    const/4 v6, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    goto/16 :goto_9

    :cond_c
    move-object/from16 v32, v2

    move-object/from16 v33, v5

    move-object/from16 v31, v13

    move-object/from16 v29, v14

    .line 179
    new-instance v1, Lo5/f;

    .line 180
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 181
    iget v2, v3, Lo5/f;->a:I

    .line 182
    iput v2, v1, Lo5/f;->a:I

    .line 183
    iget v2, v3, Lo5/f;->b:I

    .line 184
    iput v2, v1, Lo5/f;->b:I

    .line 185
    iget v2, v3, Lo5/f;->c:I

    .line 186
    iput v2, v1, Lo5/f;->c:I

    .line 187
    iget v2, v3, Lo5/f;->d:I

    .line 188
    iput v2, v1, Lo5/f;->d:I

    .line 189
    iget v2, v3, Lo5/f;->e:I

    .line 190
    iput v2, v1, Lo5/f;->e:I

    .line 191
    iget v2, v3, Lo5/f;->f:I

    .line 192
    iput v2, v1, Lo5/f;->f:I

    .line 193
    new-instance v2, Lm1/c;

    invoke-static {v8}, Lj$/util/DesugarCollections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v3

    const/4 v5, 0x3

    invoke-direct {v2, v5, v3}, Lm1/c;-><init>(ILjava/lang/Object;)V

    .line 194
    iput-object v1, v0, Lo/u3;->a:Ljava/lang/Object;

    .line 195
    iput-object v2, v0, Lo/u3;->g:Ljava/lang/Object;

    .line 196
    iget-object v1, v0, Lo/u3;->b:Ljava/lang/Object;

    check-cast v1, Lq4/b;

    if-nez v1, :cond_d

    .line 197
    new-instance v1, Lq4/b;

    const/4 v2, 0x4

    .line 198
    invoke-direct {v1, v2}, Lq4/b;-><init>(I)V

    .line 199
    iput-object v1, v0, Lo/u3;->b:Ljava/lang/Object;

    .line 200
    :cond_d
    iget-object v1, v0, Lo/u3;->c:Ljava/lang/Object;

    check-cast v1, Lq4/b;

    if-nez v1, :cond_e

    .line 201
    new-instance v1, Lq4/b;

    const/16 v2, 0xb

    .line 202
    invoke-direct {v1, v2}, Lq4/b;-><init>(I)V

    .line 203
    iput-object v1, v0, Lo/u3;->c:Ljava/lang/Object;

    .line 204
    :cond_e
    iget-object v1, v0, Lo/u3;->d:Ljava/lang/Object;

    check-cast v1, Ln3/f;

    if-nez v1, :cond_f

    .line 205
    new-instance v1, Ln3/f;

    const/16 v2, 0x19

    .line 206
    invoke-direct {v1, v2}, Ln3/f;-><init>(I)V

    .line 207
    iput-object v1, v0, Lo/u3;->d:Ljava/lang/Object;

    .line 208
    :cond_f
    iget-object v1, v0, Lo/u3;->e:Ljava/lang/Object;

    check-cast v1, Lq4/b;

    if-nez v1, :cond_10

    .line 209
    new-instance v1, Lq4/b;

    const/4 v5, 0x7

    .line 210
    invoke-direct {v1, v5}, Lq4/b;-><init>(I)V

    .line 211
    iput-object v1, v0, Lo/u3;->e:Ljava/lang/Object;

    .line 212
    :cond_10
    iget-object v1, v0, Lo/u3;->f:Ljava/lang/Object;

    check-cast v1, Lq4/b;

    if-nez v1, :cond_11

    .line 213
    new-instance v1, Lq4/b;

    const/4 v2, 0x5

    .line 214
    invoke-direct {v1, v2}, Lq4/b;-><init>(I)V

    .line 215
    iput-object v1, v0, Lo/u3;->f:Ljava/lang/Object;

    .line 216
    :cond_11
    new-instance v1, Lc7/e0;

    .line 217
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 218
    iget-object v2, v0, Lo/u3;->a:Ljava/lang/Object;

    check-cast v2, Lo5/f;

    .line 219
    iput-object v2, v1, Lc7/e0;->a:Ljava/lang/Object;

    .line 220
    iget-object v2, v0, Lo/u3;->c:Ljava/lang/Object;

    check-cast v2, Lq4/b;

    .line 221
    iput-object v2, v1, Lc7/e0;->b:Ljava/lang/Object;

    .line 222
    iget-object v2, v0, Lo/u3;->d:Ljava/lang/Object;

    check-cast v2, Ln3/f;

    .line 223
    iput-object v2, v1, Lc7/e0;->c:Ljava/lang/Object;

    .line 224
    iget-object v2, v0, Lo/u3;->e:Ljava/lang/Object;

    check-cast v2, Lq4/b;

    .line 225
    iput-object v2, v1, Lc7/e0;->d:Ljava/lang/Object;

    .line 226
    iget-object v0, v0, Lo/u3;->g:Ljava/lang/Object;

    check-cast v0, Lm1/c;

    .line 227
    iput-object v0, v1, Lc7/e0;->e:Ljava/lang/Object;

    .line 228
    new-instance v0, Laa/e;

    const/16 v2, 0x16

    move-object/from16 v3, v33

    invoke-direct {v0, v2, v3, v1}, Laa/e;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 229
    new-instance v12, Ln5/a;

    .line 230
    new-instance v1, Lc7/q;

    move-object/from16 v2, v32

    invoke-direct {v1, v2}, Lc7/q;-><init>(Lc7/q;)V

    .line 231
    invoke-static/range {v29 .. v29}, Lj$/util/DesugarCollections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    move-object/from16 v3, v31

    invoke-direct {v12, v3, v1, v0, v2}, Ln5/a;-><init>(La4/a;Lc7/q;Laa/e;Ljava/util/List;)V

    goto :goto_a

    .line 232
    :cond_12
    const-string v0, "No plugins were added to this builder. Use #usePlugin method to add them"

    invoke-static {v0}, Lq0/b;->m(Ljava/lang/String;)V

    goto/16 :goto_7

    :goto_a
    return-object v12

    .line 233
    :pswitch_10
    sget-object v0, Le4/b;->h:Lv5/i;

    invoke-virtual {v0}, Lv5/i;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lc7/c0;

    .line 234
    new-instance v1, Lja/v0;

    invoke-direct {v1}, Lja/v0;-><init>()V

    .line 235
    new-instance v2, Lja/d;

    const/4 v4, 0x2

    .line 236
    invoke-direct {v2, v4}, Lja/d;-><init>(I)V

    .line 237
    iget-object v3, v1, Lja/v0;->c:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 238
    new-instance v2, Lh7/u;

    invoke-direct {v2}, Lh7/u;-><init>()V

    new-instance v7, Lcom/topjohnwu/magisk/core/model/DateTimeAdapter;

    .line 239
    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    .line 240
    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 241
    new-instance v14, Ljava/util/ArrayList;

    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    .line 242
    const-class v17, Lcom/topjohnwu/magisk/core/model/DateTimeAdapter;

    move-object/from16 v15, v17

    :goto_b
    const-class v4, Ljava/lang/Object;

    if-eq v15, v4, :cond_26

    .line 243
    invoke-virtual {v15}, Ljava/lang/Class;->getDeclaredMethods()[Ljava/lang/reflect/Method;

    move-result-object v4

    array-length v5, v4

    const/4 v6, 0x0

    :goto_c
    if-ge v6, v5, :cond_25

    aget-object v8, v4, v6

    .line 244
    const-class v9, Lw3/i0;

    invoke-virtual {v8, v9}, Ljava/lang/reflect/AccessibleObject;->isAnnotationPresent(Ljava/lang/Class;)Z

    move-result v9

    const-string v10, "Nullable"

    const-class v11, Lw3/q;

    const-string v12, "\n    "

    move-object/from16 v18, v15

    const-string v15, "Unexpected signature for "

    move-object/from16 v20, v15

    sget-object v15, Ljava/lang/Void;->TYPE:Ljava/lang/Class;

    if-eqz v9, :cond_1b

    const/4 v9, 0x1

    .line 245
    invoke-virtual {v8, v9}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    move-object v9, v12

    .line 246
    invoke-virtual {v8}, Ljava/lang/reflect/Method;->getGenericReturnType()Ljava/lang/reflect/Type;

    move-result-object v12

    move-object/from16 v21, v4

    .line 247
    invoke-virtual {v8}, Ljava/lang/reflect/Method;->getGenericParameterTypes()[Ljava/lang/reflect/Type;

    move-result-object v4

    .line 248
    invoke-virtual {v8}, Ljava/lang/reflect/Method;->getParameterAnnotations()[[Ljava/lang/annotation/Annotation;

    move-result-object v23

    move/from16 v24, v5

    .line 249
    array-length v5, v4

    move/from16 v25, v6

    const/4 v6, 0x2

    if-lt v5, v6, :cond_14

    const/16 v27, 0x0

    aget-object v5, v4, v27

    const-class v6, Lw3/v;

    if-ne v5, v6, :cond_14

    if-ne v12, v15, :cond_14

    .line 250
    array-length v5, v4

    const/4 v6, 0x2

    :goto_d
    if-ge v6, v5, :cond_16

    move/from16 v26, v5

    .line 251
    aget-object v5, v4, v6

    move/from16 v28, v6

    instance-of v6, v5, Ljava/lang/reflect/ParameterizedType;

    if-nez v6, :cond_13

    goto :goto_e

    .line 252
    :cond_13
    check-cast v5, Ljava/lang/reflect/ParameterizedType;

    invoke-interface {v5}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v5

    if-eq v5, v11, :cond_15

    :cond_14
    :goto_e
    move-object/from16 v36, v9

    move-object/from16 v34, v10

    move-object/from16 v35, v11

    move-object/from16 v26, v13

    const/4 v13, 0x1

    goto :goto_10

    :cond_15
    add-int/lit8 v6, v28, 0x1

    move/from16 v5, v26

    goto :goto_d

    :cond_16
    const/16 v22, 0x1

    .line 253
    aget-object v5, v23, v22

    invoke-static {v5}, Lx3/e;->e([Ljava/lang/annotation/Annotation;)Ljava/util/Set;

    move-result-object v6

    .line 254
    new-instance v5, Lw3/b;

    move-object v12, v5

    aget-object v5, v4, v22

    move-object/from16 v23, v9

    array-length v9, v4

    move-object v4, v11

    const/4 v11, 0x1

    move-object/from16 v26, v4

    move-object v4, v12

    const/4 v12, 0x0

    move-object/from16 v28, v10

    const/4 v10, 0x2

    move-object/from16 v36, v23

    move-object/from16 v35, v26

    move-object/from16 v34, v28

    move-object/from16 v26, v13

    move/from16 v13, v22

    .line 255
    invoke-direct/range {v4 .. v12}, Lw3/b;-><init>(Ljava/lang/reflect/Type;Ljava/util/Set;Lcom/topjohnwu/magisk/core/model/DateTimeAdapter;Ljava/lang/reflect/Method;IIZI)V

    move-object/from16 v29, v0

    move-object/from16 v23, v3

    move-object/from16 v28, v14

    move-object/from16 v0, v26

    move-object/from16 v3, v34

    move-object/from16 v26, v2

    move-object/from16 v2, v20

    move-object/from16 v20, v18

    move-object/from16 v18, v1

    move-object v1, v15

    :goto_f
    move-object v5, v4

    goto/16 :goto_13

    .line 256
    :goto_10
    array-length v5, v4

    if-ne v5, v13, :cond_1a

    if-eq v12, v15, :cond_1a

    .line 257
    sget-object v5, Lx3/e;->a:Ljava/util/Set;

    .line 258
    invoke-interface {v8}, Ljava/lang/reflect/AnnotatedElement;->getAnnotations()[Ljava/lang/annotation/Annotation;

    move-result-object v5

    invoke-static {v5}, Lx3/e;->e([Ljava/lang/annotation/Annotation;)Ljava/util/Set;

    move-result-object v5

    const/16 v27, 0x0

    .line 259
    aget-object v6, v23, v27

    .line 260
    invoke-static {v6}, Lx3/e;->e([Ljava/lang/annotation/Annotation;)Ljava/util/Set;

    move-result-object v6

    .line 261
    aget-object v9, v23, v27

    .line 262
    array-length v10, v9

    const/4 v11, 0x0

    :goto_11
    if-ge v11, v10, :cond_18

    aget-object v13, v9, v11

    .line 263
    invoke-interface {v13}, Ljava/lang/annotation/Annotation;->annotationType()Ljava/lang/Class;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v13

    move-object/from16 v23, v15

    move-object/from16 v15, v34

    invoke-virtual {v13, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_17

    const/4 v10, 0x1

    goto :goto_12

    :cond_17
    add-int/lit8 v11, v11, 0x1

    move-object/from16 v34, v15

    move-object/from16 v15, v23

    goto :goto_11

    :cond_18
    move-object/from16 v23, v15

    move-object/from16 v15, v34

    const/4 v10, 0x0

    .line 264
    :goto_12
    new-instance v9, Lw3/c;

    move-object v11, v14

    const/16 v27, 0x0

    move-object v14, v5

    aget-object v5, v4, v27

    move-object v13, v9

    array-length v9, v4

    move-object/from16 v34, v15

    const/4 v15, 0x0

    move-object/from16 v28, v11

    move-object v11, v4

    move-object v4, v13

    move-object v13, v6

    move-object/from16 v29, v0

    move-object/from16 v0, v26

    move-object/from16 v26, v2

    move-object/from16 v2, v20

    move-object/from16 v20, v18

    move-object/from16 v18, v1

    move-object/from16 v1, v23

    move-object/from16 v23, v3

    move-object/from16 v3, v34

    invoke-direct/range {v4 .. v15}, Lw3/c;-><init>(Ljava/lang/reflect/Type;Ljava/util/Set;Lcom/topjohnwu/magisk/core/model/DateTimeAdapter;Ljava/lang/reflect/Method;IZ[Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;Ljava/util/Set;Ljava/util/Set;I)V

    goto :goto_f

    .line 265
    :goto_13
    iget-object v4, v5, Lw3/d;->a:Ljava/lang/reflect/Type;

    iget-object v6, v5, Lw3/d;->b:Ljava/util/Set;

    invoke-static {v0, v4, v6}, Lw3/e;->b(Ljava/util/ArrayList;Ljava/lang/reflect/Type;Ljava/util/Set;)Lw3/d;

    move-result-object v4

    if-nez v4, :cond_19

    .line 266
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v13, v36

    goto :goto_15

    .line 267
    :cond_19
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Conflicting @ToJson methods:\n    "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, v4, Lw3/d;->d:Ljava/lang/reflect/Method;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    iget-object v1, v5, Lw3/d;->d:Ljava/lang/reflect/Method;

    move-object/from16 v13, v36

    invoke-static {v0, v13, v1}, Lja/y0;->m(Ljava/lang/StringBuilder;Ljava/lang/Object;Ljava/lang/Object;)V

    :goto_14
    const/4 v12, 0x0

    goto/16 :goto_1d

    :cond_1a
    move-object/from16 v2, v20

    .line 268
    const-string v0, ".\n@ToJson method signatures may have one of the following structures:\n    <any access modifier> void toJson(JsonWriter writer, T value) throws <any>;\n    <any access modifier> void toJson(JsonWriter writer, T value, JsonAdapter<any> delegate, <any more delegates>) throws <any>;\n    <any access modifier> R toJson(T value) throws <any>;\n"

    invoke-static {v8, v0, v2}, Lu0/b;->h(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_14

    :cond_1b
    move-object/from16 v29, v0

    move-object/from16 v26, v2

    move-object/from16 v23, v3

    move-object/from16 v21, v4

    move/from16 v24, v5

    move/from16 v25, v6

    move-object v3, v10

    move-object/from16 v35, v11

    move-object v0, v13

    move-object/from16 v28, v14

    move-object/from16 v2, v20

    move-object v13, v12

    move-object/from16 v20, v18

    move-object/from16 v18, v1

    move-object v1, v15

    .line 269
    :goto_15
    const-class v4, Lw3/n;

    invoke-virtual {v8, v4}, Ljava/lang/reflect/AccessibleObject;->isAnnotationPresent(Ljava/lang/Class;)Z

    move-result v4

    if-eqz v4, :cond_24

    const/4 v15, 0x1

    .line 270
    invoke-virtual {v8, v15}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 271
    invoke-virtual {v8}, Ljava/lang/reflect/Method;->getGenericReturnType()Ljava/lang/reflect/Type;

    move-result-object v5

    .line 272
    sget-object v4, Lx3/e;->a:Ljava/util/Set;

    .line 273
    invoke-interface {v8}, Ljava/lang/reflect/AnnotatedElement;->getAnnotations()[Ljava/lang/annotation/Annotation;

    move-result-object v4

    invoke-static {v4}, Lx3/e;->e([Ljava/lang/annotation/Annotation;)Ljava/util/Set;

    move-result-object v6

    .line 274
    invoke-virtual {v8}, Ljava/lang/reflect/Method;->getGenericParameterTypes()[Ljava/lang/reflect/Type;

    move-result-object v11

    .line 275
    invoke-virtual {v8}, Ljava/lang/reflect/Method;->getParameterAnnotations()[[Ljava/lang/annotation/Annotation;

    move-result-object v4

    .line 276
    array-length v9, v11

    if-lt v9, v15, :cond_1f

    const/16 v27, 0x0

    aget-object v9, v11, v27

    const-class v10, Lw3/u;

    if-ne v9, v10, :cond_1f

    if-eq v5, v1, :cond_1f

    .line 277
    array-length v9, v11

    const/4 v10, 0x1

    :goto_16
    if-ge v10, v9, :cond_1e

    .line 278
    aget-object v12, v11, v10

    instance-of v14, v12, Ljava/lang/reflect/ParameterizedType;

    if-nez v14, :cond_1c

    goto :goto_17

    .line 279
    :cond_1c
    check-cast v12, Ljava/lang/reflect/ParameterizedType;

    invoke-interface {v12}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v12

    move-object/from16 v14, v35

    if-eq v12, v14, :cond_1d

    goto :goto_17

    :cond_1d
    add-int/lit8 v10, v10, 0x1

    move-object/from16 v35, v14

    goto :goto_16

    .line 280
    :cond_1e
    new-instance v4, Lw3/b;

    array-length v9, v11

    const/4 v11, 0x1

    const/4 v12, 0x1

    const/4 v10, 0x1

    .line 281
    invoke-direct/range {v4 .. v12}, Lw3/b;-><init>(Ljava/lang/reflect/Type;Ljava/util/Set;Lcom/topjohnwu/magisk/core/model/DateTimeAdapter;Ljava/lang/reflect/Method;IIZI)V

    move-object v1, v13

    goto :goto_1a

    .line 282
    :cond_1f
    :goto_17
    array-length v9, v11

    const/4 v15, 0x1

    if-ne v9, v15, :cond_23

    if-eq v5, v1, :cond_23

    const/16 v27, 0x0

    .line 283
    aget-object v1, v4, v27

    .line 284
    invoke-static {v1}, Lx3/e;->e([Ljava/lang/annotation/Annotation;)Ljava/util/Set;

    move-result-object v1

    .line 285
    aget-object v2, v4, v27

    .line 286
    array-length v4, v2

    const/4 v9, 0x0

    :goto_18
    if-ge v9, v4, :cond_21

    aget-object v10, v2, v9

    .line 287
    invoke-interface {v10}, Ljava/lang/annotation/Annotation;->annotationType()Ljava/lang/Class;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_20

    const/4 v10, 0x1

    goto :goto_19

    :cond_20
    add-int/lit8 v9, v9, 0x1

    goto :goto_18

    :cond_21
    const/4 v10, 0x0

    .line 288
    :goto_19
    new-instance v4, Lw3/c;

    array-length v9, v11

    const/4 v15, 0x1

    move-object v12, v5

    move-object v14, v6

    move-object/from16 v50, v13

    move-object v13, v1

    move-object/from16 v1, v50

    invoke-direct/range {v4 .. v15}, Lw3/c;-><init>(Ljava/lang/reflect/Type;Ljava/util/Set;Lcom/topjohnwu/magisk/core/model/DateTimeAdapter;Ljava/lang/reflect/Method;IZ[Ljava/lang/reflect/Type;Ljava/lang/reflect/Type;Ljava/util/Set;Ljava/util/Set;I)V

    .line 289
    :goto_1a
    iget-object v2, v4, Lw3/d;->a:Ljava/lang/reflect/Type;

    iget-object v3, v4, Lw3/d;->b:Ljava/util/Set;

    move-object/from16 v11, v28

    invoke-static {v11, v2, v3}, Lw3/e;->b(Ljava/util/ArrayList;Ljava/lang/reflect/Type;Ljava/util/Set;)Lw3/d;

    move-result-object v2

    if-nez v2, :cond_22

    .line 290
    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1b

    .line 291
    :cond_22
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, "Conflicting @FromJson methods:\n    "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, v2, Lw3/d;->d:Ljava/lang/reflect/Method;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    iget-object v2, v4, Lw3/d;->d:Ljava/lang/reflect/Method;

    invoke-static {v0, v1, v2}, Lja/y0;->m(Ljava/lang/StringBuilder;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_14

    .line 292
    :cond_23
    const-string v0, ".\n@FromJson method signatures may have one of the following structures:\n    <any access modifier> R fromJson(JsonReader jsonReader) throws <any>;\n    <any access modifier> R fromJson(JsonReader jsonReader, JsonAdapter<any> delegate, <any more delegates>) throws <any>;\n    <any access modifier> R fromJson(T value) throws <any>;\n"

    invoke-static {v8, v0, v2}, Lu0/b;->h(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    goto/16 :goto_14

    :cond_24
    move-object/from16 v11, v28

    :goto_1b
    add-int/lit8 v6, v25, 0x1

    move-object v13, v0

    move-object v14, v11

    move-object/from16 v1, v18

    move-object/from16 v15, v20

    move-object/from16 v4, v21

    move-object/from16 v3, v23

    move/from16 v5, v24

    move-object/from16 v2, v26

    move-object/from16 v0, v29

    goto/16 :goto_c

    :cond_25
    move-object/from16 v29, v0

    move-object/from16 v18, v1

    move-object/from16 v26, v2

    move-object/from16 v23, v3

    move-object v0, v13

    move-object v11, v14

    move-object/from16 v20, v15

    .line 293
    invoke-virtual/range {v20 .. v20}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object v15

    move-object/from16 v0, v29

    goto/16 :goto_b

    :cond_26
    move-object/from16 v29, v0

    move-object/from16 v18, v1

    move-object/from16 v26, v2

    move-object/from16 v23, v3

    move-object v0, v13

    move-object v11, v14

    .line 294
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_28

    invoke-virtual {v11}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_27

    goto :goto_1c

    .line 295
    :cond_27
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Expected at least one @ToJson or @FromJson method on "

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lq0/b;->g(Ljava/lang/String;)V

    goto/16 :goto_14

    .line 296
    :cond_28
    :goto_1c
    new-instance v1, Lw3/e;

    invoke-direct {v1, v0, v11}, Lw3/e;-><init>(Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    move-object/from16 v0, v26

    .line 297
    iget v2, v0, Lh7/u;->b:I

    add-int/lit8 v3, v2, 0x1

    iput v3, v0, Lh7/u;->b:I

    iget-object v3, v0, Lh7/u;->a:Ljava/util/ArrayList;

    invoke-virtual {v3, v2, v1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 298
    new-instance v1, Lw3/c0;

    invoke-direct {v1, v0}, Lw3/c0;-><init>(Lh7/u;)V

    .line 299
    new-instance v0, Lka/a;

    invoke-direct {v0, v1}, Lka/a;-><init>(Lw3/c0;)V

    move-object/from16 v1, v23

    .line 300
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v1, v18

    move-object/from16 v0, v29

    .line 301
    iput-object v0, v1, Lja/v0;->a:Lc7/c0;

    move-object v12, v1

    :goto_1d
    return-object v12

    .line 302
    :pswitch_11
    sget-object v0, La4/d;->m:La4/d;

    .line 303
    new-instance v1, Lc7/h;

    new-instance v2, Ljava/io/File;

    invoke-virtual {v0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v3

    const-string v4, "okhttp"

    invoke-direct {v2, v3, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-direct {v1, v2}, Lc7/h;-><init>(Ljava/io/File;)V

    .line 304
    new-instance v2, Lc7/b0;

    invoke-direct {v2}, Lc7/b0;-><init>()V

    .line 305
    iput-object v1, v2, Lc7/b0;->l:Lc7/h;

    .line 306
    sget-object v1, Lc7/o;->e:Lc7/o;

    .line 307
    invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    .line 308
    iget-object v3, v2, Lc7/b0;->s:Ljava/util/List;

    .line 309
    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_29

    const/4 v3, 0x0

    .line 310
    iput-object v3, v2, Lc7/b0;->C:Laa/b;

    .line 311
    :cond_29
    invoke-static {v1}, Le7/g;->i(Ljava/util/List;)Ljava/util/List;

    move-result-object v1

    iput-object v1, v2, Lc7/b0;->s:Ljava/util/List;

    .line 312
    new-instance v1, Laa/b;

    .line 313
    new-instance v3, Lc7/c0;

    invoke-direct {v3, v2}, Lc7/c0;-><init>(Lc7/b0;)V

    .line 314
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 315
    new-instance v4, Lb/a0;

    const/4 v5, 0x6

    invoke-direct {v4, v5, v3}, Lb/a0;-><init>(ILjava/lang/Object;)V

    .line 316
    new-instance v3, Lv5/i;

    invoke-direct {v3, v4}, Lv5/i;-><init>(Lj6/a;)V

    .line 317
    iput-object v3, v1, Laa/b;->m:Ljava/lang/Object;

    .line 318
    iget-object v3, v2, Lc7/b0;->m:Lc7/r;

    .line 319
    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_2a

    const/4 v3, 0x0

    .line 320
    iput-object v3, v2, Lc7/b0;->C:Laa/b;

    .line 321
    :cond_2a
    iput-object v1, v2, Lc7/b0;->m:Lc7/r;

    .line 322
    new-instance v1, Le4/a;

    .line 323
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 324
    iget-object v3, v2, Lc7/b0;->c:Ljava/util/ArrayList;

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 325
    const-string v1, "com.google.android.gms"

    :try_start_2
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    const/4 v5, 0x0

    invoke-virtual {v3, v1, v5}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v3

    .line 326
    iget v3, v3, Landroid/content/pm/ApplicationInfo;->flags:I

    const/16 v22, 0x1

    and-int/lit8 v3, v3, 0x1

    if-nez v3, :cond_2b

    goto :goto_1e

    :cond_2b
    const/4 v5, 0x3

    .line 327
    invoke-virtual {v0, v1, v5}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;

    move-result-object v0

    .line 328
    invoke-virtual {v0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    const-string v3, "com.google.android.gms.common.security.ProviderInstallerImpl"

    .line 329
    invoke-virtual {v1, v3}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const-string v3, "insertProvider"

    const/4 v15, 0x1

    new-array v4, v15, [Ljava/lang/Class;

    const-class v5, Landroid/content/Context;

    const/16 v27, 0x0

    aput-object v5, v4, v27

    .line 330
    invoke-virtual {v1, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    new-array v3, v15, [Ljava/lang/Object;

    aput-object v0, v3, v27

    const/4 v0, 0x0

    .line 331
    invoke-virtual {v1, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 332
    :catch_0
    :goto_1e
    new-instance v0, Lc7/c0;

    invoke-direct {v0, v2}, Lc7/c0;-><init>(Lc7/b0;)V

    return-object v0

    .line 333
    :pswitch_12
    new-instance v0, Lk4/f;

    .line 334
    sget-object v1, Le4/b;->f:Lv5/i;

    invoke-virtual {v1}, Lv5/i;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc4/g;

    .line 335
    invoke-direct {v0, v1}, Lk4/f;-><init>(Lc4/g;)V

    return-object v0

    :pswitch_13
    move v5, v9

    .line 336
    invoke-static {}, Le4/b;->a()Landroid/content/Context;

    move-result-object v0

    const/16 v19, 0x2

    .line 337
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v15, 0x1

    .line 338
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    .line 339
    const-string v30, "sulogs.db"

    invoke-static/range {v30 .. v30}, Lr6/i;->X(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_5c

    .line 340
    new-instance v33, Ljava/util/ArrayList;

    invoke-direct/range {v33 .. v33}, Ljava/util/ArrayList;-><init>()V

    .line 341
    new-instance v45, Ljava/util/ArrayList;

    invoke-direct/range {v45 .. v45}, Ljava/util/ArrayList;-><init>()V

    .line 342
    new-instance v4, Lu/b;

    invoke-direct {v4, v15}, Lu/b;-><init>(I)V

    .line 343
    new-instance v6, Ljava/util/LinkedHashSet;

    invoke-direct {v6}, Ljava/util/LinkedHashSet;-><init>()V

    .line 344
    new-instance v7, Ljava/util/LinkedHashSet;

    invoke-direct {v7}, Ljava/util/LinkedHashSet;-><init>()V

    .line 345
    new-instance v46, Ljava/util/ArrayList;

    invoke-direct/range {v46 .. v46}, Ljava/util/ArrayList;-><init>()V

    .line 346
    const-class v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;

    invoke-static {v8}, Lk6/q;->a(Ljava/lang/Class;)Lk6/e;

    move-result-object v8

    .line 347
    new-array v9, v15, [Lc4/h;

    sget-object v10, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->l:Lc4/h;

    const/16 v27, 0x0

    aput-object v10, v9, v27

    .line 348
    aget-object v10, v9, v27

    .line 349
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v7, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 350
    invoke-interface {v7, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 351
    invoke-static {v9, v15}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v9

    check-cast v9, [Lc4/h;

    .line 352
    array-length v10, v9

    const/4 v14, 0x0

    :goto_1f
    if-ge v14, v10, :cond_2c

    aget-object v11, v9, v14

    .line 353
    invoke-virtual {v4, v11}, Lu/b;->a(Lc4/h;)V

    add-int/lit8 v14, v14, 0x1

    goto :goto_1f

    .line 354
    :cond_2c
    invoke-interface {v7}, Ljava/util/Collection;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_2e

    .line 355
    invoke-interface {v7}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_20
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_2e

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Number;

    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    move-result v9

    .line 356
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    invoke-interface {v6, v10}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_2d

    goto :goto_20

    .line 357
    :cond_2d
    const-string v0, "Inconsistency detected. A Migration was supplied to addMigration() that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(). Start version is: "

    .line 358
    invoke-static {v9, v0}, Lb/m;->h(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 359
    invoke-static {v0}, Lq0/b;->e(Ljava/lang/Object;)V

    :goto_21
    const/4 v12, 0x0

    goto/16 :goto_3f

    .line 360
    :cond_2e
    new-instance v7, Ln3/f;

    const/16 v11, 0xa

    .line 361
    invoke-direct {v7, v11}, Ln3/f;-><init>(I)V

    .line 362
    new-instance v28, Lx1/a;

    .line 363
    const-string v9, "activity"

    invoke-virtual {v0, v9}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v9

    instance-of v10, v9, Landroid/app/ActivityManager;

    if-eqz v10, :cond_2f

    check-cast v9, Landroid/app/ActivityManager;

    goto :goto_22

    :cond_2f
    const/4 v9, 0x0

    :goto_22
    if-eqz v9, :cond_30

    .line 364
    invoke-virtual {v9}, Landroid/app/ActivityManager;->isLowRamDevice()Z

    move-result v9

    if-nez v9, :cond_30

    move/from16 v35, v5

    goto :goto_23

    :cond_30
    move/from16 v35, v19

    :goto_23
    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v34, 0x0

    .line 365
    sget-object v36, Lp/a;->g:Lj5/y0;

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x1

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v47, 0x1

    move-object/from16 v37, v36

    move-object/from16 v29, v0

    move-object/from16 v32, v4

    move-object/from16 v41, v6

    move-object/from16 v31, v7

    invoke-direct/range {v28 .. v49}, Lx1/a;-><init>(Landroid/content/Context;Ljava/lang/String;Ln3/f;Lu/b;Ljava/util/List;ZILjava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Landroid/content/Intent;ZZLjava/util/Set;Ljava/lang/String;Ljava/io/File;Ljava/util/concurrent/Callable;Ljava/util/List;Ljava/util/List;ZLe2/b;Lz5/h;)V

    move-object/from16 v0, v28

    .line 366
    iget-object v4, v8, Lk6/e;->a:Ljava/lang/Class;

    .line 367
    invoke-virtual {v4}, Ljava/lang/Class;->getPackage()Ljava/lang/Package;

    move-result-object v5

    if-eqz v5, :cond_31

    invoke-virtual {v5}, Ljava/lang/Package;->getName()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_32

    :cond_31
    const-string v5, ""

    .line 368
    :cond_32
    invoke-virtual {v4}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v6

    .line 369
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v7

    if-nez v7, :cond_33

    goto :goto_24

    :cond_33
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v7

    const/16 v22, 0x1

    add-int/lit8 v7, v7, 0x1

    invoke-virtual {v6, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    :goto_24
    const/16 v7, 0x5f

    .line 370
    invoke-virtual {v6, v3, v7}, Ljava/lang/String;->replace(CC)Ljava/lang/String;

    move-result-object v6

    .line 371
    const-string v7, "_Impl"

    invoke-virtual {v6, v7}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 372
    :try_start_3
    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v7

    if-nez v7, :cond_34

    move-object v3, v6

    goto :goto_25

    .line 373
    :cond_34
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 374
    :goto_25
    invoke-virtual {v4}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v5

    const/4 v15, 0x1

    invoke-static {v3, v15, v5}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v3

    const/4 v5, 0x0

    .line 375
    invoke-virtual {v3, v5}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v3

    invoke-virtual {v3, v5}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3
    :try_end_3
    .catch Ljava/lang/ClassNotFoundException; {:try_start_3 .. :try_end_3} :catch_4
    .catch Ljava/lang/IllegalAccessException; {:try_start_3 .. :try_end_3} :catch_3
    .catch Ljava/lang/InstantiationException; {:try_start_3 .. :try_end_3} :catch_2

    .line 376
    move-object v8, v3

    check-cast v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;

    .line 377
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 378
    iput-boolean v15, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->k:Z

    .line 379
    :try_start_4
    invoke-virtual {v8}, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->d()Lw1/c0;

    move-result-object v3
    :try_end_4
    .catch Lv5/d; {:try_start_4 .. :try_end_4} :catch_1

    goto :goto_26

    :catch_1
    const/4 v3, 0x0

    :goto_26
    if-eqz v3, :cond_5b

    .line 380
    new-instance v4, Lt7/k;

    .line 381
    new-instance v6, Lx1/q;

    const/4 v13, 0x0

    const/4 v14, 0x1

    const/4 v7, 0x2

    .line 382
    const-class v9, Lx1/r;

    const-string v10, "compatTransactionCoroutineExecute"

    const-string v11, "compatTransactionCoroutineExecute(Landroidx/room/RoomDatabase;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;"

    const/4 v12, 0x1

    invoke-direct/range {v6 .. v14}, Lx1/q;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V

    .line 383
    invoke-direct {v4, v0, v3, v6}, Lt7/k;-><init>(Lx1/a;Lw1/c0;Lx1/q;)V

    .line 384
    iput-object v4, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->e:Lt7/k;

    .line 385
    invoke-virtual {v8}, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->c()Lx1/g;

    move-result-object v3

    iput-object v3, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->f:Lx1/g;

    .line 386
    new-instance v3, Ljava/util/LinkedHashMap;

    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    .line 387
    invoke-virtual {v8}, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->e()Ljava/util/Set;

    move-result-object v4

    .line 388
    iget-object v5, v0, Lx1/a;->o:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v6

    new-array v7, v6, [Z

    .line 389
    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_27
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    const/4 v10, -0x1

    if-eqz v9, :cond_39

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lk6/e;

    .line 390
    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v11

    add-int/2addr v11, v10

    if-ltz v11, :cond_37

    :goto_28
    add-int/lit8 v12, v11, -0x1

    .line 391
    invoke-interface {v5, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    .line 392
    invoke-virtual {v9, v13}, Lk6/e;->c(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_35

    const/16 v22, 0x1

    .line 393
    aput-boolean v22, v7, v11

    move v10, v11

    goto :goto_29

    :cond_35
    if-gez v12, :cond_36

    goto :goto_29

    :cond_36
    move v11, v12

    goto :goto_28

    :cond_37
    :goto_29
    if-ltz v10, :cond_38

    .line 394
    invoke-interface {v5, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    invoke-interface {v3, v9, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_27

    .line 395
    :cond_38
    invoke-virtual {v9}, Lk6/e;->a()Ljava/lang/String;

    move-result-object v0

    const-string v1, ") is missing in the database configuration."

    .line 396
    const-string v2, "A required auto migration spec ("

    invoke-static {v0, v1, v2}, Lja/y0;->i(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    goto/16 :goto_21

    .line 397
    :cond_39
    invoke-interface {v5}, Ljava/util/Collection;->size()I

    move-result v4

    add-int/2addr v4, v10

    if-ltz v4, :cond_3c

    :goto_2a
    add-int/lit8 v5, v4, -0x1

    if-ge v4, v6, :cond_3b

    .line 398
    aget-boolean v4, v7, v4

    if-eqz v4, :cond_3b

    if-gez v5, :cond_3a

    goto :goto_2b

    :cond_3a
    move v4, v5

    goto :goto_2a

    .line 399
    :cond_3b
    const-string v0, "Unexpected auto migration specs found. Annotate AutoMigrationSpec implementation with @ProvidedAutoMigrationSpec annotation or remove this spec from the builder."

    .line 400
    invoke-static {v0}, Lq0/b;->g(Ljava/lang/String;)V

    goto/16 :goto_21

    .line 401
    :cond_3c
    :goto_2b
    invoke-virtual {v8, v3}, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->b(Ljava/util/LinkedHashMap;)Ljava/util/List;

    move-result-object v3

    .line 402
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_3d
    :goto_2c
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_40

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lc4/h;

    .line 403
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 404
    iget-object v5, v0, Lx1/a;->d:Lu/b;

    iget-object v6, v5, Lu/b;->a:Ljava/util/LinkedHashMap;

    .line 405
    invoke-interface {v6, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_3f

    .line 406
    invoke-virtual {v6, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/Map;

    if-nez v6, :cond_3e

    sget-object v6, Lw5/r;->m:Lw5/r;

    .line 407
    :cond_3e
    invoke-interface {v6, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v14

    goto :goto_2d

    :cond_3f
    const/4 v14, 0x0

    :goto_2d
    if-nez v14, :cond_3d

    .line 408
    invoke-virtual {v5, v4}, Lu/b;->a(Lc4/h;)V

    goto :goto_2c

    .line 409
    :cond_40
    invoke-virtual {v8}, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->f()Ljava/util/LinkedHashMap;

    move-result-object v1

    .line 410
    iget-object v2, v0, Lx1/a;->n:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v3

    new-array v3, v3, [Z

    .line 411
    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_41
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_46

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lk6/e;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/List;

    .line 412
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_2e
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_41

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lk6/e;

    .line 413
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v7

    add-int/2addr v7, v10

    if-ltz v7, :cond_44

    :goto_2f
    add-int/lit8 v9, v7, -0x1

    .line 414
    invoke-interface {v2, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    .line 415
    invoke-virtual {v6, v11}, Lk6/e;->c(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_42

    const/16 v22, 0x1

    .line 416
    aput-boolean v22, v3, v7

    goto :goto_31

    :cond_42
    if-gez v9, :cond_43

    goto :goto_30

    :cond_43
    move v7, v9

    goto :goto_2f

    :cond_44
    :goto_30
    move v7, v10

    :goto_31
    if-ltz v7, :cond_45

    .line 417
    invoke-interface {v2, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    .line 418
    iget-object v9, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->j:Ljava/util/LinkedHashMap;

    invoke-interface {v9, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2e

    .line 419
    :cond_45
    invoke-virtual {v6}, Lk6/e;->a()Ljava/lang/String;

    move-result-object v0

    .line 420
    invoke-virtual {v5}, Lk6/e;->a()Ljava/lang/String;

    move-result-object v1

    const-string v2, " is missing in the database configuration."

    .line 421
    const-string v3, "A required type converter ("

    const-string v4, ") for "

    invoke-static {v3, v0, v4, v1, v2}, La4/a;->n(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    goto/16 :goto_21

    .line 422
    :cond_46
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v1

    add-int/2addr v1, v10

    if-ltz v1, :cond_49

    :goto_32
    add-int/lit8 v4, v1, -0x1

    .line 423
    aget-boolean v5, v3, v1

    if-eqz v5, :cond_48

    if-gez v4, :cond_47

    goto :goto_33

    :cond_47
    move v1, v4

    goto :goto_32

    .line 424
    :cond_48
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    .line 425
    const-string v1, "Unexpected type converter "

    const-string v2, ". Annotate TypeConverter class with @ProvidedTypeConverter annotation or remove this converter from the builder."

    .line 426
    invoke-static {v0, v2, v1}, Lu0/b;->h(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    goto/16 :goto_21

    .line 427
    :cond_49
    :goto_33
    iget-object v1, v0, Lx1/a;->h:Ljava/util/concurrent/Executor;

    iput-object v1, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->c:Ljava/util/concurrent/Executor;

    .line 428
    new-instance v1, Lh/m;

    iget-object v2, v0, Lx1/a;->i:Ljava/util/concurrent/Executor;

    invoke-direct {v1, v2}, Lh/m;-><init>(Ljava/util/concurrent/Executor;)V

    iput-object v1, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->d:Lh/m;

    .line 429
    iget-object v1, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->c:Ljava/util/concurrent/Executor;

    if-nez v1, :cond_4a

    const/4 v1, 0x0

    .line 430
    :cond_4a
    instance-of v2, v1, Lt6/z;

    if-eqz v2, :cond_4b

    move-object v2, v1

    check-cast v2, Lt6/z;

    goto :goto_34

    :cond_4b
    const/4 v2, 0x0

    :goto_34
    if-eqz v2, :cond_4c

    iget-object v2, v2, Lt6/z;->m:Lt6/p;

    if-nez v2, :cond_4d

    :cond_4c
    new-instance v2, Lt6/j0;

    invoke-direct {v2, v1}, Lt6/j0;-><init>(Ljava/util/concurrent/Executor;)V

    .line 431
    :cond_4d
    new-instance v1, Lt6/a1;

    const/4 v3, 0x0

    .line 432
    invoke-direct {v1, v3}, Lt6/p0;-><init>(Lt6/v0;)V

    .line 433
    invoke-static {v2, v1}, Lo/r3;->w(Lz5/h;Lz5/h;)Lz5/h;

    move-result-object v1

    .line 434
    new-instance v2, Ly6/c;

    sget-object v4, Lt6/q;->n:Lt6/q;

    invoke-interface {v1, v4}, Lz5/h;->A(Lz5/g;)Lz5/f;

    move-result-object v4

    if-eqz v4, :cond_4e

    goto :goto_35

    .line 435
    :cond_4e
    new-instance v4, Lt6/p0;

    invoke-direct {v4, v3}, Lt6/p0;-><init>(Lt6/v0;)V

    .line 436
    invoke-interface {v1, v4}, Lz5/h;->z(Lz5/h;)Lz5/h;

    move-result-object v1

    :goto_35
    invoke-direct {v2, v1}, Ly6/c;-><init>(Lz5/h;)V

    .line 437
    iput-object v2, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->a:Ly6/c;

    .line 438
    iget-object v3, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->d:Lh/m;

    if-nez v3, :cond_4f

    const/4 v3, 0x0

    .line 439
    :cond_4f
    new-instance v2, Lt6/j0;

    invoke-direct {v2, v3}, Lt6/j0;-><init>(Ljava/util/concurrent/Executor;)V

    .line 440
    invoke-interface {v1, v2}, Lz5/h;->z(Lz5/h;)Lz5/h;

    move-result-object v1

    .line 441
    iput-object v1, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->b:Lz5/h;

    .line 442
    iget-boolean v1, v0, Lx1/a;->f:Z

    iput-boolean v1, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->h:Z

    .line 443
    iget-object v3, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->e:Lt7/k;

    if-nez v3, :cond_50

    const/4 v3, 0x0

    .line 444
    :cond_50
    iget-object v1, v3, Lt7/k;->h:Ljava/lang/Object;

    check-cast v1, Lf2/a;

    if-nez v1, :cond_52

    :cond_51
    const/4 v3, 0x0

    goto :goto_37

    :cond_52
    move-object v3, v1

    .line 445
    :goto_36
    nop

    instance-of v1, v3, La2/b;

    if-eqz v1, :cond_53

    goto :goto_37

    .line 446
    :cond_53
    instance-of v1, v3, Lx1/b;

    if-eqz v1, :cond_51

    .line 447
    check-cast v3, Lx1/b;

    invoke-interface {v3}, Lx1/b;->f()Lf2/a;

    move-result-object v3

    goto :goto_36

    .line 448
    :goto_37
    check-cast v3, La2/b;

    .line 449
    iget-object v3, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->e:Lt7/k;

    if-nez v3, :cond_54

    const/4 v3, 0x0

    .line 450
    :cond_54
    iget-object v1, v3, Lt7/k;->h:Ljava/lang/Object;

    check-cast v1, Lf2/a;

    if-nez v1, :cond_56

    :cond_55
    const/4 v3, 0x0

    goto :goto_39

    :cond_56
    move-object v3, v1

    .line 451
    :goto_38
    nop

    instance-of v1, v3, La2/a;

    if-eqz v1, :cond_57

    goto :goto_39

    .line 452
    :cond_57
    instance-of v1, v3, Lx1/b;

    if-eqz v1, :cond_55

    .line 453
    check-cast v3, Lx1/b;

    invoke-interface {v3}, Lx1/b;->f()Lf2/a;

    move-result-object v3

    goto :goto_38

    .line 454
    :goto_39
    check-cast v3, La2/a;

    .line 455
    iget-object v1, v0, Lx1/a;->j:Landroid/content/Intent;

    if-eqz v1, :cond_5a

    .line 456
    iget-object v2, v0, Lx1/a;->b:Ljava/lang/String;

    if-eqz v2, :cond_59

    .line 457
    iget-object v3, v8, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->f:Lx1/g;

    if-nez v3, :cond_58

    const/4 v12, 0x0

    goto :goto_3a

    :cond_58
    move-object v12, v3

    .line 458
    :goto_3a
    iput-object v1, v12, Lx1/g;->h:Landroid/content/Intent;

    .line 459
    new-instance v1, Lx1/j;

    iget-object v0, v0, Lx1/a;->a:Landroid/content/Context;

    invoke-direct {v1, v0, v2, v12}, Lx1/j;-><init>(Landroid/content/Context;Ljava/lang/String;Lx1/g;)V

    iput-object v1, v12, Lx1/g;->i:Lx1/j;

    goto :goto_3b

    .line 460
    :cond_59
    const-string v0, "Required value was null."

    invoke-static {v0}, Lq0/b;->g(Ljava/lang/String;)V

    goto/16 :goto_21

    .line 461
    :cond_5a
    :goto_3b
    invoke-virtual {v8}, Lcom/topjohnwu/magisk/core/data/SuLogDatabase;->j()Lc4/g;

    move-result-object v12

    goto/16 :goto_3f

    .line 462
    :cond_5b
    new-instance v1, Lt7/k;

    .line 463
    new-instance v2, Lu4/a;

    invoke-direct {v2, v8}, Lu4/a;-><init>(Lcom/topjohnwu/magisk/core/data/SuLogDatabase;)V

    .line 464
    new-instance v6, Lx1/q;

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v7, 0x2

    .line 465
    const-class v9, Lx1/r;

    const-string v10, "compatTransactionCoroutineExecute"

    const-string v11, "compatTransactionCoroutineExecute(Landroidx/room/RoomDatabase;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;"

    const/4 v12, 0x1

    invoke-direct/range {v6 .. v14}, Lx1/q;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V

    .line 466
    invoke-direct {v1, v0, v2, v6}, Lt7/k;-><init>(Lx1/a;Lu4/a;Lx1/q;)V

    const/16 v16, 0x0

    throw v16

    :catch_2
    move-exception v0

    goto :goto_3c

    :catch_3
    move-exception v0

    goto :goto_3d

    :catch_4
    move-exception v0

    goto :goto_3e

    .line 467
    :goto_3c
    new-instance v1, Ljava/lang/RuntimeException;

    invoke-virtual {v4}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Failed to create an instance of "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    .line 468
    :goto_3d
    new-instance v1, Ljava/lang/RuntimeException;

    invoke-virtual {v4}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Cannot access the constructor "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    .line 469
    :goto_3e
    new-instance v1, Ljava/lang/RuntimeException;

    .line 470
    invoke-virtual {v4}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Cannot find implementation for "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ". "

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " does not exist. Is Room annotation processor correctly configured?"

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    .line 471
    invoke-direct {v1, v2, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1

    :cond_5c
    const/16 v16, 0x0

    .line 472
    const-string v0, "Cannot build a database with null or empty name. If you are trying to create an in memory database, use Room.inMemoryDatabaseBuilder"

    .line 473
    invoke-static {v0}, Lq0/b;->g(Ljava/lang/String;)V

    move-object/from16 v12, v16

    :goto_3f
    return-object v12

    .line 474
    :pswitch_14
    invoke-static {}, Le4/b;->a()Landroid/content/Context;

    move-result-object v0

    const-string v1, "su_timeout"

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v5}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    return-object v0

    .line 475
    :pswitch_15
    sget-object v0, La4/d;->m:La4/d;

    invoke-static {v0}, Lf5/d;->f(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v0

    return-object v0

    :pswitch_16
    const/high16 v0, 0x7fff0000

    .line 476
    sget-object v1, Lm6/a;->m:Lm6/a;

    .line 477
    invoke-virtual {v1, v0}, Lm6/a;->b(I)I

    move-result v0

    const/high16 v1, 0x10000

    add-int/2addr v0, v1

    .line 478
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    return-object v0

    .line 479
    :pswitch_17
    :try_start_5
    const-class v0, Landroid/view/inputmethod/InputMethodManager;

    .line 480
    const-string v1, "mServedView"

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    const/4 v15, 0x1

    invoke-virtual {v1, v15}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 481
    const-string v2, "mNextServedView"

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    invoke-virtual {v2, v15}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 482
    const-string v3, "mH"

    invoke-virtual {v0, v3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    invoke-virtual {v0, v15}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 483
    new-instance v3, Lb/v;

    invoke-direct {v3, v0, v1, v2}, Lb/v;-><init>(Ljava/lang/reflect/Field;Ljava/lang/reflect/Field;Ljava/lang/reflect/Field;)V
    :try_end_5
    .catch Ljava/lang/NoSuchFieldException; {:try_start_5 .. :try_end_5} :catch_5

    goto :goto_40

    .line 484
    :catch_5
    sget-object v3, Lb/u;->a:Lb/u;

    :goto_40
    return-object v3

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
