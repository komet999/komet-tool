.class public final Lb4/j;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Ln/x;
.implements Lf3/m;


# static fields
.field public static o:Z


# instance fields
.field public m:Z

.field public final n:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lcom/google/android/material/bottomsheet/BottomSheetBehavior;Z)V
    .locals 0

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb4/j;->n:Ljava/lang/Object;

    iput-boolean p2, p0, Lb4/j;->m:Z

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;)V
    .locals 0

    .line 9
    iput-object p1, p0, Lb4/j;->n:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Z)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-boolean p2, p0, Lb4/j;->m:Z

    .line 5
    .line 6
    iput-object p1, p0, Lb4/j;->n:Ljava/lang/Object;

    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method

.method public constructor <init>(Lr0/e;Z)V
    .locals 0

    .line 10
    invoke-direct {p0, p1}, Lb4/j;-><init>(Ljava/lang/Object;)V

    .line 11
    iput-boolean p2, p0, Lb4/j;->m:Z

    return-void
.end method


# virtual methods
.method public a(Ln/m;Z)V
    .locals 2

    .line 1
    iget-object p2, p0, Lb4/j;->n:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p2, Lh/k0;

    .line 4
    .line 5
    iget-boolean v0, p0, Lb4/j;->m:Z

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    return-void

    .line 10
    :cond_0
    const/4 v0, 0x1

    .line 11
    iput-boolean v0, p0, Lb4/j;->m:Z

    .line 12
    .line 13
    iget-object v0, p2, Lh/k0;->m:Lo/p3;

    .line 14
    .line 15
    iget-object v0, v0, Lo/p3;->a:Landroidx/appcompat/widget/Toolbar;

    .line 16
    .line 17
    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->m:Landroidx/appcompat/widget/ActionMenuView;

    .line 18
    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    iget-object v0, v0, Landroidx/appcompat/widget/ActionMenuView;->F:Lo/k;

    .line 22
    .line 23
    if-eqz v0, :cond_1

    .line 24
    .line 25
    invoke-virtual {v0}, Lo/k;->c()Z

    .line 26
    .line 27
    .line 28
    iget-object v0, v0, Lo/k;->G:Lo/f;

    .line 29
    .line 30
    if-eqz v0, :cond_1

    .line 31
    .line 32
    invoke-virtual {v0}, Ln/w;->b()Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    if-eqz v1, :cond_1

    .line 37
    .line 38
    iget-object v0, v0, Ln/w;->i:Ln/u;

    .line 39
    .line 40
    invoke-interface {v0}, Ln/c0;->dismiss()V

    .line 41
    .line 42
    .line 43
    :cond_1
    iget-object p2, p2, Lh/k0;->n:Landroid/view/Window$Callback;

    .line 44
    .line 45
    const/16 v0, 0x6c

    .line 46
    .line 47
    invoke-interface {p2, v0, p1}, Landroid/view/Window$Callback;->onPanelClosed(ILandroid/view/Menu;)V

    .line 48
    .line 49
    .line 50
    const/4 p1, 0x0

    .line 51
    iput-boolean p1, p0, Lb4/j;->m:Z

    .line 52
    .line 53
    return-void
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method

.method public b()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Lb4/j;->m:Z

    .line 2
    .line 3
    return v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public c(Landroid/view/View;Lt0/t1;Lf3/n;)Lt0/t1;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    iget-object v4, v2, Lt0/t1;->a:Lt0/q1;

    .line 10
    .line 11
    const/16 v5, 0x207

    .line 12
    .line 13
    invoke-virtual {v4, v5}, Lt0/q1;->f(I)Lj0/b;

    .line 14
    .line 15
    .line 16
    move-result-object v5

    .line 17
    const/16 v6, 0x20

    .line 18
    .line 19
    invoke-virtual {v4, v6}, Lt0/q1;->f(I)Lj0/b;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    iget-object v6, v0, Lb4/j;->n:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast v6, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    .line 26
    .line 27
    iget-boolean v7, v6, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->o:Z

    .line 28
    .line 29
    iget v8, v5, Lj0/b;->b:I

    .line 30
    .line 31
    iget v9, v5, Lj0/b;->c:I

    .line 32
    .line 33
    iget v10, v5, Lj0/b;->a:I

    .line 34
    .line 35
    iput v8, v6, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->w:I

    .line 36
    .line 37
    invoke-virtual {v1}, Landroid/view/View;->getLayoutDirection()I

    .line 38
    .line 39
    .line 40
    move-result v8

    .line 41
    const/4 v12, 0x1

    .line 42
    if-ne v8, v12, :cond_0

    .line 43
    .line 44
    move v8, v12

    .line 45
    goto :goto_0

    .line 46
    :cond_0
    const/4 v8, 0x0

    .line 47
    :goto_0
    invoke-virtual {v1}, Landroid/view/View;->getPaddingBottom()I

    .line 48
    .line 49
    .line 50
    move-result v13

    .line 51
    invoke-virtual {v1}, Landroid/view/View;->getPaddingLeft()I

    .line 52
    .line 53
    .line 54
    move-result v14

    .line 55
    invoke-virtual {v1}, Landroid/view/View;->getPaddingRight()I

    .line 56
    .line 57
    .line 58
    move-result v15

    .line 59
    if-eqz v7, :cond_1

    .line 60
    .line 61
    invoke-virtual {v2}, Lt0/t1;->a()I

    .line 62
    .line 63
    .line 64
    move-result v13

    .line 65
    iput v13, v6, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->v:I

    .line 66
    .line 67
    iget v11, v3, Lf3/n;->d:I

    .line 68
    .line 69
    add-int/2addr v13, v11

    .line 70
    :cond_1
    iget-boolean v11, v6, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->p:Z

    .line 71
    .line 72
    if-eqz v11, :cond_3

    .line 73
    .line 74
    if-eqz v8, :cond_2

    .line 75
    .line 76
    iget v11, v3, Lf3/n;->c:I

    .line 77
    .line 78
    goto :goto_1

    .line 79
    :cond_2
    iget v11, v3, Lf3/n;->a:I

    .line 80
    .line 81
    :goto_1
    add-int v14, v11, v10

    .line 82
    .line 83
    :cond_3
    iget-boolean v11, v6, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->q:Z

    .line 84
    .line 85
    if-eqz v11, :cond_5

    .line 86
    .line 87
    if-eqz v8, :cond_4

    .line 88
    .line 89
    iget v3, v3, Lf3/n;->a:I

    .line 90
    .line 91
    goto :goto_2

    .line 92
    :cond_4
    iget v3, v3, Lf3/n;->c:I

    .line 93
    .line 94
    :goto_2
    add-int v15, v3, v9

    .line 95
    .line 96
    :cond_5
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    check-cast v3, Landroid/view/ViewGroup$MarginLayoutParams;

    .line 101
    .line 102
    iget-boolean v8, v6, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->s:Z

    .line 103
    .line 104
    if-eqz v8, :cond_6

    .line 105
    .line 106
    iget v8, v3, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 107
    .line 108
    if-eq v8, v10, :cond_6

    .line 109
    .line 110
    iput v10, v3, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 111
    .line 112
    move v11, v12

    .line 113
    goto :goto_3

    .line 114
    :cond_6
    const/4 v11, 0x0

    .line 115
    :goto_3
    iget-boolean v8, v6, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->t:Z

    .line 116
    .line 117
    if-eqz v8, :cond_7

    .line 118
    .line 119
    iget v8, v3, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 120
    .line 121
    if-eq v8, v9, :cond_7

    .line 122
    .line 123
    iput v9, v3, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 124
    .line 125
    move v11, v12

    .line 126
    :cond_7
    iget-boolean v8, v6, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->u:Z

    .line 127
    .line 128
    if-eqz v8, :cond_8

    .line 129
    .line 130
    iget v8, v3, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 131
    .line 132
    iget v5, v5, Lj0/b;->b:I

    .line 133
    .line 134
    if-eq v8, v5, :cond_8

    .line 135
    .line 136
    iput v5, v3, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 137
    .line 138
    goto :goto_4

    .line 139
    :cond_8
    move v12, v11

    .line 140
    :goto_4
    if-eqz v12, :cond_9

    .line 141
    .line 142
    invoke-virtual {v1, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 143
    .line 144
    .line 145
    :cond_9
    invoke-virtual {v1}, Landroid/view/View;->getPaddingTop()I

    .line 146
    .line 147
    .line 148
    move-result v3

    .line 149
    invoke-virtual {v1, v14, v3, v15, v13}, Landroid/view/View;->setPadding(IIII)V

    .line 150
    .line 151
    .line 152
    iget-boolean v1, v0, Lb4/j;->m:Z

    .line 153
    .line 154
    if-eqz v1, :cond_a

    .line 155
    .line 156
    iget v3, v4, Lj0/b;->d:I

    .line 157
    .line 158
    iput v3, v6, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->m:I

    .line 159
    .line 160
    :cond_a
    if-nez v7, :cond_c

    .line 161
    .line 162
    if-eqz v1, :cond_b

    .line 163
    .line 164
    goto :goto_5

    .line 165
    :cond_b
    return-object v2

    .line 166
    :cond_c
    :goto_5
    invoke-virtual {v6}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->J()V

    .line 167
    .line 168
    .line 169
    return-object v2
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
.end method

.method public d(Landroid/os/Bundle;)V
    .locals 12

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Lb4/j;->m:Z

    .line 3
    .line 4
    iget-object v1, p0, Lb4/j;->n:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v1, Lcom/topjohnwu/magisk/ui/MainActivity;

    .line 7
    .line 8
    iget-object v2, v1, Lcom/topjohnwu/magisk/ui/MainActivity;->N:Lv5/i;

    .line 9
    .line 10
    invoke-virtual {v1}, Lz3/h;->A()V

    .line 11
    .line 12
    .line 13
    const v3, 0x104000a

    .line 14
    .line 15
    .line 16
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    sget-object v4, La4/n;->h:La4/k;

    .line 21
    .line 22
    iget-boolean v4, v4, La4/k;->d:Z

    .line 23
    .line 24
    const/4 v5, 0x1

    .line 25
    if-eqz v4, :cond_0

    .line 26
    .line 27
    new-instance v4, Lg5/f;

    .line 28
    .line 29
    invoke-direct {v4, v1}, Lg5/f;-><init>(Landroid/app/Activity;)V

    .line 30
    .line 31
    .line 32
    const v6, 0x7f110189

    .line 33
    .line 34
    .line 35
    invoke-virtual {v4, v6}, Lg5/f;->setTitle(I)V

    .line 36
    .line 37
    .line 38
    new-array v6, v5, [Ljava/lang/Object;

    .line 39
    .line 40
    const-string v7, "v22.0"

    .line 41
    .line 42
    aput-object v7, v6, v0

    .line 43
    .line 44
    const v7, 0x7f110188

    .line 45
    .line 46
    .line 47
    invoke-virtual {v4, v7, v6}, Lg5/f;->h(I[Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    iget-object v6, v4, Lg5/f;->t:Lg5/c;

    .line 51
    .line 52
    iget-object v6, v6, Lg5/c;->p:Lg5/b;

    .line 53
    .line 54
    invoke-virtual {v6, v3}, Lg5/b;->c(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v4, v0}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v4}, Landroid/app/Dialog;->show()V

    .line 61
    .line 62
    .line 63
    :cond_0
    sget-boolean v4, La4/n;->q:Z

    .line 64
    .line 65
    const v6, 0x7f110187

    .line 66
    .line 67
    .line 68
    if-nez v4, :cond_5

    .line 69
    .line 70
    sget-object v4, La4/n;->h:La4/k;

    .line 71
    .line 72
    iget-boolean v4, v4, La4/k;->e:Z

    .line 73
    .line 74
    if-eqz v4, :cond_5

    .line 75
    .line 76
    const-string v4, "PATH"

    .line 77
    .line 78
    invoke-static {v4}, Ljava/lang/System;->getenv(Ljava/lang/String;)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    if-eqz v4, :cond_5

    .line 83
    .line 84
    new-array v7, v5, [C

    .line 85
    .line 86
    const/16 v8, 0x3a

    .line 87
    .line 88
    aput-char v8, v7, v0

    .line 89
    .line 90
    invoke-static {v4, v7}, Lr6/i;->f0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    .line 91
    .line 92
    .line 93
    move-result-object v4

    .line 94
    new-instance v7, Ljava/util/ArrayList;

    .line 95
    .line 96
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 97
    .line 98
    .line 99
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 100
    .line 101
    .line 102
    move-result-object v4

    .line 103
    :cond_1
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 104
    .line 105
    .line 106
    move-result v8

    .line 107
    if-eqz v8, :cond_2

    .line 108
    .line 109
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v8

    .line 113
    move-object v9, v8

    .line 114
    check-cast v9, Ljava/lang/String;

    .line 115
    .line 116
    new-instance v10, Ljava/io/File;

    .line 117
    .line 118
    new-instance v11, Ljava/lang/StringBuilder;

    .line 119
    .line 120
    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 124
    .line 125
    .line 126
    const-string v9, "/magisk"

    .line 127
    .line 128
    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 129
    .line 130
    .line 131
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v9

    .line 135
    invoke-direct {v10, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {v10}, Ljava/io/File;->exists()Z

    .line 139
    .line 140
    .line 141
    move-result v9

    .line 142
    if-nez v9, :cond_1

    .line 143
    .line 144
    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 145
    .line 146
    .line 147
    goto :goto_0

    .line 148
    :cond_2
    invoke-virtual {v7}, Ljava/util/ArrayList;->isEmpty()Z

    .line 149
    .line 150
    .line 151
    move-result v4

    .line 152
    if-eqz v4, :cond_3

    .line 153
    .line 154
    goto :goto_1

    .line 155
    :cond_3
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 156
    .line 157
    .line 158
    move-result v4

    .line 159
    move v8, v0

    .line 160
    :cond_4
    if-ge v8, v4, :cond_5

    .line 161
    .line 162
    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v9

    .line 166
    add-int/lit8 v8, v8, 0x1

    .line 167
    .line 168
    check-cast v9, Ljava/lang/String;

    .line 169
    .line 170
    new-instance v10, Ljava/io/File;

    .line 171
    .line 172
    new-instance v11, Ljava/lang/StringBuilder;

    .line 173
    .line 174
    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    .line 175
    .line 176
    .line 177
    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 178
    .line 179
    .line 180
    const-string v9, "/su"

    .line 181
    .line 182
    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 183
    .line 184
    .line 185
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 186
    .line 187
    .line 188
    move-result-object v9

    .line 189
    invoke-direct {v10, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 190
    .line 191
    .line 192
    invoke-virtual {v10}, Ljava/io/File;->exists()Z

    .line 193
    .line 194
    .line 195
    move-result v9

    .line 196
    if-eqz v9, :cond_4

    .line 197
    .line 198
    new-instance v4, Lg5/f;

    .line 199
    .line 200
    invoke-direct {v4, v1}, Lg5/f;-><init>(Landroid/app/Activity;)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {v4, v6}, Lg5/f;->setTitle(I)V

    .line 204
    .line 205
    .line 206
    const v7, 0x7f11018c

    .line 207
    .line 208
    .line 209
    new-array v8, v0, [Ljava/lang/Object;

    .line 210
    .line 211
    invoke-virtual {v4, v7, v8}, Lg5/f;->h(I[Ljava/lang/Object;)V

    .line 212
    .line 213
    .line 214
    iget-object v7, v4, Lg5/f;->t:Lg5/c;

    .line 215
    .line 216
    iget-object v7, v7, Lg5/c;->p:Lg5/b;

    .line 217
    .line 218
    invoke-virtual {v7, v3}, Lg5/b;->c(Ljava/lang/Object;)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v4, v0}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 222
    .line 223
    .line 224
    invoke-virtual {v4}, Landroid/app/Dialog;->show()V

    .line 225
    .line 226
    .line 227
    :cond_5
    :goto_1
    invoke-virtual {v1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 228
    .line 229
    .line 230
    move-result-object v4

    .line 231
    iget v4, v4, Landroid/content/pm/ApplicationInfo;->flags:I

    .line 232
    .line 233
    and-int/2addr v4, v5

    .line 234
    if-eqz v4, :cond_6

    .line 235
    .line 236
    new-instance v4, Lg5/f;

    .line 237
    .line 238
    invoke-direct {v4, v1}, Lg5/f;-><init>(Landroid/app/Activity;)V

    .line 239
    .line 240
    .line 241
    invoke-virtual {v4, v6}, Lg5/f;->setTitle(I)V

    .line 242
    .line 243
    .line 244
    const v7, 0x7f11018d

    .line 245
    .line 246
    .line 247
    new-array v8, v0, [Ljava/lang/Object;

    .line 248
    .line 249
    invoke-virtual {v4, v7, v8}, Lg5/f;->h(I[Ljava/lang/Object;)V

    .line 250
    .line 251
    .line 252
    iget-object v7, v4, Lg5/f;->t:Lg5/c;

    .line 253
    .line 254
    iget-object v7, v7, Lg5/c;->p:Lg5/b;

    .line 255
    .line 256
    invoke-virtual {v7, v3}, Lg5/b;->c(Ljava/lang/Object;)V

    .line 257
    .line 258
    .line 259
    invoke-virtual {v4, v0}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 260
    .line 261
    .line 262
    invoke-virtual {v4}, Landroid/app/Dialog;->show()V

    .line 263
    .line 264
    .line 265
    :cond_6
    invoke-virtual {v1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    .line 266
    .line 267
    .line 268
    move-result-object v4

    .line 269
    iget v4, v4, Landroid/content/pm/ApplicationInfo;->flags:I

    .line 270
    .line 271
    const/high16 v7, 0x40000

    .line 272
    .line 273
    and-int/2addr v4, v7

    .line 274
    if-eqz v4, :cond_7

    .line 275
    .line 276
    new-instance v4, Lg5/f;

    .line 277
    .line 278
    invoke-direct {v4, v1}, Lg5/f;-><init>(Landroid/app/Activity;)V

    .line 279
    .line 280
    .line 281
    invoke-virtual {v4, v6}, Lg5/f;->setTitle(I)V

    .line 282
    .line 283
    .line 284
    const v6, 0x7f110186

    .line 285
    .line 286
    .line 287
    new-array v7, v0, [Ljava/lang/Object;

    .line 288
    .line 289
    invoke-virtual {v4, v6, v7}, Lg5/f;->h(I[Ljava/lang/Object;)V

    .line 290
    .line 291
    .line 292
    iget-object v6, v4, Lg5/f;->t:Lg5/c;

    .line 293
    .line 294
    iget-object v6, v6, Lg5/c;->p:Lg5/b;

    .line 295
    .line 296
    invoke-virtual {v6, v3}, Lg5/b;->c(Ljava/lang/Object;)V

    .line 297
    .line 298
    .line 299
    invoke-virtual {v4, v0}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 300
    .line 301
    .line 302
    invoke-virtual {v4}, Landroid/app/Dialog;->show()V

    .line 303
    .line 304
    .line 305
    :cond_7
    invoke-static {}, La4/f;->a()Z

    .line 306
    .line 307
    .line 308
    move-result v4

    .line 309
    if-eqz v4, :cond_8

    .line 310
    .line 311
    sget-object v4, La4/g;->a:La4/g;

    .line 312
    .line 313
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 314
    .line 315
    .line 316
    sget-object v6, La4/g;->g:Lk4/a;

    .line 317
    .line 318
    sget-object v7, La4/g;->b:[Lp6/b;

    .line 319
    .line 320
    aget-object v8, v7, v0

    .line 321
    .line 322
    invoke-virtual {v6, v4, v8}, Lk4/a;->u0(La4/g;Lp6/b;)Ljava/lang/Boolean;

    .line 323
    .line 324
    .line 325
    move-result-object v8

    .line 326
    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    .line 327
    .line 328
    .line 329
    move-result v8

    .line 330
    if-nez v8, :cond_8

    .line 331
    .line 332
    invoke-static {v1}, Lf5/d;->p(Landroid/content/Context;)Z

    .line 333
    .line 334
    .line 335
    move-result v8

    .line 336
    if-eqz v8, :cond_8

    .line 337
    .line 338
    aget-object v7, v7, v0

    .line 339
    .line 340
    invoke-virtual {v6, v4, v7, v5}, Lk4/a;->v0(La4/g;Lp6/b;Z)V

    .line 341
    .line 342
    .line 343
    new-instance v4, Lg5/f;

    .line 344
    .line 345
    invoke-direct {v4, v1}, Lg5/f;-><init>(Landroid/app/Activity;)V

    .line 346
    .line 347
    .line 348
    const v6, 0x7f11001c

    .line 349
    .line 350
    .line 351
    invoke-virtual {v4, v6}, Lg5/f;->setTitle(I)V

    .line 352
    .line 353
    .line 354
    const v6, 0x7f11001b

    .line 355
    .line 356
    .line 357
    new-array v7, v0, [Ljava/lang/Object;

    .line 358
    .line 359
    invoke-virtual {v4, v6, v7}, Lg5/f;->h(I[Ljava/lang/Object;)V

    .line 360
    .line 361
    .line 362
    iget-object v6, v4, Lg5/f;->t:Lg5/c;

    .line 363
    .line 364
    iget-object v7, v6, Lg5/c;->r:Lg5/b;

    .line 365
    .line 366
    const/high16 v8, 0x1040000

    .line 367
    .line 368
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 369
    .line 370
    .line 371
    move-result-object v8

    .line 372
    invoke-virtual {v7, v8}, Lg5/b;->c(Ljava/lang/Object;)V

    .line 373
    .line 374
    .line 375
    iget-object v6, v6, Lg5/c;->p:Lg5/b;

    .line 376
    .line 377
    invoke-virtual {v6, v3}, Lg5/b;->c(Ljava/lang/Object;)V

    .line 378
    .line 379
    .line 380
    new-instance v3, La5/b;

    .line 381
    .line 382
    const/16 v7, 0xe

    .line 383
    .line 384
    invoke-direct {v3, v7, v1}, La5/b;-><init>(ILjava/lang/Object;)V

    .line 385
    .line 386
    .line 387
    iput-object v3, v6, Lg5/b;->q:Lj6/l;

    .line 388
    .line 389
    invoke-virtual {v4, v5}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 390
    .line 391
    .line 392
    invoke-virtual {v4}, Landroid/app/Dialog;->show()V

    .line 393
    .line 394
    .line 395
    :cond_8
    sget-object v3, La4/g;->a:La4/g;

    .line 396
    .line 397
    invoke-virtual {v3}, La4/g;->a()Z

    .line 398
    .line 399
    .line 400
    move-result v3

    .line 401
    if-eqz v3, :cond_9

    .line 402
    .line 403
    new-instance v3, Lu4/a;

    .line 404
    .line 405
    invoke-direct {v3, v0}, Lu4/a;-><init>(I)V

    .line 406
    .line 407
    .line 408
    const-string v4, "android.permission.POST_NOTIFICATIONS"

    .line 409
    .line 410
    invoke-virtual {v1, v4, v3}, Lz3/h;->B(Ljava/lang/String;Lj6/l;)V

    .line 411
    .line 412
    .line 413
    :cond_9
    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 414
    .line 415
    .line 416
    move-result-object v3

    .line 417
    const/16 v4, 0x10

    .line 418
    .line 419
    invoke-virtual {v3, v4}, Landroid/view/Window;->setSoftInputMode(I)V

    .line 420
    .line 421
    .line 422
    invoke-virtual {v2}, Lv5/i;->getValue()Ljava/lang/Object;

    .line 423
    .line 424
    .line 425
    move-result-object v3

    .line 426
    check-cast v3, Landroidx/navigation/fragment/NavHostFragment;

    .line 427
    .line 428
    iget-object v3, v3, Landroidx/navigation/fragment/NavHostFragment;->i0:Lv5/i;

    .line 429
    .line 430
    invoke-virtual {v3}, Lv5/i;->getValue()Ljava/lang/Object;

    .line 431
    .line 432
    .line 433
    move-result-object v3

    .line 434
    check-cast v3, Lp1/z;

    .line 435
    .line 436
    new-instance v4, Lu4/b;

    .line 437
    .line 438
    invoke-direct {v4, v1}, Lu4/b;-><init>(Lcom/topjohnwu/magisk/ui/MainActivity;)V

    .line 439
    .line 440
    .line 441
    iget-object v3, v3, Lp1/z;->b:Ls1/h;

    .line 442
    .line 443
    iget-object v6, v3, Ls1/h;->o:Ljava/util/ArrayList;

    .line 444
    .line 445
    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 446
    .line 447
    .line 448
    iget-object v3, v3, Ls1/h;->f:Lw5/h;

    .line 449
    .line 450
    invoke-virtual {v3}, Lw5/h;->isEmpty()Z

    .line 451
    .line 452
    .line 453
    move-result v6

    .line 454
    if-nez v6, :cond_a

    .line 455
    .line 456
    invoke-virtual {v3}, Lw5/h;->last()Ljava/lang/Object;

    .line 457
    .line 458
    .line 459
    move-result-object v3

    .line 460
    check-cast v3, Lp1/h;

    .line 461
    .line 462
    iget-object v6, v3, Lp1/h;->n:Lp1/v;

    .line 463
    .line 464
    iget-object v3, v3, Lp1/h;->t:Ls1/c;

    .line 465
    .line 466
    invoke-virtual {v3}, Ls1/c;->a()Landroid/os/Bundle;

    .line 467
    .line 468
    .line 469
    invoke-virtual {v4, v6}, Lu4/b;->a(Lp1/v;)V

    .line 470
    .line 471
    .line 472
    :cond_a
    iget-object v3, v1, Lz3/h;->L:Lb1/w;

    .line 473
    .line 474
    const/4 v4, 0x0

    .line 475
    if-eqz v3, :cond_b

    .line 476
    .line 477
    goto :goto_2

    .line 478
    :cond_b
    move-object v3, v4

    .line 479
    :goto_2
    check-cast v3, Lp4/a;

    .line 480
    .line 481
    iget-object v3, v3, Lp4/a;->J:Lcom/google/android/material/appbar/MaterialToolbar;

    .line 482
    .line 483
    invoke-virtual {v1}, Lh/i;->o()Lh/o;

    .line 484
    .line 485
    .line 486
    move-result-object v6

    .line 487
    check-cast v6, Lh/c0;

    .line 488
    .line 489
    iget-object v7, v6, Lh/c0;->v:Ljava/lang/Object;

    .line 490
    .line 491
    instance-of v7, v7, Landroid/app/Activity;

    .line 492
    .line 493
    if-nez v7, :cond_c

    .line 494
    .line 495
    goto :goto_5

    .line 496
    :cond_c
    invoke-virtual {v6}, Lh/c0;->C()V

    .line 497
    .line 498
    .line 499
    iget-object v7, v6, Lh/c0;->A:La/a;

    .line 500
    .line 501
    instance-of v8, v7, Lh/p0;

    .line 502
    .line 503
    if-nez v8, :cond_21

    .line 504
    .line 505
    iput-object v4, v6, Lh/c0;->B:Lm/h;

    .line 506
    .line 507
    if-eqz v7, :cond_d

    .line 508
    .line 509
    invoke-virtual {v7}, La/a;->N()V

    .line 510
    .line 511
    .line 512
    :cond_d
    iput-object v4, v6, Lh/c0;->A:La/a;

    .line 513
    .line 514
    if-eqz v3, :cond_f

    .line 515
    .line 516
    new-instance v7, Lh/k0;

    .line 517
    .line 518
    iget-object v8, v6, Lh/c0;->v:Ljava/lang/Object;

    .line 519
    .line 520
    instance-of v9, v8, Landroid/app/Activity;

    .line 521
    .line 522
    if-eqz v9, :cond_e

    .line 523
    .line 524
    check-cast v8, Landroid/app/Activity;

    .line 525
    .line 526
    invoke-virtual {v8}, Landroid/app/Activity;->getTitle()Ljava/lang/CharSequence;

    .line 527
    .line 528
    .line 529
    move-result-object v8

    .line 530
    goto :goto_3

    .line 531
    :cond_e
    iget-object v8, v6, Lh/c0;->C:Ljava/lang/CharSequence;

    .line 532
    .line 533
    :goto_3
    iget-object v9, v6, Lh/c0;->y:Lh/w;

    .line 534
    .line 535
    invoke-direct {v7, v3, v8, v9}, Lh/k0;-><init>(Lcom/google/android/material/appbar/MaterialToolbar;Ljava/lang/CharSequence;Lh/w;)V

    .line 536
    .line 537
    .line 538
    iput-object v7, v6, Lh/c0;->A:La/a;

    .line 539
    .line 540
    iget-object v8, v6, Lh/c0;->y:Lh/w;

    .line 541
    .line 542
    iget-object v7, v7, Lh/k0;->o:Lh/j0;

    .line 543
    .line 544
    iput-object v7, v8, Lh/w;->n:Lh/j0;

    .line 545
    .line 546
    invoke-virtual {v3, v5}, Landroidx/appcompat/widget/Toolbar;->setBackInvokedCallbackEnabled(Z)V

    .line 547
    .line 548
    .line 549
    goto :goto_4

    .line 550
    :cond_f
    iget-object v3, v6, Lh/c0;->y:Lh/w;

    .line 551
    .line 552
    iput-object v4, v3, Lh/w;->n:Lh/j0;

    .line 553
    .line 554
    :goto_4
    invoke-virtual {v6}, Lh/c0;->c()V

    .line 555
    .line 556
    .line 557
    :goto_5
    iget-object v3, v1, Lz3/h;->L:Lb1/w;

    .line 558
    .line 559
    if-eqz v3, :cond_10

    .line 560
    .line 561
    goto :goto_6

    .line 562
    :cond_10
    move-object v3, v4

    .line 563
    :goto_6
    check-cast v3, Lp4/a;

    .line 564
    .line 565
    iget-object v3, v3, Lp4/a;->I:Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;

    .line 566
    .line 567
    new-instance v6, Lb/b0;

    .line 568
    .line 569
    const/4 v7, 0x7

    .line 570
    invoke-direct {v6, v7, v1}, Lb/b0;-><init>(ILjava/lang/Object;)V

    .line 571
    .line 572
    .line 573
    invoke-virtual {v3, v6}, Li3/r;->setOnItemSelectedListener(Li3/p;)V

    .line 574
    .line 575
    .line 576
    iget-object v3, v1, Lz3/h;->L:Lb1/w;

    .line 577
    .line 578
    if-eqz v3, :cond_11

    .line 579
    .line 580
    goto :goto_7

    .line 581
    :cond_11
    move-object v3, v4

    .line 582
    :goto_7
    check-cast v3, Lp4/a;

    .line 583
    .line 584
    iget-object v3, v3, Lp4/a;->I:Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;

    .line 585
    .line 586
    new-instance v6, Lu0/b;

    .line 587
    .line 588
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 589
    .line 590
    .line 591
    invoke-virtual {v3, v6}, Li3/r;->setOnItemReselectedListener(Li3/o;)V

    .line 592
    .line 593
    .line 594
    iget-object v3, v1, Lz3/h;->L:Lb1/w;

    .line 595
    .line 596
    if-eqz v3, :cond_12

    .line 597
    .line 598
    goto :goto_8

    .line 599
    :cond_12
    move-object v3, v4

    .line 600
    :goto_8
    check-cast v3, Lp4/a;

    .line 601
    .line 602
    iget-object v3, v3, Lp4/a;->I:Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;

    .line 603
    .line 604
    invoke-virtual {v3}, Li3/r;->getMenu()Landroid/view/Menu;

    .line 605
    .line 606
    .line 607
    move-result-object v3

    .line 608
    const v6, 0x7f09024e

    .line 609
    .line 610
    .line 611
    invoke-interface {v3, v6}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    .line 612
    .line 613
    .line 614
    move-result-object v6

    .line 615
    if-eqz v6, :cond_13

    .line 616
    .line 617
    sget-object v7, La4/n;->a:La4/n;

    .line 618
    .line 619
    invoke-static {}, La4/n;->b()Z

    .line 620
    .line 621
    .line 622
    move-result v7

    .line 623
    invoke-interface {v6, v7}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    .line 624
    .line 625
    .line 626
    :cond_13
    const v6, 0x7f09018d

    .line 627
    .line 628
    .line 629
    invoke-interface {v3, v6}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    .line 630
    .line 631
    .line 632
    move-result-object v3

    .line 633
    if-eqz v3, :cond_15

    .line 634
    .line 635
    sget-object v6, La4/n;->h:La4/k;

    .line 636
    .line 637
    iget-boolean v6, v6, La4/k;->e:Z

    .line 638
    .line 639
    if-eqz v6, :cond_14

    .line 640
    .line 641
    sget-object v6, Lo4/v;->d:Lo4/s;

    .line 642
    .line 643
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 644
    .line 645
    .line 646
    invoke-static {}, Lo4/s;->a()Ll5/b;

    .line 647
    .line 648
    .line 649
    move-result-object v6

    .line 650
    const-string v7, "/data/adb/modules"

    .line 651
    .line 652
    invoke-virtual {v6, v7}, Ll5/b;->a(Ljava/lang/String;)Ll5/a;

    .line 653
    .line 654
    .line 655
    move-result-object v6

    .line 656
    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    .line 657
    .line 658
    .line 659
    move-result v6

    .line 660
    if-eqz v6, :cond_14

    .line 661
    .line 662
    move v6, v5

    .line 663
    goto :goto_9

    .line 664
    :cond_14
    move v6, v0

    .line 665
    :goto_9
    invoke-interface {v3, v6}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    .line 666
    .line 667
    .line 668
    :cond_15
    invoke-virtual {v1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 669
    .line 670
    .line 671
    move-result-object v3

    .line 672
    invoke-virtual {v3}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 673
    .line 674
    .line 675
    move-result-object v3

    .line 676
    const-string v6, "android.intent.action.APPLICATION_PREFERENCES"

    .line 677
    .line 678
    invoke-static {v3, v6}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 679
    .line 680
    .line 681
    move-result v3

    .line 682
    const-string v6, "settings"

    .line 683
    .line 684
    if-eqz v3, :cond_16

    .line 685
    .line 686
    move-object v3, v6

    .line 687
    goto :goto_a

    .line 688
    :cond_16
    invoke-virtual {v1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 689
    .line 690
    .line 691
    move-result-object v3

    .line 692
    const-string v7, "section"

    .line 693
    .line 694
    invoke-virtual {v3, v7}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 695
    .line 696
    .line 697
    move-result-object v3

    .line 698
    :goto_a
    if-eqz v3, :cond_1d

    .line 699
    .line 700
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 701
    .line 702
    .line 703
    move-result v7

    .line 704
    const v8, -0x13c7da3a

    .line 705
    .line 706
    .line 707
    if-eq v7, v8, :cond_1b

    .line 708
    .line 709
    const v8, 0x49292787

    .line 710
    .line 711
    .line 712
    if-eq v7, v8, :cond_19

    .line 713
    .line 714
    const v8, 0x5582bc23

    .line 715
    .line 716
    .line 717
    if-eq v7, v8, :cond_17

    .line 718
    .line 719
    goto :goto_b

    .line 720
    :cond_17
    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 721
    .line 722
    .line 723
    move-result v3

    .line 724
    if-nez v3, :cond_18

    .line 725
    .line 726
    goto :goto_b

    .line 727
    :cond_18
    new-instance v4, Lp1/a;

    .line 728
    .line 729
    const v3, 0x7f090044

    .line 730
    .line 731
    .line 732
    invoke-direct {v4, v3}, Lp1/a;-><init>(I)V

    .line 733
    .line 734
    .line 735
    goto :goto_b

    .line 736
    :cond_19
    const-string v6, "modules"

    .line 737
    .line 738
    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 739
    .line 740
    .line 741
    move-result v3

    .line 742
    if-nez v3, :cond_1a

    .line 743
    .line 744
    goto :goto_b

    .line 745
    :cond_1a
    new-instance v4, Lp1/a;

    .line 746
    .line 747
    const v3, 0x7f09004c

    .line 748
    .line 749
    .line 750
    invoke-direct {v4, v3}, Lp1/a;-><init>(I)V

    .line 751
    .line 752
    .line 753
    goto :goto_b

    .line 754
    :cond_1b
    const-string v6, "superuser"

    .line 755
    .line 756
    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 757
    .line 758
    .line 759
    move-result v3

    .line 760
    if-nez v3, :cond_1c

    .line 761
    .line 762
    goto :goto_b

    .line 763
    :cond_1c
    new-instance v4, Lp1/a;

    .line 764
    .line 765
    const v3, 0x7f09005c

    .line 766
    .line 767
    .line 768
    invoke-direct {v4, v3}, Lp1/a;-><init>(I)V

    .line 769
    .line 770
    .line 771
    :cond_1d
    :goto_b
    if-eqz v4, :cond_1e

    .line 772
    .line 773
    invoke-virtual {v2}, Lv5/i;->getValue()Ljava/lang/Object;

    .line 774
    .line 775
    .line 776
    move-result-object v2

    .line 777
    check-cast v2, Landroidx/navigation/fragment/NavHostFragment;

    .line 778
    .line 779
    iget-object v2, v2, Landroidx/navigation/fragment/NavHostFragment;->i0:Lv5/i;

    .line 780
    .line 781
    invoke-virtual {v2}, Lv5/i;->getValue()Ljava/lang/Object;

    .line 782
    .line 783
    .line 784
    move-result-object v2

    .line 785
    check-cast v2, Lp1/z;

    .line 786
    .line 787
    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 788
    .line 789
    .line 790
    move-result-object v3

    .line 791
    invoke-static {v4, v2, v3}, Lo2/b;->x(Lp1/w;Lp1/z;Landroid/content/ContentResolver;)V

    .line 792
    .line 793
    .line 794
    :cond_1e
    iget-boolean v2, v1, Lcom/topjohnwu/magisk/ui/MainActivity;->S:Z

    .line 795
    .line 796
    if-nez v2, :cond_20

    .line 797
    .line 798
    if-nez p1, :cond_1f

    .line 799
    .line 800
    move p1, v5

    .line 801
    goto :goto_c

    .line 802
    :cond_1f
    move p1, v0

    .line 803
    :goto_c
    invoke-static {v1, v0, p1, v5}, Lcom/topjohnwu/magisk/ui/MainActivity;->D(Lcom/topjohnwu/magisk/ui/MainActivity;ZZI)V

    .line 804
    .line 805
    .line 806
    :cond_20
    return-void

    .line 807
    :cond_21
    const-string p1, "This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead."

    .line 808
    .line 809
    invoke-static {p1}, Lq0/b;->m(Ljava/lang/String;)V

    .line 810
    .line 811
    .line 812
    return-void
    .line 813
    .line 814
    .line 815
    .line 816
    .line 817
    .line 818
    .line 819
    .line 820
    .line 821
    .line 822
    .line 823
    .line 824
    .line 825
    .line 826
    .line 827
    .line 828
    .line 829
    .line 830
    .line 831
    .line 832
    .line 833
    .line 834
    .line 835
    .line 836
    .line 837
    .line 838
    .line 839
    .line 840
    .line 841
    .line 842
    .line 843
    .line 844
    .line 845
    .line 846
    .line 847
    .line 848
    .line 849
    .line 850
    .line 851
    .line 852
    .line 853
    .line 854
    .line 855
    .line 856
    .line 857
    .line 858
    .line 859
    .line 860
    .line 861
    .line 862
    .line 863
    .line 864
    .line 865
    .line 866
    .line 867
    .line 868
    .line 869
    .line 870
    .line 871
    .line 872
    .line 873
    .line 874
    .line 875
    .line 876
    .line 877
    .line 878
    .line 879
    .line 880
    .line 881
    .line 882
    .line 883
    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    .line 889
    .line 890
    .line 891
    .line 892
    .line 893
    .line 894
    .line 895
    .line 896
    .line 897
    .line 898
    .line 899
    .line 900
    .line 901
    .line 902
    .line 903
    .line 904
    .line 905
    .line 906
    .line 907
    .line 908
    .line 909
    .line 910
    .line 911
    .line 912
    .line 913
    .line 914
    .line 915
    .line 916
    .line 917
    .line 918
    .line 919
    .line 920
    .line 921
    .line 922
    .line 923
    .line 924
    .line 925
    .line 926
    .line 927
    .line 928
    .line 929
    .line 930
    .line 931
    .line 932
    .line 933
    .line 934
    .line 935
    .line 936
    .line 937
    .line 938
    .line 939
    .line 940
    .line 941
    .line 942
    .line 943
    .line 944
    .line 945
    .line 946
    .line 947
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
.end method

.method public e(ILjava/lang/CharSequence;)Z
    .locals 6

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p2, :cond_6

    .line 3
    .line 4
    if-ltz p1, :cond_6

    .line 5
    .line 6
    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    sub-int/2addr v1, p1

    .line 11
    if-ltz v1, :cond_6

    .line 12
    .line 13
    iget-object v1, p0, Lb4/j;->n:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, Lr0/e;

    .line 16
    .line 17
    if-nez v1, :cond_0

    .line 18
    .line 19
    invoke-virtual {p0}, Lb4/j;->b()Z

    .line 20
    .line 21
    .line 22
    move-result p1

    .line 23
    return p1

    .line 24
    :cond_0
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    const/4 v1, 0x2

    .line 28
    move v2, v0

    .line 29
    move v3, v1

    .line 30
    :goto_0
    const/4 v4, 0x1

    .line 31
    if-ge v2, p1, :cond_3

    .line 32
    .line 33
    if-ne v3, v1, :cond_3

    .line 34
    .line 35
    invoke-interface {p2, v2}, Ljava/lang/CharSequence;->charAt(I)C

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    invoke-static {v3}, Ljava/lang/Character;->getDirectionality(C)B

    .line 40
    .line 41
    .line 42
    move-result v3

    .line 43
    sget-object v5, Lr0/f;->a:Lb4/j;

    .line 44
    .line 45
    if-eqz v3, :cond_2

    .line 46
    .line 47
    if-eq v3, v4, :cond_1

    .line 48
    .line 49
    if-eq v3, v1, :cond_1

    .line 50
    .line 51
    packed-switch v3, :pswitch_data_0

    .line 52
    .line 53
    .line 54
    move v3, v1

    .line 55
    goto :goto_1

    .line 56
    :cond_1
    :pswitch_0
    move v3, v0

    .line 57
    goto :goto_1

    .line 58
    :cond_2
    :pswitch_1
    move v3, v4

    .line 59
    :goto_1
    add-int/lit8 v2, v2, 0x1

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_3
    if-eqz v3, :cond_5

    .line 63
    .line 64
    if-eq v3, v4, :cond_4

    .line 65
    .line 66
    invoke-virtual {p0}, Lb4/j;->b()Z

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    return p1

    .line 71
    :cond_4
    return v0

    .line 72
    :cond_5
    return v4

    .line 73
    :cond_6
    invoke-static {}, Lq0/b;->k()V

    .line 74
    .line 75
    .line 76
    return v0

    .line 77
    :pswitch_data_0
    .packed-switch 0xe
        :pswitch_1
        :pswitch_1
        :pswitch_0
        :pswitch_0
    .end packed-switch
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method

.method public f(Ln/m;)Z
    .locals 2

    .line 1
    iget-object v0, p0, Lb4/j;->n:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lh/k0;

    .line 4
    .line 5
    iget-object v0, v0, Lh/k0;->n:Landroid/view/Window$Callback;

    .line 6
    .line 7
    const/16 v1, 0x6c

    .line 8
    .line 9
    invoke-interface {v0, v1, p1}, Landroid/view/Window$Callback;->onMenuOpened(ILandroid/view/Menu;)Z

    .line 10
    .line 11
    .line 12
    const/4 p1, 0x1

    .line 13
    return p1
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method
