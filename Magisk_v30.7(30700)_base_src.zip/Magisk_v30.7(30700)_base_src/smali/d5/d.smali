.class public final Ld5/d;
.super Landroid/os/CountDownTimer;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# instance fields
.field public final a:J

.field public final synthetic b:Ld5/f;


# direct methods
.method public constructor <init>(Ld5/f;J)V
    .locals 2

    .line 1
    iput-object p1, p0, Ld5/d;->b:Ld5/f;

    .line 2
    .line 3
    const-wide/16 v0, 0x3e8

    .line 4
    .line 5
    invoke-direct {p0, p2, p3, v0, v1}, Landroid/os/CountDownTimer;-><init>(JJ)V

    .line 6
    .line 7
    .line 8
    iput-wide p2, p0, Ld5/d;->a:J

    .line 9
    .line 10
    return-void
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method


# virtual methods
.method public final onFinish()V
    .locals 4

    .line 1
    iget-object v0, p0, Ld5/d;->b:Ld5/f;

    .line 2
    .line 3
    iget-object v1, v0, Ld5/f;->t:Ld5/b;

    .line 4
    .line 5
    iget-object v2, v1, Ld5/b;->c:Ld5/f;

    .line 6
    .line 7
    iget v3, v1, Ld5/b;->b:I

    .line 8
    .line 9
    if-eqz v3, :cond_0

    .line 10
    .line 11
    const/4 v3, 0x0

    .line 12
    iput v3, v1, Ld5/b;->b:I

    .line 13
    .line 14
    const/4 v1, 0x7

    .line 15
    invoke-static {v2, v1}, Lb/m;->c(Lp4/x0;I)V

    .line 16
    .line 17
    .line 18
    :cond_0
    const/4 v1, 0x1

    .line 19
    invoke-virtual {v0, v1}, Ld5/f;->p(I)V

    .line 20
    .line 21
    .line 22
    return-void
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final onTick(J)V
    .locals 8

    .line 1
    iget-object v0, p0, Ld5/d;->b:Ld5/f;

    .line 2
    .line 3
    iget-boolean v1, v0, Ld5/f;->v:Z

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    const/16 v3, 0x3e8

    .line 7
    .line 8
    if-nez v1, :cond_0

    .line 9
    .line 10
    iget-wide v4, p0, Ld5/d;->a:J

    .line 11
    .line 12
    int-to-long v6, v3

    .line 13
    sub-long/2addr v4, v6

    .line 14
    cmp-long v4, p1, v4

    .line 15
    .line 16
    if-gtz v4, :cond_0

    .line 17
    .line 18
    if-eq v1, v2, :cond_0

    .line 19
    .line 20
    iput-boolean v2, v0, Ld5/f;->v:Z

    .line 21
    .line 22
    const/16 v1, 0xd

    .line 23
    .line 24
    invoke-static {v0, v1}, Lb/m;->c(Lp4/x0;I)V

    .line 25
    .line 26
    .line 27
    :cond_0
    iget-object v0, v0, Ld5/f;->t:Ld5/b;

    .line 28
    .line 29
    int-to-long v3, v3

    .line 30
    div-long/2addr p1, v3

    .line 31
    long-to-int p1, p1

    .line 32
    add-int/2addr p1, v2

    .line 33
    iget-object p2, v0, Ld5/b;->c:Ld5/f;

    .line 34
    .line 35
    iget v1, v0, Ld5/b;->b:I

    .line 36
    .line 37
    if-eq v1, p1, :cond_1

    .line 38
    .line 39
    iput p1, v0, Ld5/b;->b:I

    .line 40
    .line 41
    const/4 p1, 0x7

    .line 42
    invoke-static {p2, p1}, Lb/m;->c(Lp4/x0;I)V

    .line 43
    .line 44
    .line 45
    :cond_1
    return-void
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method
