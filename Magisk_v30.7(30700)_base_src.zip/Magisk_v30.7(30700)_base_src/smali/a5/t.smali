.class public final La5/t;
.super Lz3/b;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# static fields
.field public static final v:Lk1/y;


# instance fields
.field public final q:[I

.field public final r:Lp4/l;

.field public final s:Lp4/w0;

.field public final t:Landroid/util/SparseArray;

.field public u:Z


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Lk1/y;

    .line 2
    .line 3
    invoke-direct {v0}, Lk1/y;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, La5/t;->v:Lk1/y;

    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Lz3/b;-><init>()V

    .line 2
    .line 3
    .line 4
    const v0, 0x7f09018b

    .line 5
    .line 6
    .line 7
    const v1, 0x7f090188

    .line 8
    .line 9
    .line 10
    filled-new-array {v0, v1}, [I

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iput-object v0, p0, La5/t;->q:[I

    .line 15
    .line 16
    new-instance v0, Lp4/l;

    .line 17
    .line 18
    invoke-direct {v0}, Lp4/l;-><init>()V

    .line 19
    .line 20
    .line 21
    iput-object v0, p0, La5/t;->r:Lp4/l;

    .line 22
    .line 23
    new-instance v0, Lp4/w0;

    .line 24
    .line 25
    invoke-direct {v0}, Lp4/w0;-><init>()V

    .line 26
    .line 27
    .line 28
    iput-object v0, p0, La5/t;->s:Lp4/w0;

    .line 29
    .line 30
    new-instance v0, Landroid/util/SparseArray;

    .line 31
    .line 32
    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    .line 33
    .line 34
    .line 35
    const/16 v1, 0x2c

    .line 36
    .line 37
    invoke-virtual {v0, v1, p0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 38
    .line 39
    .line 40
    iput-object v0, p0, La5/t;->t:Landroid/util/SparseArray;

    .line 41
    .line 42
    const/4 v0, 0x1

    .line 43
    iput-boolean v0, p0, La5/t;->u:Z

    .line 44
    .line 45
    return-void
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method


# virtual methods
.method public final j()V
    .locals 0

    .line 1
    invoke-virtual {p0}, Lz3/b;->q()V

    .line 2
    .line 3
    .line 4
    return-void
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final p(Lb6/c;)Ljava/lang/Object;
    .locals 10

    .line 1
    instance-of v0, p1, La5/p;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, La5/p;

    .line 7
    .line 8
    iget v1, v0, La5/p;->s:I

    .line 9
    .line 10
    const/high16 v2, -0x80000000

    .line 11
    .line 12
    and-int v3, v1, v2

    .line 13
    .line 14
    if-eqz v3, :cond_0

    .line 15
    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, La5/p;->s:I

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :cond_0
    new-instance v0, La5/p;

    .line 21
    .line 22
    invoke-direct {v0, p0, p1}, La5/p;-><init>(La5/t;Lb6/c;)V

    .line 23
    .line 24
    .line 25
    :goto_0
    iget-object p1, v0, La5/p;->q:Ljava/lang/Object;

    .line 26
    .line 27
    iget v1, v0, La5/p;->s:I

    .line 28
    .line 29
    const/16 v2, 0x16

    .line 30
    .line 31
    const/4 v3, 0x0

    .line 32
    const/4 v4, 0x3

    .line 33
    sget-object v5, Lv5/k;->a:Lv5/k;

    .line 34
    .line 35
    const/4 v6, 0x0

    .line 36
    const/4 v7, 0x2

    .line 37
    const/4 v8, 0x1

    .line 38
    sget-object v9, La6/a;->m:La6/a;

    .line 39
    .line 40
    if-eqz v1, :cond_4

    .line 41
    .line 42
    if-eq v1, v8, :cond_3

    .line 43
    .line 44
    if-eq v1, v7, :cond_2

    .line 45
    .line 46
    if-ne v1, v4, :cond_1

    .line 47
    .line 48
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    return-object v5

    .line 52
    :cond_1
    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 53
    .line 54
    invoke-static {p1}, Lq0/b;->m(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    return-object v6

    .line 58
    :cond_2
    iget v1, v0, La5/p;->p:I

    .line 59
    .line 60
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    goto :goto_4

    .line 64
    :cond_3
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    goto :goto_1

    .line 68
    :cond_4
    invoke-static {p1}, Lo/r3;->E(Ljava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    iget-boolean p1, p0, La5/t;->u:Z

    .line 72
    .line 73
    if-eq p1, v8, :cond_5

    .line 74
    .line 75
    iput-boolean v8, p0, La5/t;->u:Z

    .line 76
    .line 77
    invoke-static {p0, v2}, Lb/m;->c(Lp4/x0;I)V

    .line 78
    .line 79
    .line 80
    :cond_5
    sget-object p1, La4/n;->h:La4/k;

    .line 81
    .line 82
    iget-boolean p1, p1, La4/k;->e:Z

    .line 83
    .line 84
    if-eqz p1, :cond_7

    .line 85
    .line 86
    sget-object p1, Lt6/a0;->a:La7/d;

    .line 87
    .line 88
    sget-object p1, La7/c;->n:La7/c;

    .line 89
    .line 90
    new-instance v1, La4/c;

    .line 91
    .line 92
    invoke-direct {v1, v7, v6, v8}, La4/c;-><init>(ILz5/d;I)V

    .line 93
    .line 94
    .line 95
    iput v8, v0, La5/p;->s:I

    .line 96
    .line 97
    invoke-static {p1, v1, v0}, Lt6/t;->o(Lz5/h;Lj6/p;Lz5/d;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    if-ne p1, v9, :cond_6

    .line 102
    .line 103
    goto :goto_6

    .line 104
    :cond_6
    :goto_1
    check-cast p1, Ljava/lang/Boolean;

    .line 105
    .line 106
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 107
    .line 108
    .line 109
    move-result p1

    .line 110
    if-eqz p1, :cond_7

    .line 111
    .line 112
    goto :goto_2

    .line 113
    :cond_7
    move v8, v3

    .line 114
    :goto_2
    if-eqz v8, :cond_b

    .line 115
    .line 116
    iput v8, v0, La5/p;->p:I

    .line 117
    .line 118
    iput v7, v0, La5/p;->s:I

    .line 119
    .line 120
    sget-object p1, Lt6/a0;->a:La7/d;

    .line 121
    .line 122
    new-instance v1, La5/r;

    .line 123
    .line 124
    invoke-direct {v1, p0, v6, v3}, La5/r;-><init>(Ljava/lang/Object;Lz5/d;I)V

    .line 125
    .line 126
    .line 127
    invoke-static {p1, v1, v0}, Lt6/t;->o(Lz5/h;Lj6/p;Lz5/d;)Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object p1

    .line 131
    if-ne p1, v9, :cond_8

    .line 132
    .line 133
    goto :goto_3

    .line 134
    :cond_8
    move-object p1, v5

    .line 135
    :goto_3
    if-ne p1, v9, :cond_9

    .line 136
    .line 137
    goto :goto_6

    .line 138
    :cond_9
    move v1, v8

    .line 139
    :goto_4
    iget-object p1, p0, La5/t;->s:Lp4/w0;

    .line 140
    .line 141
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 142
    .line 143
    .line 144
    move-result v7

    .line 145
    if-eqz v7, :cond_a

    .line 146
    .line 147
    invoke-virtual {p1}, Lp4/w0;->d()V

    .line 148
    .line 149
    .line 150
    iget-object v7, p0, La5/t;->r:Lp4/l;

    .line 151
    .line 152
    invoke-virtual {p1, v7}, Lp4/w0;->f(Ljava/util/AbstractList;)V

    .line 153
    .line 154
    .line 155
    :cond_a
    move v8, v1

    .line 156
    :cond_b
    iget-boolean p1, p0, La5/t;->u:Z

    .line 157
    .line 158
    if-eqz p1, :cond_c

    .line 159
    .line 160
    iput-boolean v3, p0, La5/t;->u:Z

    .line 161
    .line 162
    invoke-static {p0, v2}, Lb/m;->c(Lp4/x0;I)V

    .line 163
    .line 164
    .line 165
    :cond_c
    iput v8, v0, La5/p;->p:I

    .line 166
    .line 167
    iput v4, v0, La5/p;->s:I

    .line 168
    .line 169
    sget-object p1, Lt6/a0;->a:La7/d;

    .line 170
    .line 171
    sget-object p1, La7/c;->n:La7/c;

    .line 172
    .line 173
    new-instance v1, La5/s;

    .line 174
    .line 175
    invoke-direct {v1, p0, v6}, La5/s;-><init>(La5/t;Lz5/d;)V

    .line 176
    .line 177
    .line 178
    invoke-static {p1, v1, v0}, Lt6/t;->o(Lz5/h;Lj6/p;Lz5/d;)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object p1

    .line 182
    if-ne p1, v9, :cond_d

    .line 183
    .line 184
    goto :goto_5

    .line 185
    :cond_d
    move-object p1, v5

    .line 186
    :goto_5
    if-ne p1, v9, :cond_e

    .line 187
    .line 188
    :goto_6
    return-object v9

    .line 189
    :cond_e
    return-object v5
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method
