.class public final La5/h;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Lj6/l;


# instance fields
.field public final synthetic m:I

.field public final synthetic n:Lz3/f;

.field public final synthetic o:Lz3/f;


# direct methods
.method public synthetic constructor <init>(Lz3/f;Lz3/f;I)V
    .locals 0

    .line 1
    iput p3, p0, La5/h;->m:I

    .line 2
    .line 3
    iput-object p1, p0, La5/h;->n:Lz3/f;

    .line 4
    .line 5
    iput-object p2, p0, La5/h;->o:Lz3/f;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
.end method


# virtual methods
.method public final j(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget v0, p0, La5/h;->m:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v3, 0x0

    .line 6
    sget-object v4, Lv5/k;->a:Lv5/k;

    .line 7
    .line 8
    const v5, 0x7f110046

    .line 9
    .line 10
    .line 11
    iget-object v6, p0, La5/h;->n:Lz3/f;

    .line 12
    .line 13
    iget-object v7, p0, La5/h;->o:Lz3/f;

    .line 14
    .line 15
    packed-switch v0, :pswitch_data_0

    .line 16
    .line 17
    .line 18
    check-cast p1, Ljava/lang/Boolean;

    .line 19
    .line 20
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 21
    .line 22
    .line 23
    move-result p1

    .line 24
    check-cast v7, Lz4/c;

    .line 25
    .line 26
    if-nez p1, :cond_0

    .line 27
    .line 28
    check-cast v6, Lz4/c;

    .line 29
    .line 30
    new-instance p1, Lr4/g;

    .line 31
    .line 32
    invoke-direct {p1, v5}, Lr4/g;-><init>(I)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v6, p1}, Lz3/f;->m(Lz3/j;)V

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_0
    invoke-static {v7}, Lk1/g0;->f(Lk1/m0;)Ln1/a;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    sget-object v0, Lt6/a0;->a:La7/d;

    .line 44
    .line 45
    sget-object v0, La7/c;->n:La7/c;

    .line 46
    .line 47
    new-instance v1, Lc4/c;

    .line 48
    .line 49
    const/4 v5, 0x4

    .line 50
    invoke-direct {v1, v7, v3, v5}, Lc4/c;-><init>(Ljava/lang/Object;Lz5/d;I)V

    .line 51
    .line 52
    .line 53
    invoke-static {p1, v0, v1, v2}, Lt6/t;->g(Lt6/s;Lz5/h;Lj6/p;I)Lt6/z0;

    .line 54
    .line 55
    .line 56
    :goto_0
    return-object v4

    .line 57
    :pswitch_0
    check-cast p1, Ljava/lang/Boolean;

    .line 58
    .line 59
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 60
    .line 61
    .line 62
    move-result p1

    .line 63
    check-cast v7, Lw4/e;

    .line 64
    .line 65
    if-nez p1, :cond_1

    .line 66
    .line 67
    check-cast v6, Lw4/e;

    .line 68
    .line 69
    new-instance p1, Lr4/g;

    .line 70
    .line 71
    invoke-direct {p1, v5}, Lr4/g;-><init>(I)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {v6, p1}, Lz3/f;->m(Lz3/j;)V

    .line 75
    .line 76
    .line 77
    goto :goto_1

    .line 78
    :cond_1
    invoke-static {v7}, Lk1/g0;->f(Lk1/m0;)Ln1/a;

    .line 79
    .line 80
    .line 81
    move-result-object p1

    .line 82
    sget-object v0, Lt6/a0;->a:La7/d;

    .line 83
    .line 84
    sget-object v0, La7/c;->n:La7/c;

    .line 85
    .line 86
    new-instance v1, Lc4/c;

    .line 87
    .line 88
    const/4 v5, 0x3

    .line 89
    invoke-direct {v1, v7, v3, v5}, Lc4/c;-><init>(Ljava/lang/Object;Lz5/d;I)V

    .line 90
    .line 91
    .line 92
    invoke-static {p1, v0, v1, v2}, Lt6/t;->g(Lt6/s;Lz5/h;Lj6/p;I)Lt6/z0;

    .line 93
    .line 94
    .line 95
    :goto_1
    return-object v4

    .line 96
    :pswitch_1
    check-cast p1, Ljava/lang/Boolean;

    .line 97
    .line 98
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 99
    .line 100
    .line 101
    move-result p1

    .line 102
    if-nez p1, :cond_2

    .line 103
    .line 104
    new-instance p1, Lr4/g;

    .line 105
    .line 106
    invoke-direct {p1, v5}, Lr4/g;-><init>(I)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v6, p1}, Lz3/f;->m(Lz3/j;)V

    .line 110
    .line 111
    .line 112
    goto :goto_2

    .line 113
    :cond_2
    check-cast v7, La5/t;

    .line 114
    .line 115
    new-instance p1, Lr4/e;

    .line 116
    .line 117
    new-instance v0, La5/o;

    .line 118
    .line 119
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 120
    .line 121
    .line 122
    const-string v2, "application/zip"

    .line 123
    .line 124
    invoke-direct {p1, v1, v0, v2}, Lr4/e;-><init>(ILjava/lang/Object;Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    invoke-virtual {v7, p1}, Lz3/f;->m(Lz3/j;)V

    .line 128
    .line 129
    .line 130
    :goto_2
    return-object v4

    .line 131
    :pswitch_2
    check-cast p1, Ljava/lang/Boolean;

    .line 132
    .line 133
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 134
    .line 135
    .line 136
    move-result p1

    .line 137
    check-cast v7, La5/j;

    .line 138
    .line 139
    if-nez p1, :cond_3

    .line 140
    .line 141
    check-cast v6, La5/j;

    .line 142
    .line 143
    new-instance p1, Lr4/g;

    .line 144
    .line 145
    invoke-direct {p1, v5}, Lr4/g;-><init>(I)V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v6, p1}, Lz3/f;->m(Lz3/j;)V

    .line 149
    .line 150
    .line 151
    goto :goto_3

    .line 152
    :cond_3
    invoke-static {v7}, Lk1/g0;->f(Lk1/m0;)Ln1/a;

    .line 153
    .line 154
    .line 155
    move-result-object p1

    .line 156
    sget-object v0, Lt6/a0;->a:La7/d;

    .line 157
    .line 158
    sget-object v0, La7/c;->n:La7/c;

    .line 159
    .line 160
    new-instance v5, La5/i;

    .line 161
    .line 162
    invoke-direct {v5, v7, v3, v1}, La5/i;-><init>(La5/j;Lz5/d;I)V

    .line 163
    .line 164
    .line 165
    invoke-static {p1, v0, v5, v2}, Lt6/t;->g(Lt6/s;Lz5/h;Lj6/p;I)Lt6/z0;

    .line 166
    .line 167
    .line 168
    :goto_3
    return-object v4

    .line 169
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method
