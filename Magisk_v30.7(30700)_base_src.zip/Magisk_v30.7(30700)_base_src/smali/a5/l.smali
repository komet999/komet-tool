.class public final La5/l;
.super Lp4/z0;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Lp4/j;
.implements Lp4/v0;


# instance fields
.field public final n:Li4/b;

.field public final o:Z

.field public final p:Z

.field public final q:Lf5/f;

.field public r:Z

.field public s:Z

.field public final t:Z


# direct methods
.method public constructor <init>(Li4/b;)V
    .locals 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La5/l;->n:Li4/b;

    .line 5
    .line 6
    iget-boolean v0, p1, Li4/b;->B:Z

    .line 7
    .line 8
    iget-boolean v1, p1, Li4/b;->A:Z

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    const/4 v3, 0x1

    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    iget-boolean v4, p1, Li4/b;->C:Z

    .line 15
    .line 16
    if-eqz v4, :cond_0

    .line 17
    .line 18
    move v4, v3

    .line 19
    goto :goto_0

    .line 20
    :cond_0
    move v4, v2

    .line 21
    :goto_0
    if-nez v4, :cond_3

    .line 22
    .line 23
    sget-boolean v5, La4/n;->n:Z

    .line 24
    .line 25
    if-eqz v5, :cond_1

    .line 26
    .line 27
    if-nez v1, :cond_3

    .line 28
    .line 29
    :cond_1
    if-nez v5, :cond_2

    .line 30
    .line 31
    if-eqz v0, :cond_2

    .line 32
    .line 33
    goto :goto_1

    .line 34
    :cond_2
    move v0, v2

    .line 35
    goto :goto_2

    .line 36
    :cond_3
    :goto_1
    move v0, v3

    .line 37
    :goto_2
    iput-boolean v0, p0, La5/l;->o:Z

    .line 38
    .line 39
    iget-boolean v5, p1, Li4/b;->D:Z

    .line 40
    .line 41
    if-eqz v5, :cond_4

    .line 42
    .line 43
    if-nez v0, :cond_4

    .line 44
    .line 45
    move v0, v3

    .line 46
    goto :goto_3

    .line 47
    :cond_4
    move v0, v2

    .line 48
    :goto_3
    iput-boolean v0, p0, La5/l;->p:Z

    .line 49
    .line 50
    if-eqz v4, :cond_5

    .line 51
    .line 52
    new-instance v0, Lf5/f;

    .line 53
    .line 54
    const v1, 0x7f110197

    .line 55
    .line 56
    .line 57
    invoke-direct {v0, v1}, Lf5/f;-><init>(I)V

    .line 58
    .line 59
    .line 60
    goto :goto_5

    .line 61
    :cond_5
    const v0, 0x7f110196

    .line 62
    .line 63
    .line 64
    if-eqz v1, :cond_6

    .line 65
    .line 66
    new-instance v1, Lf5/f;

    .line 67
    .line 68
    invoke-direct {v1, v0}, Lf5/f;-><init>(I)V

    .line 69
    .line 70
    .line 71
    new-array v0, v3, [Ljava/lang/Object;

    .line 72
    .line 73
    aput-object v1, v0, v2

    .line 74
    .line 75
    new-instance v1, Lf5/g;

    .line 76
    .line 77
    invoke-static {v0, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    const v2, 0x7f110179

    .line 82
    .line 83
    .line 84
    invoke-direct {v1, v2, v0}, Lf5/g;-><init>(I[Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    :goto_4
    move-object v0, v1

    .line 88
    goto :goto_5

    .line 89
    :cond_6
    new-instance v1, Lf5/f;

    .line 90
    .line 91
    invoke-direct {v1, v0}, Lf5/f;-><init>(I)V

    .line 92
    .line 93
    .line 94
    new-array v0, v3, [Ljava/lang/Object;

    .line 95
    .line 96
    aput-object v1, v0, v2

    .line 97
    .line 98
    new-instance v1, Lf5/g;

    .line 99
    .line 100
    invoke-static {v0, v3}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    const v2, 0x7f11017a

    .line 105
    .line 106
    .line 107
    invoke-direct {v1, v2, v0}, Lf5/g;-><init>(I[Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    goto :goto_4

    .line 111
    :goto_5
    iput-object v0, p0, La5/l;->q:Lf5/f;

    .line 112
    .line 113
    iget-object v0, p1, Li4/b;->x:Ll5/a;

    .line 114
    .line 115
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 116
    .line 117
    .line 118
    move-result v0

    .line 119
    xor-int/2addr v0, v3

    .line 120
    iput-boolean v0, p0, La5/l;->r:Z

    .line 121
    .line 122
    iget-object v0, p1, Li4/b;->w:Ll5/a;

    .line 123
    .line 124
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    iput-boolean v0, p0, La5/l;->s:Z

    .line 129
    .line 130
    iget-object p1, p1, Li4/b;->y:Ll5/a;

    .line 131
    .line 132
    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    .line 133
    .line 134
    .line 135
    move-result p1

    .line 136
    iput-boolean p1, p0, La5/l;->t:Z

    .line 137
    .line 138
    return-void
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method


# virtual methods
.method public final bridge synthetic a(Lp4/j;)Z
    .locals 0

    .line 1
    check-cast p1, La5/l;

    .line 2
    .line 3
    const/4 p1, 0x1

    .line 4
    return p1
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method

.method public final g(Lp4/j;)Z
    .locals 1

    .line 1
    check-cast p1, La5/l;

    .line 2
    .line 3
    iget-object v0, p0, La5/l;->n:Li4/b;

    .line 4
    .line 5
    iget-object v0, v0, Li4/b;->n:Ljava/lang/String;

    .line 6
    .line 7
    iget-object p1, p1, La5/l;->n:Li4/b;

    .line 8
    .line 9
    iget-object p1, p1, Li4/b;->n:Ljava/lang/String;

    .line 10
    .line 11
    invoke-static {v0, p1}, Lk6/i;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    return p1
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method

.method public final getItem()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, La5/l;->n:Li4/b;

    .line 2
    .line 3
    return-object v0
    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final h()I
    .locals 1

    .line 1
    const v0, 0x7f0c004c

    .line 2
    .line 3
    .line 4
    return v0
    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method
