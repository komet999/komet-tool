.class public final La5/n;
.super Ljava/lang/Object;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, La5/n;->a:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 8

    .line 1
    iget v0, p0, La5/n;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 7
    .line 8
    .line 9
    new-instance p1, Ly4/b;

    .line 10
    .line 11
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 12
    .line 13
    .line 14
    return-object p1

    .line 15
    :pswitch_0
    new-instance v0, Ly4/a;

    .line 16
    .line 17
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    const/4 v4, 0x0

    .line 30
    const/4 v5, 0x1

    .line 31
    if-eqz v3, :cond_0

    .line 32
    .line 33
    move v3, v5

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    move v3, v4

    .line 36
    :goto_0
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 37
    .line 38
    .line 39
    move-result v6

    .line 40
    if-eqz v6, :cond_1

    .line 41
    .line 42
    move v6, v4

    .line 43
    move v4, v5

    .line 44
    goto :goto_1

    .line 45
    :cond_1
    move v6, v4

    .line 46
    :goto_1
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    if-eqz p1, :cond_2

    .line 51
    .line 52
    goto :goto_2

    .line 53
    :cond_2
    move v5, v6

    .line 54
    :goto_2
    invoke-direct/range {v0 .. v5}, Ly4/a;-><init>(IIZZZ)V

    .line 55
    .line 56
    .line 57
    return-object v0

    .line 58
    :pswitch_1
    new-instance v0, Ly2/b;

    .line 59
    .line 60
    invoke-direct {v0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 61
    .line 62
    .line 63
    const-class v1, Ly2/b;

    .line 64
    .line 65
    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readValue(Ljava/lang/ClassLoader;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object p1

    .line 73
    check-cast p1, Ljava/lang/Integer;

    .line 74
    .line 75
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 76
    .line 77
    .line 78
    move-result p1

    .line 79
    iput p1, v0, Ly2/b;->m:I

    .line 80
    .line 81
    return-object v0

    .line 82
    :pswitch_2
    new-instance v0, Lw1/i1;

    .line 83
    .line 84
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 85
    .line 86
    .line 87
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 88
    .line 89
    .line 90
    move-result v1

    .line 91
    iput v1, v0, Lw1/i1;->m:I

    .line 92
    .line 93
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 94
    .line 95
    .line 96
    move-result v1

    .line 97
    iput v1, v0, Lw1/i1;->n:I

    .line 98
    .line 99
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 100
    .line 101
    .line 102
    move-result v1

    .line 103
    iput v1, v0, Lw1/i1;->o:I

    .line 104
    .line 105
    if-lez v1, :cond_3

    .line 106
    .line 107
    new-array v1, v1, [I

    .line 108
    .line 109
    iput-object v1, v0, Lw1/i1;->p:[I

    .line 110
    .line 111
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readIntArray([I)V

    .line 112
    .line 113
    .line 114
    :cond_3
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 115
    .line 116
    .line 117
    move-result v1

    .line 118
    iput v1, v0, Lw1/i1;->q:I

    .line 119
    .line 120
    if-lez v1, :cond_4

    .line 121
    .line 122
    new-array v1, v1, [I

    .line 123
    .line 124
    iput-object v1, v0, Lw1/i1;->r:[I

    .line 125
    .line 126
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readIntArray([I)V

    .line 127
    .line 128
    .line 129
    :cond_4
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 130
    .line 131
    .line 132
    move-result v1

    .line 133
    const/4 v2, 0x0

    .line 134
    const/4 v3, 0x1

    .line 135
    if-ne v1, v3, :cond_5

    .line 136
    .line 137
    move v1, v3

    .line 138
    goto :goto_3

    .line 139
    :cond_5
    move v1, v2

    .line 140
    :goto_3
    iput-boolean v1, v0, Lw1/i1;->t:Z

    .line 141
    .line 142
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 143
    .line 144
    .line 145
    move-result v1

    .line 146
    if-ne v1, v3, :cond_6

    .line 147
    .line 148
    move v1, v3

    .line 149
    goto :goto_4

    .line 150
    :cond_6
    move v1, v2

    .line 151
    :goto_4
    iput-boolean v1, v0, Lw1/i1;->u:Z

    .line 152
    .line 153
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 154
    .line 155
    .line 156
    move-result v1

    .line 157
    if-ne v1, v3, :cond_7

    .line 158
    .line 159
    move v2, v3

    .line 160
    :cond_7
    iput-boolean v2, v0, Lw1/i1;->v:Z

    .line 161
    .line 162
    const-class v1, Lw1/h1;

    .line 163
    .line 164
    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readArrayList(Ljava/lang/ClassLoader;)Ljava/util/ArrayList;

    .line 169
    .line 170
    .line 171
    move-result-object p1

    .line 172
    iput-object p1, v0, Lw1/i1;->s:Ljava/util/ArrayList;

    .line 173
    .line 174
    return-object v0

    .line 175
    :pswitch_3
    new-instance v0, Lw1/h1;

    .line 176
    .line 177
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 178
    .line 179
    .line 180
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 181
    .line 182
    .line 183
    move-result v1

    .line 184
    iput v1, v0, Lw1/h1;->m:I

    .line 185
    .line 186
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 187
    .line 188
    .line 189
    move-result v1

    .line 190
    iput v1, v0, Lw1/h1;->n:I

    .line 191
    .line 192
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 193
    .line 194
    .line 195
    move-result v1

    .line 196
    const/4 v2, 0x1

    .line 197
    if-ne v1, v2, :cond_8

    .line 198
    .line 199
    goto :goto_5

    .line 200
    :cond_8
    const/4 v2, 0x0

    .line 201
    :goto_5
    iput-boolean v2, v0, Lw1/h1;->p:Z

    .line 202
    .line 203
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 204
    .line 205
    .line 206
    move-result v1

    .line 207
    if-lez v1, :cond_9

    .line 208
    .line 209
    new-array v1, v1, [I

    .line 210
    .line 211
    iput-object v1, v0, Lw1/h1;->o:[I

    .line 212
    .line 213
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readIntArray([I)V

    .line 214
    .line 215
    .line 216
    :cond_9
    return-object v0

    .line 217
    :pswitch_4
    new-instance v0, Lw1/y;

    .line 218
    .line 219
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 220
    .line 221
    .line 222
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 223
    .line 224
    .line 225
    move-result v1

    .line 226
    iput v1, v0, Lw1/y;->m:I

    .line 227
    .line 228
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 229
    .line 230
    .line 231
    move-result v1

    .line 232
    iput v1, v0, Lw1/y;->n:I

    .line 233
    .line 234
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 235
    .line 236
    .line 237
    move-result p1

    .line 238
    const/4 v1, 0x1

    .line 239
    if-ne p1, v1, :cond_a

    .line 240
    .line 241
    goto :goto_6

    .line 242
    :cond_a
    const/4 v1, 0x0

    .line 243
    :goto_6
    iput-boolean v1, v0, Lw1/y;->o:Z

    .line 244
    .line 245
    return-object v0

    .line 246
    :pswitch_5
    new-instance v0, Lw0/g;

    .line 247
    .line 248
    invoke-direct {v0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 249
    .line 250
    .line 251
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 252
    .line 253
    .line 254
    move-result p1

    .line 255
    iput p1, v0, Lw0/g;->m:I

    .line 256
    .line 257
    return-object v0

    .line 258
    :pswitch_6
    new-instance v0, Lq4/h;

    .line 259
    .line 260
    const-class v1, Lq4/h;

    .line 261
    .line 262
    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 263
    .line 264
    .line 265
    move-result-object v1

    .line 266
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    .line 267
    .line 268
    .line 269
    move-result-object v1

    .line 270
    check-cast v1, Li4/d;

    .line 271
    .line 272
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 273
    .line 274
    .line 275
    move-result v2

    .line 276
    if-eqz v2, :cond_b

    .line 277
    .line 278
    const/4 v2, 0x1

    .line 279
    goto :goto_7

    .line 280
    :cond_b
    const/4 v2, 0x0

    .line 281
    :goto_7
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 282
    .line 283
    .line 284
    move-result p1

    .line 285
    invoke-direct {v0, v1, v2, p1}, Lq4/h;-><init>(Li4/d;ZI)V

    .line 286
    .line 287
    .line 288
    return-object v0

    .line 289
    :pswitch_7
    new-instance v0, Lq2/b;

    .line 290
    .line 291
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 292
    .line 293
    .line 294
    const/16 v1, 0xff

    .line 295
    .line 296
    iput v1, v0, Lq2/b;->u:I

    .line 297
    .line 298
    const/4 v1, -0x2

    .line 299
    iput v1, v0, Lq2/b;->w:I

    .line 300
    .line 301
    iput v1, v0, Lq2/b;->x:I

    .line 302
    .line 303
    iput v1, v0, Lq2/b;->y:I

    .line 304
    .line 305
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 306
    .line 307
    iput-object v1, v0, Lq2/b;->F:Ljava/lang/Boolean;

    .line 308
    .line 309
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 310
    .line 311
    .line 312
    move-result v1

    .line 313
    iput v1, v0, Lq2/b;->m:I

    .line 314
    .line 315
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 316
    .line 317
    .line 318
    move-result-object v1

    .line 319
    check-cast v1, Ljava/lang/Integer;

    .line 320
    .line 321
    iput-object v1, v0, Lq2/b;->n:Ljava/lang/Integer;

    .line 322
    .line 323
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 324
    .line 325
    .line 326
    move-result-object v1

    .line 327
    check-cast v1, Ljava/lang/Integer;

    .line 328
    .line 329
    iput-object v1, v0, Lq2/b;->o:Ljava/lang/Integer;

    .line 330
    .line 331
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 332
    .line 333
    .line 334
    move-result-object v1

    .line 335
    check-cast v1, Ljava/lang/Integer;

    .line 336
    .line 337
    iput-object v1, v0, Lq2/b;->p:Ljava/lang/Integer;

    .line 338
    .line 339
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 340
    .line 341
    .line 342
    move-result-object v1

    .line 343
    check-cast v1, Ljava/lang/Integer;

    .line 344
    .line 345
    iput-object v1, v0, Lq2/b;->q:Ljava/lang/Integer;

    .line 346
    .line 347
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 348
    .line 349
    .line 350
    move-result-object v1

    .line 351
    check-cast v1, Ljava/lang/Integer;

    .line 352
    .line 353
    iput-object v1, v0, Lq2/b;->r:Ljava/lang/Integer;

    .line 354
    .line 355
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 356
    .line 357
    .line 358
    move-result-object v1

    .line 359
    check-cast v1, Ljava/lang/Integer;

    .line 360
    .line 361
    iput-object v1, v0, Lq2/b;->s:Ljava/lang/Integer;

    .line 362
    .line 363
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 364
    .line 365
    .line 366
    move-result-object v1

    .line 367
    check-cast v1, Ljava/lang/Integer;

    .line 368
    .line 369
    iput-object v1, v0, Lq2/b;->t:Ljava/lang/Integer;

    .line 370
    .line 371
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 372
    .line 373
    .line 374
    move-result v1

    .line 375
    iput v1, v0, Lq2/b;->u:I

    .line 376
    .line 377
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 378
    .line 379
    .line 380
    move-result-object v1

    .line 381
    iput-object v1, v0, Lq2/b;->v:Ljava/lang/String;

    .line 382
    .line 383
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 384
    .line 385
    .line 386
    move-result v1

    .line 387
    iput v1, v0, Lq2/b;->w:I

    .line 388
    .line 389
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 390
    .line 391
    .line 392
    move-result v1

    .line 393
    iput v1, v0, Lq2/b;->x:I

    .line 394
    .line 395
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 396
    .line 397
    .line 398
    move-result v1

    .line 399
    iput v1, v0, Lq2/b;->y:I

    .line 400
    .line 401
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object v1

    .line 405
    iput-object v1, v0, Lq2/b;->A:Ljava/lang/CharSequence;

    .line 406
    .line 407
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 408
    .line 409
    .line 410
    move-result-object v1

    .line 411
    iput-object v1, v0, Lq2/b;->B:Ljava/lang/CharSequence;

    .line 412
    .line 413
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 414
    .line 415
    .line 416
    move-result v1

    .line 417
    iput v1, v0, Lq2/b;->C:I

    .line 418
    .line 419
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 420
    .line 421
    .line 422
    move-result-object v1

    .line 423
    check-cast v1, Ljava/lang/Integer;

    .line 424
    .line 425
    iput-object v1, v0, Lq2/b;->E:Ljava/lang/Integer;

    .line 426
    .line 427
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 428
    .line 429
    .line 430
    move-result-object v1

    .line 431
    check-cast v1, Ljava/lang/Integer;

    .line 432
    .line 433
    iput-object v1, v0, Lq2/b;->G:Ljava/lang/Integer;

    .line 434
    .line 435
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 436
    .line 437
    .line 438
    move-result-object v1

    .line 439
    check-cast v1, Ljava/lang/Integer;

    .line 440
    .line 441
    iput-object v1, v0, Lq2/b;->H:Ljava/lang/Integer;

    .line 442
    .line 443
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 444
    .line 445
    .line 446
    move-result-object v1

    .line 447
    check-cast v1, Ljava/lang/Integer;

    .line 448
    .line 449
    iput-object v1, v0, Lq2/b;->I:Ljava/lang/Integer;

    .line 450
    .line 451
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 452
    .line 453
    .line 454
    move-result-object v1

    .line 455
    check-cast v1, Ljava/lang/Integer;

    .line 456
    .line 457
    iput-object v1, v0, Lq2/b;->J:Ljava/lang/Integer;

    .line 458
    .line 459
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 460
    .line 461
    .line 462
    move-result-object v1

    .line 463
    check-cast v1, Ljava/lang/Integer;

    .line 464
    .line 465
    iput-object v1, v0, Lq2/b;->K:Ljava/lang/Integer;

    .line 466
    .line 467
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 468
    .line 469
    .line 470
    move-result-object v1

    .line 471
    check-cast v1, Ljava/lang/Integer;

    .line 472
    .line 473
    iput-object v1, v0, Lq2/b;->L:Ljava/lang/Integer;

    .line 474
    .line 475
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 476
    .line 477
    .line 478
    move-result-object v1

    .line 479
    check-cast v1, Ljava/lang/Integer;

    .line 480
    .line 481
    iput-object v1, v0, Lq2/b;->O:Ljava/lang/Integer;

    .line 482
    .line 483
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 484
    .line 485
    .line 486
    move-result-object v1

    .line 487
    check-cast v1, Ljava/lang/Integer;

    .line 488
    .line 489
    iput-object v1, v0, Lq2/b;->M:Ljava/lang/Integer;

    .line 490
    .line 491
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 492
    .line 493
    .line 494
    move-result-object v1

    .line 495
    check-cast v1, Ljava/lang/Integer;

    .line 496
    .line 497
    iput-object v1, v0, Lq2/b;->N:Ljava/lang/Integer;

    .line 498
    .line 499
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 500
    .line 501
    .line 502
    move-result-object v1

    .line 503
    check-cast v1, Ljava/lang/Boolean;

    .line 504
    .line 505
    iput-object v1, v0, Lq2/b;->F:Ljava/lang/Boolean;

    .line 506
    .line 507
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 508
    .line 509
    .line 510
    move-result-object v1

    .line 511
    check-cast v1, Ljava/util/Locale;

    .line 512
    .line 513
    iput-object v1, v0, Lq2/b;->z:Ljava/util/Locale;

    .line 514
    .line 515
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 516
    .line 517
    .line 518
    move-result-object v1

    .line 519
    check-cast v1, Ljava/lang/Boolean;

    .line 520
    .line 521
    iput-object v1, v0, Lq2/b;->P:Ljava/lang/Boolean;

    .line 522
    .line 523
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 524
    .line 525
    .line 526
    move-result-object p1

    .line 527
    check-cast p1, Ljava/lang/Integer;

    .line 528
    .line 529
    iput-object p1, v0, Lq2/b;->Q:Ljava/lang/Integer;

    .line 530
    .line 531
    return-object v0

    .line 532
    :pswitch_8
    new-instance v0, Lp3/e;

    .line 533
    .line 534
    invoke-direct {v0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 535
    .line 536
    .line 537
    invoke-virtual {p1}, Landroid/os/Parcel;->readFloat()F

    .line 538
    .line 539
    .line 540
    move-result v1

    .line 541
    iput v1, v0, Lp3/e;->m:F

    .line 542
    .line 543
    invoke-virtual {p1}, Landroid/os/Parcel;->readFloat()F

    .line 544
    .line 545
    .line 546
    move-result v1

    .line 547
    iput v1, v0, Lp3/e;->n:F

    .line 548
    .line 549
    new-instance v1, Ljava/util/ArrayList;

    .line 550
    .line 551
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 552
    .line 553
    .line 554
    iput-object v1, v0, Lp3/e;->o:Ljava/util/ArrayList;

    .line 555
    .line 556
    const-class v2, Ljava/lang/Float;

    .line 557
    .line 558
    invoke-virtual {v2}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 559
    .line 560
    .line 561
    move-result-object v2

    .line 562
    invoke-virtual {p1, v1, v2}, Landroid/os/Parcel;->readList(Ljava/util/List;Ljava/lang/ClassLoader;)V

    .line 563
    .line 564
    .line 565
    invoke-virtual {p1}, Landroid/os/Parcel;->readFloat()F

    .line 566
    .line 567
    .line 568
    move-result v1

    .line 569
    iput v1, v0, Lp3/e;->p:F

    .line 570
    .line 571
    invoke-virtual {p1}, Landroid/os/Parcel;->createBooleanArray()[Z

    .line 572
    .line 573
    .line 574
    move-result-object p1

    .line 575
    const/4 v1, 0x0

    .line 576
    aget-boolean p1, p1, v1

    .line 577
    .line 578
    iput-boolean p1, v0, Lp3/e;->q:Z

    .line 579
    .line 580
    return-object v0

    .line 581
    :pswitch_9
    new-instance v0, Lo/p0;

    .line 582
    .line 583
    invoke-direct {v0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 584
    .line 585
    .line 586
    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    .line 587
    .line 588
    .line 589
    move-result p1

    .line 590
    if-eqz p1, :cond_c

    .line 591
    .line 592
    const/4 p1, 0x1

    .line 593
    goto :goto_8

    .line 594
    :cond_c
    const/4 p1, 0x0

    .line 595
    :goto_8
    iput-boolean p1, v0, Lo/p0;->m:Z

    .line 596
    .line 597
    return-object v0

    .line 598
    :pswitch_a
    new-instance v0, Lo/j;

    .line 599
    .line 600
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 601
    .line 602
    .line 603
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 604
    .line 605
    .line 606
    move-result p1

    .line 607
    iput p1, v0, Lo/j;->m:I

    .line 608
    .line 609
    return-object v0

    .line 610
    :pswitch_b
    new-instance v0, Lm5/b;

    .line 611
    .line 612
    invoke-direct {v0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 613
    .line 614
    .line 615
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 616
    .line 617
    .line 618
    move-result p1

    .line 619
    if-eqz p1, :cond_d

    .line 620
    .line 621
    const/4 p1, 0x1

    .line 622
    goto :goto_9

    .line 623
    :cond_d
    const/4 p1, 0x0

    .line 624
    :goto_9
    iput-boolean p1, v0, Lm5/b;->m:Z

    .line 625
    .line 626
    return-object v0

    .line 627
    :pswitch_c
    new-instance v0, Landroidx/versionedparcelable/ParcelImpl;

    .line 628
    .line 629
    invoke-direct {v0, p1}, Landroidx/versionedparcelable/ParcelImpl;-><init>(Landroid/os/Parcel;)V

    .line 630
    .line 631
    .line 632
    return-object v0

    .line 633
    :pswitch_d
    new-instance v0, Lj5/m;

    .line 634
    .line 635
    invoke-direct {v0, p1}, Lj5/m;-><init>(Landroid/os/Parcel;)V

    .line 636
    .line 637
    .line 638
    return-object v0

    .line 639
    :pswitch_e
    new-instance v1, Li4/d;

    .line 640
    .line 641
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 642
    .line 643
    .line 644
    move-result-object v2

    .line 645
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 646
    .line 647
    .line 648
    move-result-object v3

    .line 649
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 650
    .line 651
    .line 652
    move-result-object v4

    .line 653
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 654
    .line 655
    .line 656
    move-result v5

    .line 657
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 658
    .line 659
    .line 660
    move-result-object v6

    .line 661
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 662
    .line 663
    .line 664
    move-result-object v7

    .line 665
    invoke-direct/range {v1 .. v7}, Li4/d;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 666
    .line 667
    .line 668
    return-object v1

    .line 669
    :pswitch_f
    new-instance v0, Li3/l;

    .line 670
    .line 671
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 672
    .line 673
    .line 674
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 675
    .line 676
    .line 677
    move-result v1

    .line 678
    iput v1, v0, Li3/l;->m:I

    .line 679
    .line 680
    const-class v1, Li3/l;

    .line 681
    .line 682
    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 683
    .line 684
    .line 685
    move-result-object v1

    .line 686
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    .line 687
    .line 688
    .line 689
    move-result-object p1

    .line 690
    check-cast p1, Lf3/e;

    .line 691
    .line 692
    iput-object p1, v0, Li3/l;->n:Lf3/e;

    .line 693
    .line 694
    return-object v0

    .line 695
    :pswitch_10
    new-instance v0, Lh5/a;

    .line 696
    .line 697
    const-class v1, Lcom/topjohnwu/magisk/widget/ConcealableBottomNavigationView;

    .line 698
    .line 699
    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 700
    .line 701
    .line 702
    move-result-object v1

    .line 703
    invoke-direct {v0, p1, v1}, Lz0/b;-><init>(Landroid/os/Parcel;Ljava/lang/ClassLoader;)V

    .line 704
    .line 705
    .line 706
    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    .line 707
    .line 708
    .line 709
    move-result p1

    .line 710
    if-eqz p1, :cond_e

    .line 711
    .line 712
    const/4 p1, 0x1

    .line 713
    goto :goto_a

    .line 714
    :cond_e
    const/4 p1, 0x0

    .line 715
    :goto_a
    iput-boolean p1, v0, Lh5/a;->o:Z

    .line 716
    .line 717
    return-object v0

    .line 718
    :pswitch_11
    new-instance v0, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 719
    .line 720
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 721
    .line 722
    .line 723
    move-result-object v1

    .line 724
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 725
    .line 726
    .line 727
    move-result v2

    .line 728
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 729
    .line 730
    .line 731
    move-result-object v3

    .line 732
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 733
    .line 734
    .line 735
    move-result-object p1

    .line 736
    invoke-direct {v0, v1, v2, v3, p1}, Lcom/topjohnwu/magisk/core/model/UpdateInfo;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    .line 737
    .line 738
    .line 739
    return-object v0

    .line 740
    :pswitch_12
    new-instance v0, Lh1/v0;

    .line 741
    .line 742
    invoke-direct {v0, p1}, Lh1/v0;-><init>(Landroid/os/Parcel;)V

    .line 743
    .line 744
    .line 745
    return-object v0

    .line 746
    :pswitch_13
    new-instance v0, Lh1/s0;

    .line 747
    .line 748
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 749
    .line 750
    .line 751
    const/4 v1, 0x0

    .line 752
    iput-object v1, v0, Lh1/s0;->q:Ljava/lang/String;

    .line 753
    .line 754
    new-instance v1, Ljava/util/ArrayList;

    .line 755
    .line 756
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 757
    .line 758
    .line 759
    iput-object v1, v0, Lh1/s0;->r:Ljava/util/ArrayList;

    .line 760
    .line 761
    new-instance v1, Ljava/util/ArrayList;

    .line 762
    .line 763
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 764
    .line 765
    .line 766
    iput-object v1, v0, Lh1/s0;->s:Ljava/util/ArrayList;

    .line 767
    .line 768
    invoke-virtual {p1}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    .line 769
    .line 770
    .line 771
    move-result-object v1

    .line 772
    iput-object v1, v0, Lh1/s0;->m:Ljava/util/ArrayList;

    .line 773
    .line 774
    invoke-virtual {p1}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    .line 775
    .line 776
    .line 777
    move-result-object v1

    .line 778
    iput-object v1, v0, Lh1/s0;->n:Ljava/util/ArrayList;

    .line 779
    .line 780
    sget-object v1, Lh1/b;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 781
    .line 782
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->createTypedArray(Landroid/os/Parcelable$Creator;)[Ljava/lang/Object;

    .line 783
    .line 784
    .line 785
    move-result-object v1

    .line 786
    check-cast v1, [Lh1/b;

    .line 787
    .line 788
    iput-object v1, v0, Lh1/s0;->o:[Lh1/b;

    .line 789
    .line 790
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 791
    .line 792
    .line 793
    move-result v1

    .line 794
    iput v1, v0, Lh1/s0;->p:I

    .line 795
    .line 796
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 797
    .line 798
    .line 799
    move-result-object v1

    .line 800
    iput-object v1, v0, Lh1/s0;->q:Ljava/lang/String;

    .line 801
    .line 802
    invoke-virtual {p1}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    .line 803
    .line 804
    .line 805
    move-result-object v1

    .line 806
    iput-object v1, v0, Lh1/s0;->r:Ljava/util/ArrayList;

    .line 807
    .line 808
    sget-object v1, Lh1/c;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 809
    .line 810
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    .line 811
    .line 812
    .line 813
    move-result-object v1

    .line 814
    iput-object v1, v0, Lh1/s0;->s:Ljava/util/ArrayList;

    .line 815
    .line 816
    sget-object v1, Lh1/l0;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 817
    .line 818
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    .line 819
    .line 820
    .line 821
    move-result-object p1

    .line 822
    iput-object p1, v0, Lh1/s0;->t:Ljava/util/ArrayList;

    .line 823
    .line 824
    return-object v0

    .line 825
    :pswitch_14
    new-instance v0, Lh1/l0;

    .line 826
    .line 827
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 828
    .line 829
    .line 830
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 831
    .line 832
    .line 833
    move-result-object v1

    .line 834
    iput-object v1, v0, Lh1/l0;->m:Ljava/lang/String;

    .line 835
    .line 836
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 837
    .line 838
    .line 839
    move-result p1

    .line 840
    iput p1, v0, Lh1/l0;->n:I

    .line 841
    .line 842
    return-object v0

    .line 843
    :pswitch_15
    new-instance v0, Lh1/c;

    .line 844
    .line 845
    invoke-direct {v0, p1}, Lh1/c;-><init>(Landroid/os/Parcel;)V

    .line 846
    .line 847
    .line 848
    return-object v0

    .line 849
    :pswitch_16
    new-instance v0, Lh1/b;

    .line 850
    .line 851
    invoke-direct {v0, p1}, Lh1/b;-><init>(Landroid/os/Parcel;)V

    .line 852
    .line 853
    .line 854
    return-object v0

    .line 855
    :pswitch_17
    new-instance v0, Lf4/j;

    .line 856
    .line 857
    sget-object v1, Lcom/topjohnwu/magisk/core/model/UpdateInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 858
    .line 859
    invoke-interface {v1, p1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 860
    .line 861
    .line 862
    move-result-object v1

    .line 863
    check-cast v1, Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 864
    .line 865
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 866
    .line 867
    .line 868
    move-result p1

    .line 869
    invoke-direct {v0, v1, p1}, Lf4/j;-><init>(Lcom/topjohnwu/magisk/core/model/UpdateInfo;I)V

    .line 870
    .line 871
    .line 872
    return-object v0

    .line 873
    :pswitch_18
    new-instance v0, Ld/h;

    .line 874
    .line 875
    const-class v1, Landroid/content/IntentSender;

    .line 876
    .line 877
    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 878
    .line 879
    .line 880
    move-result-object v1

    .line 881
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    .line 882
    .line 883
    .line 884
    move-result-object v1

    .line 885
    check-cast v1, Landroid/content/IntentSender;

    .line 886
    .line 887
    const-class v2, Landroid/content/Intent;

    .line 888
    .line 889
    invoke-virtual {v2}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 890
    .line 891
    .line 892
    move-result-object v2

    .line 893
    invoke-virtual {p1, v2}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    .line 894
    .line 895
    .line 896
    move-result-object v2

    .line 897
    check-cast v2, Landroid/content/Intent;

    .line 898
    .line 899
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 900
    .line 901
    .line 902
    move-result v3

    .line 903
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 904
    .line 905
    .line 906
    move-result p1

    .line 907
    invoke-direct {v0, v1, v2, v3, p1}, Ld/h;-><init>(Landroid/content/IntentSender;Landroid/content/Intent;II)V

    .line 908
    .line 909
    .line 910
    return-object v0

    .line 911
    :pswitch_19
    new-instance v0, Ld/a;

    .line 912
    .line 913
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 914
    .line 915
    .line 916
    move-result v1

    .line 917
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 918
    .line 919
    .line 920
    move-result v2

    .line 921
    if-nez v2, :cond_f

    .line 922
    .line 923
    const/4 p1, 0x0

    .line 924
    goto :goto_b

    .line 925
    :cond_f
    sget-object v2, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 926
    .line 927
    invoke-interface {v2, p1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 928
    .line 929
    .line 930
    move-result-object p1

    .line 931
    check-cast p1, Landroid/content/Intent;

    .line 932
    .line 933
    :goto_b
    invoke-direct {v0, v1, p1}, Ld/a;-><init>(ILandroid/content/Intent;)V

    .line 934
    .line 935
    .line 936
    return-object v0

    .line 937
    :pswitch_1a
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 938
    .line 939
    .line 940
    new-instance p1, La5/o;

    .line 941
    .line 942
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 943
    .line 944
    .line 945
    return-object p1

    .line 946
    nop

    .line 947
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 948
    .line 949
    .line 950
    .line 951
    .line 952
    .line 953
    .line 954
    .line 955
    .line 956
    .line 957
    .line 958
    .line 959
    .line 960
    .line 961
    .line 962
    .line 963
    .line 964
    .line 965
    .line 966
    .line 967
    .line 968
    .line 969
    .line 970
    .line 971
    .line 972
    .line 973
    .line 974
    .line 975
    .line 976
    .line 977
    .line 978
    .line 979
    .line 980
    .line 981
    .line 982
    .line 983
    .line 984
    .line 985
    .line 986
    .line 987
    .line 988
    .line 989
    .line 990
    .line 991
    .line 992
    .line 993
    .line 994
    .line 995
    .line 996
    .line 997
    .line 998
    .line 999
    .line 1000
    .line 1001
    .line 1002
    .line 1003
    .line 1004
    .line 1005
    .line 1006
    .line 1007
    .line 1008
    .line 1009
    .line 1010
    .line 1011
    .line 1012
    .line 1013
    .line 1014
    .line 1015
    .line 1016
    .line 1017
    .line 1018
    .line 1019
    .line 1020
    .line 1021
    .line 1022
    .line 1023
    .line 1024
    .line 1025
    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    .line 1060
    .line 1061
    .line 1062
    .line 1063
    .line 1064
    .line 1065
    .line 1066
    .line 1067
    .line 1068
    .line 1069
    .line 1070
    .line 1071
    .line 1072
    .line 1073
    .line 1074
    .line 1075
    .line 1076
    .line 1077
    .line 1078
    .line 1079
    .line 1080
    .line 1081
    .line 1082
    .line 1083
    .line 1084
    .line 1085
    .line 1086
    .line 1087
    .line 1088
    .line 1089
    .line 1090
    .line 1091
    .line 1092
    .line 1093
    .line 1094
    .line 1095
    .line 1096
    .line 1097
    .line 1098
    .line 1099
    .line 1100
    .line 1101
    .line 1102
    .line 1103
    .line 1104
    .line 1105
    .line 1106
    .line 1107
    .line 1108
    .line 1109
    .line 1110
    .line 1111
    .line 1112
    .line 1113
    .line 1114
    .line 1115
    .line 1116
    .line 1117
    .line 1118
    .line 1119
    .line 1120
    .line 1121
    .line 1122
    .line 1123
    .line 1124
    .line 1125
    .line 1126
    .line 1127
    .line 1128
    .line 1129
    .line 1130
    .line 1131
    .line 1132
    .line 1133
    .line 1134
    .line 1135
    .line 1136
    .line 1137
    .line 1138
    .line 1139
    .line 1140
    .line 1141
    .line 1142
    .line 1143
    .line 1144
    .line 1145
    .line 1146
    .line 1147
    .line 1148
    .line 1149
    .line 1150
    .line 1151
    .line 1152
    .line 1153
    .line 1154
    .line 1155
    .line 1156
    .line 1157
    .line 1158
    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    .line 1164
    .line 1165
    .line 1166
    .line 1167
    .line 1168
    .line 1169
    .line 1170
    .line 1171
    .line 1172
    .line 1173
    .line 1174
    .line 1175
    .line 1176
    .line 1177
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
.end method

.method public final newArray(I)[Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, La5/n;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-array p1, p1, [Ly4/b;

    .line 7
    .line 8
    return-object p1

    .line 9
    :pswitch_0
    new-array p1, p1, [Ly4/a;

    .line 10
    .line 11
    return-object p1

    .line 12
    :pswitch_1
    new-array p1, p1, [Ly2/b;

    .line 13
    .line 14
    return-object p1

    .line 15
    :pswitch_2
    new-array p1, p1, [Lw1/i1;

    .line 16
    .line 17
    return-object p1

    .line 18
    :pswitch_3
    new-array p1, p1, [Lw1/h1;

    .line 19
    .line 20
    return-object p1

    .line 21
    :pswitch_4
    new-array p1, p1, [Lw1/y;

    .line 22
    .line 23
    return-object p1

    .line 24
    :pswitch_5
    new-array p1, p1, [Lw0/g;

    .line 25
    .line 26
    return-object p1

    .line 27
    :pswitch_6
    new-array p1, p1, [Lq4/h;

    .line 28
    .line 29
    return-object p1

    .line 30
    :pswitch_7
    new-array p1, p1, [Lq2/b;

    .line 31
    .line 32
    return-object p1

    .line 33
    :pswitch_8
    new-array p1, p1, [Lp3/e;

    .line 34
    .line 35
    return-object p1

    .line 36
    :pswitch_9
    new-array p1, p1, [Lo/p0;

    .line 37
    .line 38
    return-object p1

    .line 39
    :pswitch_a
    new-array p1, p1, [Lo/j;

    .line 40
    .line 41
    return-object p1

    .line 42
    :pswitch_b
    new-array p1, p1, [Lm5/b;

    .line 43
    .line 44
    return-object p1

    .line 45
    :pswitch_c
    new-array p1, p1, [Landroidx/versionedparcelable/ParcelImpl;

    .line 46
    .line 47
    return-object p1

    .line 48
    :pswitch_d
    new-array p1, p1, [Lj5/m;

    .line 49
    .line 50
    return-object p1

    .line 51
    :pswitch_e
    new-array p1, p1, [Li4/d;

    .line 52
    .line 53
    return-object p1

    .line 54
    :pswitch_f
    new-array p1, p1, [Li3/l;

    .line 55
    .line 56
    return-object p1

    .line 57
    :pswitch_10
    new-array p1, p1, [Lh5/a;

    .line 58
    .line 59
    return-object p1

    .line 60
    :pswitch_11
    new-array p1, p1, [Lcom/topjohnwu/magisk/core/model/UpdateInfo;

    .line 61
    .line 62
    return-object p1

    .line 63
    :pswitch_12
    new-array p1, p1, [Lh1/v0;

    .line 64
    .line 65
    return-object p1

    .line 66
    :pswitch_13
    new-array p1, p1, [Lh1/s0;

    .line 67
    .line 68
    return-object p1

    .line 69
    :pswitch_14
    new-array p1, p1, [Lh1/l0;

    .line 70
    .line 71
    return-object p1

    .line 72
    :pswitch_15
    new-array p1, p1, [Lh1/c;

    .line 73
    .line 74
    return-object p1

    .line 75
    :pswitch_16
    new-array p1, p1, [Lh1/b;

    .line 76
    .line 77
    return-object p1

    .line 78
    :pswitch_17
    new-array p1, p1, [Lf4/j;

    .line 79
    .line 80
    return-object p1

    .line 81
    :pswitch_18
    new-array p1, p1, [Ld/h;

    .line 82
    .line 83
    return-object p1

    .line 84
    :pswitch_19
    new-array p1, p1, [Ld/a;

    .line 85
    .line 86
    return-object p1

    .line 87
    :pswitch_1a
    new-array p1, p1, [La5/o;

    .line 88
    .line 89
    return-object p1

    .line 90
    nop

    .line 91
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
.end method
