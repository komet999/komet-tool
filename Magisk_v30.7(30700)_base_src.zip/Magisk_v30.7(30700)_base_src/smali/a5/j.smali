.class public final La5/j;
.super Lz3/f;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# instance fields
.field public final p:Lk1/y;

.field public final q:Lb1/k;

.field public r:La5/f;

.field public final s:Ljava/util/List;

.field public final t:La4/m;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Lz3/f;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lk1/y;

    .line 5
    .line 6
    sget-object v1, La5/g;->m:La5/g;

    .line 7
    .line 8
    invoke-direct {v0, v1}, Lk1/y;-><init>(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, La5/j;->p:Lk1/y;

    .line 12
    .line 13
    new-instance v0, Lb1/k;

    .line 14
    .line 15
    invoke-direct {v0}, Lb1/k;-><init>()V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, La5/j;->q:Lb1/k;

    .line 19
    .line 20
    new-instance v0, Ljava/util/ArrayList;

    .line 21
    .line 22
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 23
    .line 24
    .line 25
    sget-object v1, Lg4/b;->a:Lv5/i;

    .line 26
    .line 27
    invoke-static {v0}, Lj$/util/DesugarCollections;->synchronizedList(Ljava/util/List;)Ljava/util/List;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    iput-object v0, p0, La5/j;->s:Ljava/util/List;

    .line 32
    .line 33
    new-instance v0, La4/m;

    .line 34
    .line 35
    const/4 v1, 0x1

    .line 36
    invoke-direct {v0, p0, v1}, La4/m;-><init>(Lz3/f;I)V

    .line 37
    .line 38
    .line 39
    iput-object v0, p0, La5/j;->t:La4/m;

    .line 40
    .line 41
    return-void
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method
