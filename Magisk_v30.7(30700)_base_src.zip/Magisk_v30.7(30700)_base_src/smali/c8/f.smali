.class public final Lc8/f;
.super Lx1/r;
.source "r8-map-id-039fec256e86178dd670859e96df5324cc320cc73d91a5f1d033b360f16202ea"


# instance fields
.field public final d:J

.field public e:J

.field public final synthetic f:Lc8/g;


# direct methods
.method public constructor <init>(Lc8/g;J)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lc8/f;->f:Lc8/g;

    .line 5
    .line 6
    iput-wide p2, p0, Lc8/f;->d:J

    .line 7
    .line 8
    return-void
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
.end method


# virtual methods
.method public final B()Z
    .locals 4

    .line 1
    iget-wide v0, p0, Lc8/f;->e:J

    .line 2
    .line 3
    iget-wide v2, p0, Lc8/f;->d:J

    .line 4
    .line 5
    cmp-long v0, v0, v2

    .line 6
    .line 7
    if-gez v0, :cond_0

    .line 8
    .line 9
    const/4 v0, 0x1

    .line 10
    return v0

    .line 11
    :cond_0
    const/4 v0, 0x0

    .line 12
    return v0
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final R([BII)I
    .locals 11

    .line 1
    iget-object v0, p0, Lc8/f;->f:Lc8/g;

    .line 2
    .line 3
    iget-object v1, v0, Lc8/g;->q:Lc8/c;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-nez p3, :cond_0

    .line 7
    .line 8
    return v2

    .line 9
    :cond_0
    iget-wide v3, p0, Lc8/f;->d:J

    .line 10
    .line 11
    iget-wide v5, p0, Lc8/f;->e:J

    .line 12
    .line 13
    sub-long/2addr v3, v5

    .line 14
    int-to-long v5, p3

    .line 15
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->min(JJ)J

    .line 16
    .line 17
    .line 18
    move-result-wide v3

    .line 19
    long-to-int p3, v3

    .line 20
    :goto_0
    if-ge v2, p3, :cond_6

    .line 21
    .line 22
    iget-object v3, v0, Lc8/g;->o:Lh8/a;

    .line 23
    .line 24
    iget v4, v3, Lh8/a;->p:I

    .line 25
    .line 26
    const v5, 0xffff

    .line 27
    .line 28
    .line 29
    const/4 v6, 0x1

    .line 30
    if-lez v4, :cond_2

    .line 31
    .line 32
    const/16 v4, 0x8

    .line 33
    .line 34
    invoke-static {v3, v4}, Lc8/g;->z(Lh8/a;I)J

    .line 35
    .line 36
    .line 37
    move-result-wide v3

    .line 38
    long-to-int v3, v3

    .line 39
    int-to-byte v3, v3

    .line 40
    add-int v4, p2, v2

    .line 41
    .line 42
    iget-object v7, v1, Lc8/c;->c:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v7, [B

    .line 45
    .line 46
    iget v8, v1, Lc8/c;->b:I

    .line 47
    .line 48
    aput-byte v3, v7, v8

    .line 49
    .line 50
    add-int/lit8 v7, v8, 0x1

    .line 51
    .line 52
    and-int/2addr v5, v7

    .line 53
    iget-boolean v7, v1, Lc8/c;->a:Z

    .line 54
    .line 55
    if-nez v7, :cond_1

    .line 56
    .line 57
    if-ge v5, v8, :cond_1

    .line 58
    .line 59
    iput-boolean v6, v1, Lc8/c;->a:Z

    .line 60
    .line 61
    :cond_1
    iput v5, v1, Lc8/c;->b:I

    .line 62
    .line 63
    aput-byte v3, p1, v4

    .line 64
    .line 65
    goto :goto_2

    .line 66
    :cond_2
    iget-object v3, v0, Lc8/g;->p:Ljava/io/InputStream;

    .line 67
    .line 68
    add-int v4, p2, v2

    .line 69
    .line 70
    sub-int v7, p3, v2

    .line 71
    .line 72
    invoke-virtual {v3, p1, v4, v7}, Ljava/io/InputStream;->read([BII)I

    .line 73
    .line 74
    .line 75
    move-result v3

    .line 76
    const/4 v7, -0x1

    .line 77
    if-eq v3, v7, :cond_5

    .line 78
    .line 79
    move v7, v4

    .line 80
    :goto_1
    add-int v8, v4, v3

    .line 81
    .line 82
    if-ge v7, v8, :cond_4

    .line 83
    .line 84
    aget-byte v8, p1, v7

    .line 85
    .line 86
    iget-object v9, v1, Lc8/c;->c:Ljava/lang/Object;

    .line 87
    .line 88
    check-cast v9, [B

    .line 89
    .line 90
    iget v10, v1, Lc8/c;->b:I

    .line 91
    .line 92
    aput-byte v8, v9, v10

    .line 93
    .line 94
    add-int/lit8 v8, v10, 0x1

    .line 95
    .line 96
    and-int/2addr v8, v5

    .line 97
    iget-boolean v9, v1, Lc8/c;->a:Z

    .line 98
    .line 99
    if-nez v9, :cond_3

    .line 100
    .line 101
    if-ge v8, v10, :cond_3

    .line 102
    .line 103
    iput-boolean v6, v1, Lc8/c;->a:Z

    .line 104
    .line 105
    :cond_3
    iput v8, v1, Lc8/c;->b:I

    .line 106
    .line 107
    add-int/lit8 v7, v7, 0x1

    .line 108
    .line 109
    goto :goto_1

    .line 110
    :cond_4
    move v6, v3

    .line 111
    :goto_2
    iget-wide v3, p0, Lc8/f;->e:J

    .line 112
    .line 113
    int-to-long v7, v6

    .line 114
    add-long/2addr v3, v7

    .line 115
    iput-wide v3, p0, Lc8/f;->e:J

    .line 116
    .line 117
    add-int/2addr v2, v6

    .line 118
    goto :goto_0

    .line 119
    :cond_5
    new-instance p1, Ljava/io/EOFException;

    .line 120
    .line 121
    const-string p2, "Truncated Deflate64 Stream"

    .line 122
    .line 123
    invoke-direct {p1, p2}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    throw p1

    .line 127
    :cond_6
    return p3
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    .line 165
    .line 166
    .line 167
    .line 168
    .line 169
    .line 170
    .line 171
    .line 172
    .line 173
    .line 174
    .line 175
    .line 176
    .line 177
    .line 178
    .line 179
    .line 180
    .line 181
    .line 182
    .line 183
    .line 184
    .line 185
    .line 186
    .line 187
    .line 188
    .line 189
    .line 190
    .line 191
    .line 192
    .line 193
    .line 194
    .line 195
    .line 196
    .line 197
    .line 198
    .line 199
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
.end method

.method public final c0()I
    .locals 4

    .line 1
    iget-wide v0, p0, Lc8/f;->e:J

    .line 2
    .line 3
    iget-wide v2, p0, Lc8/f;->d:J

    .line 4
    .line 5
    cmp-long v0, v0, v2

    .line 6
    .line 7
    if-gez v0, :cond_0

    .line 8
    .line 9
    const/4 v0, 0x2

    .line 10
    return v0

    .line 11
    :cond_0
    const/4 v0, 0x1

    .line 12
    return v0
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method

.method public final d()I
    .locals 9

    .line 1
    iget-wide v0, p0, Lc8/f;->d:J

    .line 2
    .line 3
    iget-wide v2, p0, Lc8/f;->e:J

    .line 4
    .line 5
    sub-long/2addr v0, v2

    .line 6
    iget-object v2, p0, Lc8/f;->f:Lc8/g;

    .line 7
    .line 8
    iget-object v2, v2, Lc8/g;->o:Lh8/a;

    .line 9
    .line 10
    iget v3, v2, Lh8/a;->p:I

    .line 11
    .line 12
    int-to-long v3, v3

    .line 13
    iget-object v2, v2, Lh8/a;->m:Ln8/b;

    .line 14
    .line 15
    invoke-virtual {v2}, Ln8/b;->available()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    int-to-long v5, v2

    .line 20
    const-wide/16 v7, 0x8

    .line 21
    .line 22
    mul-long/2addr v5, v7

    .line 23
    add-long/2addr v5, v3

    .line 24
    div-long/2addr v5, v7

    .line 25
    invoke-static {v0, v1, v5, v6}, Ljava/lang/Math;->min(JJ)J

    .line 26
    .line 27
    .line 28
    move-result-wide v0

    .line 29
    long-to-int v0, v0

    .line 30
    return v0
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
.end method
