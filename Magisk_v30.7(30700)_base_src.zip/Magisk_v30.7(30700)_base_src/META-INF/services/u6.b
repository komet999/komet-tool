u6.b
