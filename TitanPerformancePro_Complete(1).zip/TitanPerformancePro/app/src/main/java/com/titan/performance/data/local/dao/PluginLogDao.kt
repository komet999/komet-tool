package com.titan.performance.data.local.dao

import androidx.room.*
import com.titan.performance.data.local.entity.PluginLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PluginLogDao {
    @Query("SELECT * FROM plugin_logs ORDER BY timestamp DESC")
    fun getAll(): Flow<List<PluginLogEntity>>

    @Query("SELECT * FROM plugin_logs WHERE pluginName = :name ORDER BY timestamp DESC")
    fun getByPlugin(name: String): Flow<List<PluginLogEntity>>

    @Insert
    suspend fun insert(log: PluginLogEntity)

    @Query("DELETE FROM plugin_logs WHERE timestamp < :timestamp")
    suspend fun deleteOlderThan(timestamp: Long)

    @Query("DELETE FROM plugin_logs")
    suspend fun deleteAll()
}
