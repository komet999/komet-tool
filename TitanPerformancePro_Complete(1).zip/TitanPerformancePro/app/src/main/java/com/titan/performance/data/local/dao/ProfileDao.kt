package com.titan.performance.data.local.dao

import androidx.room.*
import com.titan.performance.data.local.entity.ProfileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY createdAt DESC")
    fun getAll(): Flow<List<ProfileEntity>>

    @Query("SELECT * FROM profiles WHERE id = :id")
    suspend fun getById(id: Int): ProfileEntity?

    @Query("SELECT * FROM profiles WHERE type = :type LIMIT 1")
    suspend fun getByType(type: String): ProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(profile: ProfileEntity): Long

    @Update
    suspend fun update(profile: ProfileEntity)

    @Delete
    suspend fun delete(profile: ProfileEntity)

    @Query("DELETE FROM profiles WHERE id = :id")
    suspend fun deleteById(id: Int)

    @Query("UPDATE profiles SET isEnabled = 0")
    suspend fun disableAll()

    @Query("UPDATE profiles SET isEnabled = 1 WHERE id = :id")
    suspend fun enableById(id: Int)
}