package com.titan.performance.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val type: String,
    val cpuGovernor: String? = null,
    val cpuMinFreq: Int? = null,
    val cpuMaxFreq: Int? = null,
    val gpuFreq: Int? = null,
    val animationScale: Float = 1.0f,
    val backgroundProcessLimit: String? = null,
    val isEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)