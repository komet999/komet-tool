package com.titan.performance.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "plugin_logs")
data class PluginLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val pluginName: String,
    val command: String,
    val stdout: String,
    val stderr: String,
    val exitCode: Int,
    val timestamp: Long = System.currentTimeMillis()
)
