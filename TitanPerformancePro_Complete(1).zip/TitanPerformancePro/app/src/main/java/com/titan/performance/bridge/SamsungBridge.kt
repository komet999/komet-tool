package com.titan.performance.bridge

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader

class SamsungBridge(
    private val context: Context
) : DeviceBridge {


    override val name: String = "Samsung Bridge"

    override val priority: Int = 90



    override suspend fun isAvailable(): Boolean =
        withContext(Dispatchers.IO) {

            Build.MANUFACTURER.equals(
                "samsung",
                ignoreCase = true
            )
        }



    override fun hasPermission(): Boolean {
        return true
    }



    override fun requestPermission() {
        // Samsung bridge does not require extra permission.
    }




    override suspend fun execute(
        command: String
    ): ShellResult =
        withContext(Dispatchers.IO) {

            try {

                val process =
                    Runtime.getRuntime().exec(
                        arrayOf(
                            "sh",
                            "-c",
                            command
                        )
                    )


                val stdout =
                    BufferedReader(
                        InputStreamReader(
                            process.inputStream
                        )
                    ).use {
                        it.readText()
                    }



                val stderr =
                    BufferedReader(
                        InputStreamReader(
                            process.errorStream
                        )
                    ).use {
                        it.readText()
                    }



                val exitCode =
                    process.waitFor()



                ShellResult(
                    output = stdout,
                    error = stderr,
                    exitCode = exitCode,
                    executionTime = 0
                )


            } catch (e: Exception) {


                Timber.e(
                    e,
                    "Samsung bridge failed"
                )


                ShellResult(
                    output = "",
                    error = e.message ?: "Samsung error",
                    exitCode = -1,
                    executionTime = 0
                )
            }
        }




    override suspend fun disconnect() {
        // No active connection.
    }
}