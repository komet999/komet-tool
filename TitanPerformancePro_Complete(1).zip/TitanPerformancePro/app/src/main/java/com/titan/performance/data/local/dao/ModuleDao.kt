package com.titan.performance.data.local.dao

import androidx.room.*
import com.titan.performance.data.local.entity.ModuleEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ModuleDao {
    @Query("SELECT * FROM modules ORDER BY name ASC")
    fun getAll(): Flow<List<ModuleEntity>>

    @Query("SELECT * FROM modules WHERE isInstalled = 1")
    fun getInstalled(): Flow<List<ModuleEntity>>

    @Query("SELECT * FROM modules WHERE id = :id")
    suspend fun getById(id: String): ModuleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(module: ModuleEntity)

    @Update
    suspend fun update(module: ModuleEntity)

    @Delete
    suspend fun delete(module: ModuleEntity)

    @Query("UPDATE modules SET isEnabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: String, enabled: Boolean)
}