package com.titan.performance.bridge

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader

class OppoBridge(
    private val context: Context
) : DeviceBridge {

    override val name: String = "Oppo Bridge"

    override val priority: Int = 90

    override suspend fun isAvailable(): Boolean =
        withContext(Dispatchers.IO) {
            val manufacturer = Build.MANUFACTURER.lowercase()
            val brand = Build.BRAND.lowercase()

            manufacturer.contains("oppo") ||
                    brand.contains("oppo") ||
                    manufacturer.contains("oneplus") ||
                    brand.contains("oneplus") ||
                    manufacturer.contains("realme") ||
                    brand.contains("realme")
        }

    override fun hasPermission(): Boolean {
        return true
    }

    override fun requestPermission() {
        // Oppo Bridge does not require a separate permission request.
    }

    override suspend fun execute(
        command: String
    ): ShellResult = withContext(Dispatchers.IO) {

        try {
            val process = Runtime.getRuntime().exec(
                arrayOf(
                    "sh",
                    "-c",
                    command
                )
            )

            val stdout = BufferedReader(
                InputStreamReader(process.inputStream)
            ).use {
                it.readText()
            }

            val stderr = BufferedReader(
                InputStreamReader(process.errorStream)
            ).use {
                it.readText()
            }

            val exitCode = process.waitFor()

            ShellResult(
                output = stdout,
                error = stderr,
                exitCode = exitCode,
                bridgeName = name
            )

        } catch (e: Exception) {

            Timber.e(
                e,
                "Oppo bridge failed"
            )

            ShellResult(
                output = "",
                error = e.message ?: "Oppo bridge error",
                exitCode = -1,
                bridgeName = name
            )
        }
    }

    override suspend fun disconnect() {
        // No persistent connection to close.
    }
}