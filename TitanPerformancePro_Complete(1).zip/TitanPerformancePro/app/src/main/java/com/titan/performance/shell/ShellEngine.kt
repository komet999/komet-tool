package com.titan.performance.shell

import com.titan.performance.bridge.BridgeManager
import com.titan.performance.bridge.ShellResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ShellEngine @Inject constructor(
    private val bridgeManager: BridgeManager
) {

    suspend fun execute(command: String, timeoutMs: Long = 10000): ShellResult =
        withContext(Dispatchers.IO) {
            val bridgeResult = bridgeManager.execute(command)
            if (bridgeResult.success) {
                return@withContext bridgeResult
            }

            val basicResult = executeBasic(command, timeoutMs)
            if (basicResult.success) {
                return@withContext basicResult
            }

            bridgeResult
        }

    /**
     * Execute with root privileges. Only called when user has explicitly
     * authorized root access through the UI.
     */
    suspend fun executeWithRoot(command: String, timeoutMs: Long = 10000): ShellResult =
        withContext(Dispatchers.IO) {
            try {
                val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))

                val stdout = withTimeoutOrNull(timeoutMs) {
                    BufferedReader(InputStreamReader(process.inputStream)).readText()
                } ?: ""

                val stderr = withTimeoutOrNull(timeoutMs) {
                    BufferedReader(InputStreamReader(process.errorStream)).readText()
                } ?: ""

                val exitCode = withTimeoutOrNull(timeoutMs) {
                    process.waitFor()
                } ?: -1

                ShellResult(
                    command = command,
                    output = stdout,
                    error = stderr,
                    exitCode = exitCode,
                    bridgeName = "root"
                )
            } catch (e: Exception) {
                Timber.e(e, "Root execution failed: $command")
                ShellResult(
                    command = command,
                    output = "",
                    error = e.message ?: "Root execution failed",
                    exitCode = -1,
                    bridgeName = "root"
                )
            }
        }

    private suspend fun executeBasic(command: String, timeoutMs: Long = 10000): ShellResult =
        withContext(Dispatchers.IO) {
            try {
                val process = Runtime.getRuntime().exec(command)

                val stdout = withTimeoutOrNull(timeoutMs) {
                    BufferedReader(InputStreamReader(process.inputStream)).readText()
                } ?: ""

                val stderr = withTimeoutOrNull(timeoutMs) {
                    BufferedReader(InputStreamReader(process.errorStream)).readText()
                } ?: ""

                val exitCode = withTimeoutOrNull(timeoutMs) {
                    process.waitFor()
                } ?: -1

                ShellResult(
                    command = command,
                    output = stdout,
                    error = stderr,
                    exitCode = exitCode,
                    bridgeName = "basic"
                )
            } catch (e: Exception) {
                Timber.e(e, "Basic execution failed: $command")
                ShellResult(
                    command = command,
                    output = "",
                    error = e.message ?: "Execution failed",
                    exitCode = -1,
                    bridgeName = "basic"
                )
            }
        }

    fun isRootAvailable(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec("su -c id")
            process.waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }
}
