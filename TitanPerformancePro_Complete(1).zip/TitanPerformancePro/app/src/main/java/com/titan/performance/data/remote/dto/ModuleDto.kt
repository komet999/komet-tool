package com.titan.performance.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class ModuleDto(
    val id: String,
    val name: String,
    val description: String,
    val version: String,
    val developer: String,
    val iconUrl: String? = null,
    val bannerUrl: String? = null,
    val minAndroid: Int,
    val supportedDevices: List<String> = emptyList(),
    val permissions: List<String> = emptyList(),
    val changelog: String = "",
    val downloadUrl: String,
    val rating: Float = 0f,
    val downloadCount: Int = 0,
    val category: String = ""
)
