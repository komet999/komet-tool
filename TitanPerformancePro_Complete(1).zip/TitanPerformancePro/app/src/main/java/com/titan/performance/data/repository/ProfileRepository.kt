package com.titan.performance.data.repository

import com.titan.performance.data.local.dao.ProfileDao
import com.titan.performance.data.local.entity.ProfileEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProfileRepository @Inject constructor(
    private val profileDao: ProfileDao
) {
    fun getAllProfiles(): Flow<List<ProfileEntity>> = profileDao.getAll()
    suspend fun getProfileById(id: Int): ProfileEntity? = profileDao.getById(id)
    suspend fun getProfileByType(type: String): ProfileEntity? = profileDao.getByType(type)
    suspend fun insertProfile(profile: ProfileEntity): Long = profileDao.insert(profile)
    suspend fun updateProfile(profile: ProfileEntity) = profileDao.update(profile)
    suspend fun deleteProfile(profile: ProfileEntity) = profileDao.delete(profile)
    suspend fun deleteProfileById(id: Int) = profileDao.deleteById(id)
    suspend fun activateProfile(id: Int) {
        profileDao.disableAll()
        profileDao.enableById(id)
    }
}
