package com.titan.performance.di


import com.titan.performance.device.DeviceRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton



@Module
@InstallIn(SingletonComponent::class)
object DeviceModule {



    @Provides
    @Singleton
    fun provideDeviceRepository(

        deviceRepository: DeviceRepository

    ): DeviceRepository {


        return deviceRepository

    }


}