package com.titan.performance.domain.model

data class SecurityScanResult(
    val overallScore: Int,
    val appSecurityScore: Int,
    val permissionScore: Int,
    val storageScore: Int,
    val settingsScore: Int,
    val issues: List<SecurityIssue>,
    val recommendations: List<String>,
    val scanTime: Long = System.currentTimeMillis()
)

data class SecurityIssue(
    val severity: IssueSeverity,
    val category: String,
    val description: String,
    val recommendation: String
)

enum class IssueSeverity { CRITICAL, HIGH, MEDIUM, LOW, INFO }
