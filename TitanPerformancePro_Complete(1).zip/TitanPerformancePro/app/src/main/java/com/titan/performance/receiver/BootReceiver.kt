package com.titan.performance.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.titan.performance.service.MonitoringService
import com.titan.performance.worker.BootRecoveryWorker
import timber.log.Timber
import java.util.concurrent.TimeUnit

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_LOCKED_BOOT_COMPLETED
        ) {
            return
        }

        Timber.i("Titan BootReceiver: Device booted, starting recovery")

        // Schedule recovery worker
        val recoveryWork = OneTimeWorkRequestBuilder<BootRecoveryWorker>()
            .setInitialDelay(10, TimeUnit.SECONDS)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            "titan_boot_recovery",
            ExistingWorkPolicy.REPLACE,
            recoveryWork
        )

        // Start monitoring service if it was enabled
        try {
            val serviceIntent = Intent(context, MonitoringService::class.java)
            ContextCompat.startForegroundService(context, serviceIntent)
        } catch (e: Exception) {
            Timber.e(e, "Failed to start monitoring service after boot")
        }
    }
}
