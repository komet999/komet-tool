package com.titan.performance.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.titan.performance.BuildConfig
import com.titan.performance.R
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(navController: NavController) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text(stringResource(R.string.about), color = Color.White, fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // App Logo
            Surface(
                modifier = Modifier.size(100.dp),
                shape = RoundedCornerShape(24.dp),
                color = TitanTeal.copy(alpha = 0.15f)
            ) {
                Icon(
                    Icons.Default.Bolt,
                    contentDescription = null,
                    tint = TitanTeal,
                    modifier = Modifier.padding(24.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                stringResource(R.string.app_name),
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                "${stringResource(R.string.version)} ${BuildConfig.VERSION_NAME}",
                color = TitanGray,
                fontSize = 14.sp
            )
            Text(
                "${stringResource(R.string.build_number)} ${BuildConfig.VERSION_CODE}",
                color = TitanGray,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(32.dp))

            // Developer Section
            Text(
                stringResource(R.string.developer),
                color = TitanTeal,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(12.dp))

            SocialLink(
                name = stringResource(R.string.facebook),
                description = "MRKOMET Projects",
                icon = Icons.Default.Facebook,
                color = Color(0xFF1877F2),
                url = "https://facebook.com/mrkomet"
            )
            SocialLink(
                name = stringResource(R.string.telegram),
                description = "@mrkomet",
                icon = Icons.Default.Send,
                color = Color(0xFF0088CC),
                url = "https://t.me/mrkomet"
            )
            SocialLink(
                name = stringResource(R.string.youtube),
                description = "MRKOMET Channel",
                icon = Icons.Default.PlayCircle,
                color = Color(0xFFFF0000),
                url = "https://youtube.com/@mrkomet"
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Privacy Info
            Surface(
                color = TitanCard,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        stringResource(R.string.privacy_information),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Titan Performance Pro is a local device management utility. " +
                        "All data stays on your device. No personal information is collected or transmitted.",
                        color = TitanGray,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Open Source Libraries
            Surface(
                color = TitanCard,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        stringResource(R.string.open_source_libraries),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• Jetpack Compose", color = TitanGray, fontSize = 12.sp)
                    Text("• Hilt (Dependency Injection)", color = TitanGray, fontSize = 12.sp)
                    Text("• Room (Database)", color = TitanGray, fontSize = 12.sp)
                    Text("• Retrofit (Networking)", color = TitanGray, fontSize = 12.sp)
                    Text("• Shizuku (Privileged APIs)", color = TitanGray, fontSize = 12.sp)
                    Text("• Timber (Logging)", color = TitanGray, fontSize = 12.sp)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun SocialLink(name: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, url: String) {
    val context = LocalContext.current
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(intent)
            }
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier.size(40.dp),
                shape = RoundedCornerShape(12.dp),
                color = color.copy(alpha = 0.1f)
            ) {
                Icon(icon, null, tint = color, modifier = Modifier.padding(10.dp))
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(description, color = TitanGray, fontSize = 12.sp)
            }
        }
    }
}
