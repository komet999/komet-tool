package com.titan.performance.bridge

import com.titan.performance.shizuku.ShizukuShell
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WirelessAdbBridge @Inject constructor(
    private val manager: WirelessAdbManager
) : DeviceBridge {

    override val name: String = "Wireless ADB"

    override val priority: Int = 50

    override suspend fun isAvailable(): Boolean {
        return try {
            val connection = manager.getConnection() ?: return false
            manager.testConnection(connection.host, connection.port)
        } catch (e: Exception) {
            Timber.e(e, "Wireless ADB unavailable")
            false
        }
    }

    override suspend fun connect(): Boolean {
        return isAvailable()
    }

    override suspend fun execute(command: String): ShellResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        
        // Ensure connection exists
        if (manager.getConnection() == null) {
            return@withContext ShellResult(
                error = "No wireless ADB connection",
                exitCode = -1,
                bridgeName = name
            )
        }

        try {
            // Try Shizuku first as it's the most reliable way to run ADB commands on-device
            val shizukuResult = ShizukuShell.execute(command)
            ShellResult(
                output = shizukuResult.stdout,
                error = shizukuResult.stderr,
                exitCode = shizukuResult.exitCode,
                executionTime = System.currentTimeMillis() - start,
                bridgeName = "$name (via Shizuku)"
            )
        } catch (e: Exception) {
            Timber.w(e, "Shizuku fallback failed, trying direct shell")
            try {
                val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
                val output = process.inputStream.bufferedReader().use { it.readText() }
                val error = process.errorStream.bufferedReader().use { it.readText() }
                val code = process.waitFor()

                ShellResult(
                    output = output,
                    error = error,
                    exitCode = code,
                    executionTime = System.currentTimeMillis() - start,
                    bridgeName = name
                )
            } catch (ex: Exception) {
                ShellResult(
                    output = "",
                    error = ex.message ?: "Execution failed",
                    exitCode = -1,
                    executionTime = System.currentTimeMillis() - start,
                    bridgeName = name
                )
            }
        }
    }

    override suspend fun disconnect() {
        Timber.d("Wireless ADB disconnected")
    }
}
