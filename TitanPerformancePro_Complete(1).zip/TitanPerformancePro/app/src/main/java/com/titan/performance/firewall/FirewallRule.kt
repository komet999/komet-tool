package com.titan.performance.firewall

import kotlinx.serialization.Serializable

@Serializable
data class FirewallRule(
    val packageName: String,
    val uid: Int,
    val appName: String = "",
    val blockedAt: Long = System.currentTimeMillis()
)

@Serializable
data class FirewallConfig(
    val version: Int = 1,
    val blocked: List<FirewallRule> = emptyList()
)
