package com.titan.performance.presentation.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.titan.performance.data.local.entity.ProfileEntity
import com.titan.performance.data.repository.*
import com.titan.performance.hardware.HardwareEngine
import com.titan.performance.hardware.TweaksEngine
import com.titan.performance.util.NotificationHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PerformanceViewModel @Inject constructor(
    application: Application,
    private val profileRepository: ProfileRepository,
    private val historyRepository: HistoryRepository,
    private val hardwareEngine: HardwareEngine,
    private val tweaksEngine: TweaksEngine
) : AndroidViewModel(application) {

    private val _profiles = MutableStateFlow<List<ProfileEntity>>(emptyList())
    val profiles: StateFlow<List<ProfileEntity>> = _profiles.asStateFlow()

    private val _selectedProfile = MutableStateFlow<ProfileEntity?>(null)
    val selectedProfile: StateFlow<ProfileEntity?> = _selectedProfile.asStateFlow()

    init { loadProfiles() }

    private fun loadProfiles() {
        viewModelScope.launch {
            profileRepository.getAllProfiles().collect { _profiles.value = it }
        }
    }

    fun selectProfile(profile: ProfileEntity) { _selectedProfile.value = profile }

    fun createProfile(name: String, type: String) {
        viewModelScope.launch {
            val profile = ProfileEntity(
                name = name, type = type,
                animationScale = when (type) {
                    "battery" -> 0.5f; "balanced" -> 1.0f; "performance" -> 0.75f
                    "gaming" -> 0.5f; "extreme" -> 0.25f; else -> 1.0f
                }
            )
            profileRepository.insertProfile(profile)
            historyRepository.addHistory("Profile Created", name)
        }
    }

    fun deleteProfile(profile: ProfileEntity) {
        viewModelScope.launch {
            profileRepository.deleteProfile(profile)
            historyRepository.addHistory("Profile Deleted", profile.name)
        }
    }

    fun activateProfile(id: Int) {
        viewModelScope.launch {
            val profile = _profiles.value.find { it.id == id }
            profile?.let {
                applyProfileEffects(it.type)
            }
            profileRepository.activateProfile(id)
            historyRepository.addHistory("Profile Activated", "ID: $id")
        }
    }

    fun activateProfileByType(type: String) {
        viewModelScope.launch {
            applyProfileEffects(type)
            historyRepository.addHistory("Deployment", "Type: $type")
        }
    }

    fun applyExhaustiveTweaks() {
        viewModelScope.launch {
            NotificationHelper.showShellNotification(getApplication(), "TITAN CORE", "Injecting Exhaustive Scripts...", 50)
            tweaksEngine.applyExhaustiveTweaks()
            NotificationHelper.showShellNotification(getApplication(), "TITAN CORE", "System Overclocked Successfully", -1)
            historyRepository.addHistory("Exhaustive Tweaks", "Vexiro V3 + AX Mode Active")
        }
    }

    private suspend fun applyProfileEffects(type: String) {
        tweaksEngine.applyUniversalCompatibility()

        when (type) {
            "extreme" -> {
                hardwareEngine.setCpuPerformanceMode(true)
                hardwareEngine.optimizeZram(4096)
                hardwareEngine.lockCpuFrequency(true)
                hardwareEngine.forceMaxRefreshRate(true)
                tweaksEngine.applyTitanUltraTweaks()
                tweaksEngine.applyRadioBoost()
                tweaksEngine.applyAdBlock(true)
                tweaksEngine.applyPersistenceFix()
            }
            "gaming" -> {
                hardwareEngine.setCpuPerformanceMode(true)
                hardwareEngine.forceMaxRefreshRate(true)
                tweaksEngine.applyTitanUltraTweaks()
                tweaksEngine.applyRadioBoost()
                tweaksEngine.applyAdBlock(true)
            }
            "performance" -> {
                hardwareEngine.setCpuPerformanceMode(true)
                tweaksEngine.applyTitanUltraTweaks()
            }
            "battery" -> {
                hardwareEngine.setCpuPerformanceMode(false)
                tweaksEngine.applyBatterySurvival()
                tweaksEngine.applyAdBlock(false)
            }
            "balanced" -> {
                hardwareEngine.setCpuPerformanceMode(false)
                tweaksEngine.applyAdBlock(false)
            }
        }
    }
}
