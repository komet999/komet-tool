package com.titan.performance.presentation.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.titan.performance.bridge.*
import com.titan.performance.domain.model.DeviceInfo
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PermissionWizardViewModel @Inject constructor(
    application: Application,
    private val bridgeManager: BridgeManager,
    private val getDeviceInfo: com.titan.performance.domain.usecase.GetDeviceInfoUseCase
) : AndroidViewModel(application) {

    private val _deviceInfo = MutableStateFlow<DeviceInfo?>(null)
    val deviceInfo: StateFlow<DeviceInfo?> = _deviceInfo.asStateFlow()

    private val _availableBridges = MutableStateFlow<List<DeviceBridge>>(emptyList())
    val availableBridges: StateFlow<List<DeviceBridge>> = _availableBridges.asStateFlow()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _isChecking = MutableStateFlow(false)
    val isChecking: StateFlow<Boolean> = _isChecking.asStateFlow()

    init {
        viewModelScope.launch {
            bridgeManager.connectionState.collect { _connectionState.value = it }
        }
        scanDevice()
    }

    fun scanDevice() {
        viewModelScope.launch {
            _isChecking.value = true
            _deviceInfo.value = getDeviceInfo()
            _availableBridges.value = bridgeManager.getAvailableBridges()
            _isChecking.value = false
        }
    }

    fun getRecommendedBridgeName(info: DeviceInfo): String {
        return when {
            info.manufacturer.contains("Samsung", true) -> "Samsung Bridge"
            info.manufacturer.contains("Xiaomi", true) -> "Xiaomi Bridge"
            info.manufacturer.contains("Oppo", true) || info.manufacturer.contains("Realme", true) -> "Oppo Bridge"
            else -> "Wireless ADB"
        }
    }

    suspend fun connectBridge(bridge: DeviceBridge): Boolean {
        _isChecking.value = true
        val result = bridgeManager.connectBridge(bridge)
        _isChecking.value = false
        return result
    }

    fun pairWirelessAdb(port: String, code: String) {
        viewModelScope.launch {
            _isChecking.value = true
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                // TITAN AUTO-INFILTRATION
                val result = WirelessAdbPairing.pair("127.0.0.1", port, code)
                if (result.isSuccess) {
                    delay(3000) // Wait for system service to stabilize
                    bridgeManager.autoConnect()
                }
            }
            _isChecking.value = false
        }
    }

    fun autoConnect() {
        viewModelScope.launch {
            _isChecking.value = true
            bridgeManager.autoConnect()
            _isChecking.value = false
        }
    }
}
