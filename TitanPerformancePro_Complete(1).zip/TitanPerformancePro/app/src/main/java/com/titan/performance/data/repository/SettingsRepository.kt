package com.titan.performance.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import com.titan.performance.data.local.dao.SettingDao
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>,
    private val settingDao: SettingDao,
    @ApplicationContext private val context: Context
) {
    companion object {
        val THEME_KEY = stringPreferencesKey("theme")
        val LANGUAGE_KEY = stringPreferencesKey("language")
        val DYNAMIC_COLORS_KEY = booleanPreferencesKey("dynamic_colors")
        val NOTIFICATIONS_ENABLED_KEY = booleanPreferencesKey("notifications_enabled")
        val MONITORING_ENABLED_KEY = booleanPreferencesKey("monitoring_enabled")
        val VPN_FIREWALL_ENABLED_KEY = booleanPreferencesKey("vpn_firewall_enabled")
        val SYSTEM_FIREWALL_ENABLED_KEY = booleanPreferencesKey("system_firewall_enabled")
        val RESTORE_MONITORING_KEY = booleanPreferencesKey("restore_monitoring")
        val RESTORE_FIREWALL_KEY = booleanPreferencesKey("restore_firewall")
        val RESTORE_PLUGINS_KEY = booleanPreferencesKey("restore_plugins")
        val REFRESH_INTERVAL_KEY = intPreferencesKey("refresh_interval")
        val MONITORING_INTERVAL_KEY = intPreferencesKey("monitoring_interval")
    }

    val theme: Flow<String> = dataStore.data.map { it[THEME_KEY] ?: "system" }
    val language: Flow<String> = dataStore.data.map { it[LANGUAGE_KEY] ?: "device" }
    val dynamicColors: Flow<Boolean> = dataStore.data.map { it[DYNAMIC_COLORS_KEY] ?: true }
    val notificationsEnabled: Flow<Boolean> = dataStore.data.map { it[NOTIFICATIONS_ENABLED_KEY] ?: true }
    val monitoringEnabled: Flow<Boolean> = dataStore.data.map { it[MONITORING_ENABLED_KEY] ?: true }
    val vpnFirewallEnabled: Flow<Boolean> = dataStore.data.map { it[VPN_FIREWALL_ENABLED_KEY] ?: false }
    val systemFirewallEnabled: Flow<Boolean> = dataStore.data.map { it[SYSTEM_FIREWALL_ENABLED_KEY] ?: false }
    val restoreMonitoring: Flow<Boolean> = dataStore.data.map { it[RESTORE_MONITORING_KEY] ?: true }
    val restoreFirewall: Flow<Boolean> = dataStore.data.map { it[RESTORE_FIREWALL_KEY] ?: true }
    val restorePlugins: Flow<Boolean> = dataStore.data.map { it[RESTORE_PLUGINS_KEY] ?: true }
    val refreshInterval: Flow<Int> = dataStore.data.map { it[REFRESH_INTERVAL_KEY] ?: 1000 }
    val monitoringInterval: Flow<Int> = dataStore.data.map { it[MONITORING_INTERVAL_KEY] ?: 3000 }

    suspend fun setTheme(theme: String) { dataStore.edit { it[THEME_KEY] = theme } }
    suspend fun setLanguage(language: String) {
        dataStore.edit { it[LANGUAGE_KEY] = language }
        val prefs = context.getSharedPreferences("settings_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("language", language).apply()
    }
    suspend fun setDynamicColors(enabled: Boolean) { dataStore.edit { it[DYNAMIC_COLORS_KEY] = enabled } }
    suspend fun setNotificationsEnabled(enabled: Boolean) { dataStore.edit { it[NOTIFICATIONS_ENABLED_KEY] = enabled } }
    suspend fun setMonitoringEnabled(enabled: Boolean) { dataStore.edit { it[MONITORING_ENABLED_KEY] = enabled } }
    suspend fun setVpnFirewallEnabled(enabled: Boolean) { dataStore.edit { it[VPN_FIREWALL_ENABLED_KEY] = enabled } }
    suspend fun setSystemFirewallEnabled(enabled: Boolean) { dataStore.edit { it[SYSTEM_FIREWALL_ENABLED_KEY] = enabled } }
    suspend fun setRestoreMonitoring(enabled: Boolean) { dataStore.edit { it[RESTORE_MONITORING_KEY] = enabled } }
    suspend fun setRestoreFirewall(enabled: Boolean) { dataStore.edit { it[RESTORE_FIREWALL_KEY] = enabled } }
    suspend fun setRestorePlugins(enabled: Boolean) { dataStore.edit { it[RESTORE_PLUGINS_KEY] = enabled } }
    suspend fun setRefreshInterval(interval: Int) { dataStore.edit { it[REFRESH_INTERVAL_KEY] = interval } }
    suspend fun setMonitoringInterval(interval: Int) { dataStore.edit { it[MONITORING_INTERVAL_KEY] = interval } }

    suspend fun isMonitoringEnabled(): Boolean {
        return dataStore.data.map { it[MONITORING_ENABLED_KEY] ?: true }.first()
    }

    suspend fun isVpnFirewallEnabled(): Boolean {
        return dataStore.data.map { it[VPN_FIREWALL_ENABLED_KEY] ?: false }.first()
    }

    suspend fun isSystemFirewallEnabled(): Boolean {
        return dataStore.data.map { it[SYSTEM_FIREWALL_ENABLED_KEY] ?: false }.first()
    }
}
