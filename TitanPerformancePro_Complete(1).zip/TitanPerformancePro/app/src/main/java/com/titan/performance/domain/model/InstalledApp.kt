package com.titan.performance.domain.model

data class InstalledApp(
    val packageName: String,
    val appName: String,
    val uid: Int,
    val isSystemApp: Boolean,
    val isInternetBlocked: Boolean = false
)
