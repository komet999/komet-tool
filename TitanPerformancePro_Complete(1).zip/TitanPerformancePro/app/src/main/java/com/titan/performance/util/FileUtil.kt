package com.titan.performance.util

import android.content.Context
import android.net.Uri
import timber.log.Timber
import java.io.File
import java.io.FileOutputStream

object FileUtil {
    /**
     * يحول الـ Uri من الذاكرة الداخلية إلى ملف حقيقي داخل مجلد التطبيق
     * لحل مشكلة Scoped Storage في أندرويد 11+
     */
    fun copyUriToInternal(context: Context, uri: Uri, fileName: String): File? {
        return try {
            val destinationFile = File(context.cacheDir, fileName)
            if (destinationFile.exists()) destinationFile.delete()
            
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destinationFile).use { output ->
                    input.copyTo(output)
                }
            }
            if (destinationFile.exists() && destinationFile.length() > 0) {
                Timber.d("Successfully copied URI to: ${destinationFile.absolutePath}")
                destinationFile
            } else {
                null
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to copy URI to internal storage")
            null
        }
    }
}
