package com.titan.performance.data.repository

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import dagger.hilt.android.qualifiers.ApplicationContext
import com.titan.performance.bridge.BridgeManager
import com.titan.performance.domain.model.InstalledApp
import com.titan.performance.firewall.FirewallRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class InstalledAppsRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val bridgeManager: BridgeManager,
    private val firewallRepository: FirewallRepository
) {

    /** Returns every app on the device (system + user), original & 3rd-party alike. */
    suspend fun getAllApps(): List<InstalledApp> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val blocked = firewallRepository.getBlockedApps().map { it.packageName }.toSet()

        val fromPm = try {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
        } catch (e: Exception) {
            Timber.e(e, "getInstalledApplications failed")
            emptyList()
        }

        val apps = if (fromPm.isNotEmpty()) {
            fromPm.map { it.toInstalledApp(pm, blocked) }
        } else {
            // Fallback for Android 11+ package-visibility restrictions when
            // QUERY_ALL_PACKAGES isn't honored (e.g. some OEM ROMs): ask
            // for the full package list through the shell instead, which
            // bypasses the normal per-app visibility filter.
            getAllPackagesViaShell(blocked)
        }

        apps.sortedBy { it.appName.lowercase() }
    }

    private fun ApplicationInfo.toInstalledApp(
        pm: PackageManager,
        blockedPackages: Set<String>
    ): InstalledApp {
        val label = try {
            pm.getApplicationLabel(this).toString()
        } catch (e: Exception) {
            packageName
        }
        val isSystem = (flags and ApplicationInfo.FLAG_SYSTEM) != 0
        return InstalledApp(
            packageName = packageName,
            appName = label,
            uid = uid,
            isSystemApp = isSystem,
            isInternetBlocked = packageName in blockedPackages
        )
    }

    private suspend fun getAllPackagesViaShell(blockedPackages: Set<String>): List<InstalledApp> {
        val result = bridgeManager.execute("pm list packages -U")
        if (!result.success) return emptyList()

        val pm = context.packageManager
        return result.output.lineSequence()
            .mapNotNull { line ->
                // format: package:com.example.app uid:10123
                val pkgMatch = Regex("package:(\\S+)").find(line)?.groupValues?.get(1)
                val uidMatch = Regex("uid:(\\d+)").find(line)?.groupValues?.get(1)
                if (pkgMatch == null) return@mapNotNull null

                val appInfo = try {
                    pm.getApplicationInfo(pkgMatch, 0)
                } catch (e: Exception) {
                    null
                }

                val label = appInfo?.let {
                    try { pm.getApplicationLabel(it).toString() } catch (e: Exception) { pkgMatch }
                } ?: pkgMatch

                val isSystem = appInfo?.let { (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0 } ?: false

                InstalledApp(
                    packageName = pkgMatch,
                    appName = label,
                    uid = uidMatch?.toIntOrNull() ?: appInfo?.uid ?: -1,
                    isSystemApp = isSystem,
                    isInternetBlocked = pkgMatch in blockedPackages
                )
            }
            .toList()
    }
}
