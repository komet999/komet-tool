package com.titan.performance.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.R
import com.titan.performance.bridge.ConnectionState
import com.titan.performance.presentation.viewmodel.DashboardViewModel
import com.titan.performance.ui.components.*
import com.titan.performance.ui.navigation.Screen
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(navController: NavController, viewModel: DashboardViewModel = hiltViewModel()) {
    val systemStats by viewModel.systemStats.collectAsState()
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val bridgeState by viewModel.bridgeConnectionState.collectAsState()
    val cpuHistory by viewModel.cpuHistory.collectAsState()
    val ramHistory by viewModel.ramHistory.collectAsState()
    val liveHardware by viewModel.liveHardware.collectAsState()
    val healthScore by viewModel.healthScore.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier.size(36.dp),
                            shape = RoundedCornerShape(10.dp),
                            color = TitanTeal.copy(alpha = 0.15f)
                        ) {
                            Icon(Icons.Default.Bolt, null, tint = TitanTeal, modifier = Modifier.padding(6.dp))
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("TITAN PRO", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                            Text(stringResource(R.string.dashboard), color = TitanTeal, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.refresh() }) {
                        Icon(Icons.Default.Refresh, null, tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp)
        ) {
            // Health Score Card
            HealthScoreCard(healthScore)
            Spacer(modifier = Modifier.height(16.dp))

            // Quick Stats Grid
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickStatCard(
                    label = stringResource(R.string.cpu),
                    value = "${systemStats?.cpuUsagePercent?.toInt() ?: 0}%",
                    icon = Icons.Default.Memory,
                    modifier = Modifier.weight(1f)
                )
                QuickStatCard(
                    label = stringResource(R.string.ram),
                    value = "${systemStats?.ramUsedPercent?.toInt() ?: 0}%",
                    icon = Icons.Default.Storage,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickStatCard(
                    label = stringResource(R.string.battery),
                    value = "${systemStats?.batteryLevel ?: 0}%",
                    icon = Icons.Default.BatteryFull,
                    modifier = Modifier.weight(1f)
                )
                QuickStatCard(
                    label = stringResource(R.string.storage),
                    value = "${systemStats?.storageUsedPercent?.toInt() ?: 0}%",
                    icon = Icons.Default.SdStorage,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Live Graphs
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GraphBox(
                    label = stringResource(R.string.cpu_usage),
                    value = "${systemStats?.cpuUsagePercent?.toInt() ?: 0}%",
                    history = cpuHistory,
                    color = TitanTeal,
                    modifier = Modifier.weight(1f)
                )
                GraphBox(
                    label = stringResource(R.string.ram_percentage),
                    value = "${systemStats?.ramUsedPercent?.toInt() ?: 0}%",
                    history = ramHistory,
                    color = TitanGreen,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Device Info
            DeviceInfoCard(deviceInfo, liveHardware)
            Spacer(modifier = Modifier.height(16.dp))

            // Backend Status
            BackendStatusCard(bridgeState)
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun HealthScoreCard(score: Int) {
    val color = when {
        score >= 80 -> TitanGreen
        score >= 50 -> TitanTeal
        else -> TitanRed
    }
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text("$score", color = color, fontSize = 24.sp, fontWeight = FontWeight.Black)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(stringResource(R.string.health_score), color = TitanGray, fontSize = 12.sp)
                Text(
                    when {
                        score >= 80 -> "Excellent"
                        score >= 50 -> "Good"
                        else -> "Needs Attention"
                    },
                    color = color,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun QuickStatCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(20.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Icon(icon, null, tint = TitanTeal, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text(label, color = TitanGray, fontSize = 11.sp)
        }
    }
}

@Composable
fun GraphBox(label: String, value: String, history: List<Float>, color: Color, modifier: Modifier = Modifier) {
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(24.dp),
        modifier = modifier.height(150.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(label, color = TitanGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Spacer(modifier = Modifier.weight(1f))
            RealTimeLineChart(
                data = history,
                color = color,
                modifier = Modifier.fillMaxWidth().height(50.dp)
            )
        }
    }
}

@Composable
fun DeviceInfoCard(deviceInfo: com.titan.performance.domain.model.DeviceInfo?, liveHardware: com.titan.performance.hardware.TitanHardwareMonitor.LiveHardwareInfo?) {
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(stringResource(R.string.device_info), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            deviceInfo?.let {
                InfoRow(stringResource(R.string.device_model), it.model)
                InfoRow(stringResource(R.string.manufacturer), it.manufacturer)
                InfoRow(stringResource(R.string.android_version), it.androidVersion)
                InfoRow(stringResource(R.string.kernel), it.kernelVersion)
            }
            liveHardware?.let {
                InfoRow(stringResource(R.string.cpu_frequency), it.cpuFreq)
                InfoRow(stringResource(R.string.core_count), "${it.activeCores}")
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TitanGray, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun BackendStatusCard(state: ConnectionState) {
    val (statusText, statusColor) = when (state) {
        ConnectionState.Connected -> stringResource(R.string.connected) to TitanGreen
        ConnectionState.Connecting -> "Connecting..." to TitanTeal
        ConnectionState.Disconnected -> stringResource(R.string.disconnected) to TitanGray
        ConnectionState.Failed -> "Failed" to TitanRed
    }
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(statusColor)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(stringResource(R.string.shizuku_status), color = TitanGray, fontSize = 11.sp)
                Text(statusText, color = statusColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
