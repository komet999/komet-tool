package com.titan.performance.bridge

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader

class XiaomiBridge(
    private val context: Context
) : DeviceBridge {


    override val name: String = "Xiaomi Bridge"


    override val priority: Int = 90



    override suspend fun isAvailable(): Boolean =
        withContext(Dispatchers.IO) {

            val manufacturer =
                Build.MANUFACTURER.lowercase()

            val brand =
                Build.BRAND.lowercase()


            manufacturer.contains("xiaomi") ||
                    manufacturer.contains("redmi") ||
                    manufacturer.contains("poco") ||
                    brand.contains("xiaomi") ||
                    brand.contains("redmi") ||
                    brand.contains("poco")
        }



    override fun hasPermission(): Boolean {
        return true
    }



    override fun requestPermission() {
        // لا يحتاج صلاحيات إضافية
    }



    override suspend fun execute(
        command: String
    ): ShellResult =
        withContext(Dispatchers.IO) {

            try {

                val process =
                    Runtime.getRuntime().exec(
                        arrayOf(
                            "sh",
                            "-c",
                            command
                        )
                    )


                val stdout =
                    BufferedReader(
                        InputStreamReader(
                            process.inputStream
                        )
                    ).use {
                        it.readText()
                    }


                val stderr =
                    BufferedReader(
                        InputStreamReader(
                            process.errorStream
                        )
                    ).use {
                        it.readText()
                    }


                val exitCode =
                    process.waitFor()



                ShellResult(
                    output = stdout,
                    error = stderr,
                    exitCode = exitCode,
                    executionTime = 0
                )


            } catch (e: Exception) {


                Timber.e(
                    e,
                    "Xiaomi bridge failed"
                )


                ShellResult(
                    output = "",
                    error = e.message ?: "Xiaomi error",
                    exitCode = -1,
                    executionTime = 0
                )
            }
        }




    override suspend fun disconnect() {
        // لا يوجد اتصال يحتاج إغلاق
    }
}