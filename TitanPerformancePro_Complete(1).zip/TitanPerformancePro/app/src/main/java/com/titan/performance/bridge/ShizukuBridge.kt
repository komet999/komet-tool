package com.titan.performance.bridge

import com.titan.performance.shizuku.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class ShizukuBridge @Inject constructor() : DeviceBridge {


    override val name: String = "Shizuku"


    override val priority: Int = 100



    override suspend fun isAvailable(): Boolean {

        return try {

            val running =
                ShizukuManager.isRunning()


            Timber.d(
                "Shizuku running = $running"
            )

            running


        } catch (e: Exception) {

            Timber.e(
                e,
                "Shizuku unavailable"
            )

            false
        }
    }




    override suspend fun connect(): Boolean {

        return try {


            if (!ShizukuManager.isRunning()) {

                return false
            }


            if (!ShizukuManager.hasPermission()) {

                ShizukuManager.requestPermission()

                return false
            }


            true


        } catch (e: Exception) {

            Timber.e(
                e,
                "Shizuku connect failed"
            )

            false
        }

    }





    override suspend fun execute(
        command: String
    ): ShellResult =
        withContext(Dispatchers.IO) {


            val start =
                System.currentTimeMillis()



            if (!ShizukuManager.hasPermission()) {


                return@withContext ShellResult(

                    error =
                        "Shizuku permission missing",

                    exitCode = -1,

                    bridgeName = name
                )
            }




            try {


                val process =
                    Shizuku.newProcess(
                        arrayOf(
                            "sh",
                            "-c",
                            command
                        ),
                        null,
                        null
                    )



                val output =
                    BufferedReader(
                        InputStreamReader(
                            process.inputStream
                        )
                    ).use {
                        it.readText()
                    }



                val error =
                    BufferedReader(
                        InputStreamReader(
                            process.errorStream
                        )
                    ).use {
                        it.readText()
                    }



                val exit =
                    process.waitFor()



                ShellResult(

                    output = output,

                    error = error,

                    exitCode = exit,

                    executionTime =
                        System.currentTimeMillis()
                                - start,

                    bridgeName = name
                )



            } catch (e: Exception) {


                Timber.e(
                    e,
                    "Shizuku command failed"
                )


                ShellResult(

                    error =
                        e.message
                            ?: "Shizuku error",

                    exitCode = -1,

                    executionTime =
                        System.currentTimeMillis()
                                - start,

                    bridgeName = name
                )

            }

        }





    override suspend fun disconnect() {

        Timber.d(
            "Shizuku disconnect"
        )

    }

}