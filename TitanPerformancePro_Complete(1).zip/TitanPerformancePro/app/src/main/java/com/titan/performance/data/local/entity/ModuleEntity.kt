package com.titan.performance.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "modules")
data class ModuleEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val description: String,
    val version: String,
    val developer: String,
    val iconUrl: String? = null,
    val bannerUrl: String? = null,
    val minAndroid: Int,
    val permissions: String,
    val changelog: String,
    val isInstalled: Boolean = false,
    val isEnabled: Boolean = false,
    val installPath: String? = null,
    val installedAt: Long? = null,
    val updatedAt: Long = System.currentTimeMillis()
)