package com.titan.performance.data.repository

import com.titan.performance.data.local.dao.StatisticDao
import com.titan.performance.data.local.entity.StatisticEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StatisticRepository @Inject constructor(
    private val statisticDao: StatisticDao
) {
    fun getRecentStatistics(): Flow<List<StatisticEntity>> = statisticDao.getRecent()
    suspend fun insertStatistic(statistic: StatisticEntity) = statisticDao.insert(statistic)
    suspend fun clearOldStatistics(olderThanMs: Long) = statisticDao.deleteOlderThan(System.currentTimeMillis() - olderThanMs)
}
