package com.titan.performance.hardware

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TitanHardwareMonitor @Inject constructor() {

    data class LiveHardwareInfo(
        val cpuFreq: String,
        val gpuFreq: String,
        val thermalStatus: String,
        val activeCores: Int,
        val socModel: String,
        val batteryVoltage: String,
        val kernelVersion: String
    )

    suspend fun getLiveInfo(): LiveHardwareInfo = withContext(Dispatchers.IO) {
        val cpuFreq = try {
            val freq = File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq").readText().trim().toLong()
            "${freq / 1000} MHz"
        } catch (e: Exception) { "N/A" }

        val gpuFreq = try {
            val freqFile = File("/sys/class/kgsl/kgsl-3d0/gpuclk")
            if (freqFile.exists()) "${freqFile.readText().trim().toLong() / 1000000} MHz" else "N/A"
        } catch (e: Exception) { "N/A" }

        val thermal = try {
            val tempFile = File("/sys/class/thermal/thermal_zone0/temp")
            if (tempFile.exists()) {
                val temp = tempFile.readText().trim().toIntOrNull() ?: 0
                "${temp / 1000}°C"
            } else "NORMAL"
        } catch (e: Exception) { "NORMAL" }

        val soc = android.os.Build.HARDWARE.uppercase()
        val kernel = System.getProperty("os.version") ?: "Unknown"
        val cores = Runtime.getRuntime().availableProcessors()

        LiveHardwareInfo(
            cpuFreq = cpuFreq,
            gpuFreq = gpuFreq,
            thermalStatus = thermal,
            activeCores = cores,
            socModel = soc,
            batteryVoltage = readBatteryVoltage(),
            kernelVersion = kernel
        )
    }

    private fun readBatteryVoltage(): String {
        return try {
            val voltage = File("/sys/class/power_supply/battery/voltage_now").readText().trim().toLong()
            "${voltage / 1000} mV"
        } catch (e: Exception) { "N/A" }
    }
}
