package com.titan.performance.util

object Constants {
    const val DATABASE_NAME = "titan_database"
    const val DATASTORE_NAME = "titan_preferences"
    const val BASE_URL = "https://api.titan-performance.com/"
    const val NOTIFICATION_CHANNEL_ID = "titan_monitoring_channel"
    const val NOTIFICATION_CHANNEL_NAME = "Titan Monitoring"
    const val MONITORING_INTERVAL_MS = 1000L
}
