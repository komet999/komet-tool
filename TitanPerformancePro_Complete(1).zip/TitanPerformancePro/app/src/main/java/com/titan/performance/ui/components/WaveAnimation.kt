package com.titan.performance.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import com.titan.performance.ui.theme.TitanTeal

@Composable
fun WaveAnimation(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Canvas(modifier = modifier.fillMaxWidth().height(40.dp)) {
        val width = size.width
        val height = size.height
        val path = Path()
        
        path.moveTo(0f, height)
        for (x in 0..width.toInt()) {
            val y = (Math.sin(x.toDouble() * 0.02 + phase).toFloat() * 10f) + height / 2
            path.lineTo(x.toFloat(), y)
        }
        path.lineTo(width, height)
        path.close()

        drawPath(
            path = path,
            brush = Brush.verticalGradient(
                colors = listOf(TitanTeal.copy(alpha = 0.5f), TitanTeal.copy(alpha = 0f))
            )
        )
    }
}
