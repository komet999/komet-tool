package com.titan.performance.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val action: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)