package com.titan.performance.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.presentation.viewmodel.PerformanceViewModel
import com.titan.performance.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GamingScreen(navController: NavController, viewModel: PerformanceViewModel = hiltViewModel()) {
    var gamingModeActive by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    
    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text("GAMING HUB", color = Color.White, fontWeight = FontWeight.Black) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Main Gaming Mode Toggle
            Surface(
                color = if (gamingModeActive) TitanTeal.copy(alpha = 0.1f) else TitanCard,
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (gamingModeActive) TitanTeal else Color.Transparent)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("GAMING MODE", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                            Text(
                                if (gamingModeActive) "SYSTEM OPTIMIZED" else "READY TO LAUNCH",
                                color = if (gamingModeActive) TitanGreen else TitanGray,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Switch(
                            checked = gamingModeActive,
                            onCheckedChange = { 
                                gamingModeActive = it 
                                if (it) {
                                    scope.launch { viewModel.activateProfileByType("gaming") }
                                }
                            },
                            colors = SwitchDefaults.colors(checkedTrackColor = TitanTeal)
                        )
                    }
                    
                    if (gamingModeActive) {
                        Spacer(modifier = Modifier.height(16.dp))
                        OptimizationDetail("CPU Boost", "ACTIVE")
                        OptimizationDetail("GPU Acceleration", "ACTIVE")
                        OptimizationDetail("Touch Latency Fix", "ACTIVE")
                        OptimizationDetail("Network Priority", "ACTIVE")
                    }
                }
            }

            // Launch Game Button
            Button(
                onClick = { /* TODO: Game Launcher */ },
                modifier = Modifier.fillMaxWidth().height(60.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TitanTeal, contentColor = TitanBlack)
            ) {
                Icon(Icons.Default.SportsEsports, null)
                Spacer(modifier = Modifier.width(12.dp))
                Text("LAUNCH GAME", fontWeight = FontWeight.Black, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))
            
            Text("OPTIMIZATION STATS", color = TitanGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GameStatCard("FPS STABILITY", "98%", Modifier.weight(1f))
                GameStatCard("PING REDUCTION", "-15ms", Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun OptimizationDetail(label: String, status: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TitanLightGray, fontSize = 12.sp)
        Text(status, color = TitanGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun GameStatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(label, color = TitanGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, color = TitanTeal, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
    }
}
