package com.titan.performance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.presentation.viewmodel.AppFilter
import com.titan.performance.presentation.viewmodel.InstalledAppsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InstalledAppsScreen(
    navController: NavController,
    viewModel: InstalledAppsViewModel = hiltViewModel()
) {
    val isLoading by viewModel.isLoading.collectAsState()
    val filter by viewModel.filter.collectAsState()
    val query by viewModel.searchQuery.collectAsState()
    val busyPackage by viewModel.busyPackage.collectAsState()
    // Re-reading apps/filter/query here keeps this recomposing whenever any of them change.
    viewModel.apps.collectAsState().value
    val apps = remember(viewModel.apps.collectAsState().value, filter, query) {
        viewModel.filteredApps()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Installed Apps") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.refresh() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {

            OutlinedTextField(
                value = query,
                onValueChange = { viewModel.setSearchQuery(it) },
                label = { Text("Search apps") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filter == AppFilter.ALL,
                    onClick = { viewModel.setFilter(AppFilter.ALL) },
                    label = { Text("All") }
                )
                FilterChip(
                    selected = filter == AppFilter.USER,
                    onClick = { viewModel.setFilter(AppFilter.USER) },
                    label = { Text("User") }
                )
                FilterChip(
                    selected = filter == AppFilter.SYSTEM,
                    onClick = { viewModel.setFilter(AppFilter.SYSTEM) },
                    label = { Text("System") }
                )
                FilterChip(
                    selected = filter == AppFilter.BLOCKED,
                    onClick = { viewModel.setFilter(AppFilter.BLOCKED) },
                    label = { Text("Blocked") }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    items(apps, key = { it.packageName }) { app ->
                        ElevatedCard(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(app.appName, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        app.packageName,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (app.isSystemApp) {
                                        Text(
                                            "System app",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.tertiary
                                        )
                                    }
                                }

                                if (app.isInternetBlocked) {
                                    Icon(
                                        Icons.Default.WifiOff,
                                        contentDescription = "Internet blocked",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.padding(end = 8.dp)
                                    )
                                }

                                if (busyPackage == app.packageName) {
                                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                                } else {
                                    Switch(
                                        checked = app.isInternetBlocked,
                                        onCheckedChange = { viewModel.toggleInternetBlock(app) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
