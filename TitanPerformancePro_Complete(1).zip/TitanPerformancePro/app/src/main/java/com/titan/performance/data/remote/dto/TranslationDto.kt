package com.titan.performance.data.remote.dto

import kotlinx.serialization.Serializable

@Serializable
data class TranslationDto(
    val language: String,
    val version: Int,
    val strings: Map<String, String>
)
