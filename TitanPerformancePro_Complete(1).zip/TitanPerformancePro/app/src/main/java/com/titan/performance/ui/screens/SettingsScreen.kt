package com.titan.performance.ui.screens

import android.app.Activity
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.R
import com.titan.performance.presentation.viewmodel.SettingsViewModel
import com.titan.performance.ui.theme.*
import com.titan.performance.util.LocaleHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController, viewModel: SettingsViewModel = hiltViewModel()) {
    val language by viewModel.language.collectAsState()
    val theme by viewModel.theme.collectAsState()
    val dynamicColors by viewModel.dynamicColors.collectAsState()
    val notifications by viewModel.notificationsEnabled.collectAsState()
    val monitoring by viewModel.monitoringEnabled.collectAsState()
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var showLanguageDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.languageChanged.collect {
            (context as? Activity)?.recreate()
        }
    }

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text(stringResource(R.string.settings), color = Color.White, fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // General Section
            SectionTitle(stringResource(R.string.general))
            SettingsCard {
                SettingsItem(
                    label = stringResource(R.string.language),
                    value = when (language) {
                        "ar" -> stringResource(R.string.arabic)
                        "en" -> stringResource(R.string.english)
                        else -> stringResource(R.string.system_theme)
                    },
                    icon = Icons.Default.Language,
                    onClick = { showLanguageDialog = true }
                )
                Divider(color = TitanSurface, modifier = Modifier.padding(horizontal = 16.dp))
                SettingsItem(
                    label = stringResource(R.string.theme),
                    value = when (theme) {
                        "light" -> stringResource(R.string.light_theme)
                        "dark" -> stringResource(R.string.dark_theme)
                        else -> stringResource(R.string.system_theme)
                    },
                    icon = Icons.Default.Palette,
                    onClick = { showThemeDialog = true }
                )
                Divider(color = TitanSurface, modifier = Modifier.padding(horizontal = 16.dp))
                SettingsToggle(
                    label = stringResource(R.string.notifications),
                    checked = notifications,
                    onCheckedChange = { viewModel.setNotificationsEnabled(it) }
                )
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Performance Section
            SectionTitle(stringResource(R.string.performance))
            SettingsCard {
                SettingsToggle(
                    label = stringResource(R.string.startup_monitoring),
                    checked = monitoring,
                    onCheckedChange = { viewModel.setMonitoringEnabled(it) }
                )
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Recovery Section
            SectionTitle(stringResource(R.string.recovery))
            SettingsCard {
                SettingsToggle(
                    label = stringResource(R.string.restore_monitoring_after_reboot),
                    checked = true,
                    onCheckedChange = { }
                )
                Divider(color = TitanSurface, modifier = Modifier.padding(horizontal = 16.dp))
                SettingsToggle(
                    label = stringResource(R.string.restore_firewall_state),
                    checked = true,
                    onCheckedChange = { }
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = { Text(stringResource(R.string.select_language), color = Color.White) },
            containerColor = TitanCard,
            text = {
                Column {
                    LanguageOption(stringResource(R.string.english)) {
                        viewModel.setLanguage("en")
                        showLanguageDialog = false
                    }
                    LanguageOption(stringResource(R.string.arabic)) {
                        viewModel.setLanguage("ar")
                        showLanguageDialog = false
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLanguageDialog = false }) {
                    Text(stringResource(R.string.cancel), color = TitanTeal)
                }
            }
        )
    }

    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = { Text("Select Theme", color = Color.White) },
            containerColor = TitanCard,
            text = {
                Column {
                    LanguageOption(stringResource(R.string.light_theme)) {
                        viewModel.setTheme("light")
                        showThemeDialog = false
                    }
                    LanguageOption(stringResource(R.string.dark_theme)) {
                        viewModel.setTheme("dark")
                        showThemeDialog = false
                    }
                    LanguageOption(stringResource(R.string.system_theme)) {
                        viewModel.setTheme("system")
                        showThemeDialog = false
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemeDialog = false }) {
                    Text(stringResource(R.string.cancel), color = TitanTeal)
                }
            }
        )
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(
        title,
        color = TitanTeal,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
    )
}

@Composable
fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(content = content)
    }
}

@Composable
fun SettingsToggle(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = TitanTeal)
        )
    }
}

@Composable
fun SettingsItem(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = TitanTeal, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            Text(value, color = TitanGray, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = TitanGray)
    }
}

@Composable
fun LanguageOption(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(label, color = Color.White, modifier = Modifier.fillMaxWidth())
    }
}
