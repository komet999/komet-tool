package com.titan.performance.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.performance.data.local.entity.LogEntity
import com.titan.performance.data.repository.LogRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject

@HiltViewModel
class LogsViewModel @Inject constructor(
    private val logRepository: LogRepository
) : ViewModel() {

    private val _logs = MutableStateFlow<List<LogEntity>>(emptyList())
    val logs: StateFlow<List<LogEntity>> = _logs.asStateFlow()

    init {
        viewModelScope.launch {
            logRepository.getAllLogs().collect { _logs.value = it }
        }
    }

    fun clearLogs() { viewModelScope.launch { logRepository.clearAllLogs() } }
    fun exportLogs(): String = Json.encodeToString(_logs.value)
}
