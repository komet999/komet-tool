package com.titan.performance.plugins

import android.content.Context
import kotlinx.serialization.json.Json
import timber.log.Timber
import java.io.File
import java.util.zip.ZipFile

object PluginInstaller {

    fun install(context: Context, zipFile: File): Result<Plugin> {
        val validation = PluginValidator.validate(zipFile)
        if (!validation.valid) {
            return Result.failure(Exception(validation.message))
        }

        val manifest = validation.manifest!!
        val pluginId = manifest.name.lowercase().replace(Regex("[^a-z0-9]"), "_")
        val pluginsDir = File(context.getExternalFilesDir(null), "plugins").apply { mkdirs() }
        val pluginDir = File(pluginsDir, pluginId)

        return try {
            if (pluginDir.exists()) pluginDir.deleteRecursively()
            pluginDir.mkdirs()

            ZipFile(zipFile).use { zip ->
                zip.entries().asSequence().forEach { entry ->
                    val outFile = File(pluginDir, entry.name)
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        zip.getInputStream(entry).use { input ->
                            outFile.outputStream().use { output -> input.copyTo(output) }
                        }
                    }
                }
            }

            // TITAN HEURISTICS: If zip has a single root folder, move content up
            val rootFiles = pluginDir.listFiles()
            if (rootFiles?.size == 1 && rootFiles[0].isDirectory) {
                val subFolder = rootFiles[0]
                subFolder.listFiles()?.forEach { 
                    it.renameTo(File(pluginDir, it.name))
                }
                subFolder.delete()
            }

            // Ensure manifest exists for future reads
            val manifestFile = File(pluginDir, "plugin.json")
            if (!manifestFile.exists()) {
                val manifestJson = Json.encodeToString(PluginManifest.serializer(), manifest)
                manifestFile.writeText(manifestJson)
            }

            // Make all scripts executable recursively (Deep Infiltration)
            pluginDir.walkTopDown().forEach { 
                if (it.extension == "sh" || it.name.contains("run") || it.name.contains("rish")) {
                    it.setExecutable(true, false) 
                }
            }

            val plugin = Plugin(
                id = pluginId,
                name = manifest.name,
                version = manifest.version,
                author = manifest.author,
                description = manifest.description,
                minAndroid = manifest.minAndroid,
                type = manifest.type,
                supportedBrands = manifest.supportedBrands,
                requiredPermission = manifest.requiredPermission,
                profileType = manifest.profileType,
                installPath = pluginDir.absolutePath,
                isInstalled = true,
                installedAt = System.currentTimeMillis()
            )

            Timber.i("TITAN DEPLOYED: ${plugin.name}")
            Result.success(plugin)
        } catch (e: Exception) {
            Timber.e(e, "Titan Install Engine Failure")
            pluginDir.deleteRecursively()
            Result.failure(e)
        }
    }

    fun uninstall(plugin: Plugin): Boolean {
        return try {
            File(plugin.installPath).deleteRecursively()
            true
        } catch (e: Exception) {
            false
        }
    }
}
