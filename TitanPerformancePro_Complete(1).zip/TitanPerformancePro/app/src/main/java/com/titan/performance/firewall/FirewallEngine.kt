package com.titan.performance.firewall

import com.titan.performance.shell.ShellEngine
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Dual Firewall System:
 * A) VPN Firewall (No-Root) - blocks traffic per app via VpnService
 * B) System Firewall (Privileged) - uses Shizuku/Root for iptables/netpolicy
 */
@Singleton
class FirewallEngine @Inject constructor(
    private val shellEngine: ShellEngine
) {

    data class FirewallRule(
        val uid: Int,
        val packageName: String,
        val allowed: Boolean,
        val wifiOnly: Boolean = false,
        val mobileOnly: Boolean = false,
        val temporary: Boolean = false
    )

    private val _rules = mutableListOf<FirewallRule>()
    val rules: List<FirewallRule> get() = _rules.toList()

    /**
     * System Firewall: Block app using netpolicy (works with Shizuku)
     */
    suspend fun blockApp(uid: Int, packageName: String): Boolean {
        val result = shellEngine.execute("cmd netpolicy add restrict-background-blacklist $uid")
        Timber.d("Blocked $packageName (uid=$uid): success=${result.success}")
        if (result.success) {
            _rules.add(FirewallRule(uid, packageName, allowed = false))
        }
        return result.success
    }

    /**
     * System Firewall: Unblock app
     */
    suspend fun unblockApp(uid: Int, packageName: String): Boolean {
        val result = shellEngine.execute("cmd netpolicy remove restrict-background-blacklist $uid")
        Timber.d("Unblocked $packageName (uid=$uid): success=${result.success}")
        _rules.removeAll { it.uid == uid }
        return result.success
    }

    /**
     * System Firewall: Block with root iptables (requires explicit root)
     */
    suspend fun blockAppWithRoot(uid: Int, packageName: String): Boolean {
        val result = shellEngine.executeWithRoot("iptables -I OUTPUT -m owner --uid-owner $uid -j DROP")
        Timber.d("Root-blocked $packageName (uid=$uid): success=${result.success}")
        return result.success
    }

    /**
     * System Firewall: Unblock with root iptables
     */
    suspend fun unblockAppWithRoot(uid: Int, packageName: String): Boolean {
        val result = shellEngine.executeWithRoot("iptables -D OUTPUT -m owner --uid-owner $uid -j DROP")
        Timber.d("Root-unblocked $packageName (uid=$uid): success=${result.success}")
        return result.success
    }

    /**
     * Reset all firewall rules
     */
    suspend fun resetAllRules(): Boolean {
        var success = true
        _rules.toList().forEach { rule ->
            if (!unblockApp(rule.uid, rule.packageName)) success = false
        }
        _rules.clear()
        return success
    }

    fun getRuleForPackage(packageName: String): FirewallRule? {
        return _rules.find { it.packageName == packageName }
    }
}
