package com.titan.performance.bridge


import android.os.Build


object DeviceDetector {


    fun manufacturer(): String {

        return Build.MANUFACTURER
            .replaceFirstChar {
                it.uppercase()
            }
    }


    fun model(): String {

        return Build.MODEL

    }


    fun androidVersion(): String {

        return Build.VERSION.RELEASE

    }


    fun sdk(): Int {

        return Build.VERSION.SDK_INT

    }


    fun detectBrand(): String {

        return when {

            Build.MANUFACTURER.contains(
                "samsung",
                true
            ) -> "Samsung"


            Build.MANUFACTURER.contains(
                "xiaomi",
                true
            ) -> "Xiaomi"


            Build.MANUFACTURER.contains(
                "oppo",
                true
            ) -> "Oppo"


            Build.MANUFACTURER.contains(
                "realme",
                true
            ) -> "Realme"


            Build.MANUFACTURER.contains(
                "oneplus",
                true
            ) -> "OnePlus"


            else -> "Generic"

        }
    }
}