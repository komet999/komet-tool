package com.titan.performance.plugins

data class ShellPlugin(
    val name: String,
    val description: String,
    val command: String,
    val category: String = "General",
    val requiresRoot: Boolean = false,
    val isEnabled: Boolean = true
)
