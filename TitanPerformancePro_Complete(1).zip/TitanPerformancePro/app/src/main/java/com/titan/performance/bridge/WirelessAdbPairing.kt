package com.titan.performance.bridge

import android.os.Build
import androidx.annotation.RequiresApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader

object WirelessAdbPairing {

    /**
     * تنفيذ عملية الاقتران عبر ADB Pair (أندرويد 11+)
     */
    @RequiresApi(Build.VERSION_CODES.R)
    suspend fun pair(ip: String, port: String, pairingCode: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            // ملاحظة: تنفيذ adb pair برمجياً يتطلب مكتبة adb-lib أو تنفيذها عبر shell إذا كان الـ adb binary مدمجاً
            // في مشروعنا، سنستخدم Shizuku للقيام بالعمليات العالية، لكن للاقتران المبدئي:
            val command = "am startservice -n com.android.shell/.PairingService --es port $port --es code $pairingCode"
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val error = process.errorStream.bufferedReader().readText()
            val exitCode = process.waitFor()

            if (exitCode == 0) {
                Result.success("Pairing request sent to system")
            } else {
                Result.failure(Exception(error))
            }
        } catch (e: Exception) {
            Timber.e(e, "Pairing failed")
            Result.failure(e)
        }
    }
}
