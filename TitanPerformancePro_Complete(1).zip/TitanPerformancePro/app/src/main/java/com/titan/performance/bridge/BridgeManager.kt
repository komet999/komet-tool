package com.titan.performance.bridge

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton


enum class ConnectionState {
    Connected,
    Connecting,
    Disconnected,
    Failed
}



@Singleton
class BridgeManager @Inject constructor(

    @ApplicationContext
    private val context: Context,

    private val shizukuBridge: ShizukuBridge,

    private val wirelessAdbBridge: WirelessAdbBridge,

    private val genericAdbBridge: GenericAdbBridge

) {



    private val bridges: List<DeviceBridge> = listOf(

        shizukuBridge,

        OppoBridge(context),

        SamsungBridge(context),

        XiaomiBridge(context),

        wirelessAdbBridge,

        genericAdbBridge

    )



    private val _connectionState =
        MutableStateFlow(
            ConnectionState.Disconnected
        )


    val connectionState: StateFlow<ConnectionState>
        get() = _connectionState




    private var currentBridge: DeviceBridge? = null



    val currentConnection: DeviceBridge?
        get() = currentBridge




    fun current(): DeviceBridge? =
        currentBridge





    /**
     * البحث عن Bridges جاهزة
     */
    suspend fun getAvailableBridges():
            List<DeviceBridge> =
        withContext(Dispatchers.IO) {


            bridges
                .filter {

                    try {

                        it.isAvailable()

                    } catch (e:Exception){

                        Timber.e(
                            e,
                            "Bridge check failed"
                        )

                        false
                    }

                }
                .sortedByDescending {
                    it.priority
                }

        }







    /**
     * اختيار أقوى Bridge
     */
    suspend fun detect():
            DeviceBridge? {


        val available =
            getAvailableBridges()



        Timber.i(
            "Available bridges: ${available.map { it.name }}"
        )


        return available.firstOrNull()

    }







    /**
     * اتصال آمن
     */
    suspend fun connectBridge(
        bridge: DeviceBridge
    ): Boolean {



        _connectionState.value =
            ConnectionState.Connecting



        return try {



            val result =
                bridge.connect()



            if(result){


                currentBridge =
                    bridge



                _connectionState.value =
                    ConnectionState.Connected



                Timber.i(
                    "Bridge connected ${bridge.name}"
                )


            }else{


                _connectionState.value =
                    ConnectionState.Failed


            }



            result



        }catch(e:Exception){


            Timber.e(
                e,
                "Bridge connect failed"
            )


            _connectionState.value =
                ConnectionState.Failed


            false
        }

    }







    /**
     * اتصال تلقائي بعد Boot
     */
    suspend fun autoConnect():
            Boolean {


        repeat(8){


            val bridge =
                detect()



            if(bridge != null){


                if(connectBridge(bridge)){

                    return true

                }

            }



            Timber.d(
                "Waiting bridge startup..."
            )



            delay(5000)

        }



        return false

    }







    /**
     * تنفيذ Shell
     */
    suspend fun execute(
        command:String
    ):ShellResult =
        withContext(
            Dispatchers.IO
        ){



            currentBridge?.let { bridge ->



                try {


                    val result =
                        bridge.execute(command)



                    if(result.success){

                        return@withContext result

                    }


                }catch(e:Exception){


                    Timber.e(
                        e,
                        "Current bridge failed"
                    )


                    currentBridge=null

                }

            }







            /*
             إعادة البحث عن Bridge
             */
            val bridge =
                detect()



            if(
                bridge != null &&
                connectBridge(bridge)
            ){


                val result =
                    bridge.execute(command)



                if(result.success){

                    return@withContext result

                }

            }








            ShellResult(

                output = "",

                error =
                    "No shell bridge available",

                exitCode = -1,

                executionTime = 0

            )

        }







    /**
     * فصل الاتصال
     */
    suspend fun disconnect(){


        try {


            currentBridge
                ?.disconnect()



        }catch(e:Exception){


            Timber.e(
                e,
                "Disconnect failed"
            )

        }



        currentBridge=null



        _connectionState.value =
            ConnectionState.Disconnected


    }

}