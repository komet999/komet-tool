package com.titan.performance.presentation.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.performance.firewall.FirewallEngine
import com.titan.performance.firewall.FirewallRepository
import com.titan.performance.firewall.FirewallRule
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FirewallViewModel @Inject constructor(
    private val firewallRepository: FirewallRepository,
    private val firewallEngine: FirewallEngine
) : ViewModel() {

    val blockedApps: StateFlow<List<FirewallRule>> = firewallRepository.blockedApps

    private val _rootAvailable = MutableStateFlow(false)
    val rootAvailable: StateFlow<Boolean> = _rootAvailable.asStateFlow()

    private val _lastImportResult = MutableStateFlow<String?>(null)
    val lastImportResult: StateFlow<String?> = _lastImportResult.asStateFlow()

    init {
        viewModelScope.launch {
            _rootAvailable.value = firewallEngine.isRootBlockAvailable()
        }
    }

    fun unblock(rule: FirewallRule) {
        viewModelScope.launch {
            firewallRepository.unblockApp(rule.packageName, rule.uid)
        }
    }

    fun importConfig(uri: Uri) {
        viewModelScope.launch {
            val count = firewallRepository.importConfig(uri)
            _lastImportResult.value = "Imported and applied $count rule(s)"
        }
    }

    fun exportConfig(uri: Uri) {
        viewModelScope.launch {
            firewallRepository.exportConfig(uri)
        }
    }

    fun clearImportResult() {
        _lastImportResult.value = null
    }
}
