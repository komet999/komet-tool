package com.titan.performance.presentation.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.titan.performance.data.repository.SettingsRepository
import com.titan.performance.util.LocaleHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    application: Application,
    private val settingsRepository: SettingsRepository
) : AndroidViewModel(application) {

    val theme: StateFlow<String> = settingsRepository.theme.stateIn(viewModelScope, SharingStarted.WhileSubscribed(), "system")
    val language: StateFlow<String> = settingsRepository.language.stateIn(viewModelScope, SharingStarted.WhileSubscribed(), "device")
    val dynamicColors: StateFlow<Boolean> = settingsRepository.dynamicColors.stateIn(viewModelScope, SharingStarted.WhileSubscribed(), true)
    val notificationsEnabled: StateFlow<Boolean> = settingsRepository.notificationsEnabled.stateIn(viewModelScope, SharingStarted.WhileSubscribed(), true)
    val monitoringEnabled: StateFlow<Boolean> = settingsRepository.monitoringEnabled.stateIn(viewModelScope, SharingStarted.WhileSubscribed(), true)

    fun setTheme(theme: String) { viewModelScope.launch { settingsRepository.setTheme(theme) } }
    fun setLanguage(language: String) { 
        viewModelScope.launch { 
            settingsRepository.setLanguage(language)
            LocaleHelper.applyLocale(getApplication(), language)
            
            // TITAN GLOBAL BROADCAST: Force all contexts to sync
            val context = getApplication<Application>().applicationContext
            LocaleHelper.onAttach(context, language)
            
            _languageChanged.emit(Unit)
        } 
    }

    private val _languageChanged = MutableSharedFlow<Unit>()
    val languageChanged = _languageChanged.asSharedFlow()
    fun setDynamicColors(enabled: Boolean) { viewModelScope.launch { settingsRepository.setDynamicColors(enabled) } }
    fun setNotificationsEnabled(enabled: Boolean) { viewModelScope.launch { settingsRepository.setNotificationsEnabled(enabled) } }
    fun setMonitoringEnabled(enabled: Boolean) { viewModelScope.launch { settingsRepository.setMonitoringEnabled(enabled) } }
}
