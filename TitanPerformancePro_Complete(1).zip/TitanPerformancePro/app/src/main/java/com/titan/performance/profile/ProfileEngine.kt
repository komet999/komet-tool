package com.titan.performance.profile

import com.titan.performance.shell.ShellEngine
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProfileEngine @Inject constructor(
    private val shellEngine: ShellEngine
) {

    /**
     * Read-only performance profile information
     */
    suspend fun getCurrentProfileInfo(): Map<String, String> {
        val info = mutableMapOf<String, String>()
        try {
            // Read CPU governor
            val govResult = shellEngine.execute("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")
            info["cpu_governor"] = govResult.output.trim().ifEmpty { "unknown" }

            // Read current CPU freq
            val freqResult = shellEngine.execute("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
            val freq = freqResult.output.trim().toLongOrNull() ?: 0
            info["cpu_freq"] = "${freq / 1000} MHz"

            // Read available governors
            val availGov = shellEngine.execute("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors")
            info["available_governors"] = availGov.output.trim().ifEmpty { "unknown" }

            // Read thermal status
            val thermal = shellEngine.execute("cat /sys/class/thermal/thermal_zone0/temp")
            val temp = thermal.output.trim().toIntOrNull() ?: 0
            info["thermal"] = "${temp / 1000}°C"

        } catch (e: Exception) {
            Timber.e(e, "Failed to read profile info")
        }
        return info
    }

    /**
     * Get list of available performance profiles (informational only)
     */
    fun getAvailableProfiles(): List<ProfileType> {
        return listOf(
            ProfileType.BATTERY,
            ProfileType.BALANCED,
            ProfileType.PERFORMANCE,
            ProfileType.GAMING
        )
    }
}
