package com.titan.performance.system

interface SystemBackend {
    fun isAvailable(): Boolean
    suspend fun execute(command: String, timeoutMs: Long): BackendResult
    fun getName(): String
    fun getStatus(): String
}

data class BackendResult(
    val success: Boolean,
    val output: String,
    val error: String,
    val exitCode: Int
)
