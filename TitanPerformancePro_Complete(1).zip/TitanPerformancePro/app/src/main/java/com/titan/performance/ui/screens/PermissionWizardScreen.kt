package com.titan.performance.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.R
import com.titan.performance.bridge.ConnectionState
import com.titan.performance.presentation.viewmodel.PermissionWizardViewModel
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionWizardScreen(navController: NavController, viewModel: PermissionWizardViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val connectionState by viewModel.connectionState.collectAsState()
    val deviceProfile by viewModel.deviceProfile.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text(stringResource(R.string.dev_options), color = Color.White, fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Device Profile Card
            Surface(
                color = TitanCard,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(stringResource(R.string.device_info), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    deviceProfile?.let {
                        InfoRow(stringResource(R.string.device_model), it.model)
                        InfoRow(stringResource(R.string.manufacturer), it.manufacturer)
                        InfoRow(stringResource(R.string.android_version), it.androidVersion)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Connection Status
            Surface(
                color = TitanCard,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Backend Status", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    val (statusText, statusColor) = when (connectionState) {
                        ConnectionState.Connected -> stringResource(R.string.connected) to TitanGreen
                        ConnectionState.Connecting -> "Connecting..." to TitanTeal
                        ConnectionState.Disconnected -> stringResource(R.string.disconnected) to TitanGray
                        ConnectionState.Failed -> "Failed" to TitanRed
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(statusColor, RoundedCornerShape(6.dp))
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(statusText, color = statusColor, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Quick Actions
            Text("Quick Actions", color = TitanTeal, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionButton("Developer Options", Icons.Default.Code) {
                    context.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                }
                ActionButton("Wireless Debug", Icons.Default.Wifi) {
                    context.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ActionButton("App Settings", Icons.Default.Settings) {
                    context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.parse("package:${context.packageName}")
                    })
                }
                ActionButton("Battery", Icons.Default.BatteryFull) {
                    context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ActionButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .weight(1f)
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, null, tint = TitanTeal, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TitanGray, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
