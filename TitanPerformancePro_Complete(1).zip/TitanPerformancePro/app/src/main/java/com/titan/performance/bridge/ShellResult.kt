package com.titan.performance.bridge

data class ShellResult(
    val command: String = "",
    val output: String = "",
    val error: String = "",
    val exitCode: Int = -1,
    val executionTime: Long = 0L,
    val bridgeName: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    val success: Boolean
        get() = exitCode == 0
}
