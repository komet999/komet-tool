package com.titan.performance.bridge

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WirelessAdbExecutor @Inject constructor(
    private val manager: WirelessAdbManager
) {


    suspend fun execute(
        command: String
    ): ShellResult = withContext(
        Dispatchers.IO
    ) {


        val connection =
            manager.getConnection()
                ?: return@withContext ShellResult(
                    error = "No ADB device connected"
                )


        val start =
            System.currentTimeMillis()


        try {


            val process =
                Runtime.getRuntime()
                    .exec(
                        arrayOf(
                            "adb",
                            "-s",
                            "${connection.host}:${connection.port}",
                            "shell",
                            command
                        )
                    )


            val output =
                BufferedReader(
                    InputStreamReader(
                        process.inputStream
                    )
                )
                .readText()


            val error =
                BufferedReader(
                    InputStreamReader(
                        process.errorStream
                    )
                )
                .readText()


            val code =
                process.waitFor()


            ShellResult(
                output = output,
                error = error,
                exitCode = code,
                executionTime =
                    System.currentTimeMillis()
                    - start
            )


        } catch(e:Exception){


            Timber.e(e)


            ShellResult(
                error =
                e.message ?: "ADB execution failed"
            )

        }

    }

}