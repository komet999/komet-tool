package com.titan.performance.hardware

import com.titan.performance.shell.ShellEngine
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HardwareEngine @Inject constructor(
    private val shellEngine: ShellEngine
) {

    /**
     * Read current CPU governor (read-only)
     */
    suspend fun getCpuGovernor(): String {
        return try {
            val result = shellEngine.execute("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")
            result.output.trim().ifEmpty { "unknown" }
        } catch (e: Exception) {
            Timber.e(e, "Failed to read CPU governor")
            "unknown"
        }
    }

    /**
     * Read current CPU frequencies (read-only)
     */
    suspend fun getCpuFrequencies(): List<Pair<Int, String>> {
        val freqs = mutableListOf<Pair<Int, String>>()
        try {
            val result = shellEngine.execute("cat /proc/cpuinfo | grep -c processor")
            val cores = result.output.trim().toIntOrNull() ?: Runtime.getRuntime().availableProcessors()
            for (i in 0 until cores) {
                val freqResult = shellEngine.execute("cat /sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq")
                val freq = freqResult.output.trim().toLongOrNull() ?: 0L
                freqs.add(i to "${freq / 1000} MHz")
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to read CPU frequencies")
        }
        return freqs
    }

    /**
     * Read thermal zones (read-only)
     */
    suspend fun getThermalInfo(): List<Pair<String, String>> {
        val thermals = mutableListOf<Pair<String, String>>()
        try {
            val result = shellEngine.execute("cat /sys/class/thermal/thermal_zone*/type")
            val types = result.output.lines().filter { it.isNotBlank() }
            val temps = shellEngine.execute("cat /sys/class/thermal/thermal_zone*/temp")
            val temperatures = temps.output.lines().filter { it.isNotBlank() }
            types.zip(temperatures).forEach { (type, temp) ->
                val tempC = temp.toIntOrNull()?.let { it / 1000 } ?: 0
                thermals.add(type to "$tempC°C")
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to read thermal info")
        }
        return thermals
    }
}
