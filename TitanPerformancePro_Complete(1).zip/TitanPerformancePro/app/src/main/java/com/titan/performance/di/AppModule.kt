package com.titan.performance.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStoreFile
import androidx.room.Room
import com.titan.performance.data.local.TitanDatabase
import com.titan.performance.data.remote.ApiService
import com.titan.performance.util.Constants
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import timber.log.Timber
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDataStore(@ApplicationContext context: Context): DataStore<Preferences> {
        return PreferenceDataStoreFactory.create {
            context.preferencesDataStoreFile(Constants.DATASTORE_NAME)
        }
    }

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): TitanDatabase {
        return Room.databaseBuilder(
            context,
            TitanDatabase::class.java,
            Constants.DATABASE_NAME
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        val logging = HttpLoggingInterceptor { message ->
            Timber.tag("OkHttp").d(message)
        }.apply { level = HttpLoggingInterceptor.Level.BODY }
        return OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    @Provides
    @Singleton
    fun provideRetrofit(okHttpClient: OkHttpClient): Retrofit {
        val json = Json { ignoreUnknownKeys = true; isLenient = true }
        return Retrofit.Builder()
            .baseUrl(Constants.BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
    }

    @Provides
    @Singleton
    fun provideApiService(retrofit: Retrofit): ApiService {
        return retrofit.create(ApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideProfileDao(db: TitanDatabase) = db.profileDao()

    @Provides
    @Singleton
    fun provideModuleDao(db: TitanDatabase) = db.moduleDao()

    @Provides
    @Singleton
    fun provideLogDao(db: TitanDatabase) = db.logDao()

    @Provides
    @Singleton
    fun provideSettingDao(db: TitanDatabase) = db.settingDao()

    @Provides
    @Singleton
    fun provideHistoryDao(db: TitanDatabase) = db.historyDao()

    @Provides
    @Singleton
    fun provideStatisticDao(db: TitanDatabase) = db.statisticDao()

    @Provides
    @Singleton
    fun providePluginLogDao(db: TitanDatabase) = db.pluginLogDao()

    @Provides
    @Singleton
    fun provideBridgeConnectionDao(db: TitanDatabase) = db.bridgeConnectionDao()
}
