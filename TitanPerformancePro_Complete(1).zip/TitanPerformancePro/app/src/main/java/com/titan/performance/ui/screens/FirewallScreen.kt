package com.titan.performance.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.titan.performance.R
import com.titan.performance.service.TitanVpnService
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirewallScreen(navController: NavController) {
    val context = LocalContext.current
    var vpnEnabled by remember { mutableStateOf(false) }
    var selectedMode by remember { mutableStateOf(0) } // 0 = VPN, 1 = System
    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = {
                    Text(stringResource(R.string.firewall), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Firewall Status Card
            Surface(
                color = TitanCard,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(stringResource(R.string.firewall), color = TitanGray, fontSize = 12.sp)
                            Text(
                                if (vpnEnabled) stringResource(R.string.firewall_on) else stringResource(R.string.firewall_off),
                                color = if (vpnEnabled) TitanGreen else TitanRed,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Switch(
                            checked = vpnEnabled,
                            onCheckedChange = { enabled ->
                                vpnEnabled = enabled
                                if (enabled) {
                                    val intent = Intent(context, TitanVpnService::class.java)
                                    intent.action = TitanVpnService.ACTION_START
                                    context.startService(intent)
                                } else {
                                    val intent = Intent(context, TitanVpnService::class.java)
                                    intent.action = TitanVpnService.ACTION_STOP
                                    context.startService(intent)
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = TitanTeal,
                                checkedTrackColor = TitanTeal.copy(alpha = 0.5f)
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        stringResource(R.string.vpn_firewall),
                        color = TitanTeal,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Mode Selection
            Surface(
                color = TitanCard,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Mode", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    SingleChoiceSegmentedButtonRow {
                        SegmentedButton(
                            selected = selectedMode == 0,
                            onClick = { selectedMode = 0 },
                            shape = SegmentedButtonDefaults.itemShape(0, 2)
                        ) {
                            Text(stringResource(R.string.vpn_firewall))
                        }
                        SegmentedButton(
                            selected = selectedMode == 1,
                            onClick = { selectedMode = 1 },
                            shape = SegmentedButtonDefaults.itemShape(1, 2)
                        ) {
                            Text(stringResource(R.string.system_firewall))
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Rules Section (placeholder)
            Surface(
                color = TitanCard,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(stringResource(R.string.connection_logs), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("No connections logged yet", color = TitanGray, fontSize = 12.sp)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
