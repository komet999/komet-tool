package com.titan.performance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.R
import com.titan.performance.presentation.viewmodel.DashboardViewModel
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceScreen(navController: NavController, viewModel: DashboardViewModel = hiltViewModel()) {
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val liveHardware by viewModel.liveHardware.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = {
                    Text(stringResource(R.string.device), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Device Info
            Surface(
                color = TitanCard,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(stringResource(R.string.device_info), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    deviceInfo?.let {
                        DeviceInfoRow(Icons.Default.PhoneAndroid, stringResource(R.string.device_model), it.model)
                        DeviceInfoRow(Icons.Default.Business, stringResource(R.string.manufacturer), it.manufacturer)
                        DeviceInfoRow(Icons.Default.Android, stringResource(R.string.android_version), it.androidVersion)
                        DeviceInfoRow(Icons.Default.Security, stringResource(R.string.security_patch), it.securityPatch)
                        DeviceInfoRow(Icons.Default.Code, stringResource(R.string.api_level), "${it.apiLevel}")
                        DeviceInfoRow(Icons.Default.Memory, stringResource(R.string.kernel), it.kernelVersion)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Hardware Info
            Surface(
                color = TitanCard,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Hardware", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(16.dp))
                    liveHardware?.let {
                        DeviceInfoRow(Icons.Default.Speed, stringResource(R.string.cpu_frequency), it.cpuFreq)
                        DeviceInfoRow(Icons.Default.Dashboard, "SoC", it.socModel)
                        DeviceInfoRow(Icons.Default.Thermostat, stringResource(R.string.temperature), it.thermalStatus)
                        DeviceInfoRow(Icons.Default.BatteryFull, stringResource(R.string.battery_voltage), it.batteryVoltage)
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun DeviceInfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = TitanTeal, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(label, color = TitanGray, fontSize = 11.sp)
            Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
}
