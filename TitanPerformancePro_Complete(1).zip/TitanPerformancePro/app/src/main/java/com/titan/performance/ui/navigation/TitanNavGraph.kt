package com.titan.performance.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.titan.performance.ui.screens.*

@Composable
fun TitanNavGraph(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Dashboard.route,
        modifier = modifier
    ) {
        composable(Screen.Dashboard.route) { DashboardScreen(navController) }
        composable(Screen.Performance.route) { PerformanceScreen(navController) }
        composable(Screen.Firewall.route) { FirewallScreen(navController) }
        composable(Screen.Plugins.route) { PluginsScreen(navController) }
        composable(Screen.Terminal.route) { TerminalScreen(navController) }
        composable(Screen.Device.route) { DeviceScreen(navController) }
        composable(Screen.Logs.route) { LogsScreen(navController) }
        composable(Screen.Settings.route) { SettingsScreen(navController) }
        composable(Screen.About.route) { AboutScreen(navController) }
        composable(Screen.InstalledApps.route) { InstalledAppsScreen(navController) }
    }
}
