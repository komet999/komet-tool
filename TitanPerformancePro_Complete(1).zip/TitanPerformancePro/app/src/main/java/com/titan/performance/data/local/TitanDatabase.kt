package com.titan.performance.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.titan.performance.data.local.dao.*
import com.titan.performance.data.local.entity.*

@Database(
    entities = [
        ProfileEntity::class,
        ModuleEntity::class,
        LogEntity::class,
        SettingEntity::class,
        HistoryEntity::class,
        StatisticEntity::class,
        PluginLogEntity::class,
        BridgeConnectionEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class TitanDatabase : RoomDatabase() {
    abstract fun profileDao(): ProfileDao
    abstract fun moduleDao(): ModuleDao
    abstract fun logDao(): LogDao
    abstract fun settingDao(): SettingDao
    abstract fun historyDao(): HistoryDao
    abstract fun statisticDao(): StatisticDao
    abstract fun pluginLogDao(): PluginLogDao
    abstract fun bridgeConnectionDao(): BridgeConnectionDao
}
