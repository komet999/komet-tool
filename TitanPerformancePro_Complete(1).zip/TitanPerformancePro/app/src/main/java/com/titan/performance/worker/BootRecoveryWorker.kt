package com.titan.performance.worker

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.titan.performance.data.repository.SettingsRepository
import com.titan.performance.service.MonitoringService
import com.titan.performance.service.TitanVpnService
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import timber.log.Timber

@HiltWorker
class BootRecoveryWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val settingsRepository: SettingsRepository
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        Timber.i("Titan BootRecoveryWorker started")

        return try {
            // Restore monitoring service if enabled
            val monitoringEnabled = settingsRepository.isMonitoringEnabled()
            if (monitoringEnabled) {
                try {
                    val intent = Intent(applicationContext, MonitoringService::class.java)
                    ContextCompat.startForegroundService(applicationContext, intent)
                    Timber.i("Monitoring service restored")
                } catch (e: Exception) {
                    Timber.e(e, "Failed to restore monitoring")
                }
            }

            // Restore VPN firewall if enabled
            val firewallEnabled = settingsRepository.isVpnFirewallEnabled()
            if (firewallEnabled) {
                try {
                    val intent = Intent(applicationContext, TitanVpnService::class.java)
                    intent.action = TitanVpnService.ACTION_START
                    ContextCompat.startForegroundService(applicationContext, intent)
                    Timber.i("VPN firewall restored")
                } catch (e: Exception) {
                    Timber.e(e, "Failed to restore VPN firewall")
                }
            }

            Timber.i("Titan BootRecoveryWorker completed")
            Result.success()
        } catch (e: Exception) {
            Timber.e(e, "BootRecoveryWorker failed")
            Result.failure()
        }
    }
}
