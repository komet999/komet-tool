package com.titan.performance.profile

enum class ProfileType {
    GAMING, BATTERY, PERFORMANCE, BALANCED, EXTREME
}
