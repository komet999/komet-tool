package com.titan.performance.bridge

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class GenericAdbBridge @Inject constructor() : DeviceBridge {



    override val name: String = "ADB"



    override val priority: Int = 10





    override suspend fun isAvailable(): Boolean {


        return try {


            val process =
                Runtime.getRuntime()
                    .exec(
                        arrayOf(
                            "adb",
                            "devices"
                        )
                    )



            val output =
                BufferedReader(
                    InputStreamReader(
                        process.inputStream
                    )
                ).use {
                    it.readText()
                }



            output.contains(
                "\tdevice"
            )



        } catch (e: Exception) {


            Timber.e(
                e,
                "ADB detection failed"
            )


            false

        }

    }





    override suspend fun connect(): Boolean {

        return isAvailable()

    }





    override suspend fun execute(
        command: String
    ): ShellResult =
        withContext(
            Dispatchers.IO
        ) {



            val start =
                System.currentTimeMillis()



            try {


                val process =
                    Runtime.getRuntime()
                        .exec(
                            arrayOf(
                                "adb",
                                "shell",
                                command
                            )
                        )



                val output =
                    BufferedReader(
                        InputStreamReader(
                            process.inputStream
                        )
                    ).use {

                        it.readText()

                    }



                val error =
                    BufferedReader(
                        InputStreamReader(
                            process.errorStream
                        )
                    ).use {

                        it.readText()

                    }



                val code =
                    process.waitFor()



                ShellResult(

                    output = output,

                    error = error,

                    exitCode = code,

                    executionTime =
                        System.currentTimeMillis()
                                - start,

                    bridgeName = name

                )



            } catch (e: Exception) {


                Timber.e(
                    e,
                    "ADB execution failed"
                )



                ShellResult(

                    output = "",

                    error =
                        e.message
                            ?: "ADB error",

                    exitCode = -1,

                    executionTime =
                        System.currentTimeMillis()
                                - start,

                    bridgeName = name

                )

            }

        }





    override suspend fun disconnect() {


        Timber.d(
            "ADB disconnected"
        )


    }

}