package com.titan.performance.data.repository

import com.titan.performance.data.local.dao.ModuleDao
import com.titan.performance.data.local.entity.ModuleEntity
import com.titan.performance.data.remote.ApiService
import com.titan.performance.util.Resource
import kotlinx.coroutines.flow.Flow
import retrofit2.HttpException
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ModuleRepository @Inject constructor(
    private val moduleDao: ModuleDao,
    private val apiService: ApiService
) {
    fun getAllModules(): Flow<List<ModuleEntity>> = moduleDao.getAll()
    fun getInstalledModules(): Flow<List<ModuleEntity>> = moduleDao.getInstalled()
    suspend fun getModuleById(id: String): ModuleEntity? = moduleDao.getById(id)
    suspend fun installModule(module: ModuleEntity) = moduleDao.insert(module)
    suspend fun updateModule(module: ModuleEntity) = moduleDao.update(module)
    suspend fun deleteModule(module: ModuleEntity) = moduleDao.delete(module)
    suspend fun setModuleEnabled(id: String, enabled: Boolean) = moduleDao.setEnabled(id, enabled)

    suspend fun fetchModulesFromServer(): Resource<List<ModuleEntity>> {
        return try {
            val response = apiService.getModules()
            if (response.isSuccessful) {
                val modules = response.body()?.map { dto ->
                    ModuleEntity(
                        id = dto.id,
                        name = dto.name,
                        description = dto.description,
                        version = dto.version,
                        developer = dto.developer,
                        iconUrl = dto.iconUrl,
                        bannerUrl = dto.bannerUrl,
                        minAndroid = dto.minAndroid,
                        permissions = dto.permissions.joinToString(","),
                        changelog = dto.changelog
                    )
                } ?: emptyList()
                Resource.Success(modules)
            } else {
                Resource.Error("Server error: ${'$'}{response.code()}")
            }
        } catch (e: HttpException) {
            Resource.Error("Network error: ${'$'}{e.message()}")
        } catch (e: IOException) {
            Resource.Error("IO error: ${'$'}{e.message}")
        }
    }
}
