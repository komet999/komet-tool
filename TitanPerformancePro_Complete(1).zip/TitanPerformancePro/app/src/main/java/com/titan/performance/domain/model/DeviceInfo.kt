package com.titan.performance.domain.model

data class DeviceInfo(
    val manufacturer: String,
    val model: String,
    val device: String,
    val board: String,
    val hardware: String,
    val androidVersion: String,
    val sdkInt: Int,
    val securityPatch: String,
    val buildId: String,
    val fingerprint: String,
    val abi: String,
    val totalRam: Long,
    val totalStorage: Long,
    val screenResolution: String,
    val refreshRate: Float,
    val densityDpi: Int
)
