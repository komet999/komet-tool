package com.titan.performance.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bridge_connections")
data class BridgeConnectionEntity(
    @PrimaryKey
    val bridgeName: String,
    val host: String? = null,
    val port: Int? = null,
    val isConnected: Boolean = false,
    val lastConnected: Long = 0
)
