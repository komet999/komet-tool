package com.titan.performance.shizuku

import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import rikka.shizuku.Shizuku
import rikka.shizuku.Shizuku.OnRequestPermissionResultListener

class ShizukuPermissionHandler(
    private val activity: ComponentActivity,
    private val onResult: (granted: Boolean) -> Unit
) {
    private val listener = OnRequestPermissionResultListener { _, grantResult ->
        onResult(grantResult == PackageManager.PERMISSION_GRANTED)
    }

    init {
        Shizuku.addRequestPermissionResultListener(listener)
    }

    fun requestPermission(requestCode: Int = 1001) {
        if (Shizuku.isPreV11()) {
            onResult(false)
            return
        }
        if (ShizukuManager.hasPermission()) {
            onResult(true)
        } else {
            Shizuku.requestPermission(requestCode)
        }
    }

    fun dispose() {
        Shizuku.removeRequestPermissionResultListener(listener)
    }
}
