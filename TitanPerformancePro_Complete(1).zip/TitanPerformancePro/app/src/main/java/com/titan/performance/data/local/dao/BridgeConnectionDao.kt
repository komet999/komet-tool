package com.titan.performance.data.local.dao

import androidx.room.*
import com.titan.performance.data.local.entity.BridgeConnectionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BridgeConnectionDao {
    @Query("SELECT * FROM bridge_connections")
    fun getAll(): Flow<List<BridgeConnectionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(connection: BridgeConnectionEntity)

    @Delete
    suspend fun delete(connection: BridgeConnectionEntity)
}
