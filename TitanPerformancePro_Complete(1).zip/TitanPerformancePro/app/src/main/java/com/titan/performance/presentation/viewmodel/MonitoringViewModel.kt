package com.titan.performance.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.performance.data.local.entity.StatisticEntity
import com.titan.performance.data.repository.*
import com.titan.performance.domain.usecase.GetSystemStatsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MonitoringViewModel @Inject constructor(
    private val getSystemStats: GetSystemStatsUseCase,
    private val statisticRepository: StatisticRepository
) : ViewModel() {

    private val _statistics = MutableStateFlow<List<StatisticEntity>>(emptyList())
    val statistics: StateFlow<List<StatisticEntity>> = _statistics.asStateFlow()

    private val _isMonitoring = MutableStateFlow(false)
    val isMonitoring: StateFlow<Boolean> = _isMonitoring.asStateFlow()

    init { loadStatistics() }

    private fun loadStatistics() {
        viewModelScope.launch {
            statisticRepository.getRecentStatistics().collect { _statistics.value = it }
        }
    }

    fun startMonitoring() {
        _isMonitoring.value = true
        viewModelScope.launch {
            while (_isMonitoring.value) {
                val stats = getSystemStats()
                statisticRepository.insertStatistic(
                    StatisticEntity(
                        cpuUsage = stats.cpuUsagePercent,
                        ramUsage = stats.ramUsedPercent,
                        storageUsage = stats.storageUsedPercent,
                        batteryLevel = stats.batteryLevel,
                        temperature = stats.cpuTemperature
                    )
                )
                delay(1000)
            }
        }
    }

    fun stopMonitoring() { _isMonitoring.value = false }
    fun clearOldData() {
        viewModelScope.launch { statisticRepository.clearOldStatistics(7 * 24 * 60 * 60 * 1000L) }
    }
}
