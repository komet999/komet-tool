package com.titan.performance.device


import com.titan.performance.bridge.BridgeManager
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class DeviceRepository @Inject constructor(

    private val bridgeManager: BridgeManager

) {



    suspend fun loadDeviceInfo(): DeviceInfo {


        val bridge =
            bridgeManager.current()


        val connection =
            bridge?.name
                ?: "No Connection"



        val battery =
            bridgeManager.execute(
                "dumpsys battery | grep level"
            ).output



        val temp =
            bridgeManager.execute(
                "dumpsys battery | grep temperature"
            ).output



        val model =
            bridgeManager.execute(
                "getprop ro.product.model"
            ).output.trim()



        val manufacturer =
            bridgeManager.execute(
                "getprop ro.product.manufacturer"
            ).output.trim()



        val android =
            bridgeManager.execute(
                "getprop ro.build.version.release"
            ).output.trim()



        val ram =
            bridgeManager.execute(
                "cat /proc/meminfo | grep MemTotal"
            ).output.trim()



        return DeviceInfo(

            model = model,

            manufacturer = manufacturer,

            androidVersion = android,

            battery = battery,

            temperature = temp,

            ram = ram,

            connection = connection

        )

    }

}