package com.titan.performance.bridge

import android.content.Context
import com.titan.performance.shizuku.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import timber.log.Timber
import java.io.File

/**
 * Titan Daemon Manager - Engineered for Global Domination
 * يقوم هذا المحرك بحقن عمليات Java داخل النظام (DEX Injection)
 * تماماً كما يفعل AX Manager و Shizuku rish.
 */
object TitanDaemonManager {

    private const val DAEMON_NICE_NAME = "titan_daemon"

    suspend fun launchDaemon(context: Context, dexPath: String, className: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            if (!ShizukuManager.hasPermission()) {
                return@withContext Result.failure(Exception("Shizuku Permission Denied"))
            }

            val internalDex = File(context.filesDir, "daemon.dex")
            File(dexPath).copyTo(internalDex, overwrite = true)
            
            // جعل الملف قابلاً للقراءة فقط (شرط أندرويد 14+)
            internalDex.setWritable(false)
            internalDex.setReadable(true, false)

            val cmd = arrayOf(
                "export CLASSPATH=${internalDex.absolutePath}",
                "app_process /system/bin --nice-name=$DAEMON_NICE_NAME $className"
            ).joinToString(" && ")

            val process = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
            val exitCode = process.waitFor()

            if (exitCode == 0) {
                Timber.i("Titan Daemon Injected Successfully")
                Result.success(true)
            } else {
                val error = process.errorStream.bufferedReader().readText()
                Result.failure(Exception("Injection Failed: $error"))
            }
        } catch (e: Exception) {
            Timber.e(e, "Daemon Launch Error")
            Result.failure(e)
        }
    }

    /**
     * التحقق مما إذا كان الديمون نشطاً في الـ Kernel
     */
    suspend fun isDaemonRunning(): Boolean = withContext(Dispatchers.IO) {
        val result = Shizuku.newProcess(arrayOf("pgrep", "-f", DAEMON_NICE_NAME), null, null)
        val output = result.inputStream.bufferedReader().readText()
        output.isNotBlank()
    }
}
