package com.titan.performance.data.repository

import com.titan.performance.data.local.dao.HistoryDao
import com.titan.performance.data.local.entity.HistoryEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HistoryRepository @Inject constructor(
    private val historyDao: HistoryDao
) {
    fun getAllHistory(): Flow<List<HistoryEntity>> = historyDao.getAll()
    suspend fun addHistory(action: String, details: String) {
        historyDao.insert(HistoryEntity(action = action, details = details))
    }
    suspend fun clearOldHistory(olderThanMs: Long) = historyDao.deleteOlderThan(System.currentTimeMillis() - olderThanMs)
}
