package com.titan.performance.system.adb

import com.titan.performance.system.BackendResult
import com.titan.performance.system.SystemBackend
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AdbBackend @Inject constructor() : SystemBackend {

    private var adbConnected = false

    override fun isAvailable(): Boolean {
        // Check if wireless debugging is enabled
        return try {
            val process = Runtime.getRuntime().exec("getprop service.adb.tcp.port")
            val port = process.inputStream.bufferedReader().readText().trim()
            port.isNotBlank() && port != "-1"
        } catch (e: Exception) {
            false
        }
    }

    override suspend fun execute(command: String, timeoutMs: Long): BackendResult =
        withContext(Dispatchers.IO) {
            try {
                // ADB execution through local socket
                BackendResult(false, "", "ADB execution requires socket connection", -1)
            } catch (e: Exception) {
                Timber.e(e, "ADB execution failed")
                BackendResult(false, "", e.message ?: "ADB failed", -1)
            }
        }

    override fun getName(): String = "ADB"
    override fun getStatus(): String = if (isAvailable()) "Connected" else "Disconnected"
}
