package com.titan.performance.data.repository

import com.titan.performance.data.local.dao.LogDao
import com.titan.performance.data.local.entity.LogEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LogRepository @Inject constructor(
    private val logDao: LogDao
) {
    fun getAllLogs(): Flow<List<LogEntity>> = logDao.getAll()
    fun getLogsByTag(tag: String): Flow<List<LogEntity>> = logDao.getByTag(tag)
    fun getLogsByLevel(level: String): Flow<List<LogEntity>> = logDao.getByLevel(level)
    suspend fun insertLog(log: LogEntity) = logDao.insert(log)
    suspend fun clearOldLogs(olderThanMs: Long) = logDao.deleteOlderThan(System.currentTimeMillis() - olderThanMs)
    suspend fun clearAllLogs() = logDao.deleteAll()
}
