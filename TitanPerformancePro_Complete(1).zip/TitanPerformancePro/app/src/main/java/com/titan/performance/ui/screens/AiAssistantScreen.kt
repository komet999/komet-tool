package com.titan.performance.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiAssistantScreen(navController: NavController) {
    var message by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf(
        "Welcome to Titan Neural Hub. I am MRKOMET's AI engine. How can I optimize your device today?" to false
    ) }

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { 
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, null, tint = TitanTeal, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("TITAN NEURAL AI", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages) { (text, isUser) ->
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Surface(
                            color = if (isUser) TitanTeal.copy(alpha = 0.1f) else TitanCard,
                            shape = RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 16.dp,
                                bottomStart = if (isUser) 16.dp else 0.dp,
                                bottomEnd = if (isUser) 0.dp else 16.dp
                            ),
                            border = if (isUser) androidx.compose.foundation.BorderStroke(1.dp, TitanTeal.copy(alpha = 0.3f)) else null
                        ) {
                            Text(
                                text = text,
                                color = if (isUser) TitanTeal else Color.White,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextField(
                    value = message,
                    onValueChange = { message = it },
                    placeholder = { Text("Query Titan Engine...", color = TitanGray, fontSize = 12.sp) },
                    modifier = Modifier.weight(1f),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = TitanCard,
                        unfocusedContainerColor = TitanCard,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = TitanTeal,
                        focusedIndicatorColor = TitanTeal
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                FloatingActionButton(
                    onClick = {
                        if (message.isNotBlank()) {
                            val userMsg = message
                            messages.add(userMsg to true)
                            message = ""
                            // Simulate AI Response based on MRKOMET logic
                            messages.add("Analyzing '$userMsg'... Optimization profile suggested: EXTREME. Deploying Titan Vulcan Engine." to false)
                        }
                    },
                    containerColor = TitanTeal,
                    contentColor = TitanBlack,
                    modifier = Modifier.size(56.dp)
                ) {
                    Icon(Icons.Default.Send, null)
                }
            }
        }
    }
}
