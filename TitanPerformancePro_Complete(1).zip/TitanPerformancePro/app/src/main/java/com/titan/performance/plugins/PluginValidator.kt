package com.titan.performance.plugins

import android.content.Context
import kotlinx.serialization.json.Json
import timber.log.Timber
import java.io.File
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PluginValidator @Inject constructor() {

    data class ValidationResult(
        val valid: Boolean,
        val errors: List<String>,
        val warnings: List<String>
    )

    /**
     * Validate a plugin package before installation
     */
    fun validatePlugin(pluginDir: File): ValidationResult {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        // Check manifest exists
        val manifestFile = File(pluginDir, "plugin.json")
        if (!manifestFile.exists()) {
            errors.add("Missing plugin.json manifest")
            return ValidationResult(false, errors, warnings)
        }

        // Parse manifest
        val manifest = try {
            Json.decodeFromString<PluginManifest>(manifestFile.readText())
        } catch (e: Exception) {
            errors.add("Invalid plugin.json: ${e.message}")
            return ValidationResult(false, errors, warnings)
        }

        // Validate required fields
        if (manifest.id.isBlank()) errors.add("Plugin ID is required")
        if (manifest.name.isBlank()) errors.add("Plugin name is required")
        if (manifest.version.isBlank()) errors.add("Plugin version is required")
        if (manifest.author.isBlank()) errors.add("Plugin author is required")
        if (manifest.description.isBlank()) warnings.add("Plugin description is empty")

        // Check for dangerous commands in install.sh
        val installScript = File(pluginDir, "install.sh")
        if (installScript.exists()) {
            val content = installScript.readText().lowercase()
            val dangerousCommands = listOf("rm -rf /", "format", "dd if=", "mkfs", "flash")
            dangerousCommands.forEach { cmd ->
                if (content.contains(cmd)) {
                    errors.add("Dangerous command detected in install.sh: $cmd")
                }
            }
        }

        // Validate type
        val validTypes = listOf("monitoring", "widget", "profile", "device_info", "config")
        if (manifest.type !in validTypes) {
            warnings.add("Unknown plugin type: ${manifest.type}")
        }

        Timber.i("Plugin validation: ${manifest.name} - errors=${errors.size}, warnings=${warnings.size}")
        return ValidationResult(errors.isEmpty(), errors, warnings)
    }

    /**
     * Calculate SHA-256 hash of a file
     */
    fun calculateHash(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            var read: Int
            while (input.read(buffer).also { read = it } > 0) {
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
