package com.titan.performance.data.local.dao

import androidx.room.*
import com.titan.performance.data.local.entity.StatisticEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StatisticDao {
    @Query("SELECT * FROM statistics ORDER BY timestamp DESC LIMIT 100")
    fun getRecent(): Flow<List<StatisticEntity>>

    @Insert
    suspend fun insert(statistic: StatisticEntity)

    @Query("DELETE FROM statistics WHERE timestamp < :timestamp")
    suspend fun deleteOlderThan(timestamp: Long)
}