package com.titan.performance.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.performance.domain.model.SecurityScanResult
import com.titan.performance.domain.usecase.SecurityScanUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SecurityViewModel @Inject constructor(
    private val securityScanUseCase: SecurityScanUseCase
) : ViewModel() {

    private val _scanResult = MutableStateFlow<SecurityScanResult?>(null)
    val scanResult: StateFlow<SecurityScanResult?> = _scanResult.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    fun startScan() {
        viewModelScope.launch {
            _isScanning.value = true
            _scanResult.value = securityScanUseCase()
            _isScanning.value = false
        }
    }
}
