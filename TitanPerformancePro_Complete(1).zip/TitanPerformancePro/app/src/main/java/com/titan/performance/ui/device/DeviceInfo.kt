package com.titan.performance.device


data class DeviceInfo(

    val model:String = "",

    val manufacturer:String = "",

    val androidVersion:String = "",

    val battery:String = "",

    val temperature:String = "",

    val ram:String = "",

    val storage:String = "",

    val connection:String = "Disconnected"

)