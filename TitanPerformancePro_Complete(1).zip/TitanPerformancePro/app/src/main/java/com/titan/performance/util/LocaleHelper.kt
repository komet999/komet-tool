package com.titan.performance.util

import android.app.LocaleManager
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.LocaleList
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import java.util.Locale

object LocaleHelper {
    
    fun onAttach(context: Context, language: String): Context {
        return updateResources(context, language)
    }

    fun applyLocale(context: Context, languageCode: String) {
        val locale = if (languageCode == "device") Locale.getDefault() else Locale(languageCode)
        Locale.setDefault(locale)

        // Important: Update Application context as well
        updateResources(context.applicationContext, languageCode)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val localeManager = context.getSystemService(LocaleManager::class.java)
            if (languageCode == "device") {
                localeManager.applicationLocales = LocaleList.getEmptyLocaleList()
            } else {
                localeManager.applicationLocales = LocaleList(locale)
            }
        } else {
            val appLocale: LocaleListCompat = if (languageCode == "device") {
                LocaleListCompat.getEmptyLocaleList()
            } else {
                LocaleListCompat.forLanguageTags(languageCode)
            }
            AppCompatDelegate.setApplicationLocales(appLocale)
        }
    }

    private fun updateResources(context: Context, language: String): Context {
        val locale = if (language == "device") Locale.getDefault() else Locale(language)
        Locale.setDefault(locale)

        val res = context.resources
        val config = Configuration(res.configuration)
        
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val localeList = LocaleList(locale)
            config.setLocales(localeList)
            return context.createConfigurationContext(config)
        } else {
            res.updateConfiguration(config, res.displayMetrics)
            return context
        }
    }
}
