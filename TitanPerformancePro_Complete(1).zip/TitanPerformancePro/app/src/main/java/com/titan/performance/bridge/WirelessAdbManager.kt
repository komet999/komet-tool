package com.titan.performance.bridge

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.net.InetSocketAddress
import java.net.Socket
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class WirelessAdbManager @Inject constructor(
    @ApplicationContext private val context: Context
) {


    private val prefs: SharedPreferences =
        context.getSharedPreferences(
            "wireless_adb",
            Context.MODE_PRIVATE
        )



    data class AdbConnection(

        val host: String,

        val port: Int,

        val paired: Boolean,

        val lastConnected: Long

    )





    /**
     * حفظ بيانات Wireless Debugging
     */
    fun saveConnection(
        host: String,
        port: Int,
        paired: Boolean = true
    ) {


        prefs.edit {


            putString(
                "adb_host",
                host
            )


            putInt(
                "adb_port",
                port
            )


            putBoolean(
                "adb_paired",
                paired
            )


            putLong(
                "adb_last",
                System.currentTimeMillis()
            )


        }


    }





    fun getConnection(): AdbConnection? {


        val host =
            prefs.getString(
                "adb_host",
                null
            )
                ?: return null



        return AdbConnection(

            host = host,

            port =
                prefs.getInt(
                    "adb_port",
                    5555
                ),


            paired =
                prefs.getBoolean(
                    "adb_paired",
                    false
                ),


            lastConnected =
                prefs.getLong(
                    "adb_last",
                    0
                )

        )


    }







    fun isPaired(): Boolean {


        return prefs.getBoolean(
            "adb_paired",
            false
        )

    }






    fun clearConnection() {


        prefs.edit {


            clear()

        }

    }








    /**
     * فحص المنفذ
     */
    suspend fun testConnection(
        host: String,
        port: Int
    ): Boolean =
        withContext(
            Dispatchers.IO
        ) {


            try {


                Socket().use { socket ->


                    socket.connect(

                        InetSocketAddress(
                            host,
                            port
                        ),

                        3000

                    )


                    socket.isConnected

                }



            } catch (e: Exception) {


                Timber.w(
                    e,
                    "Wireless ADB unavailable"
                )


                false

            }


        }









    /**
     * إعادة الاتصال بعد إعادة تشغيل الجهاز
     */
    suspend fun autoReconnect():
            Boolean =
        withContext(
            Dispatchers.IO
        ) {


            val connection =
                getConnection()
                    ?: return@withContext false



            if(!connection.paired){

                return@withContext false

            }




            val result =
                testConnection(
                    connection.host,
                    connection.port
                )



            if(result){


                Timber.i(
                    "Wireless ADB restored ${connection.host}:${connection.port}"
                )

            }else{


                Timber.w(
                    "Wireless ADB lost after reboot"
                )

            }



            result


        }




}