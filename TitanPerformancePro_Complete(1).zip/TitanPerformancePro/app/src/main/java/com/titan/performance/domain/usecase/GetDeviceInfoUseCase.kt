package com.titan.performance.domain.usecase

import android.content.Context
import android.os.Build
import com.titan.performance.domain.model.DeviceInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class GetDeviceInfoUseCase @Inject constructor(
    @ApplicationContext private val context: Context
) {
    operator fun invoke(): DeviceInfo {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val memInfo = android.app.ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        val statFs = android.os.StatFs(android.os.Environment.getDataDirectory().path)
        val displayMetrics = context.resources.displayMetrics
        val refreshRate = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as android.hardware.display.DisplayManager
                displayManager.getDisplay(android.view.Display.DEFAULT_DISPLAY)?.refreshRate ?: 60f
            } else {
                60f
            }
        } catch (e: Exception) {
            60f
        }

        return DeviceInfo(
            manufacturer = Build.MANUFACTURER,
            model = Build.MODEL,
            device = Build.DEVICE,
            board = Build.BOARD,
            hardware = Build.HARDWARE,
            androidVersion = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            securityPatch = Build.VERSION.SECURITY_PATCH ?: "Unknown",
            buildId = Build.ID,
            fingerprint = Build.FINGERPRINT,
            abi = Build.SUPPORTED_ABIS.firstOrNull() ?: Build.CPU_ABI,
            totalRam = memInfo.totalMem,
            totalStorage = statFs.totalBytes,
            screenResolution = "${displayMetrics.widthPixels}x${displayMetrics.heightPixels}",
            refreshRate = refreshRate,
            densityDpi = displayMetrics.densityDpi
        )
    }
}
