package com.titan.performance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.R
import com.titan.performance.presentation.viewmodel.PluginsViewModel
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PluginsScreen(navController: NavController, viewModel: PluginsViewModel = hiltViewModel()) {
    val plugins by viewModel.plugins.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text(stringResource(R.string.plugins), color = Color.White, fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { viewModel.refreshPlugins() }) {
                        Icon(Icons.Default.Refresh, null, tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            if (plugins.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Extension,
                            null,
                            tint = TitanGray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            stringResource(R.string.no_plugins_installed),
                            color = TitanGray,
                            fontSize = 16.sp
                        )
                    }
                }
            } else {
                plugins.forEach { plugin ->
                    PluginCard(
                        name = plugin.name,
                        version = plugin.version,
                        author = plugin.author,
                        description = plugin.description,
                        enabled = plugin.enabled,
                        onToggle = { viewModel.togglePlugin(plugin) },
                        onUninstall = { viewModel.uninstallPlugin(plugin) }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun PluginCard(
    name: String,
    version: String,
    author: String,
    description: String,
    enabled: Boolean,
    onToggle: () -> Unit,
    onUninstall: () -> Unit
) {
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("v$version by $author", color = TitanGray, fontSize = 12.sp)
                }
                Switch(
                    checked = enabled,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(checkedTrackColor = TitanTeal)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(description, color = TitanGray, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(12.dp))
            TextButton(onClick = onUninstall) {
                Text(stringResource(R.string.uninstall), color = TitanRed)
            }
        }
    }
}
