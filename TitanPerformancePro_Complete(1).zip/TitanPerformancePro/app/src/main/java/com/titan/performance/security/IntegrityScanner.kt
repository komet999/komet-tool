package com.titan.performance.security

import android.content.pm.PackageManager
import com.titan.performance.shell.ShellEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class IntegrityScanner @Inject constructor(
    private val shellEngine: ShellEngine,
    private val packageManager: PackageManager
) {

    data class ScanResult(
        val packageName: String,
        val isSystemApp: Boolean,
        val hasRootAccess: Boolean,
        val isDebuggable: Boolean,
        val riskLevel: RiskLevel
    )

    enum class RiskLevel {
        SAFE, LOW, MEDIUM, HIGH
    }

    suspend fun scanInstalledApps(): List<ScanResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<ScanResult>()
        try {
            val packages = packageManager.getInstalledApplications(0)
            packages.forEach { app ->
                val isSystem = (app.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
                val isDebug = (app.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
                val risk = when {
                    isDebug -> RiskLevel.MEDIUM
                    !isSystem -> RiskLevel.LOW
                    else -> RiskLevel.SAFE
                }
                results.add(ScanResult(
                    packageName = app.packageName,
                    isSystemApp = isSystem,
                    hasRootAccess = false,
                    isDebuggable = isDebug,
                    riskLevel = risk
                ))
            }
        } catch (e: Exception) {
            Timber.e(e, "App scan failed")
        }
        results
    }

    suspend fun checkRootStatus(): Boolean = withContext(Dispatchers.IO) {
        try {
            val result = shellEngine.execute("which su")
            result.success
        } catch (e: Exception) {
            false
        }
    }
}
