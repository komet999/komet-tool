package com.titan.performance.bridge


interface DeviceBridge {


    /**
     * اسم الـ Bridge
     */
    val name: String



    /**
     * أولوية الاختيار
     *
     * Shizuku = 100
     * Wireless ADB = 50
     * Vendor Bridge = 30
     * Generic = 10
     */
    val priority: Int
        get() = 10




    /**
     * هل الـ Bridge متاح على الجهاز
     */
    suspend fun isAvailable(): Boolean




    /**
     * إنشاء اتصال
     *
     * التنفيذ الافتراضي:
     * يعتمد على توفر الـ Bridge
     */
    suspend fun connect(): Boolean {

        return isAvailable()

    }





    /**
     * هل الصلاحية موجودة
     */
    fun hasPermission(): Boolean {

        return true

    }





    /**
     * طلب الصلاحية
     */
    fun requestPermission() {

        // Default: no permission required

    }





    /**
     * تنفيذ أمر Shell
     */
    suspend fun execute(
        command: String
    ): ShellResult





    /**
     * إنهاء الاتصال
     */
    suspend fun disconnect()

}