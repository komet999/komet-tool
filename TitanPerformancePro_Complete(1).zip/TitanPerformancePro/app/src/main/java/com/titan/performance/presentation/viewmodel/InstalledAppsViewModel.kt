package com.titan.performance.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.performance.data.repository.InstalledAppsRepository
import com.titan.performance.domain.model.InstalledApp
import com.titan.performance.firewall.FirewallRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class AppFilter { ALL, USER, SYSTEM, BLOCKED }

@HiltViewModel
class InstalledAppsViewModel @Inject constructor(
    private val repository: InstalledAppsRepository,
    private val firewallRepository: FirewallRepository
) : ViewModel() {

    private val _apps = MutableStateFlow<List<InstalledApp>>(emptyList())
    val apps: StateFlow<List<InstalledApp>> = _apps.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _filter = MutableStateFlow(AppFilter.ALL)
    val filter: StateFlow<AppFilter> = _filter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _busyPackage = MutableStateFlow<String?>(null)
    val busyPackage: StateFlow<String?> = _busyPackage.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _isLoading.value = true
            _apps.value = repository.getAllApps()
            _isLoading.value = false
        }
    }

    fun setFilter(filter: AppFilter) {
        _filter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun filteredApps(): List<InstalledApp> {
        val query = _searchQuery.value.trim().lowercase()
        return _apps.value
            .filter { app ->
                when (_filter.value) {
                    AppFilter.ALL -> true
                    AppFilter.USER -> !app.isSystemApp
                    AppFilter.SYSTEM -> app.isSystemApp
                    AppFilter.BLOCKED -> app.isInternetBlocked
                }
            }
            .filter { query.isEmpty() || it.appName.lowercase().contains(query) || it.packageName.lowercase().contains(query) }
    }

    fun toggleInternetBlock(app: InstalledApp) {
        viewModelScope.launch {
            _busyPackage.value = app.packageName
            val success = if (app.isInternetBlocked) {
                firewallRepository.unblockApp(app.packageName, app.uid)
            } else {
                firewallRepository.blockApp(app.packageName, app.uid, app.appName)
            }
            if (success) {
                _apps.value = _apps.value.map {
                    if (it.packageName == app.packageName) it.copy(isInternetBlocked = !app.isInternetBlocked) else it
                }
            }
            _busyPackage.value = null
        }
    }
}
