package com.titan.performance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.R
import com.titan.performance.presentation.viewmodel.PerformanceViewModel
import com.titan.performance.ui.components.*
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerformanceScreen(navController: NavController, viewModel: PerformanceViewModel = hiltViewModel()) {
    val systemStats by viewModel.systemStats.collectAsState()
    val cpuHistory by viewModel.cpuHistory.collectAsState()
    val ramHistory by viewModel.ramHistory.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text(stringResource(R.string.performance), color = Color.White, fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // CPU Card
            Surface(
                color = TitanCard,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(stringResource(R.string.cpu), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("${systemStats?.cpuUsagePercent?.toInt() ?: 0}%", color = TitanTeal, fontSize = 36.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(8.dp))
                    RealTimeLineChart(
                        data = cpuHistory,
                        color = TitanTeal,
                        modifier = Modifier.fillMaxWidth().height(80.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            // RAM Card
            Surface(
                color = TitanCard,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(stringResource(R.string.ram), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("${systemStats?.ramUsedPercent?.toInt() ?: 0}%", color = TitanGreen, fontSize = 36.sp, fontWeight = FontWeight.Black)
                    Spacer(modifier = Modifier.height(8.dp))
                    RealTimeLineChart(
                        data = ramHistory,
                        color = TitanGreen,
                        modifier = Modifier.fillMaxWidth().height(80.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Stats Grid
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(stringResource(R.string.temperature), "${systemStats?.batteryTemperature ?: 0}°C", Icons.Default.Thermostat, TitanRed, Modifier.weight(1f))
                StatCard(stringResource(R.string.battery), "${systemStats?.batteryLevel ?: 0}%", Icons.Default.BatteryFull, TitanGreen, Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard(stringResource(R.string.storage), "${systemStats?.storageUsedPercent?.toInt() ?: 0}%", Icons.Default.SdStorage, TitanTeal, Modifier.weight(1f))
                StatCard(stringResource(R.string.network), "WiFi", Icons.Default.Wifi, TitanTeal, Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun StatCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, modifier: Modifier = Modifier) {
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(20.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Icon(icon, null, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text(label, color = TitanGray, fontSize = 11.sp)
        }
    }
}
