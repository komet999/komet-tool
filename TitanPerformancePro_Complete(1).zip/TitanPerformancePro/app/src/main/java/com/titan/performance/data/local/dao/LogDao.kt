package com.titan.performance.data.local.dao

import androidx.room.*
import com.titan.performance.data.local.entity.LogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LogDao {
    @Query("SELECT * FROM logs ORDER BY timestamp DESC")
    fun getAll(): Flow<List<LogEntity>>

    @Query("SELECT * FROM logs WHERE tag = :tag ORDER BY timestamp DESC")
    fun getByTag(tag: String): Flow<List<LogEntity>>

    @Query("SELECT * FROM logs WHERE level = :level ORDER BY timestamp DESC")
    fun getByLevel(level: String): Flow<List<LogEntity>>

    @Insert
    suspend fun insert(log: LogEntity)

    @Query("DELETE FROM logs WHERE timestamp < :timestamp")
    suspend fun deleteOlderThan(timestamp: Long)

    @Query("DELETE FROM logs")
    suspend fun deleteAll()
}