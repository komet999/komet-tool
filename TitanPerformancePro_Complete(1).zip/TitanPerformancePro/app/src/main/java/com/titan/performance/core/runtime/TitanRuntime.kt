package com.titan.performance.core.runtime

import android.content.Context
import androidx.work.*
import com.titan.performance.data.repository.SettingsRepository
import com.titan.performance.plugins.manager.PluginManager
import com.titan.performance.service.MonitoringService
import com.titan.performance.service.TitanVpnService
import com.titan.performance.system.shell.TitanShellEngine
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class TitanRuntime @Inject constructor(
    @ApplicationContext private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val pluginManager: PluginManager,
    private val shellEngine: TitanShellEngine
) {

    data class RuntimeState(
        val monitoringEnabled: Boolean,
        val vpnFirewallEnabled: Boolean,
        val systemFirewallEnabled: Boolean,
        val activePlugins: List<String>,
        val backendType: String
    )

    suspend fun saveState(state: RuntimeState) {
        val prefs = context.getSharedPreferences("titan_runtime", Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean("monitoring", state.monitoringEnabled)
            .putBoolean("vpn_firewall", state.vpnFirewallEnabled)
            .putBoolean("system_firewall", state.systemFirewallEnabled)
            .putStringSet("plugins", state.activePlugins.toSet())
            .putString("backend", state.backendType)
            .apply()
    }

    suspend fun restoreState(): RuntimeState {
        val prefs = context.getSharedPreferences("titan_runtime", Context.MODE_PRIVATE)
        return RuntimeState(
            monitoringEnabled = prefs.getBoolean("monitoring", false),
            vpnFirewallEnabled = prefs.getBoolean("vpn_firewall", false),
            systemFirewallEnabled = prefs.getBoolean("system_firewall", false),
            activePlugins = prefs.getStringSet("plugins", emptySet())?.toList() ?: emptyList(),
            backendType = prefs.getString("backend", "shell") ?: "shell"
        )
    }

    fun scheduleBootRecovery() {
        val workRequest = OneTimeWorkRequestBuilder<BootRecoveryWorker>()
            .setInitialDelay(10, TimeUnit.SECONDS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiresBatteryNotLow(false)
                    .build()
            )
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            "titan_boot_recovery",
            ExistingWorkPolicy.REPLACE,
            workRequest
        )
    }
}
