package com.titan.performance.plugins

import android.content.Context
import kotlinx.serialization.json.Json
import timber.log.Timber
import java.io.File

object PluginManager {

    fun getPluginsDirectory(context: Context): File {
        return File(context.getExternalFilesDir(null), "plugins").apply { mkdirs() }
    }

    /**
     * Deploy safe internal plugins from assets.
     * Only copies plugins that have a valid plugin.json manifest.
     */
    fun deployInternalPlugins(context: Context) {
        val pluginsDir = getPluginsDirectory(context)
        try {
            val assets = context.assets.list("plugins") ?: return
            assets.forEach { pluginName ->
                // Skip shell scripts at root level - only process directories with manifests
                val pluginFolder = File(pluginsDir, pluginName)
                if (pluginFolder.exists()) return@forEach

                val assetFiles = context.assets.list("plugins/$pluginName") ?: return@forEach
                if (!assetFiles.contains("plugin.json")) {
                    Timber.w("Skipping $pluginName - no plugin.json manifest found")
                    return@forEach
                }

                pluginFolder.mkdirs()
                assetFiles.forEach { fileName ->
                    val outFile = File(pluginFolder, fileName)
                    context.assets.open("plugins/$pluginName/$fileName").use { input ->
                        outFile.outputStream().use { output -> input.copyTo(output) }
                    }
                }
                // Do NOT auto-enable - user must explicitly enable
                Timber.i("Deployed plugin: $pluginName")
            }
        } catch (e: Exception) {
            Timber.e(e, "Plugin deployment failed")
        }
    }

    fun getInstalledPlugins(context: Context): List<Plugin> {
        val pluginsDir = getPluginsDirectory(context)
        if (!pluginsDir.exists()) return emptyList()

        return pluginsDir.listFiles()?.filter { it.isDirectory }?.mapNotNull { dir ->
            try {
                val manifestFile = File(dir, "plugin.json")
                if (!manifestFile.exists()) return@mapNotNull null
                val manifest = Json.decodeFromString<PluginManifest>(manifestFile.readText())
                val enabled = File(dir, ".enabled").exists()
                Plugin(
                    id = manifest.id,
                    name = manifest.name,
                    description = manifest.description,
                    version = manifest.version,
                    author = manifest.author,
                    type = manifest.type,
                    enabled = enabled,
                    path = dir.absolutePath,
                    installedAt = dir.lastModified()
                )
            } catch (e: Exception) {
                Timber.e(e, "Failed to parse plugin: ${dir.name}")
                null
            }
        } ?: emptyList()
    }

    fun getInstallScript(plugin: Plugin): File? {
        val script = File(plugin.path, "install.sh")
        return if (script.exists()) script else null
    }

    fun enablePlugin(plugin: Plugin) {
        File(plugin.path, ".enabled").createNewFile()
    }

    fun disablePlugin(plugin: Plugin) {
        File(plugin.path, ".enabled").delete()
    }

    fun uninstallPlugin(plugin: Plugin): Boolean {
        return File(plugin.path).deleteRecursively()
    }
}
