package com.titan.performance.plugins.executor

import android.content.Context
import com.titan.performance.system.shell.TitanShellEngine
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DexPluginExecutor @Inject constructor(
    private val shellEngine: TitanShellEngine,
    @ApplicationContext private val context: Context
) {

    data class ExecutionStep(
        val step: Int,
        val total: Int,
        val command: String,
        val status: String, // "running", "success", "error"
        val output: String = ""
    )

    /**
     * Execute a plugin's install.sh with live progress
     */
    fun executeInstallScript(pluginDir: File): Flow<ExecutionStep> = flow {
        val script = File(pluginDir, "install.sh")
        if (!script.exists()) {
            emit(ExecutionStep(0, 0, "", "error", "No install.sh found"))
            return@flow
        }

        // Read script and split into commands
        val commands = script.readLines()
            .filter { it.trim().isNotBlank() && !it.trim().startsWith("#") }

        val total = commands.size

        commands.forEachIndexed { index, cmd ->
            emit(ExecutionStep(index + 1, total, cmd, "running"))

            val result = shellEngine.execute(cmd)

            if (result.exitCode == 0) {
                emit(ExecutionStep(index + 1, total, cmd, "success", result.output))
            } else {
                emit(ExecutionStep(index + 1, total, cmd, "error", result.error))
                return@flow
            }
        }
    }.flowOn(Dispatchers.IO)

    /**
     * Execute a DEX file using app_process (like Axeron)
     */
    suspend fun executeDex(dexFile: File, className: String, args: List<String> = emptyList()): String =
        withContext(Dispatchers.IO) {
            try {
                val cmd = buildString {
                    append("app_process -Djava.class.path=${dexFile.absolutePath} /system/bin ")
                    append(className)
                    args.forEach { append(" $it") }
                }

                val result = shellEngine.execute(cmd)
                if (result.success) result.output else result.error
            } catch (e: Exception) {
                Timber.e(e, "DEX execution failed")
                "Error: ${e.message}"
            }
        }
}
