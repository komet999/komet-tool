package com.titan.performance.service

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.titan.performance.MainActivity
import com.titan.performance.R
import kotlinx.coroutines.*
import timber.log.Timber
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * VPN-based No-Root Firewall Service.
 * Intercepts all traffic and applies per-app allow/block rules.
 */
class TitanVpnService : VpnService() {

    private val isRunning = AtomicBoolean(false)
    private var vpnInterface: ParcelFileDescriptor? = null
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        const val ACTION_START = "com.titan.performance.START_VPN"
        const val ACTION_STOP = "com.titan.performance.STOP_VPN"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startVpn()
            ACTION_STOP -> stopVpn()
        }
        return START_NOT_STICKY
    }

    private fun startVpn() {
        if (isRunning.get()) return
        isRunning.set(true)

        val notification = createNotification()
        startForeground(1001, notification)

        serviceScope.launch {
            try {
                val builder = Builder()
                    .addAddress("10.0.0.2", 24)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer("1.1.1.1")
                    .addDnsServer("1.0.0.1")
                    .setSession(getString(R.string.app_name))
                    .setBlocking(true)

                vpnInterface = builder.establish()
                Timber.i("Titan VPN started")

                // Simple packet loop (placeholder for full implementation)
                vpnInterface?.let { iface ->
                    val buffer = ByteBuffer.allocate(32767)
                    val input = FileInputStream(iface.fileDescriptor)
                    val output = FileOutputStream(iface.fileDescriptor)

                    while (isRunning.get()) {
                        try {
                            val length = input.read(buffer.array())
                            if (length > 0) {
                                // In a full implementation, parse packets and apply rules here
                                // For now, pass through all traffic
                                output.write(buffer.array(), 0, length)
                            }
                        } catch (e: Exception) {
                            if (isRunning.get()) Timber.e(e, "VPN packet error")
                            break
                        }
                    }
                }
            } catch (e: Exception) {
                Timber.e(e, "VPN start failed")
                stopSelf()
            }
        }
    }

    private fun stopVpn() {
        isRunning.set(false)
        try {
            vpnInterface?.close()
        } catch (e: Exception) {
            Timber.e(e, "VPN close error")
        }
        vpnInterface = null
        serviceScope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        Timber.i("Titan VPN stopped")
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, "titan_firewall_channel")
            .setContentTitle(getString(R.string.vpn_firewall_active))
            .setContentText(getString(R.string.vpn_firewall_desc))
            .setSmallIcon(android.R.drawable.ic_secure)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}
