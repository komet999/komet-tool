package com.titan.performance.data.remote

import com.titan.performance.data.remote.dto.ModuleDto
import com.titan.performance.data.remote.dto.TranslationDto
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("modules")
    suspend fun getModules(): Response<List<ModuleDto>>

    @GET("modules/{id}")
    suspend fun getModuleDetail(@Path("id") id: String): Response<ModuleDto>

    @GET("translations/{lang}")
    suspend fun getTranslations(@Path("lang") lang: String): Response<TranslationDto>

    @GET("translations/check")
    suspend fun checkTranslationVersion(@Query("lang") lang: String, @Query("version") version: Int): Response<Boolean>
}
