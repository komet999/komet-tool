package com.titan.performance.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.titan.performance.bridge.BridgeManager
import com.titan.performance.bridge.ConnectionState
import com.titan.performance.shell.ShellEngine
import com.titan.performance.shizuku.ShizukuShell
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TerminalViewModel @Inject constructor(
    private val shellEngine: ShellEngine,
    private val bridgeManager: BridgeManager
) : ViewModel() {

    private val _history = MutableStateFlow<List<com.titan.performance.bridge.ShellResult>>(emptyList())
    val history: StateFlow<List<com.titan.performance.bridge.ShellResult>> = _history.asStateFlow()

    private val _isExecuting = MutableStateFlow(false)
    val isExecuting: StateFlow<Boolean> = _isExecuting.asStateFlow()

    private val _currentLiveOutput = MutableStateFlow("")
    val currentLiveOutput: StateFlow<String> = _currentLiveOutput.asStateFlow()

    fun executeCommand(command: String) {
        viewModelScope.launch {
            _isExecuting.value = true
            _currentLiveOutput.value = ""
            
            // Auto-connect if link is dead
            if (bridgeManager.connectionState.value != ConnectionState.Connected) {
                bridgeManager.autoConnect()
            }

            val startTime = System.currentTimeMillis()
            val outputBuffer = StringBuilder()
            
            ShizukuShell.executeLive(command).onEach { line ->
                outputBuffer.append(line).append("\n")
                _currentLiveOutput.value = outputBuffer.toString()
            }.onCompletion {
                val finalOutput = outputBuffer.toString()
                val result = com.titan.performance.bridge.ShellResult(
                    command = command,
                    output = finalOutput,
                    exitCode = 0,
                    executionTime = System.currentTimeMillis() - startTime,
                    bridgeName = "Titan Stream Shell"
                )
                _history.value = (_history.value + result).takeLast(50)
                _currentLiveOutput.value = ""
                _isExecuting.value = false
            }.launchIn(this)
        }
    }

    fun clearHistory() { 
        _history.value = emptyList() 
        _currentLiveOutput.value = ""
    }
}
