package com.titan.performance.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Facebook
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

private data class DevLink(val label: String, val url: String, val icon: ImageVector)

private val devLinks = listOf(
    DevLink("Facebook", "https://www.facebook.com/komet.shkohi.2025", Icons.Default.Facebook),
    DevLink("Telegram", "https://t.me/Komaitsh", Icons.Default.Send),
    DevLink("YouTube", "https://www.youtube.com/@komet22", Icons.Default.SmartDisplay)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeveloperScreen(navController: NavController) {
    val context = LocalContext.current
    Scaffold(topBar = { TopAppBar(title = { Text("Developer") }) }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("App Version: 1.0.0"); Text("Build: 1")
                    Text("System: Android ${android.os.Build.VERSION.RELEASE}")
                    Text("SDK: ${android.os.Build.VERSION.SDK_INT}")
                    Text("Developer: MR KOMET / Zoala Tech")
                }
            }

            devLinks.forEach { link ->
                OutlinedButton(
                    onClick = {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link.url)))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(link.icon, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(link.label)
                    Spacer(modifier = Modifier.weight(1f))
                    Icon(Icons.Default.OpenInBrowser, contentDescription = null)
                }
            }
        }
    }
}
