package com.titan.performance.domain.usecase

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.titan.performance.domain.model.*
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class SecurityScanUseCase @Inject constructor(
    @ApplicationContext private val context: Context
) {
    operator fun invoke(): SecurityScanResult {
        val issues = mutableListOf<SecurityIssue>()
        val recommendations = mutableListOf<String>()
        val pm = context.packageManager
        val packages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0))
        } else {
            pm.getInstalledPackages(0)
        }

        val appsWithDangerousPerms = packages.count { pkg ->
            val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(pkg.packageName, PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())).requestedPermissions
            } else {
                pkg.requestedPermissions
            }
            perms?.any { it.contains("android.permission.") && !it.contains("NORMAL") } ?: false
        }

        if (appsWithDangerousPerms > 10) {
            issues.add(SecurityIssue(IssueSeverity.MEDIUM, "Permissions", "$appsWithDangerousPerms apps have sensitive permissions", "Review app permissions in Settings"))
        }

        val statFs = android.os.StatFs(android.os.Environment.getDataDirectory().path)
        val storagePercent = ((statFs.totalBytes - statFs.availableBytes).toFloat() / statFs.totalBytes.toFloat()) * 100
        if (storagePercent > 90) {
            issues.add(SecurityIssue(IssueSeverity.HIGH, "Storage", "Storage is ${storagePercent.toInt()}% full", "Free up storage space"))
        }

        val adbEnabled = android.provider.Settings.Global.getInt(context.contentResolver, android.provider.Settings.Global.ADB_ENABLED, 0) == 1
        if (adbEnabled) {
            issues.add(SecurityIssue(IssueSeverity.MEDIUM, "Settings", "USB Debugging is enabled", "Disable USB Debugging when not needed"))
        }

        val unknownSources = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            pm.canRequestPackageInstalls()
        } else {
            android.provider.Settings.Secure.getInt(context.contentResolver, android.provider.Settings.Secure.INSTALL_NON_MARKET_APPS, 0) == 1
        }
        if (unknownSources) {
            issues.add(SecurityIssue(IssueSeverity.HIGH, "Settings", "Installation from unknown sources is allowed", "Disable unknown sources installation"))
        }

        val appScore = maxOf(0, 100 - packages.size / 5)
        val permScore = maxOf(0, 100 - appsWithDangerousPerms * 2)
        val storageScore = maxOf(0, 100 - storagePercent.toInt())
        val settingsScore = maxOf(0, 100 - issues.count { it.category == "Settings" } * 15)
        val overall = (appScore + permScore + storageScore + settingsScore) / 4

        if (overall < 70) recommendations.add("Review and fix identified security issues")
        if (storagePercent > 80) recommendations.add("Clean up storage to improve performance and security")
        recommendations.add("Keep your device updated with latest security patches")
        recommendations.add("Use strong screen lock and biometric authentication")

        return SecurityScanResult(overall, appScore, permScore, storageScore, settingsScore, issues, recommendations)
    }
}
