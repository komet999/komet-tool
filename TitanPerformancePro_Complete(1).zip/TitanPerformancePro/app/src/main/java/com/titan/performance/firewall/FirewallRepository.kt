package com.titan.performance.firewall

import android.content.Context
import com.titan.performance.data.local.dao.LogDao
import com.titan.performance.data.local.entity.LogEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirewallRepository @Inject constructor(
    private val firewallEngine: FirewallEngine,
    private val logDao: LogDao,
    @ApplicationContext private val context: Context
) {
    private val _isVpnEnabled = MutableStateFlow(false)
    val isVpnEnabled: StateFlow<Boolean> = _isVpnEnabled

    private val _isSystemFirewallEnabled = MutableStateFlow(false)
    val isSystemFirewallEnabled: StateFlow<Boolean> = _isSystemFirewallEnabled

    private val _logs = MutableStateFlow<List<LogEntity>>(emptyList())
    val logs: StateFlow<List<LogEntity>> = _logs

    suspend fun enableVpnFirewall() {
        _isVpnEnabled.value = true
        Timber.i("VPN Firewall enabled")
    }

    suspend fun disableVpnFirewall() {
        _isVpnEnabled.value = false
        Timber.i("VPN Firewall disabled")
    }

    suspend fun enableSystemFirewall() {
        _isSystemFirewallEnabled.value = true
        Timber.i("System Firewall enabled")
    }

    suspend fun disableSystemFirewall() {
        _isSystemFirewallEnabled.value = false
        Timber.i("System Firewall disabled")
    }

    suspend fun blockApp(uid: Int, packageName: String): Boolean {
        return withContext(Dispatchers.IO) {
            val success = firewallEngine.blockApp(uid, packageName)
            if (success) {
                logDao.insert(LogEntity(
                    tag = "FIREWALL",
                    message = "Blocked $packageName",
                    timestamp = System.currentTimeMillis()
                ))
            }
            success
        }
    }

    suspend fun unblockApp(uid: Int, packageName: String): Boolean {
        return withContext(Dispatchers.IO) {
            val success = firewallEngine.unblockApp(uid, packageName)
            if (success) {
                logDao.insert(LogEntity(
                    tag = "FIREWALL",
                    message = "Unblocked $packageName",
                    timestamp = System.currentTimeMillis()
                ))
            }
            success
        }
    }

    suspend fun loadLogs() {
        _logs.value = logDao.getAllLogs()
    }
}
