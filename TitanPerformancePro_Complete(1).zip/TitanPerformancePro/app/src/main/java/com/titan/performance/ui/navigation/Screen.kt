package com.titan.performance.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val titleRes: Int, val icon: ImageVector) {
    data object Dashboard : Screen("dashboard", R.string.dashboard, Icons.Default.Dashboard)
    data object Performance : Screen("performance", R.string.performance, Icons.Default.Speed)
    data object Firewall : Screen("firewall", R.string.firewall, Icons.Default.VpnLock)
    data object Plugins : Screen("plugins", R.string.plugins, Icons.Default.Extension)
    data object Terminal : Screen("terminal", R.string.terminal, Icons.Default.Terminal)
    data object Device : Screen("device", R.string.device, Icons.Default.PhoneAndroid)
    data object Logs : Screen("logs", R.string.logs, Icons.Default.ListAlt)
    data object Settings : Screen("settings", R.string.settings, Icons.Default.Settings)
    data object About : Screen("about", R.string.about, Icons.Default.Info)
    data object InstalledApps : Screen("installed_apps", R.string.apps, Icons.Default.Apps)
}
