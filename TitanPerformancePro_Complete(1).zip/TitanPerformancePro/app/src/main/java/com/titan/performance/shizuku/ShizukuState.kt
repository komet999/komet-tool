package com.titan.performance.shizuku

sealed class ShizukuState {
    data object Available : ShizukuState()
    data object NotInstalled : ShizukuState()
    data object PermissionDenied : ShizukuState()
    data object Running : ShizukuState()
    data class Error(val message: String) : ShizukuState()
}
