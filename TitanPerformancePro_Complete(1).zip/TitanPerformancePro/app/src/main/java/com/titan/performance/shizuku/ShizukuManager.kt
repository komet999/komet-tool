package com.titan.performance.shizuku

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import timber.log.Timber

object ShizukuManager {

    private const val REQUEST_CODE = 200


    /**
     * هل Shizuku يعمل
     */
    fun isRunning(): Boolean {
        return try {

            Shizuku.pingBinder()

        } catch (e: Exception) {

            Timber.e(
                e,
                "Shizuku is not running"
            )

            false
        }
    }


    /**
     * هل توجد صلاحية Shizuku
     */
    fun hasPermission(): Boolean {

        return try {

            Shizuku.checkSelfPermission() ==
                    PackageManager.PERMISSION_GRANTED

        } catch (e: Exception) {

            Timber.e(
                e,
                "Permission check failed"
            )

            false
        }
    }



    /**
     * طلب صلاحية Shizuku
     */
    fun requestPermission() {

        try {

            if (isRunning() && !hasPermission()) {

                Shizuku.requestPermission(
                    REQUEST_CODE
                )

                Timber.i(
                    "Shizuku permission requested"
                )
            }

        } catch (e: Exception) {

            Timber.e(
                e,
                "Permission request failed"
            )
        }
    }



    /**
     * مراقبة نتيجة منح الصلاحية
     */
    fun registerPermissionListener(
        listener: () -> Unit
    ) {

        try {

            Shizuku.addRequestPermissionResultListener {
                    requestCode,
                    grantResult ->


                if (
                    requestCode == REQUEST_CODE &&
                    grantResult == PackageManager.PERMISSION_GRANTED
                ) {

                    Timber.i(
                        "Shizuku permission granted"
                    )

                    listener()
                }
            }


        } catch (e: Exception) {

            Timber.e(
                e,
                "Permission listener failed"
            )
        }
    }



    /**
     * جاهزية Shizuku للتنفيذ
     */
    fun canUseShizuku(): Boolean {

        return isRunning() &&
                hasPermission()

    }

    /**
     * الحصول على حالة Shizuku الحالية
     */
    fun getState(): ShizukuState {
        return try {
            if (!isRunning()) {
                ShizukuState.NotInstalled
            } else if (!hasPermission()) {
                ShizukuState.PermissionDenied
            } else {
                ShizukuState.Running
            }
        } catch (e: Exception) {
            ShizukuState.Error(e.message ?: "Unknown Shizuku Error")
        }
    }

}