package com.titan.performance.hardware

import com.titan.performance.shell.ShellEngine
import dagger.hilt.android.qualifiers.ApplicationContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TweaksEngine @Inject constructor(
    private val shellEngine: ShellEngine,
    @ApplicationContext private val context: android.content.Context
) {

    /**
     * Read current system performance settings (read-only, safe)
     */
    suspend fun readPerformanceSettings(): Map<String, String> {
        val settings = mutableMapOf<String, String>()
        try {
            val result = shellEngine.execute("settings list global | grep -E 'game_mode|cached_apps_freezer'")
            result.output.lines().forEach { line ->
                val parts = line.split("=", limit = 2)
                if (parts.size == 2) settings[parts[0].trim()] = parts[1].trim()
            }
        } catch (e: Exception) {
            Timber.e(e, "Failed to read performance settings")
        }
        return settings
    }

    /**
     * Check if fixed performance mode is enabled (read-only)
     */
    suspend fun isFixedPerformanceMode(): Boolean {
        return try {
            val result = shellEngine.execute("cmd power get-fixed-performance-mode-enabled")
            result.output.trim() == "true"
        } catch (e: Exception) {
            false
        }
    }
}
