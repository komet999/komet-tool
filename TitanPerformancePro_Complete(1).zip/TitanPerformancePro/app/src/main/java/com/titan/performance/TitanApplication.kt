package com.titan.performance

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.titan.performance.util.LocaleHelper
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber
import javax.inject.Inject

@HiltAndroidApp
class TitanApplication : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    override fun attachBaseContext(base: Context) {
        val prefs = base.getSharedPreferences("settings_prefs", Context.MODE_PRIVATE)
        val lang = prefs.getString("language", "device") ?: "device"
        super.attachBaseContext(LocaleHelper.onAttach(base, lang))
    }

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            val monitoringChannel = NotificationChannel(
                "titan_monitoring_channel",
                getString(R.string.channel_monitoring),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.channel_monitoring_desc)
            }

            val firewallChannel = NotificationChannel(
                "titan_firewall_channel",
                getString(R.string.channel_firewall),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = getString(R.string.channel_firewall_desc)
            }

            val pluginChannel = NotificationChannel(
                "titan_plugin_channel",
                getString(R.string.channel_plugin),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = getString(R.string.channel_plugin_desc)
            }

            val recoveryChannel = NotificationChannel(
                "titan_recovery_channel",
                getString(R.string.channel_recovery),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = getString(R.string.channel_recovery_desc)
            }

            manager.createNotificationChannels(
                listOf(monitoringChannel, firewallChannel, pluginChannel, recoveryChannel)
            )
        }
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(android.util.Log.DEBUG)
            .build()
}
