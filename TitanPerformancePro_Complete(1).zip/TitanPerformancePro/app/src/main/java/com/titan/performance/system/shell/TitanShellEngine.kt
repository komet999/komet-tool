package com.titan.performance.system.shell

import com.titan.performance.system.adb.AdbBackend
import com.titan.performance.system.root.RootBackend
import com.titan.performance.system.shizuku.ShizukuBackend
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton

data class ShellResult(
    val command: String,
    val output: String,
    val error: String,
    val exitCode: Int,
    val backend: BackendType,
    val executionTime: Long = 0
)

enum class BackendType {
    ROOT, SHIZUKU, ADB, SHELL, NONE
}

@Singleton
class TitanShellEngine @Inject constructor(
    private val rootBackend: RootBackend,
    private val shizukuBackend: ShizukuBackend,
    private val adbBackend: AdbBackend
) {
    /**
     * Auto-select best backend:
     * ROOT → SHIZUKU → ADB → SHELL
     */
    suspend fun execute(command: String, timeoutMs: Long = 30000): ShellResult {
        val startTime = System.currentTimeMillis()

        // Try ROOT first
        if (rootBackend.isAvailable()) {
            val result = rootBackend.execute(command, timeoutMs)
            if (result.success) {
                return ShellResult(
                    command = command,
                    output = result.output,
                    error = result.error,
                    exitCode = result.exitCode,
                    backend = BackendType.ROOT,
                    executionTime = System.currentTimeMillis() - startTime
                )
            }
        }

        // Try SHIZUKU
        if (shizukuBackend.isAvailable()) {
            val result = shizukuBackend.execute(command, timeoutMs)
            if (result.success) {
                return ShellResult(
                    command = command,
                    output = result.output,
                    error = result.error,
                    exitCode = result.exitCode,
                    backend = BackendType.SHIZUKU,
                    executionTime = System.currentTimeMillis() - startTime
                )
            }
        }

        // Try ADB
        if (adbBackend.isAvailable()) {
            val result = adbBackend.execute(command, timeoutMs)
            if (result.success) {
                return ShellResult(
                    command = command,
                    output = result.output,
                    error = result.error,
                    exitCode = result.exitCode,
                    backend = BackendType.ADB,
                    executionTime = System.currentTimeMillis() - startTime
                )
            }
        }

        // Fallback to basic shell
        return executeBasic(command, timeoutMs, startTime)
    }

    private suspend fun executeBasic(command: String, timeoutMs: Long, startTime: Long): ShellResult =
        withContext(Dispatchers.IO) {
            try {
                val process = Runtime.getRuntime().exec(command)

                val stdout = withTimeoutOrNull(timeoutMs) {
                    BufferedReader(InputStreamReader(process.inputStream)).readText()
                } ?: ""

                val stderr = withTimeoutOrNull(timeoutMs) {
                    BufferedReader(InputStreamReader(process.errorStream)).readText()
                } ?: ""

                val exitCode = withTimeoutOrNull(timeoutMs) {
                    process.waitFor()
                } ?: -1

                ShellResult(
                    command = command,
                    output = stdout,
                    error = stderr,
                    exitCode = exitCode,
                    backend = BackendType.SHELL,
                    executionTime = System.currentTimeMillis() - startTime
                )
            } catch (e: Exception) {
                Timber.e(e, "Shell execution failed: $command")
                ShellResult(
                    command = command,
                    output = "",
                    error = e.message ?: "Execution failed",
                    exitCode = -1,
                    backend = BackendType.NONE,
                    executionTime = System.currentTimeMillis() - startTime
                )
            }
        }

    fun getActiveBackend(): BackendType {
        return when {
            rootBackend.isAvailable() -> BackendType.ROOT
            shizukuBackend.isAvailable() -> BackendType.SHIZUKU
            adbBackend.isAvailable() -> BackendType.ADB
            else -> BackendType.SHELL
        }
    }
}
