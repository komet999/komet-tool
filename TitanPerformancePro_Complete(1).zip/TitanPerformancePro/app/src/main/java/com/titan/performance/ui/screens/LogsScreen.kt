package com.titan.performance.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.presentation.viewmodel.LogsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogsScreen(navController: NavController, viewModel: LogsViewModel = hiltViewModel()) {
    val logs by viewModel.logs.collectAsState()
    Scaffold(topBar = {
        TopAppBar(title = { Text("Logs") }, actions = {
            IconButton(onClick = { viewModel.clearLogs() }) { Icon(Icons.Default.Delete, contentDescription = "Clear") }
        })
    }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            items(logs.size) { index ->
                val log = logs[index]
                Text("[${log.level}] ${log.tag}: ${log.message}", style = MaterialTheme.typography.bodySmall)
                Divider()
            }
        }
    }
}
