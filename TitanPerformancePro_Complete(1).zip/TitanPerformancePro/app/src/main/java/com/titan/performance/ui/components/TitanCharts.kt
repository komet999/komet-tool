package com.titan.performance.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.titan.performance.ui.theme.TitanTeal

@Composable
fun RealTimeLineChart(
    data: List<Float>,
    modifier: Modifier = Modifier,
    color: Color = TitanTeal,
    fillColor: Color = TitanTeal.copy(alpha = 0.1f)
) {
    val animatedData = remember { mutableStateListOf<Float>() }
    
    LaunchedEffect(data) {
        animatedData.clear()
        animatedData.addAll(data)
    }

    Canvas(modifier = modifier) {
        if (animatedData.size < 2) return@Canvas

        val path = Path()
        val fillPath = Path()
        val width = size.width
        val height = size.height
        val maxData = 100f 
        val stepX = width / (animatedData.size - 1)

        animatedData.forEachIndexed { index, value ->
            val x = index * stepX
            val y = height - (value.coerceIn(0f, 100f) / maxData * height)
            if (index == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, height)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
            if (index == animatedData.size - 1) {
                fillPath.lineTo(x, height)
                fillPath.close()
            }
        }

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(fillColor, Color.Transparent)
            )
        )

        drawPath(
            path = path,
            color = color,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        
        // Glow effect on last point
        drawCircle(
            color = color,
            radius = 4.dp.toPx(),
            center = Offset((animatedData.size - 1) * stepX, height - (animatedData.last().coerceIn(0f, 100f) / maxData * height)),
            alpha = 0.8f
        )
    }
}
