package com.titan.performance.presentation.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.titan.performance.data.local.dao.PluginLogDao
import com.titan.performance.data.local.entity.PluginLogEntity
import com.titan.performance.plugins.*
import com.titan.performance.shizuku.ShizukuManager
import com.titan.performance.shizuku.ShizukuState
import com.titan.performance.util.FileUtil
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File
import javax.inject.Inject

@HiltViewModel
class PluginsViewModel @Inject constructor(
    application: Application,
    private val pluginLogDao: PluginLogDao,
    private val pluginExecutor: PluginExecutor
) : AndroidViewModel(application) {

    private val _plugins = MutableStateFlow<List<Plugin>>(emptyList())
    val plugins: StateFlow<List<Plugin>> = _plugins.asStateFlow()

    private val _shizukuState = MutableStateFlow<ShizukuState>(ShizukuManager.getState())
    val shizukuState: StateFlow<ShizukuState> = _shizukuState.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _installResult = MutableStateFlow<String?>(null)
    val installResult: StateFlow<String?> = _installResult.asStateFlow()

    private val _liveLog = MutableStateFlow<List<String>>(emptyList())
    val liveLog: StateFlow<List<String>> = _liveLog.asStateFlow()

    private val _showLogConsole = MutableStateFlow(false)
    val showLogConsole: StateFlow<Boolean> = _showLogConsole.asStateFlow()

    init {
        refreshPlugins()
        refreshShizuku()
    }

    fun refreshPlugins() {
        val context = getApplication<Application>().applicationContext
        _plugins.value = PluginManager.getInstalledPlugins(context)
    }

    fun refreshShizuku() {
        _shizukuState.value = ShizukuManager.getState()
    }

    fun installPlugin(uri: Uri) {
        viewModelScope.launch {
            _isLoading.value = true
            _liveLog.value = listOf("[*] TITAN INGESTION: Accessing storage...")
            _showLogConsole.value = true
            
            val context = getApplication<Application>().applicationContext
            try {
                // SOLUTION for Scoped Storage: Copy URI to internal cache first
                val tempFile = FileUtil.copyUriToInternal(context, uri, "titan_incoming_${System.currentTimeMillis()}.zip")
                
                if (tempFile == null || !tempFile.exists()) {
                    _liveLog.value = _liveLog.value + "! CRITICAL: ACCESS DENIED BY SYSTEM"
                    _isLoading.value = false
                    return@launch
                }

                _liveLog.value = _liveLog.value + "[*] Analyzing structure (Vexiro/Magisk detection)..."
                val result = PluginInstaller.install(context, tempFile)
                
                result.onSuccess { plugin ->
                    _installResult.value = "SUCCESS: ${plugin.name.uppercase()} DEPLOYED"
                    
                    val logs = _liveLog.value.toMutableList()
                    logs.add("[+] Extraction Complete: ${plugin.installPath}")
                    logs.add("[*] Executing Installation Script...")
                    
                    pluginExecutor.runInstallLive(context, plugin).onEach { line ->
                        logs.add(line)
                        _liveLog.value = logs.toList()
                    }.onCompletion {
                        _isLoading.value = false
                    }.launchIn(this)
                    
                    refreshPlugins()
                }.onFailure { error ->
                    _installResult.value = "FAILURE: ${error.message}"
                    _liveLog.value = _liveLog.value + "! VALIDATION FAILED: ${error.message}"
                }
                
                if (tempFile.exists()) tempFile.delete()
            } catch (e: Exception) {
                _liveLog.value = _liveLog.value + "! ERROR: ${e.message}"
                Timber.e(e, "Plugin install failed")
            }
            _isLoading.value = false
        }
    }

    fun uninstallPlugin(plugin: Plugin) {
        viewModelScope.launch {
            _isLoading.value = true
            _showLogConsole.value = true
            _liveLog.value = listOf("[*] REMOVING: ${plugin.name}")
            
            val context = getApplication<Application>().applicationContext
            val logs = _liveLog.value.toMutableList()
            
            pluginExecutor.runUninstallLive(context, plugin).onEach { line ->
                logs.add(line)
                _liveLog.value = logs.toList()
            }.onCompletion {
                PluginInstaller.uninstall(plugin)
                refreshPlugins()
            }.launchIn(this)
            
            _isLoading.value = false
        }
    }

    fun runPlugin(plugin: Plugin) {
        viewModelScope.launch {
            _isLoading.value = true
            _showLogConsole.value = true
            _liveLog.value = listOf("[*] RE-DEPLOYING: ${plugin.name}")

            val context = getApplication<Application>().applicationContext
            val logs = _liveLog.value.toMutableList()
            
            pluginExecutor.runInstallLive(context, plugin).onEach { line ->
                logs.add(line)
                _liveLog.value = logs.toList()
            }.launchIn(this)
            
            _isLoading.value = false
        }
    }

    fun dismissLogConsole() {
        _showLogConsole.value = false
    }

    fun togglePlugin(plugin: Plugin) {
        PluginManager.setPluginEnabled(plugin, !plugin.isEnabled)
        refreshPlugins()
    }

    fun clearResult() { _installResult.value = null }
}
