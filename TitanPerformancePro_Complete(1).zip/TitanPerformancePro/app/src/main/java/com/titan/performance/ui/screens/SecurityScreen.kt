package com.titan.performance.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.domain.model.IssueSeverity
import com.titan.performance.presentation.viewmodel.SecurityViewModel
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SecurityScreen(navController: NavController, viewModel: SecurityViewModel = hiltViewModel()) {
    val scanResult by viewModel.scanResult.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text("Security Shield", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .background(TitanCard, RoundedCornerShape(80.dp))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = if (scanResult == null) TitanTeal else if (scanResult!!.overallScore > 70) TitanGreen else TitanRed,
                    modifier = Modifier.size(80.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (scanResult == null) {
                Text("SAFE", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text("No threats detected. Last scan: Never", color = TitanGray, fontSize = 12.sp)
                
                Spacer(modifier = Modifier.height(32.dp))
                
                Button(
                    onClick = { viewModel.startScan() },
                    enabled = !isScanning,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TitanTeal, contentColor = TitanBlack)
                ) {
                    if (isScanning) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = TitanBlack)
                    } else {
                        Text("SCAN NOW", fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Text(
                    text = if (scanResult!!.overallScore > 90) "SECURE" else "ATTENTION NEEDED",
                    color = if (scanResult!!.overallScore > 90) TitanGreen else TitanRed,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black
                )
                Text("Scan score: ${scanResult!!.overallScore}/100", color = TitanGray, fontSize = 12.sp)

                Spacer(modifier = Modifier.height(24.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(scanResult!!.issues) { issue ->
                        Surface(
                            color = TitanCard,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (issue.severity == IssueSeverity.CRITICAL) Icons.Default.Warning else Icons.Default.Info,
                                    contentDescription = null,
                                    tint = when (issue.severity) {
                                        IssueSeverity.CRITICAL -> TitanRed
                                        IssueSeverity.HIGH -> TitanOrange
                                        else -> TitanTeal
                                    }
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(issue.description, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(issue.recommendation, color = TitanGray, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Button(onClick = { viewModel.startScan() }, modifier = Modifier.fillMaxWidth()) {
                    Text("RESCAN")
                }
            }
        }
    }
}
