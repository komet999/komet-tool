package com.titan.performance.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.presentation.viewmodel.MonitoringViewModel
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonitoringScreen(navController: NavController, viewModel: MonitoringViewModel = hiltViewModel()) {
    val isMonitoring by viewModel.isMonitoring.collectAsState()
    val statistics by viewModel.statistics.collectAsState()

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text("Live Monitor", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("REAL-TIME STATS", color = TitanTeal, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Switch(checked = isMonitoring, onCheckedChange = { if (it) viewModel.startMonitoring() else viewModel.stopMonitoring() })
            }

            Spacer(modifier = Modifier.height(16.dp))

            // CPU Graph
            MonitorGraph(
                label = "CPU USAGE",
                data = statistics.map { it.cpuUsage.toFloat() },
                color = TitanTeal
            )

            Spacer(modifier = Modifier.height(16.dp))

            // RAM Graph
            MonitorGraph(
                label = "RAM USAGE",
                data = statistics.map { it.ramUsage.toFloat() },
                color = TitanGreen
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Battery Graph
            MonitorGraph(
                label = "BATTERY LEVEL",
                data = statistics.map { it.batteryLevel.toFloat() },
                color = TitanOrange
            )
        }
    }
}

@Composable
fun MonitorGraph(label: String, data: List<Float>, color: Color) {
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().height(160.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(label, color = TitanGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Canvas(modifier = Modifier.fillMaxSize()) {
                if (data.size < 2) return@Canvas
                
                val path = Path()
                val stepX = size.width / (data.size - 1)
                
                path.moveTo(0f, size.height - (data[0] / 100f * size.height))
                
                for (i in 1 until data.size) {
                    path.lineTo(i * stepX, size.height - (data[i] / 100f * size.height))
                }
                
                drawPath(
                    path = path,
                    color = color,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }
}
