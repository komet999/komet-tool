package com.titan.performance.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "logs")
data class LogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val tag: String,
    val message: String,
    val level: String,
    val timestamp: Long = System.currentTimeMillis()
)