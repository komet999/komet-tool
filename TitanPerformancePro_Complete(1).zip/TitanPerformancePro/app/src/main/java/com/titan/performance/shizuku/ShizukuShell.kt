package com.titan.performance.shizuku

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import rikka.shizuku.Shizuku
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuShell {

    data class ShellResult(
        val stdout: String,
        val stderr: String,
        val exitCode: Int
    )

    fun execute(command: String): ShellResult {
        if (!ShizukuManager.hasPermission()) {
            return ShellResult("", "Shizuku permission not granted", -1)
        }

        return try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val stdout = process.inputStream.bufferedReader().use { it.readText() }
            val stderr = process.errorStream.bufferedReader().use { it.readText() }
            val exitCode = process.waitFor()
            
            ShellResult(stdout, stderr, exitCode)
        } catch (e: Exception) {
            Timber.e(e, "Shizuku official API failed")
            fallbackExecute(command)
        }
    }

    /**
     * Titan Live Console Engine - Stream output line by line
     */
    fun executeLive(command: String): Flow<String> = flow {
        if (!ShizukuManager.hasPermission()) {
            emit("! Shizuku Permission Denied")
            return@flow
        }
        try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                emit(line ?: "")
            }
            val errorReader = BufferedReader(InputStreamReader(process.errorStream))
            while (errorReader.readLine().also { line = it } != null) {
                emit("ERR: $line")
            }
            process.waitFor()
        } catch (e: Exception) {
            emit("! System Execution Error: ${e.message}")
        }
    }.flowOn(Dispatchers.IO)

    private fun fallbackExecute(command: String): ShellResult {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val stdout = process.inputStream.bufferedReader().use { it.readText() }
            val stderr = process.errorStream.bufferedReader().use { it.readText() }
            val exitCode = process.waitFor()
            ShellResult(stdout, stderr, exitCode)
        } catch (e: Exception) {
            ShellResult("", e.message ?: "Fallback failed", -1)
        }
    }
}
