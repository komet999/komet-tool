package com.titan.performance.domain.model

data class SystemStats(
    val cpuUsagePercent: Float,
    val ramUsedPercent: Float,
    val ramTotal: Long,
    val ramAvailable: Long,
    val storageUsedPercent: Float,
    val storageTotal: Long,
    val storageAvailable: Long,
    val batteryLevel: Int,
    val batteryTemperature: Float,
    val batteryVoltage: Int,
    val batteryHealth: String,
    val isCharging: Boolean,
    val cpuTemperature: Float,
    val gpuTemperature: Float? = null,
    val networkRxSpeed: Long,
    val networkTxSpeed: Long,
    val fps: Int? = null,
    val uptime: Long
)
