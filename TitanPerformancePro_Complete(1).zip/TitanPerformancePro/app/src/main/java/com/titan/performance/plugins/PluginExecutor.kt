package com.titan.performance.plugins

import android.content.Context
import com.titan.performance.bridge.ShellResult
import com.titan.performance.shell.ShellEngine
import com.titan.performance.util.NotificationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import javax.inject.Inject

class PluginExecutor @Inject constructor(
    private val shellEngine: ShellEngine
) {

    data class ExecutionLog(
        val pluginName: String,
        val command: String,
        val stdout: String,
        val stderr: String,
        val exitCode: Int,
        val timestamp: Long = System.currentTimeMillis()
    )

    fun runInstallLive(context: Context, plugin: Plugin): Flow<String> = flow {
        val script = PluginManager.getInstallScript(plugin)
        if (script == null) {
            emit("Error: No installation script (install.sh) found.")
            return@flow
        }

        // Validate script first
        val validator = PluginValidator()
        val pluginDir = File(plugin.path)
        val validation = validator.validatePlugin(pluginDir)
        if (!validation.valid) {
            emit("Validation failed:")
            validation.errors.forEach { emit("  - $it") }
            return@flow
        }

        emit("Validating plugin...")
        emit("Installing ${plugin.name}...")

        val result = shellEngine.execute(script.absolutePath)
        if (result.success) {
            emit("Installation completed successfully.")
            NotificationHelper.showPluginNotification(context, "${plugin.name} installed successfully")
        } else {
            emit("Installation failed: ${result.error}")
        }
    }.flowOn(Dispatchers.IO)

    suspend fun executePluginCommand(plugin: Plugin, command: String): ExecutionLog = withContext(Dispatchers.IO) {
        val result = shellEngine.execute(command)
        ExecutionLog(
            pluginName = plugin.name,
            command = command,
            stdout = result.output,
            stderr = result.error,
            exitCode = result.exitCode
        )
    }
}
