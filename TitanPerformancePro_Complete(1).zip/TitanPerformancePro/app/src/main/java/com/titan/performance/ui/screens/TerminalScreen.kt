package com.titan.performance.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.R
import com.titan.performance.presentation.viewmodel.TerminalViewModel
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TerminalScreen(navController: NavController, viewModel: TerminalViewModel = hiltViewModel()) {
    val history by viewModel.history.collectAsState()
    val liveOutput by viewModel.currentLiveOutput.collectAsState()
    val isExecuting by viewModel.isExecuting.collectAsState()
    var command by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(history.size, liveOutput) {
        if (history.isNotEmpty() || liveOutput.isNotEmpty()) {
            listState.animateScrollToItem(if (isExecuting) Int.MAX_VALUE else history.size)
        }
    }

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text(stringResource(R.string.terminal), color = Color.White, fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { viewModel.clearHistory() }) {
                        Icon(Icons.Default.Delete, null, tint = TitanGray)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color.Black, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text(
                            "Titan Terminal v${stringResource(R.string.app_name)}\nReady.\n",
                            color = TitanTeal,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                    }
                    items(history) { result ->
                        Column {
                            Row {
                                Text("titan@device:~$ ", color = TitanGreen, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Text(result.command, color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            }
                            if (result.output.isNotBlank()) {
                                Text(result.output, color = TitanLightGray, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp, top = 2.dp))
                            }
                            if (result.error.isNotBlank()) {
                                Text(result.error, color = TitanRed, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp, top = 2.dp))
                            }
                            Text(
                                text = "Exit: ${result.exitCode} | Time: ${result.executionTime}ms",
                                color = TitanGray,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }

                    if (isExecuting && liveOutput.isNotBlank()) {
                        item {
                            Text(liveOutput, color = Color.White.copy(alpha = 0.8f), fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text("QUICK COMMANDS", color = TitanGray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickCmdButton("Device Info", "getprop") { viewModel.executeCommand(it) }
                QuickCmdButton("Memory Info", "cat /proc/meminfo") { viewModel.executeCommand(it) }
                QuickCmdButton("CPU Info", "cat /proc/cpuinfo") { viewModel.executeCommand(it) }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickCmdButton("Battery", "dumpsys battery") { viewModel.executeCommand(it) }
                QuickCmdButton("Network", "ifconfig") { viewModel.executeCommand(it) }
                QuickCmdButton("Processes", "ps") { viewModel.executeCommand(it) }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextField(
                    value = command,
                    onValueChange = { command = it },
                    placeholder = { Text("Enter command...", color = TitanGray, fontSize = 12.sp) },
                    modifier = Modifier.weight(1f),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = TitanCard,
                        unfocusedContainerColor = TitanCard,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = TitanTeal,
                        focusedIndicatorColor = TitanTeal
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                FloatingActionButton(
                    onClick = { 
                        if (command.isNotBlank()) { 
                            viewModel.executeCommand(command)
                            command = "" 
                        } 
                    },
                    containerColor = TitanTeal,
                    contentColor = TitanBlack,
                    modifier = Modifier.size(56.dp)
                ) {
                    if (isExecuting) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = TitanBlack)
                    } else {
                        Icon(Icons.Default.Send, null)
                    }
                }
            }
        }
    }
}

@Composable
fun QuickCmdButton(label: String, cmd: String, onClick: (String) -> Unit) {
    Surface(
        color = TitanTeal.copy(alpha = 0.1f),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, TitanTeal.copy(alpha = 0.3f)),
        modifier = Modifier.clickable { onClick(cmd) }
    ) {
        Text(
            text = label,
            color = TitanTeal,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}
