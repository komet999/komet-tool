package com.titan.performance.system.root

import com.titan.performance.system.BackendResult
import com.titan.performance.system.SystemBackend
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RootBackend @Inject constructor() : SystemBackend {

    override fun isAvailable(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec("su -c id")
            process.waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }

    override suspend fun execute(command: String, timeoutMs: Long): BackendResult =
        withContext(Dispatchers.IO) {
            try {
                val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))

                val stdout = withTimeoutOrNull(timeoutMs) {
                    BufferedReader(InputStreamReader(process.inputStream)).readText()
                } ?: ""

                val stderr = withTimeoutOrNull(timeoutMs) {
                    BufferedReader(InputStreamReader(process.errorStream)).readText()
                } ?: ""

                val exitCode = withTimeoutOrNull(timeoutMs) {
                    process.waitFor()
                } ?: -1

                BackendResult(
                    success = exitCode == 0,
                    output = stdout,
                    error = stderr,
                    exitCode = exitCode
                )
            } catch (e: Exception) {
                Timber.e(e, "Root execution failed")
                BackendResult(false, "", e.message ?: "Root failed", -1)
            }
        }

    override fun getName(): String = "Root"
    override fun getStatus(): String = if (isAvailable()) "Granted" else "Missing"
}
