package com.titan.performance.di


import com.titan.performance.bridge.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton



@Module
@InstallIn(
    SingletonComponent::class
)
object BridgeModule {



    @Provides
    @Singleton
    fun provideBridges(

        shizuku:
        ShizukuBridge,

        wireless:
        WirelessAdbBridge,

        adb:
        GenericAdbBridge

    ): List<DeviceBridge> {


        return listOf(

            shizuku,

            wireless,

            adb

        )

    }


}