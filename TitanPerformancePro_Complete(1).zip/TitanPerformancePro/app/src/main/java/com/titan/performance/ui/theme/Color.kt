package com.titan.performance.ui.theme

import androidx.compose.ui.graphics.Color

// Titan Performance Pro - Cyber/Neon Dark Theme Colors
val TitanTeal = Color(0xFF00D4AA)
val TitanGreen = Color(0xFF00E676)
val TitanRed = Color(0xFFFF5252)
val TitanYellow = Color(0xFFFFD740)
val TitanBlue = Color(0xFF448AFF)
val TitanPurple = Color(0xFFE040FB)
val TitanOrange = Color(0xFFFFAB40)

// Background colors
val TitanBlack = Color(0xFF080808)
val TitanDark = Color(0xFF0D0D0D)
val TitanCard = Color(0xFF141414)
val TitanSurface = Color(0xFF1A1A1A)

// Text colors
val TitanGray = Color(0xFF8A8A8A)
val TitanLightGray = Color(0xFFB0B0B0)
val TitanWhite = Color(0xFFFFFFFF)
