package com.titan.performance.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "statistics")
data class StatisticEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val cpuUsage: Float,
    val ramUsage: Float,
    val storageUsage: Float,
    val batteryLevel: Int,
    val temperature: Float,
    val timestamp: Long = System.currentTimeMillis()
)