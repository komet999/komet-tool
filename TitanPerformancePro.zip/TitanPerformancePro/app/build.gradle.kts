plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.kapt)
    alias(libs.plugins.hilt)
    alias(libs.plugins.kotlin.serialization)
}

android {

    namespace = "com.titan.performance"

    compileSdk = 35

    defaultConfig {

        applicationId = "com.titan.performance"

        minSdk = 29

        targetSdk = 35

        versionCode = 1

        versionName = "1.0.0"

        testInstrumentationRunner =
            "androidx.test.runner.AndroidJUnitRunner"

        vectorDrawables {
            useSupportLibrary = true
        }
    }


    buildTypes {

        release {

            isMinifyEnabled = true

            isShrinkResources = true

            proguardFiles(
                getDefaultProguardFile(
                    "proguard-android-optimize.txt"
                ),
                "proguard-rules.pro"
            )
        }


        debug {

            isMinifyEnabled = false

        }
    }


    compileOptions {

        sourceCompatibility =
            JavaVersion.VERSION_17

        targetCompatibility =
            JavaVersion.VERSION_17
    }


    kotlinOptions {

        jvmTarget = "17"

    }


    buildFeatures {

        compose = true

        buildConfig = true

    }


    composeOptions {

        kotlinCompilerExtensionVersion =
            "1.5.14"

    }


    packaging {

        resources {

            excludes += "/META-INF/{AL2.0,LGPL2.1}"

        }
    }
}


dependencies {

    implementation(libs.androidx.core.ktx)

    implementation(libs.androidx.lifecycle.runtime.ktx)

    implementation(libs.androidx.lifecycle.viewmodel.compose)

    implementation(libs.androidx.lifecycle.runtime.compose)

    implementation(libs.androidx.activity.compose)


    implementation(
        platform(
            libs.androidx.compose.bom
        )
    )


    implementation(libs.androidx.ui)

    implementation(libs.androidx.ui.graphics)

    implementation(libs.androidx.ui.tooling.preview)

    implementation(libs.androidx.material3)

    implementation(libs.androidx.material.icons)

    implementation(libs.androidx.navigation.compose)


    // Hilt

    implementation(libs.hilt.android)

    implementation(libs.hilt.navigation.compose)

    implementation(libs.hilt.work)

    kapt(libs.hilt.compiler)


    // Room

    implementation(libs.androidx.room.runtime)

    implementation(libs.androidx.room.ktx)

    kapt(libs.androidx.room.compiler)


    // WorkManager

    implementation(libs.androidx.work.runtime)


    // DataStore

    implementation(libs.androidx.datastore.preferences)

    implementation(libs.androidx.datastore.core)


    // Network

    implementation(libs.retrofit)

    implementation(libs.retrofit.kotlinx.serialization)

    implementation(libs.okhttp)

    implementation(libs.okhttp.logging)


    // Images

    implementation(libs.coil.compose)


    // Logs

    implementation(libs.timber)


    // Kotlin

    implementation(libs.kotlinx.serialization.json)

    implementation(libs.kotlinx.coroutines.android)

    implementation(libs.kotlinx.coroutines.core)


    implementation(libs.androidx.appcompat)

    implementation(libs.material)


    // Shizuku

    implementation(libs.shizuku.api)

    implementation(libs.shizuku.provider)


    // Tests

    testImplementation(libs.junit)

    androidTestImplementation(libs.androidx.junit)

    androidTestImplementation(libs.androidx.espresso.core)


    androidTestImplementation(
        platform(
            libs.androidx.compose.bom
        )
    )


    androidTestImplementation(
        libs.androidx.ui.test.junit4
    )


    debugImplementation(
        libs.androidx.ui.tooling
    )


    debugImplementation(
        libs.androidx.ui.test.manifest
    )
}