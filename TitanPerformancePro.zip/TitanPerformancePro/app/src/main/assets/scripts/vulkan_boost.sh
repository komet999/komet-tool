#!/system/bin/sh
# Titan Vulcan Boost - Vexiro Style
# تحسين أداء الرسوميات والنظام للألعاب

echo "[*] Initiating Titan Vulcan Boost..."

# إجبار النظام على استخدام GPU للرسم (Hardware Acceleration)
setprop debug.hwui.renderer opengl
setprop debug.egl.hw 1
setprop debug.vulkan.layers.enable 1
setprop persist.sys.ui.hw true

# تحسين استجابة اللمس وإلغاء التأخير
settings put system touch_responsiveness 1
settings put global touch_boost 1
setprop debug.touch_latency 0

# تعطيل الـ Throttling مؤقتاً لرفع الأداء
setprop persist.sys.performance.level 10
setprop ro.product.performance.level 10

# تنظيف الذاكرة المؤقتة (Caches) لزيادة السرعة
sync
echo 3 > /proc/sys/vm/drop_caches

echo "[+] Vulcan Boost Applied Successfully."
