#!/system/bin/sh
# Titan Cyber-Shield & Network Ping Fix
# تحسين جودة الاتصال وحجب الإعلانات

echo "[*] Optimizing Network Protocols..."

# تعديل قيم الـ TCP لتقليل الـ Ping في الألعاب
setprop net.tcp.buffersize.wifi 4096,87380,110208,4096,16384,110208
setprop net.tcp.buffersize.lte 4094,87380,1220608,4096,16384,1220608

# تفعيل DNS مشفر لحجب الإعلانات وتوفير البيانات
settings put global private_dns_mode hostname
settings put global private_dns_specifier dns.adguard.com

# منع التطبيقات من استهلاك البيانات في الخلفية بغير داعي
cmd netpolicy set restrict-background true

echo "[+] Cyber-Shield Active."
