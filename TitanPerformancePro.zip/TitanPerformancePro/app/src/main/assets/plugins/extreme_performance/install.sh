#!/system/bin/sh
# TITAN EXTREME DEPLOYMENT - BY MRKOMET
echo "[*] Initializing Titan Overclock Engine..."
setprop persist.sys.performance.level 10
setprop debug.sf.perf_mode 1
for i in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo performance > $i; done
echo "[+] CPU Governor set to PERFORMANCE"
setprop debug.hwui.renderer skiagl
echo "[+] GPU Vulkan Backend Active"
echo "[+] Titan Extreme Active."
