#!/system/bin/sh
# TITAN DISPLAY OVERDRIVE - BY MRKOMET
echo "[*] Overclocking Display Refresh..."
settings put global peak_refresh_rate 144
settings put global min_refresh_rate 144
setprop persist.vendor.display.refresh_rate 144
setprop debug.sf.disable_backpressure 1
echo "[+] 144Hz Forced Successfully."
