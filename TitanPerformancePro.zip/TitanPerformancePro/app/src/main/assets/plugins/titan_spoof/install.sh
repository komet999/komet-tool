#!/system/bin/sh
# TITAN IDENTITY SPOOF - BY MRKOMET
echo "[*] Masking Device Identity..."
setprop ro.product.model "TITAN-X PRO"
setprop ro.product.brand "MRKOMET"
setprop ro.product.manufacturer "MRKOMET PROJECTS"
setprop ro.build.display.id "TITAN-ULTRA-OS"
echo "[+] Identity changed to TITAN-X PRO."
echo "[+] Identity Spoof Complete."
