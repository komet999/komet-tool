#!/system/bin/sh
#desc: Battery optimization profile
#category: Battery

settings put system peak_refresh_rate 60
settings put system min_refresh_rate 60
cmd power set-fixed-performance-mode-enabled false
dumpsys battery | grep -E "level|status|temperature"

echo "Battery saver mode activated - 60Hz"
