#!/system/bin/sh
#desc: Maximum performance mode
#category: Performance
#requires_root

cmd power set-fixed-performance-mode-enabled true
settings put global animator_duration_scale 0.5
settings put global transition_animation_scale 0.5
settings put global window_animation_scale 0.5

echo "Maximum performance mode activated"
