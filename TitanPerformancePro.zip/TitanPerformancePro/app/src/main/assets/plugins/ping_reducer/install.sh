#!/system/bin/sh
# TITAN NETWORK INJECTION - BY MRKOMET
echo "[*] Recalibrating TCP Stack..."
setprop net.tcp.buffersize.wifi 4096,87380,110208,4096,16384,110208
setprop net.tcp.buffersize.lte 4094,87380,1220608,4096,16384,1220608
setprop net.dns1 1.1.1.1
setprop net.dns2 1.0.0.1
echo "[+] TCP Buffers Optimized."
echo "[+] Google DNS Injected."
