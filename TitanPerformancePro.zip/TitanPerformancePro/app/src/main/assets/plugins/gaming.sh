#!/system/bin/sh
#desc: Optimize device for gaming - 120Hz + performance mode
#category: Gaming
#requires_root

settings put system peak_refresh_rate 120
settings put system min_refresh_rate 120
cmd power set-fixed-performance-mode-enabled true
cmd activity memory-factor critical
settings put global cached_apps_freezer enabled

echo "Gaming mode activated - 120Hz + Performance"
