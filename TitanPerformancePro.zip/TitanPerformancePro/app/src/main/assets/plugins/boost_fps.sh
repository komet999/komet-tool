#!/system/bin/sh
#desc: Boost FPS and refresh rate
#category: Gaming
#requires_root

settings put system peak_refresh_rate 144
settings put system min_refresh_rate 144
settings put global animator_duration_scale 0.0
settings put global transition_animation_scale 0.0
settings put global window_animation_scale 0.0

echo "FPS Boost activated - 144Hz + No animations"
