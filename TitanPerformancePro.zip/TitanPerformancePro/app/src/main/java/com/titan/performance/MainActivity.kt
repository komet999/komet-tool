package com.titan.performance

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.titan.performance.service.TitanGhostService
import com.titan.performance.ui.navigation.Screen
import com.titan.performance.ui.navigation.TitanNavGraph
import com.titan.performance.ui.theme.TitanPerformanceTheme
import com.titan.performance.ui.theme.TitanTeal
import com.titan.performance.util.LocaleHelper
import com.titan.performance.data.repository.SettingsRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

@OptIn(ExperimentalMaterial3Api::class)
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject
    lateinit var settingsRepository: SettingsRepository

    override fun attachBaseContext(newBase: Context) {
        val lang = runBlocking {
            try {
                val prefs = newBase.getSharedPreferences("settings_prefs", Context.MODE_PRIVATE)
                prefs.getString("language", "device") ?: "device"
            } catch (e: Exception) {
                "device"
            }
        }
        super.attachBaseContext(LocaleHelper.onAttach(newBase, lang))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Ensure Titan Ghost Engine is active
        try {
            val serviceIntent = Intent(this, TitanGhostService::class.java)
            ContextCompat.startForegroundService(this, serviceIntent)
        } catch (e: Exception) { /* Logged in service */ }

        setContent {
            TitanPerformanceTheme {
                val navController = rememberNavController()
                val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
                val scope = rememberCoroutineScope()
                
                val items = listOf(
                    Screen.Dashboard,
                    Screen.Performance,
                    Screen.Gaming,
                    Screen.Modules,
                    Screen.Security,
                    Screen.Monitoring,
                    Screen.Terminal,
                    Screen.AiAssistant,
                    Screen.Firewall,
                    Screen.InstalledApps,
                    Screen.Settings,
                    Screen.About
                )
                
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                ModalNavigationDrawer(
                    drawerState = drawerState,
                    drawerContent = {
                        ModalDrawerSheet(
                            drawerContainerColor = Color(0xFF080808),
                            drawerContentColor = Color.White
                        ) {
                            Spacer(Modifier.height(24.dp))
                            Text("TITAN PRO", modifier = Modifier.padding(16.dp), color = TitanTeal, style = MaterialTheme.typography.headlineMedium)
                            items.forEach { screen ->
                                NavigationDrawerItem(
                                    icon = { Icon(screen.icon, contentDescription = null) },
                                    label = { Text(screen.title) },
                                    selected = currentRoute == screen.route,
                                    onClick = {
                                        scope.launch { drawerState.close() }
                                        navController.navigate(screen.route) {
                                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                                    colors = NavigationDrawerItemDefaults.colors(
                                        selectedContainerColor = TitanTeal.copy(alpha = 0.1f),
                                        selectedTextColor = TitanTeal,
                                        selectedIconColor = TitanTeal,
                                        unselectedTextColor = Color.Gray,
                                        unselectedIconColor = Color.Gray
                                    )
                                )
                            }
                        }
                    }
                ) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        topBar = {
                            if (currentRoute != null) {
                                CenterAlignedTopAppBar(
                                    title = { Text(currentRoute.uppercase(), style = MaterialTheme.typography.labelLarge) },
                                    navigationIcon = {
                                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                            Icon(Icons.Default.Menu, "Open Menu")
                                        }
                                    },
                                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                        containerColor = Color.Transparent,
                                        titleContentColor = Color.White,
                                        navigationIconContentColor = Color.White
                                    )
                                )
                            }
                        }
                    ) { innerPadding ->
                        TitanNavGraph(
                            navController = navController,
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }
}
