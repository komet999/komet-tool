package com.titan.performance.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.plugins.Plugin
import com.titan.performance.presentation.viewmodel.PluginsViewModel
import com.titan.performance.shizuku.ShizukuState
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PluginsScreen(navController: NavController, viewModel: PluginsViewModel = hiltViewModel()) {
    val plugins by viewModel.plugins.collectAsState()
    val shizukuState by viewModel.shizukuState.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val liveLog by viewModel.liveLog.collectAsState()
    val showLogConsole by viewModel.showLogConsole.collectAsState()

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.installPlugin(it) }
    }

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text("TITAN MODULES", color = Color.White, fontWeight = FontWeight.Black) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { filePicker.launch(arrayOf("application/zip")) }) {
                        Icon(Icons.Default.AddCircle, null, tint = TitanTeal)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Active Shield Status
            Surface(
                color = if (shizukuState is ShizukuState.Running) TitanGreen.copy(alpha = 0.1f) else TitanCard,
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, if (shizukuState is ShizukuState.Running) TitanGreen else Color.Transparent)
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (shizukuState is ShizukuState.Running) Icons.Default.OfflineBolt else Icons.Default.FlashOff,
                        contentDescription = null,
                        tint = if (shizukuState is ShizukuState.Running) TitanGreen else TitanRed
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = if (shizukuState is ShizukuState.Running) "ENGINE INJECTION ACTIVE" else "SHIZUKU/ADB LINK REQUIRED",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text("INSTALLED GHOST MODULES", color = TitanGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))

            if (plugins.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No modules detected in storage.", color = TitanGray, fontSize = 12.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(plugins) { plugin ->
                        PluginItem(
                            plugin = plugin,
                            onToggle = { viewModel.togglePlugin(plugin) },
                            onRun = { viewModel.runPlugin(plugin) }
                        )
                    }
                }
            }
        }
    }

    if (showLogConsole) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissLogConsole() },
            containerColor = Color.Black,
            title = { 
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Terminal, null, tint = TitanTeal)
                    Spacer(Modifier.width(8.dp))
                    Text("TITAN ENGINE OUTPUT", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                }
            },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                        .background(Color(0xFF080808), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(liveLog) { line ->
                            Text(
                                text = line,
                                color = if (line.startsWith("!")) TitanRed else if (line.startsWith("[+]")) TitanGreen else if (line.startsWith("[*]")) TitanTeal else Color.White,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(vertical = 1.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.dismissLogConsole() }) {
                    Text("TERMINATE", color = TitanRed, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun PluginItem(
    plugin: Plugin,
    onToggle: () -> Unit,
    onRun: () -> Unit
) {
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (plugin.isEnabled) TitanTeal.copy(alpha = 0.2f) else Color.Transparent)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(TitanBlack, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (plugin.name.contains("Performance")) Icons.Default.AutoGraph else Icons.Default.Extension,
                        contentDescription = null,
                        tint = if (plugin.isEnabled) TitanTeal else TitanGray
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(plugin.name.uppercase(), color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    Text("VERSION ${plugin.version} • ${plugin.author.uppercase()}", color = TitanGray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Switch(
                    checked = plugin.isEnabled,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = TitanTeal,
                        uncheckedTrackColor = Color.DarkGray
                    )
                )
            }
            
            if (plugin.isEnabled) {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onRun,
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TitanBlack),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TitanTeal.copy(alpha = 0.5f))
                ) {
                    Text("DEPLOY SCRIPT", color = TitanTeal, fontSize = 11.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}
