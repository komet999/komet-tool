package com.titan.performance.hardware

import com.titan.performance.shell.ShellEngine
import com.titan.performance.util.NotificationHelper
import dagger.hilt.android.qualifiers.ApplicationContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TweaksEngine @Inject constructor(
    private val shellEngine: ShellEngine,
    @ApplicationContext private val context: android.content.Context
) {

    /**
     * TITAN ULTIMATE ENGINE - BY MRKOMET
     * Engineered for Global Domination - Universal Compatibility
     */
    suspend fun applyTitanUltraTweaks(): Boolean {
        val commands = listOf(
            // --- 1. CORE POWER & PERFORMANCE (VULCAN CORE) ---
            "cmd power set-fixed-performance-mode-enabled true",
            "settings put system POWER_SAVE_PRE_HIDE_MODE performance",
            "settings put global game_mode 2",
            "settings put global game_process_boost_enabled 1",
            "setprop persist.sys.performance.level 10",
            "setprop ro.product.performance.level 10",
            "setprop debug.performance.tuning 1",
            
            // --- 2. GPU & GRAPHICS REVOLUTION (144Hz UNLOCK) ---
            "setprop debug.hwui.renderer skiagl",
            "setprop debug.renderengine.backend skiaglthreaded",
            "setprop debug.egl.force_msaa 1",
            "setprop debug.gr.swapinterval -60",
            "setprop persist.sys.composition.type gpu",
            "setprop debug.sf.perf_mode 1",
            "setprop debug.overlayui.enable 1",
            "setprop debug.graphics.game_default_frame_rate 144",
            "setprop persist.vendor.display.refresh_rate 144",
            "setprop debug.hwui.render_dirty_regions false",
            "setprop debug.sf.high_fps_early_phase_offset_ns 500000",

            // --- 3. MEMORY & I/O OVERDRIVE (MAX CACHE) ---
            "cmd device_config put activity_manager max_phantom_processes 2147483647",
            "cmd device_config put activity_manager max_cached_processes 1024",
            "settings put global activity_manager_constants max_cached_processes 1024",
            "device_config put activity_manager_native_boot use_freezer true",
            "setprop persist.sys.purgeable_assets 1",
            "setprop ro.sys.fw.bg_apps_limit 128",
            "settings put global iorapd.readahead.enable true",
            "settings put global iorapd.perfetto.enable true",

            // --- 4. ZERO LATENCY TOUCH & INPUT ---
            "settings put system windowsmgr.max_events_per_sec 300",
            "setprop debug.touch_latency 0",
            "settings put system touch_responsiveness 1",
            "settings put global touch_boost 1",
            "settings put system pointer_speed 7",

            // --- 5. THERMAL & NETWORK SURVIVAL ---
            "cmd thermalservice override-status 0",
            "setprop debug.thermal.cpu_thermal_throttle.disable 1",
            "settings put global thermal_throttling 0",
            "setprop debug.thermal_status 0",
            "setprop net.tcp.buffersize.wifi 4096,87380,110208,4096,16384,110208",
            "setprop net.tcp.buffersize.lte 4094,87380,1220608,4096,16384,1220608",
            "setprop persist.sys.use_dithering 0",
            
            // --- 6. DEVICE FINGERPRINT (MRKOMET SPOOF) ---
            "setprop ro.product.model TITAN-ULTRA",
            "setprop ro.product.brand MRKOMET",
            "setprop ro.build.id TITAN-PRO-X",
            "setprop ro.config.fha_enable true",
            "echo 0 > /proc/sys/kernel/panic",
            "echo 0 > /proc/sys/kernel/panic_on_oops",
            "echo 1 > /proc/sys/vm/overcommit_memory"
        )
        return executeBulk(commands, "TITAN CORE")
    }

    suspend fun applyRadioBoost(): Boolean {
        val commands = listOf(
            "setprop net.tcp.buffersize.wifi 4096,87380,110208,4096,16384,110208",
            "setprop net.tcp.buffersize.lte 4094,87380,1220608,4096,16384,1220608",
            "setprop ro.config.fha_enable true",
            "setprop persist.cust.tel.eons 1",
            "settings put global private_dns_mode hostname",
            "settings put global private_dns_specifier dns.adguard.com"
        )
        return executeBulk(commands, "RADIO BOOST")
    }

    suspend fun applyAdBlock(enable: Boolean): Boolean {
        val mode = if (enable) "hostname" else "off"
        val spec = if (enable) "dns.adguard.com" else ""
        return shellEngine.execute("settings put global private_dns_mode $mode && settings put global private_dns_specifier $spec").success
    }

    suspend fun applyUniversalCompatibility(): Boolean {
        val commands = listOf(
            "setprop ro.config.fha_enable true",
            "setprop ro.sys.fw.bg_apps_limit 64",
            "setprop persist.sys.use_dithering 0"
        )
        return executeBulk(commands, "COMPATIBILITY")
    }

    suspend fun applyPersistenceFix(): Boolean {
        val commands = listOf(
            "setprop persist.sys.performance.level 10",
            "setprop persist.sys.ui.hw true",
            "setprop persist.vendor.display.refresh_rate 144",
            "setprop persist.sys.surfaceflinger.idle_reduce_framerate_enable false"
        )
        return executeBulk(commands, "TITAN SURVIVAL")
    }

    suspend fun applyExhaustiveTweaks(): Boolean {
        return applyTitanUltraTweaks() && applyRadioBoost()
    }

    suspend fun applyBatterySurvival(): Boolean {
        val commands = listOf(
            "cmd power set-adaptive-power-saver-enabled true",
            "settings put global low_power 1",
            "cmd deviceidle force-idle deep",
            "settings put global sync_enabled 0"
        )
        return executeBulk(commands, "BATTERY SURVIVAL")
    }

    private suspend fun executeBulk(commands: List<String>, label: String): Boolean {
        var allSuccess = true
        commands.forEachIndexed { index, cmd ->
            NotificationHelper.showShellNotification(
                context, 
                "TITAN BY MRKOMET", 
                "Infiltrating $label: ${index + 1}/${commands.size}", 
                (index + 1) * 100 / commands.size
            )
            val result = shellEngine.execute(cmd)
            if (!result.success) allSuccess = false
        }
        NotificationHelper.showShellNotification(context, "TITAN PRO", "$label DEPLOYED", -1)
        return allSuccess
    }
}
