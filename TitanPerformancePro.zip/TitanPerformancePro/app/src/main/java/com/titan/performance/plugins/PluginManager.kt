package com.titan.performance.plugins

import android.content.Context
import kotlinx.serialization.json.Json
import timber.log.Timber
import java.io.File

object PluginManager {

    fun getPluginsDirectory(context: Context): File {
        return File(context.getExternalFilesDir(null), "plugins").apply { mkdirs() }
    }

    /**
     * Titan Infiltration Logic: Deploy internal assets plugins to storage
     */
    fun deployInternalPlugins(context: Context) {
        val pluginsDir = getPluginsDirectory(context)
        try {
            val assets = context.assets.list("plugins") ?: return
            assets.forEach { pluginName ->
                val pluginFolder = File(pluginsDir, pluginName)
                if (!pluginFolder.exists()) {
                    pluginFolder.mkdirs()
                    val files = context.assets.list("plugins/$pluginName") ?: return@forEach
                    files.forEach { fileName ->
                        val outFile = File(pluginFolder, fileName)
                        context.assets.open("plugins/$pluginName/$fileName").use { input ->
                            outFile.outputStream().use { output -> input.copyTo(output) }
                        }
                        if (fileName.endsWith(".sh")) outFile.setExecutable(true)
                    }
                    // Auto-enable internal plugins
                    File(pluginFolder, ".enabled").createNewFile()
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Internal Plugin Deployment Failed")
        }
    }

    fun getInstalledPlugins(context: Context): List<Plugin> {
        val pluginsDir = getPluginsDirectory(context)
        if (!pluginsDir.exists()) return emptyList()

        return pluginsDir.listFiles()?.filter { it.isDirectory }?.mapNotNull { dir ->
            try {
                val manifestFile = File(dir, "plugin.json")
                if (!manifestFile.exists()) return@mapNotNull null
                val manifest = Json.decodeFromString(PluginManifest.serializer(), manifestFile.readText())
                Plugin(
                    id = dir.name,
                    name = manifest.name,
                    version = manifest.version,
                    author = manifest.author,
                    description = manifest.description,
                    minAndroid = manifest.minAndroid,
                    type = manifest.type,
                    supportedBrands = manifest.supportedBrands,
                    requiredPermission = manifest.requiredPermission,
                    profileType = manifest.profileType,
                    installPath = dir.absolutePath,
                    isInstalled = true,
                    isEnabled = File(dir, ".enabled").exists(),
                    installedAt = dir.lastModified()
                )
            } catch (e: Exception) {
                Timber.e(e, "Read failed: ${dir.name}")
                null
            }
        } ?: emptyList()
    }

    fun setPluginEnabled(plugin: Plugin, enabled: Boolean) {
        val flag = File(plugin.installPath, ".enabled")
        if (enabled) flag.createNewFile() else flag.delete()
    }

    fun getInstallScript(plugin: Plugin): File? {
        val root = File(plugin.installPath)
        return root.walkTopDown().find { 
            it.name == "install.sh" || it.name == "active.sh" || it.name == "apply.sh" || it.name == "run.sh"
        }
    }

    fun getUninstallScript(plugin: Plugin): File? {
        val root = File(plugin.installPath)
        return root.walkTopDown().find { 
            it.name == "uninstall.sh" || it.name == "disable.sh" || it.name == "remove.sh"
        }
    }

    fun getConfig(plugin: Plugin): PluginConfig? {
        val f = File(plugin.installPath, "config.json")
        return if (f.exists()) {
            try {
                Json.decodeFromString(PluginConfig.serializer(), f.readText())
            } catch (e: Exception) { null }
        } else null
    }
}
