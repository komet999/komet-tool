package com.titan.performance.ui.screens

import android.app.Activity
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.presentation.viewmodel.SettingsViewModel
import com.titan.performance.ui.theme.*
import com.titan.performance.util.LocaleHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController, viewModel: SettingsViewModel = hiltViewModel()) {
    val language by viewModel.language.collectAsState()
    val dynamicColors by viewModel.dynamicColors.collectAsState()
    val notifications by viewModel.notificationsEnabled.collectAsState()
    val monitoring by viewModel.monitoringEnabled.collectAsState()
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var showLanguageDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.languageChanged.collect {
            (context as? Activity)?.recreate()
        }
    }

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text("TITAN SETTINGS", color = Color.White, fontWeight = FontWeight.Black) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SettingsSection(title = "VISUAL INTERFACE") {
                SettingsToggle(
                    label = "Dynamic Colors",
                    description = "Material You color extraction",
                    checked = dynamicColors,
                    onCheckedChange = { viewModel.setDynamicColors(it) }
                )
                
                SettingsItem(
                    label = "Language",
                    value = when(language) {
                        "ar" -> "العربية"
                        "ru" -> "Русский"
                        "zh" -> "中文"
                        else -> "English"
                    },
                    icon = Icons.Default.Translate,
                    onClick = { showLanguageDialog = true }
                )
            }

            SettingsSection(title = "CORE SURVIVAL") {
                SettingsToggle(
                    label = "Ghost Mode (Persistence)",
                    description = "Restore tweaks automatically after reboot",
                    checked = true,
                    onCheckedChange = { }
                )
                SettingsToggle(
                    label = "Live Monitoring",
                    description = "Collect hardware data in real-time",
                    checked = monitoring,
                    onCheckedChange = { viewModel.setMonitoringEnabled(it) }
                )
                SettingsToggle(
                    label = "Silent Notifications",
                    description = "Run shell commands in background",
                    checked = notifications,
                    onCheckedChange = { viewModel.setNotificationsEnabled(it) }
                )
            }
            
            Spacer(modifier = Modifier.height(40.dp))
            Text("TITAN PRO • MRKOMET EDITION", color = TitanGray, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }

    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            containerColor = TitanCard,
            title = { Text("SELECT ENGINE LANGUAGE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp) },
            text = {
                Column {
                    LanguageOption("English") { viewModel.setLanguage("en"); showLanguageDialog = false }
                    LanguageOption("العربية") { viewModel.setLanguage("ar"); showLanguageDialog = false }
                    LanguageOption("Русский") { viewModel.setLanguage("ru"); showLanguageDialog = false }
                    LanguageOption("中文") { viewModel.setLanguage("zh"); showLanguageDialog = false }
                }
            },
            confirmButton = {}
        )
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(title, color = TitanTeal, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
        Spacer(Modifier.height(12.dp))
        Surface(color = TitanCard, shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(8.dp), content = content)
        }
    }
}

@Composable
fun SettingsToggle(label: String, description: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(description, color = TitanGray, fontSize = 10.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedTrackColor = TitanTeal)
        )
    }
}

@Composable
fun SettingsItem(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = TitanTeal, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(value, color = TitanGray, fontSize = 10.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = TitanGray)
    }
}

@Composable
fun LanguageOption(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Text(label, color = Color.White, modifier = Modifier.fillMaxWidth())
    }
}
