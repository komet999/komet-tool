package com.titan.performance.security

import com.titan.performance.shell.ShellEngine
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class IntegrityScanner @Inject constructor(
    private val shellEngine: ShellEngine
) {

    data class SecurityReport(
        val isRooted: Boolean,
        val isAdbEnabled: Boolean,
        val suspiciousAppsCount: Int,
        val systemModified: Boolean,
        val vulnerabilities: List<String>
    )

    suspend fun fullScan(): SecurityReport {
        val vulnerabilities = mutableListOf<String>()
        
        // 1. Check Root
        val rootCheck = shellEngine.executeWithRoot("id").success
        if (rootCheck) vulnerabilities.add("Device is Rooted (Potential Risk)")

        // 2. Check ADB Status
        val adbCheck = shellEngine.execute("getprop init.svc.adbd").output.contains("running")
        if (adbCheck) vulnerabilities.add("USB Debugging is Active")

        // 3. Check for Suspicious BusyBox/Binaries
        val busybox = shellEngine.execute("which busybox").success
        if (busybox) vulnerabilities.add("BusyBox binary detected")

        // 4. SELinux Status
        val selinux = shellEngine.execute("getenforce").output.trim()
        if (selinux == "Permissive") vulnerabilities.add("SELinux is Permissive (Low Security)")

        return SecurityReport(
            isRooted = rootCheck,
            isAdbEnabled = adbCheck,
            suspiciousAppsCount = 0, // Need package manager logic
            systemModified = busybox || selinux == "Permissive",
            vulnerabilities = vulnerabilities
        )
    }
}
