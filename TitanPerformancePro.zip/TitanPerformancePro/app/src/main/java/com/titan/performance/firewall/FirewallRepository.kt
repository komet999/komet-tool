package com.titan.performance.firewall

import android.content.Context
import android.net.Uri
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import timber.log.Timber
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirewallRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val firewallEngine: FirewallEngine
) {

    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    private val configFile: File
        get() = File(context.filesDir, "firewall_rules.json")

    private val _blockedApps = MutableStateFlow<List<FirewallRule>>(emptyList())
    val blockedApps: StateFlow<List<FirewallRule>> = _blockedApps.asStateFlow()

    init {
        _blockedApps.value = readFromDisk()
    }

    fun getBlockedApps(): List<FirewallRule> = _blockedApps.value

    fun isBlocked(packageName: String): Boolean =
        _blockedApps.value.any { it.packageName == packageName }

    suspend fun blockApp(packageName: String, uid: Int, appName: String): Boolean =
        withContext(Dispatchers.IO) {
            val success = firewallEngine.block(uid, packageName)
            if (success) {
                val updated = _blockedApps.value
                    .filterNot { it.packageName == packageName } +
                    FirewallRule(packageName = packageName, uid = uid, appName = appName)
                _blockedApps.value = updated
                persist(updated)
            }
            success
        }

    suspend fun unblockApp(packageName: String, uid: Int): Boolean =
        withContext(Dispatchers.IO) {
            val success = firewallEngine.unblock(uid, packageName)
            if (success) {
                val updated = _blockedApps.value.filterNot { it.packageName == packageName }
                _blockedApps.value = updated
                persist(updated)
            }
            success
        }

    /**
     * Imports a firewall config file (JSON: {"version":1,"blocked":[{"packageName":"...","uid":...}]}),
     * merges it into the current rule set and applies every new rule via Shizuku/root.
     * Returns the number of rules successfully applied.
     */
    suspend fun importConfig(uri: Uri): Int = withContext(Dispatchers.IO) {
        var applied = 0
        try {
            val text = context.contentResolver.openInputStream(uri)
                ?.bufferedReader()
                ?.use { it.readText() }
                ?: return@withContext 0

            val parsed = json.decodeFromString(FirewallConfig.serializer(), text)

            for (rule in parsed.blocked) {
                val ok = firewallEngine.block(rule.uid, rule.packageName)
                if (ok) applied++
            }

            val merged = (_blockedApps.value.filterNot { existing ->
                parsed.blocked.any { it.packageName == existing.packageName }
            } + parsed.blocked)

            _blockedApps.value = merged
            persist(merged)
        } catch (e: Exception) {
            Timber.e(e, "Firewall config import failed")
        }
        applied
    }

    suspend fun exportConfig(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val config = FirewallConfig(blocked = _blockedApps.value)
            val text = json.encodeToString(FirewallConfig.serializer(), config)
            context.contentResolver.openOutputStream(uri)?.use {
                it.write(text.toByteArray())
            }
            true
        } catch (e: Exception) {
            Timber.e(e, "Firewall config export failed")
            false
        }
    }

    private fun persist(rules: List<FirewallRule>) {
        try {
            val config = FirewallConfig(blocked = rules)
            configFile.writeText(json.encodeToString(FirewallConfig.serializer(), config))
        } catch (e: Exception) {
            Timber.e(e, "Failed to persist firewall rules")
        }
    }

    private fun readFromDisk(): List<FirewallRule> {
        return try {
            if (!configFile.exists()) return emptyList()
            json.decodeFromString(FirewallConfig.serializer(), configFile.readText()).blocked
        } catch (e: Exception) {
            Timber.e(e, "Failed to read firewall rules")
            emptyList()
        }
    }
}
