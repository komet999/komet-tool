package com.titan.performance.firewall

import com.titan.performance.shell.ShellEngine
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Blocks or restores per-app internet access.
 *
 * Two layers are attempted for every uid, through the same shell chain
 * used everywhere else in the app (Shizuku/vendor bridge -> root -> plain
 * shell, see [ShellEngine]):
 *
 *  1. `cmd netpolicy` - a normal ADB-shell level command, works without
 *     root through Shizuku. It restricts *background* data for the uid,
 *     which is what standard "restrict background data" toggles in
 *     Android settings do.
 *  2. `iptables -m owner` OUTPUT DROP - blocks the uid's outbound traffic
 *     completely (foreground + background). This needs root; it is
 *     skipped/ignored automatically if root isn't available.
 *
 * On a Shizuku-only (non-root) device only layer 1 applies, so a blocked
 * app can still use the internet in the foreground. The UI should surface
 * that distinction rather than promise a full block it can't deliver.
 */
@Singleton
class FirewallEngine @Inject constructor(
    private val shellEngine: ShellEngine
) {

    suspend fun block(uid: Int, packageName: String): Boolean {
        val background = shellEngine.execute(
            "cmd netpolicy add restrict-background-blacklist $uid"
        )

        val fullBlock = shellEngine.executeWithRoot(
            "iptables -I OUTPUT -m owner --uid-owner $uid -j DROP"
        )

        Timber.d(
            "Firewall block uid=$uid pkg=$packageName background=${background.success} root=${fullBlock.success}"
        )

        // Consider it a success if at least one layer actually applied.
        return background.success || fullBlock.success
    }

    suspend fun unblock(uid: Int, packageName: String): Boolean {
        val background = shellEngine.execute(
            "cmd netpolicy remove restrict-background-blacklist $uid"
        )

        val fullBlock = shellEngine.executeWithRoot(
            "iptables -D OUTPUT -m owner --uid-owner $uid -j DROP"
        )

        Timber.d(
            "Firewall unblock uid=$uid pkg=$packageName background=${background.success} root=${fullBlock.success}"
        )

        return background.success || fullBlock.success
    }

    /** Whether a full (foreground+background) block is actually available on this device. */
    suspend fun isRootBlockAvailable(): Boolean {
        val probe = shellEngine.executeWithRoot("id")
        return probe.success
    }
}
