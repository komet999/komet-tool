package com.titan.performance.shell

import com.titan.performance.bridge.BridgeManager
import com.titan.performance.bridge.ShellResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ShellEngine @Inject constructor(
    private val bridgeManager: BridgeManager
) {


    suspend fun execute(
        command: String
    ): ShellResult =
        withContext(Dispatchers.IO) {


            val bridgeResult =
                bridgeManager.execute(command)


            if (bridgeResult.success) {
                return@withContext bridgeResult
            }



            val rootResult =
                executeWithRoot(command)


            if (rootResult.success) {
                return@withContext rootResult
            }



            val basicResult =
                executeBasic(command)


            if (basicResult.success) {
                return@withContext basicResult
            }



            bridgeResult
        }




    suspend fun executeWithRoot(
        command: String
    ): ShellResult =
        withContext(Dispatchers.IO) {

            try {

                val process =
                    Runtime.getRuntime().exec(
                        arrayOf(
                            "su",
                            "-c",
                            command
                        )
                    )


                val stdout =
                    BufferedReader(
                        InputStreamReader(
                            process.inputStream
                        )
                    ).readText()


                val stderr =
                    BufferedReader(
                        InputStreamReader(
                            process.errorStream
                        )
                    ).readText()


                val exitCode =
                    process.waitFor()



                ShellResult(
                    output = stdout,
                    error = stderr,
                    exitCode = exitCode,
                    executionTime = 0
                )


            } catch (e: Exception) {

                Timber.e(
                    e,
                    "Root execution failed"
                )


                ShellResult(
                    output = "",
                    error = e.message ?: "Root not available",
                    exitCode = -1,
                    executionTime = 0
                )
            }
        }





    suspend fun executeBasic(
        command: String
    ): ShellResult =
        withContext(Dispatchers.IO) {

            try {

                val process =
                    Runtime.getRuntime().exec(
                        arrayOf(
                            "sh",
                            "-c",
                            command
                        )
                    )


                val stdout =
                    BufferedReader(
                        InputStreamReader(
                            process.inputStream
                        )
                    ).readText()


                val stderr =
                    BufferedReader(
                        InputStreamReader(
                            process.errorStream
                        )
                    ).readText()


                val exitCode =
                    process.waitFor()



                ShellResult(
                    output = stdout,
                    error = stderr,
                    exitCode = exitCode,
                    executionTime = 0
                )


            } catch (e: Exception) {

                Timber.e(
                    e,
                    "Basic shell failed"
                )


                ShellResult(
                    output = "",
                    error = e.message ?: "Shell error",
                    exitCode = -1,
                    executionTime = 0
                )
            }
        }




    suspend fun executeMultiple(
        commands: List<String>
    ): List<ShellResult> =
        withContext(Dispatchers.IO) {

            commands.map {
                execute(it)
            }
        }
}