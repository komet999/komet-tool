package com.titan.performance.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.titan.performance.shizuku.ShizukuShell
import kotlinx.coroutines.*
import timber.log.Timber

/**
 * TITAN GHOST SERVICE - THE MRKOMET PERSISTENCE ENGINE
 * Keeps tweaks active and prevents system from killing shell processes on Android 11+
 * Uses a double-keep-alive strategy.
 */
class TitanGhostService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        startForeground(GHOST_NOTIFICATION_ID, createNotification())
        
        // Start the Ghost Infiltration Loop
        serviceScope.launch {
            while (isActive) {
                try {
                    // Re-apply Core Persistence Props
                    ShizukuShell.execute("setprop persist.sys.performance.level 10")
                    ShizukuShell.execute("setprop debug.sf.perf_mode 1")
                    ShizukuShell.execute("setprop persist.vendor.display.refresh_rate 144")
                    
                    // Keep Shizuku process active if possible
                    ShizukuShell.execute("id") 
                    
                    Timber.d("Ghost Mode: Tweaks Re-Injected")
                } catch (e: Exception) {
                    Timber.e(e, "Ghost Heartbeat Failed")
                }
                delay(30000) // Pulse every 30 seconds
            }
        }
    }

    private fun createNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("TITAN GHOST MODE")
        .setContentText("Uplink Persistent • MRKOMET Edition")
        .setSmallIcon(android.R.drawable.ic_menu_compass)
        .setPriority(NotificationCompat.PRIORITY_MIN)
        .setCategory(NotificationCompat.CATEGORY_SERVICE)
        .build()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "titan_ghost_channel"
        private const val GHOST_NOTIFICATION_ID = 5005
    }
}
