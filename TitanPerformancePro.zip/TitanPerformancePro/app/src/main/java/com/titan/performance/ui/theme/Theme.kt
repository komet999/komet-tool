package com.titan.performance.ui.theme

import android.app.Activity
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = TitanTeal,
    onPrimary = TitanBlack,
    secondary = TitanTealVariant,
    onSecondary = TitanBlack,
    background = TitanBlack,
    onBackground = TitanLightGray,
    surface = TitanSurface,
    onSurface = TitanLightGray,
    error = TitanRed,
    onError = TitanBlack,
    surfaceVariant = TitanCard,
    onSurfaceVariant = TitanLightGray
)

@Composable
fun TitanPerformanceTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
