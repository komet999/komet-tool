package com.titan.performance.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.bridge.ConnectionState
import com.titan.performance.bridge.DeviceBridge
import com.titan.performance.presentation.viewmodel.PermissionWizardViewModel
import com.titan.performance.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionWizardScreen(navController: NavController, viewModel: PermissionWizardViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val bridges by viewModel.availableBridges.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()
    val isChecking by viewModel.isChecking.collectAsState()
    
    var showPairingDialog by remember { mutableStateOf(false) }
    var adbPort by remember { mutableStateOf("5555") }
    var adbCode by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) { viewModel.scanDevice() }

    Scaffold(
        containerColor = TitanBlack,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text("TITAN SETUP WIZARD", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Xiaomi/Redmi Special Guide
            if (deviceInfo?.manufacturer?.contains("Xiaomi", ignoreCase = true) == true || 
                deviceInfo?.manufacturer?.contains("Redmi", ignoreCase = true) == true ||
                deviceInfo?.manufacturer?.contains("Poco", ignoreCase = true) == true) {
                item {
                    Surface(
                        color = TitanOrange.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TitanOrange)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, null, tint = TitanOrange)
                                Spacer(Modifier.width(12.dp))
                                Text("XIAOMI/POCO DETECTED", color = Color.White, fontWeight = FontWeight.Black)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "1. Enable 'USB Debugging (Security Settings)' in Developer Options.\n" +
                                "2. Enable 'Wireless Debugging'.\n" +
                                "3. Use the 'Pairing Code' method below.",
                                color = TitanGray,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // Connection Status
            item {
                Surface(
                    color = if (connectionState == ConnectionState.Connected) TitanGreen.copy(alpha = 0.1f) else TitanCard,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (connectionState == ConnectionState.Connected) TitanGreen else Color.Transparent)
                ) {
                    Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (connectionState == ConnectionState.Connected) Icons.Default.Link else Icons.Default.LinkOff,
                            contentDescription = null,
                            tint = if (connectionState == ConnectionState.Connected) TitanGreen else TitanRed,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(Modifier.width(20.dp))
                        Column {
                            Text("ENGINE STATUS", color = TitanGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (connectionState == ConnectionState.Connected) "TITAN CORE ACTIVE" else "WAITING FOR UPLINK",
                                color = if (connectionState == ConnectionState.Connected) TitanGreen else Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }

            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { 
                            val intent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                            if (intent != null) context.startActivity(intent)
                            else {
                                // Open browser to Shizuku download
                                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                                context.startActivity(browserIntent)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                    ) {
                        Text("OPEN SHIZUKU", fontSize = 10.sp)
                    }
                    Button(
                        onClick = { viewModel.scanDevice() },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = TitanTeal, contentColor = TitanBlack)
                    ) {
                        Text("REFRESH", fontSize = 10.sp)
                    }
                }
            }

            item { Text("SELECT ACCESS METHOD", color = TitanGray, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            
            items(bridges.size) { index ->
                val bridge = bridges[index]
                Surface(
                    color = TitanCard,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(bridge.name.uppercase(), color = Color.White, fontWeight = FontWeight.Black)
                            Text("Stability Score: ${bridge.priority}%", color = TitanTeal, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                if (bridge.name.contains("Wireless", ignoreCase = true)) {
                                    showPairingDialog = true
                                } else {
                                    scope.launch { viewModel.connectBridge(bridge) }
                                }
                            },
                            enabled = !isChecking,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = TitanTeal, contentColor = TitanBlack)
                        ) {
                            Text("CONNECT", fontWeight = FontWeight.Black, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }

    if (showPairingDialog) {
        AlertDialog(
            onDismissRequest = { showPairingDialog = false },
            containerColor = TitanCard,
            title = { Text("WIRELESS ADB PAIRING", color = Color.White, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Enter the 5-digit port and 6-digit pairing code from Wireless Debugging settings.", color = TitanGray, fontSize = 11.sp)
                    OutlinedTextField(
                        value = adbPort,
                        onValueChange = { adbPort = it },
                        label = { Text("Port (e.g. 38445)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TitanTeal,
                            unfocusedBorderColor = Color.Gray,
                            focusedLabelColor = TitanTeal,
                            unfocusedLabelColor = TitanGray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    OutlinedTextField(
                        value = adbCode,
                        onValueChange = { adbCode = it },
                        label = { Text("Pairing Code") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TitanTeal,
                            unfocusedBorderColor = Color.Gray,
                            focusedLabelColor = TitanTeal,
                            unfocusedLabelColor = TitanGray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPairingDialog = false
                        viewModel.pairWirelessAdb(adbPort, adbCode)
                        scope.launch {
                            snackbarHostState.showSnackbar("Titan Infiltrating... Port: $adbPort")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TitanTeal, contentColor = TitanBlack)
                ) { Text("INFILTRATE", fontWeight = FontWeight.Black) }
            }
        )
    }
}
