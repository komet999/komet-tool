package com.titan.performance.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.titan.performance.R
import com.titan.performance.bridge.BridgeManager
import com.titan.performance.util.Constants
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject


@AndroidEntryPoint
class MonitoringService : Service() {



    @Inject
    lateinit var bridgeManager: BridgeManager



    private val serviceScope =
        CoroutineScope(
            SupervisorJob() +
                    Dispatchers.IO
        )





    override fun onCreate() {

        super.onCreate()


        createNotificationChannel()


        Timber.i(
            "Titan MonitoringService created"
        )

    }







    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {


        startForeground(
            1,
            createNotification()
        )



        restoreShellConnection()



        return START_STICKY

    }







    private fun restoreShellConnection() {


        serviceScope.launch {


            try {


                val connected =
                    bridgeManager.autoConnect()



                if (connected) {


                    Timber.i(
                        "Titan Bridge restored successfully"
                    )


                } else {


                    Timber.w(
                        "No bridge available after boot"
                    )

                }



            } catch(e:Exception) {


                Timber.e(
                    e,
                    "Bridge recovery failed"
                )

            }


        }


    }








    override fun onTaskRemoved(
        rootIntent: Intent?
    ) {


        try {


            val restartIntent =
                Intent(
                    applicationContext,
                    MonitoringService::class.java
                )



            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {


                startForegroundService(
                    restartIntent
                )


            } else {


                startService(
                    restartIntent
                )

            }



            Timber.i(
                "Service restart requested"
            )



        } catch(e:Exception) {


            Timber.e(
                e,
                "Service restart failed"
            )

        }



        super.onTaskRemoved(
            rootIntent
        )

    }








    override fun onBind(
        intent: Intent?
    ): IBinder? = null








    private fun createNotificationChannel() {


        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {


            val channel =
                NotificationChannel(

                    Constants.NOTIFICATION_CHANNEL_ID,

                    Constants.NOTIFICATION_CHANNEL_NAME,

                    NotificationManager.IMPORTANCE_LOW

                )



            getSystemService(
                NotificationManager::class.java
            )
                ?.createNotificationChannel(
                    channel
                )


        }

    }








    private fun createNotification(): Notification {


        return NotificationCompat.Builder(
            this,
            Constants.NOTIFICATION_CHANNEL_ID
        )

            .setContentTitle(
                "Titan Performance"
            )

            .setContentText(
                "Shell monitoring active"
            )

            .setSmallIcon(
                R.drawable.ic_launcher_foreground
            )

            .setOngoing(true)

            .setSilent(true)

            .build()


    }







    override fun onDestroy() {


        Timber.w(
            "Titan MonitoringService destroyed"
        )


        super.onDestroy()


    }



}