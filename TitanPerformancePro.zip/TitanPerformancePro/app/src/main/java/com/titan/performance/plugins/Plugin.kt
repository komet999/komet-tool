package com.titan.performance.plugins

import kotlinx.serialization.Serializable

@Serializable
data class Plugin(
    val id: String,
    val name: String,
    val version: String,
    val author: String,
    val description: String,
    val minAndroid: Int = 29,
    val type: String = "shell",
    val supportedBrands: List<String> = emptyList(),
    val requiredPermission: String = "shizuku",
    val profileType: String? = null,
    val installPath: String = "",
    val isInstalled: Boolean = false,
    val isEnabled: Boolean = false,
    val installedAt: Long = 0
)

@Serializable
data class PluginManifest(
    val name: String,
    val version: String,
    val author: String,
    val description: String,
    val minAndroid: Int = 29,
    val type: String = "shell",
    val supportedBrands: List<String> = emptyList(),
    val requiredPermission: String = "shizuku",
    val profileType: String? = null
)

@Serializable
data class PluginConfig(
    val autoRun: Boolean = false,
    val runOnBoot: Boolean = false,
    val showNotification: Boolean = true
)
