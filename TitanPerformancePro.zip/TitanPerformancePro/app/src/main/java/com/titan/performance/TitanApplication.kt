package com.titan.performance

import android.app.Application
import android.content.Context
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.titan.performance.util.LocaleHelper
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber
import javax.inject.Inject

@HiltAndroidApp
class TitanApplication : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    override fun attachBaseContext(base: Context) {
        val prefs = base.getSharedPreferences("settings_prefs", Context.MODE_PRIVATE)
        val lang = prefs.getString("language", "device") ?: "device"
        super.attachBaseContext(LocaleHelper.onAttach(base, lang))
    }

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }
        
        // Deploy internal TITAN engine modules
        com.titan.performance.plugins.PluginManager.deployInternalPlugins(this)
        
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val ghostChannel = android.app.NotificationChannel(
                "titan_ghost_channel",
                "Titan Ghost Mode",
                android.app.NotificationManager.IMPORTANCE_MIN
            )
            val manager = getSystemService(android.app.NotificationManager::class.java)
            manager.createNotificationChannel(ghostChannel)
        }
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(android.util.Log.DEBUG)
            .build()
}
