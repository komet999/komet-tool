package com.titan.performance.hardware

import com.titan.performance.shizuku.ShizukuShell
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TitanHardwareMonitor @Inject constructor() {

    data class LiveHardwareInfo(
        val cpuFreq: String,
        val gpuFreq: String,
        val thermalStatus: String,
        val activeCores: Int,
        val socModel: String,
        val batteryVoltage: String,
        val kernelVersion: String
    )

    suspend fun getLiveInfo(): LiveHardwareInfo = withContext(Dispatchers.IO) {
        val cpuFreq = try {
            val freq = File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq").readText().trim().toLong()
            "${freq / 1000} MHz"
        } catch (e: Exception) { "N/A" }

        val gpuFreq = try {
            val freqFile = File("/sys/class/kgsl/kgsl-3d0/gpuclk")
            if (freqFile.exists()) "${freqFile.readText().trim().toLong() / 1000000} MHz" else "N/A"
        } catch (e: Exception) { "N/A" }

        val thermal = try {
            val res = ShizukuShell.execute("dumpsys thermalservice | grep \"Thermal Status\"")
            res.stdout.substringAfter(":").trim().ifEmpty { "NORMAL" }
        } catch (e: Exception) { "NORMAL" }

        val soc = android.os.Build.HARDWARE.uppercase()
        val kernel = System.getProperty("os.version") ?: "Unknown"

        LiveHardwareInfo(
            cpuFreq = cpuFreq,
            gpuFreq = gpuFreq,
            thermalStatus = thermal,
            activeCores = Runtime.getRuntime().availableProcessors(),
            socModel = soc,
            batteryVoltage = "3.8V", // Placeholder for real battery probe
            kernelVersion = kernel
        )
    }
}
