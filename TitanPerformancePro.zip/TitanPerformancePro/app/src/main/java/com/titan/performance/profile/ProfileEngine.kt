package com.titan.performance.profile

import com.titan.performance.bridge.BridgeManager
import com.titan.performance.bridge.ShellResult
import com.titan.performance.shell.ShellEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProfileEngine @Inject constructor(
    private val shellEngine: ShellEngine
) {

    data class ProfileCommands(
        val name: String,
        val commands: List<String>,
        val revertCommands: List<String>
    )

    fun getGamingProfile(): ProfileCommands = ProfileCommands(
        name = "Gaming Mode",
        commands = listOf(
            "settings put system peak_refresh_rate 120",
            "settings put system min_refresh_rate 120",
            "cmd power set-fixed-performance-mode-enabled true",
            "settings put global animator_duration_scale 0.5",
            "settings put global transition_animation_scale 0.5",
            "settings put global window_animation_scale 0.5",
            "settings put global cached_apps_freezer enabled",
            "cmd activity memory-factor critical"
        ),
        revertCommands = listOf(
            "settings put system peak_refresh_rate 60",
            "settings put system min_refresh_rate 60",
            "cmd power set-fixed-performance-mode-enabled false",
            "settings put global animator_duration_scale 1.0",
            "settings put global transition_animation_scale 1.0",
            "settings put global window_animation_scale 1.0"
        )
    )

    fun getBatteryProfile(): ProfileCommands = ProfileCommands(
        name = "Battery Saver",
        commands = listOf(
            "settings put system peak_refresh_rate 60",
            "settings put system min_refresh_rate 60",
            "cmd power set-fixed-performance-mode-enabled false",
            "settings put global animator_duration_scale 1.5",
            "settings put global transition_animation_scale 1.5",
            "settings put global window_animation_scale 1.5",
            "cmd activity memory-factor normal"
        ),
        revertCommands = listOf(
            "settings put system peak_refresh_rate 60",
            "settings put global animator_duration_scale 1.0",
            "settings put global transition_animation_scale 1.0",
            "settings put global window_animation_scale 1.0"
        )
    )

    fun getPerformanceProfile(): ProfileCommands = ProfileCommands(
        name = "Performance Mode",
        commands = listOf(
            "cmd power set-fixed-performance-mode-enabled true",
            "settings put global animator_duration_scale 0.0",
            "settings put global transition_animation_scale 0.0",
            "settings put global window_animation_scale 0.0",
            "settings put global cached_apps_freezer enabled"
        ),
        revertCommands = listOf(
            "cmd power set-fixed-performance-mode-enabled false",
            "settings put global animator_duration_scale 1.0",
            "settings put global transition_animation_scale 1.0",
            "settings put global window_animation_scale 1.0"
        )
    )

    fun getBalancedProfile(): ProfileCommands = ProfileCommands(
        name = "Balanced",
        commands = listOf(
            "settings put system peak_refresh_rate 90",
            "settings put system min_refresh_rate 60",
            "cmd power set-fixed-performance-mode-enabled false",
            "settings put global animator_duration_scale 1.0",
            "settings put global transition_animation_scale 1.0",
            "settings put global window_animation_scale 1.0"
        ),
        revertCommands = listOf(
            "settings put system peak_refresh_rate 60",
            "settings put global animator_duration_scale 1.0"
        )
    )

    fun getProfile(type: ProfileType): ProfileCommands = when (type) {
        ProfileType.GAMING -> getGamingProfile()
        ProfileType.BATTERY -> getBatteryProfile()
        ProfileType.PERFORMANCE -> getPerformanceProfile()
        ProfileType.BALANCED -> getBalancedProfile()
        ProfileType.EXTREME -> getGamingProfile().copy(name = "Extreme Mode")
    }

    suspend fun applyProfile(type: ProfileType): List<ShellResult> = withContext(Dispatchers.IO) {
        val profile = getProfile(type)
        Timber.i("Applying profile: ${profile.name}")
        profile.commands.map { shellEngine.execute(it) }
    }

    suspend fun revertProfile(type: ProfileType): List<ShellResult> = withContext(Dispatchers.IO) {
        val profile = getProfile(type)
        Timber.i("Reverting profile: ${profile.name}")
        profile.revertCommands.map { shellEngine.execute(it) }
    }
}
