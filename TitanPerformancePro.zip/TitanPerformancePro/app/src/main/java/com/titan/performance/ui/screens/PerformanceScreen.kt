package com.titan.performance.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.presentation.viewmodel.PerformanceViewModel
import com.titan.performance.ui.components.*
import com.titan.performance.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerformanceScreen(navController: NavController, viewModel: PerformanceViewModel = hiltViewModel()) {
    var selectedCategory by remember { mutableStateOf("CPU") }
    val scrollState = rememberScrollState()

    Row(modifier = Modifier.fillMaxSize().background(TitanBlack)) {
        // Sidebar (Exact GameTurbo Style)
        Column(
            modifier = Modifier
                .width(220.dp)
                .fillMaxHeight()
                .background(TitanBlack)
                .padding(vertical = 24.dp)
        ) {
            Box(modifier = Modifier.padding(start = 32.dp, bottom = 32.dp)) {
                Icon(Icons.Default.Tune, null, tint = TitanTeal, modifier = Modifier.size(32.dp))
            }
            
            TurboSidebarItem("Disturbance Settings", selectedCategory == "Disturbance") { selectedCategory = "Disturbance" }
            TurboSidebarItem("Radio & Network", selectedCategory == "Radio") { selectedCategory = "Radio" }
            TurboSidebarItem("Setting CPU", selectedCategory == "CPU") { selectedCategory = "CPU" }
            TurboSidebarItem("Performance", selectedCategory == "Performance") { selectedCategory = "Performance" }
            TurboSidebarItem("Mem & Ram", selectedCategory == "Memory") { selectedCategory = "Memory" }
        }

        // Content Area (Midnight Blue)
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(Color(0xFF0A0C14))
                .padding(24.dp)
                .verticalScroll(scrollState)
        ) {
            when (selectedCategory) {
                "CPU" -> CpuTunerScreen(viewModel)
                "Performance" -> PerformanceTweaksScreen(viewModel)
                "Radio" -> RadioBoostCategory(viewModel)
                "Memory" -> MemoryBoostCategory(viewModel)
                "Disturbance" -> DisturbanceCategory()
                else -> {
                    Text("MODULE ACTIVE", color = TitanTeal, fontSize = 12.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
fun CpuTunerScreen(viewModel: PerformanceViewModel) {
    val scope = rememberCoroutineScope()
    var selectedMode by remember { mutableStateOf("Balanced") }

    Text("SELECT FORMAT", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    Spacer(modifier = Modifier.height(32.dp))

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        CpuGaugeCard("2.84", "GHz", selectedMode == "Energy", Modifier.weight(1f))
        CpuGaugeCard("3000", "MHz", selectedMode == "Balanced", Modifier.weight(1f))
        CpuGaugeCard("100%", "CORE", selectedMode == "Extreme", Modifier.weight(1f))
    }

    Spacer(modifier = Modifier.height(40.dp))
    
    Surface(
        color = TitanOrange.copy(alpha = 0.1f),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = "TITAN ENGINE: Entering $selectedMode mode. System overclocked.",
            color = TitanOrange,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(12.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
    
    Spacer(modifier = Modifier.height(24.dp))

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        ModeButton("Energy Saving", selectedMode == "Energy", Modifier.weight(1f)) { 
            selectedMode = "Energy"
            scope.launch { viewModel.activateProfileByType("battery") }
        }
        ModeButton("Balanced Mode", selectedMode == "Balanced", Modifier.weight(1f)) { 
            selectedMode = "Balanced"
            scope.launch { viewModel.activateProfileByType("balanced") }
        }
        ModeButton("Acceleration", selectedMode == "Extreme", Modifier.weight(1f)) { 
            selectedMode = "Extreme"
            scope.launch { viewModel.activateProfileByType("extreme") }
        }
    }
}

@Composable
fun CpuGaugeCard(value: String, unit: String, active: Boolean, modifier: Modifier = Modifier) {
    Surface(
        color = Color.Transparent,
        modifier = modifier
            .height(160.dp)
            .border(2.dp, if (active) TitanRed else Color(0xFF1E212E), RoundedCornerShape(16.dp))
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(value, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text(unit, color = TitanGray, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(12.dp))
            Icon(Icons.Default.Bolt, null, tint = if (active) TitanOrange else TitanGray, modifier = Modifier.size(36.dp))
        }
    }
}

@Composable
fun ModeButton(label: String, active: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(56.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (active) TitanRed else Color(0xFF1A1C26),
            contentColor = Color.White
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = if (active) 8.dp else 0.dp)
    ) {
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
    }
}

@Composable
fun PerformanceTweaksScreen(viewModel: PerformanceViewModel) {
    val scope = rememberCoroutineScope()
    
    Text("SYSTEM OVERDRIVE", color = TitanTeal, fontSize = 14.sp, fontWeight = FontWeight.Black)
    Spacer(modifier = Modifier.height(24.dp))

    TurboSlider(label = "Render Resolution", value = 1f, onValueChange = {}, range = 0.3f..1f, valueLabels = listOf("1.0", "0.8", "0.6", "0.4"))
    TurboSlider(label = "FPS Limit", value = 144f, onValueChange = {}, range = 60f..144f, valueLabels = listOf("60", "90", "120", "144"))
    TurboSlider(label = "Touch Response", value = 300f, onValueChange = {}, range = 120f..300f, valueLabels = listOf("120Hz", "240Hz", "300Hz"))

    Spacer(modifier = Modifier.height(24.dp))
    TurboSwitch(label = "Titan Vulkan Engine", description = "Forced Vulkan rendering for UI and Games", checked = true) {}
    TurboSwitch(label = "Skiagl Threaded", description = "Parallel graphics processing", checked = true) {}
    
    Spacer(modifier = Modifier.height(32.dp))
    Button(
        onClick = { scope.launch { viewModel.applyExhaustiveTweaks() } },
        modifier = Modifier.fillMaxWidth().height(60.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = TitanTeal, contentColor = TitanBlack)
    ) {
        Icon(Icons.Default.RocketLaunch, null)
        Spacer(Modifier.width(12.dp))
        Text("DEPLOY VEXIRO ULTRA SYSTEM", fontWeight = FontWeight.Black, fontSize = 14.sp)
    }
}

@Composable
fun RadioBoostCategory(viewModel: PerformanceViewModel) {
    val scope = rememberCoroutineScope()
    Text("RADIO & NETWORK", color = TitanTeal, fontSize = 14.sp, fontWeight = FontWeight.Black)
    Spacer(modifier = Modifier.height(24.dp))
    TurboSwitch("Radio Boost", "Accelerate 4G/5G/WiFi protocols", true) {}
    TurboSwitch("Ping Stabilizer", "Reduce jitter in online games", true) {}
    TurboSwitch("Cyber-Shield DNS", "System-wide AdBlock by MRKOMET", true) {}
}

@Composable
fun MemoryBoostCategory(viewModel: PerformanceViewModel) {
    val scope = rememberCoroutineScope()
    Text("MEM & RAM TUNER", color = TitanTeal, fontSize = 14.sp, fontWeight = FontWeight.Black)
    Spacer(modifier = Modifier.height(24.dp))
    TurboSwitch("ZRAM 4GB", "Forced memory compression", true) {}
    TurboSwitch("LMK Minfree", "Optimal app retention", true) {}
    TurboSwitch("Purge Assets", "Automatic cache cleanup", false) {}
}

@Composable
fun DisturbanceCategory() {
    Text("DISTURBANCE SETTINGS", color = TitanTeal, fontSize = 14.sp, fontWeight = FontWeight.Black)
    Spacer(modifier = Modifier.height(24.dp))
    TurboSwitch("Extreme DND", "Block all calls and popups", true) {}
    TurboSwitch("Brightness Lock", "Prevent auto-dimming during gaming", false) {}
}
