package com.titan.performance.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.R
import com.titan.performance.presentation.viewmodel.FirewallViewModel
import com.titan.performance.ui.navigation.Screen
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirewallScreen(
    navController: NavController,
    viewModel: FirewallViewModel = hiltViewModel()
) {
    val blocked by viewModel.blockedApps.collectAsState()
    val rootAvailable by viewModel.rootAvailable.collectAsState()
    val importResult by viewModel.lastImportResult.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { viewModel.importConfig(it) } }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> uri?.let { viewModel.exportConfig(it) } }

    LaunchedEffect(importResult) {
        importResult?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearImportResult()
        }
    }

    Scaffold(
        containerColor = TitanBlack,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text("TITAN FIREWALL", color = Color.White, fontWeight = FontWeight.Black) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {

            // Status Banner
            Surface(
                color = if (rootAvailable) TitanGreen.copy(alpha = 0.1f) else TitanOrange.copy(alpha = 0.1f),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (rootAvailable) TitanGreen else TitanOrange)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (rootAvailable) Icons.Default.GppGood else Icons.Default.GppMaybe,
                        contentDescription = null,
                        tint = if (rootAvailable) TitanGreen else TitanOrange
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (rootAvailable) "FULL PROTECTION ACTIVE" else "LIMITED PROTECTION",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = if (rootAvailable) "Kernel-level blocking enabled." else "Grant Root for absolute blocking.",
                            color = TitanGray,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action Buttons
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { navController.navigate(Screen.InstalledApps.route) },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TitanTeal, contentColor = TitanBlack)
                ) {
                    Icon(Icons.Default.Apps, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("SELECT APPS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { importLauncher.launch(arrayOf("application/json")) },
                    modifier = Modifier.weight(1f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TitanGray)
                ) {
                    Text("IMPORT", color = Color.White, fontSize = 11.sp)
                }
                OutlinedButton(
                    onClick = { exportLauncher.launch("titan_firewall.json") },
                    modifier = Modifier.weight(1f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TitanGray)
                ) {
                    Text("EXPORT", color = Color.White, fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text("BLOCKED TARGETS (${blocked.size})", color = TitanGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))

            if (blocked.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("No apps restricted.", color = TitanGray, fontSize = 12.sp)
                }
            } else {
                LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(blocked, key = { it.packageName }) { rule ->
                        Surface(
                            color = TitanCard,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(rule.appName.ifBlank { rule.packageName }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(rule.packageName, color = TitanGray, fontSize = 11.sp)
                                }
                                IconButton(onClick = { viewModel.unblock(rule) }) {
                                    Icon(Icons.Default.Close, contentDescription = "Unblock", tint = TitanRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
