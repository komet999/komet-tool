package com.titan.performance.presentation.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.titan.performance.bridge.BridgeManager
import com.titan.performance.bridge.ConnectionState
import com.titan.performance.data.repository.*
import com.titan.performance.domain.model.*
import com.titan.performance.domain.usecase.GetDeviceInfoUseCase
import com.titan.performance.domain.usecase.GetSystemStatsUseCase
import com.titan.performance.hardware.HardwareEngine
import com.titan.performance.hardware.TitanHardwareMonitor
import com.titan.performance.hardware.TweaksEngine
import com.titan.performance.shizuku.ShizukuManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    application: Application,
    private val getDeviceInfo: GetDeviceInfoUseCase,
    private val getSystemStats: GetSystemStatsUseCase,
    private val profileRepository: ProfileRepository,
    private val historyRepository: HistoryRepository,
    private val bridgeManager: BridgeManager,
    private val hardwareMonitor: TitanHardwareMonitor,
    private val tweaksEngine: TweaksEngine,
    private val hardwareEngine: HardwareEngine
) : AndroidViewModel(application) {

    private val _deviceInfo = MutableStateFlow<DeviceInfo?>(null)
    val deviceInfo: StateFlow<DeviceInfo?> = _deviceInfo.asStateFlow()

    private val _systemStats = MutableStateFlow<SystemStats?>(null)
    val systemStats: StateFlow<SystemStats?> = _systemStats.asStateFlow()

    private val _liveHardware = MutableStateFlow<TitanHardwareMonitor.LiveHardwareInfo?>(null)
    val liveHardware: StateFlow<TitanHardwareMonitor.LiveHardwareInfo?> = _liveHardware.asStateFlow()

    private val _cpuHistory = MutableStateFlow<List<Float>>(List(20) { 0f })
    val cpuHistory: StateFlow<List<Float>> = _cpuHistory.asStateFlow()

    private val _ramHistory = MutableStateFlow<List<Float>>(List(20) { 0f })
    val ramHistory: StateFlow<List<Float>> = _ramHistory.asStateFlow()

    private val _healthScore = MutableStateFlow(0)
    val healthScore: StateFlow<Int> = _healthScore.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    val bridgeConnectionState: StateFlow<ConnectionState> = bridgeManager.connectionState

    init {
        loadDeviceInfo()
        startMonitoring()
        viewModelScope.launch { bridgeManager.autoConnect() }
    }

    private fun loadDeviceInfo() { _deviceInfo.value = getDeviceInfo() }

    private fun startMonitoring() {
        viewModelScope.launch {
            while (true) {
                val stats = getSystemStats()
                _systemStats.value = stats
                calculateHealthScore(stats)
                
                // Titan Real-time Hardware Probe
                _liveHardware.value = hardwareMonitor.getLiveInfo()

                val currentCpu = _cpuHistory.value.toMutableList()
                currentCpu.add(stats.cpuUsagePercent)
                if (currentCpu.size > 20) currentCpu.removeAt(0)
                _cpuHistory.value = currentCpu

                val currentRam = _ramHistory.value.toMutableList()
                currentRam.add(stats.ramUsedPercent)
                if (currentRam.size > 20) currentRam.removeAt(0)
                _ramHistory.value = currentRam

                delay(1000)
            }
        }
    }

    private fun calculateHealthScore(stats: SystemStats) {
        var score = 100
        if (stats.cpuUsagePercent > 80) score -= 15
        if (stats.ramUsedPercent > 85) score -= 15
        if (stats.storageUsedPercent > 90) score -= 15
        if (stats.batteryTemperature > 45) score -= 20
        if (stats.batteryLevel < 20) score -= 10
        _healthScore.value = score.coerceIn(0, 100)
    }

    fun refresh() {
        viewModelScope.launch {
            _isRefreshing.value = true
            loadDeviceInfo()
            bridgeManager.autoConnect()
            _isRefreshing.value = false
        }
    }

    fun quickUltraBoost() {
        viewModelScope.launch {
            tweaksEngine.applyTitanUltraTweaks()
            historyRepository.addHistory("Dashboard", "Ultra Boost Deployed")
        }
    }

    fun quickPurgeRam() {
        viewModelScope.launch {
            hardwareEngine.optimizeZram(4096)
            historyRepository.addHistory("Dashboard", "RAM Purged")
        }
    }

    fun quickRadioBoost() {
        viewModelScope.launch {
            tweaksEngine.applyRadioBoost()
            historyRepository.addHistory("Dashboard", "Radio Infiltrated")
        }
    }

    fun quickCoolDown() {
        viewModelScope.launch {
            hardwareEngine.setCpuPerformanceMode(false)
            historyRepository.addHistory("Dashboard", "Cool Down Triggered")
        }
    }
}
