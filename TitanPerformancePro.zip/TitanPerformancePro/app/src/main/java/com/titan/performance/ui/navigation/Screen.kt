package com.titan.performance.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    data object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Dashboard)
    data object Performance : Screen("performance", "Performance", Icons.Default.Speed)
    data object Gaming : Screen("gaming", "Gaming", Icons.Default.SportsEsports)
    data object Modules : Screen("modules", "Modules", Icons.Default.Extension)
    data object Security : Screen("security", "Security", Icons.Default.Security)
    data object Monitoring : Screen("monitoring", "Monitoring", Icons.Default.BarChart)
    data object Terminal : Screen("terminal", "Terminal", Icons.Default.Terminal)
    data object AiAssistant : Screen("ai_assistant", "Titan AI", Icons.Default.Psychology)
    data object Settings : Screen("settings", "Settings", Icons.Default.Settings)
    data object About : Screen("about", "About", Icons.Default.Info)
    data object Logs : Screen("logs", "Logs", Icons.Default.ListAlt)
    data object Developer : Screen("developer", "Developer", Icons.Default.Code)
    data object InstalledApps : Screen("installed_apps", "Apps", Icons.Default.Apps)
    data object Firewall : Screen("firewall", "Firewall", Icons.Default.VpnLock)
}
