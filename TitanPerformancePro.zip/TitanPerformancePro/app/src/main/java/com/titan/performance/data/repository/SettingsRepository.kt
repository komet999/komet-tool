package com.titan.performance.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import com.titan.performance.data.local.dao.SettingDao
import com.titan.performance.data.local.entity.SettingEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsRepository @Inject constructor(
    private val dataStore: DataStore<Preferences>,
    private val settingDao: SettingDao,
    @ApplicationContext private val context: Context
) {
    companion object {
        val THEME_KEY = stringPreferencesKey("theme")
        val LANGUAGE_KEY = stringPreferencesKey("language")
        val DYNAMIC_COLORS_KEY = booleanPreferencesKey("dynamic_colors")
        val NOTIFICATIONS_ENABLED_KEY = booleanPreferencesKey("notifications_enabled")
        val MONITORING_ENABLED_KEY = booleanPreferencesKey("monitoring_enabled")
    }

    val theme: Flow<String> = dataStore.data.map { it[THEME_KEY] ?: "system" }
    val language: Flow<String> = dataStore.data.map { it[LANGUAGE_KEY] ?: "device" }
    val dynamicColors: Flow<Boolean> = dataStore.data.map { it[DYNAMIC_COLORS_KEY] ?: true }
    val notificationsEnabled: Flow<Boolean> = dataStore.data.map { it[NOTIFICATIONS_ENABLED_KEY] ?: true }
    val monitoringEnabled: Flow<Boolean> = dataStore.data.map { it[MONITORING_ENABLED_KEY] ?: true }

    suspend fun setTheme(theme: String) { dataStore.edit { it[THEME_KEY] = theme } }
    suspend fun setLanguage(language: String) { 
        dataStore.edit { it[LANGUAGE_KEY] = language }
        // Also save to SharedPreferences for attachBaseContext
        val prefs = context.getSharedPreferences("settings_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("language", language).apply()
    }
    suspend fun setDynamicColors(enabled: Boolean) { dataStore.edit { it[DYNAMIC_COLORS_KEY] = enabled } }
    suspend fun setNotificationsEnabled(enabled: Boolean) { dataStore.edit { it[NOTIFICATIONS_ENABLED_KEY] = enabled } }
    suspend fun setMonitoringEnabled(enabled: Boolean) { dataStore.edit { it[MONITORING_ENABLED_KEY] = enabled } }
    fun getAllSettings(): Flow<List<SettingEntity>> = settingDao.getAll()
    suspend fun saveSetting(key: String, value: String, type: String = "string") {
        settingDao.insert(SettingEntity(key, value, type))
    }
}
