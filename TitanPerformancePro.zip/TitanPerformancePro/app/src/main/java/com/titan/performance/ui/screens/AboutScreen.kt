package com.titan.performance.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(navController: NavController) {
    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = { Text("TITAN REVOLUTION", color = Color.White, fontWeight = FontWeight.Black) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, null, tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(scrollState)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Logo MRKOMET Edition
            Surface(
                modifier = Modifier.size(120.dp),
                shape = RoundedCornerShape(30.dp),
                color = TitanTeal.copy(alpha = 0.1f),
                border = androidx.compose.foundation.BorderStroke(2.dp, TitanTeal)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Bolt, null, tint = TitanTeal, modifier = Modifier.size(60.dp))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("TITAN PERFORMANCE PRO", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("DEVELOPED BY MRKOMET", color = TitanTeal, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)

            Spacer(modifier = Modifier.height(40.dp))

            Text("CONNECT WITH THE ARCHITECT", color = TitanGray, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
            Spacer(modifier = Modifier.height(16.dp))

            SocialLink(
                name = "Telegram Channel",
                description = "@Komaitsh",
                icon = Icons.Default.Send,
                color = Color(0xFF26A5E4),
                url = "https://t.me/Komaitsh"
            )

            SocialLink(
                name = "YouTube Channel",
                description = "@Komet22",
                icon = Icons.Default.PlayArrow,
                color = Color(0xFFFF0000),
                url = "https://www.youtube.com/@Komet22"
            )

            SocialLink(
                name = "GitHub Repository",
                description = "komet999/KOMET-Optimizer",
                icon = Icons.Default.Code,
                color = Color.White,
                url = "https://github.com/komet999/KOMET-Optimizer"
            )

            SocialLink(
                name = "Facebook Profile",
                description = "Komet Shkohi",
                icon = Icons.Default.Public,
                color = Color(0xFF1877F2),
                url = "https://www.facebook.com/komet.shkohi.2025"
            )

            Spacer(modifier = Modifier.height(48.dp))
            
            Text(
                "A New Era of System Control.\nNo Root Required. Pure Engineering.",
                color = TitanGray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            Text("© 2026 MRKOMET PROJECTS", color = TitanGray, fontSize = 9.sp)
        }
    }
}

@Composable
fun SocialLink(name: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color, url: String) {
    val context = LocalContext.current
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(intent)
            }
    ) {
        Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier.size(44.dp),
                shape = RoundedCornerShape(12.dp),
                color = color.copy(alpha = 0.1f)
            ) {
                Icon(icon, null, tint = color, modifier = Modifier.padding(10.dp))
            }
            Spacer(modifier = Modifier.width(20.dp))
            Column {
                Text(name, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Text(description, color = TitanGray, fontSize = 12.sp)
            }
        }
    }
}
