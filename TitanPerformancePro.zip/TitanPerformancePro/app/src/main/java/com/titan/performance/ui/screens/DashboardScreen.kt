package com.titan.performance.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.titan.performance.R
import com.titan.performance.bridge.ConnectionState
import com.titan.performance.presentation.viewmodel.DashboardViewModel
import com.titan.performance.ui.components.*
import com.titan.performance.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(navController: NavController, viewModel: DashboardViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val systemStats by viewModel.systemStats.collectAsState()
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val bridgeState by viewModel.bridgeConnectionState.collectAsState()
    val cpuHistory by viewModel.cpuHistory.collectAsState()
    val ramHistory by viewModel.ramHistory.collectAsState()
    val liveHardware by viewModel.liveHardware.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = TitanBlack,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier.size(36.dp),
                            shape = RoundedCornerShape(10.dp),
                            color = TitanTeal.copy(alpha = 0.15f)
                        ) {
                            Icon(Icons.Default.Bolt, null, tint = TitanTeal, modifier = Modifier.padding(6.dp))
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("TITAN ULTRA", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                            Text("ENGINEERED BY MRKOMET", color = TitanTeal, fontSize = 8.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { /* Notifications */ }) {
                        Icon(Icons.Default.Notifications, null, tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // Main Neural Gauge
            Surface(
                color = TitanCard,
                shape = RoundedCornerShape(32.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Brush.linearGradient(listOf(TitanTeal.copy(alpha = 0.3f), Color.Transparent))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(28.dp)) {
                    Text("NEURAL UPLINK ACTIVE", color = TitanTeal, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    Box(contentAlignment = Alignment.Center) {
                        TitanCircularStat(
                            progress = (systemStats?.cpuUsagePercent ?: 0f) / 100f,
                            label = "CORE LOAD",
                            value = "${systemStats?.cpuUsagePercent?.toInt() ?: 0}%",
                            subValue = liveHardware?.cpuFreq ?: "SEARCHING..."
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                        LiveStatItem("VULKAN GPU", liveHardware?.gpuFreq ?: "N/A", Icons.Default.Speed)
                        LiveStatItem("SOC", liveHardware?.socModel ?: "N/A", Icons.Default.DeveloperBoard)
                        LiveStatItem("THERMAL", "${systemStats?.cpuTemperature ?: 0}°C", Icons.Default.Thermostat)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Real-time Wave Analytics
            Text("SYSTEM PULSE", color = TitanGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                GraphBox(
                    label = "CPU CLOCK",
                    value = "${systemStats?.cpuUsagePercent?.toInt() ?: 0}%",
                    history = cpuHistory,
                    color = TitanTeal,
                    modifier = Modifier.weight(1f)
                )
                GraphBox(
                    label = "MEMORY BANK",
                    value = "${systemStats?.ramUsedPercent?.toInt() ?: 0}%",
                    history = ramHistory,
                    color = TitanGreen,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Rapid Deployment Actions
            Text("TITAN COMMANDS", color = TitanGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TitanQuickAction("OVERCLOCK", Icons.Default.FlashOn, { viewModel.quickUltraBoost() }, color = TitanTeal)
                TitanQuickAction("PURGE RAM", Icons.Default.CleaningServices, { viewModel.quickPurgeRam() }, color = TitanGreen)
                TitanQuickAction("RADIO BOOST", Icons.Default.CellTower, { viewModel.quickRadioBoost() }, color = TitanOrange)
                TitanQuickAction("GHOST MODE", Icons.Default.Security, { 
                    val intent = Intent(context, com.titan.performance.service.TitanGhostService::class.java)
                    context.startForegroundService(intent)
                }, color = TitanRed)
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Connection Persistence Card
            Surface(
                color = if (bridgeState == ConnectionState.Connected) TitanGreen.copy(alpha = 0.05f) else TitanCard,
                shape = RoundedCornerShape(20.dp),
                border = if (bridgeState == ConnectionState.Connected) androidx.compose.foundation.BorderStroke(1.dp, TitanGreen.copy(alpha = 0.2f)) else null,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(50.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            progress = { if (bridgeState == ConnectionState.Connected) 1f else 0.4f },
                            color = if (bridgeState == ConnectionState.Connected) TitanGreen else TitanGray,
                            strokeWidth = 3.dp
                        )
                        Icon(
                            imageVector = if (bridgeState == ConnectionState.Connected) Icons.Default.ShieldMoon else Icons.Default.Shield,
                            contentDescription = null,
                            tint = if (bridgeState == ConnectionState.Connected) TitanGreen else TitanGray,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(20.dp))
                    Column {
                        Text(
                            text = if (bridgeState == ConnectionState.Connected) "TITAN GHOST ACTIVE" else "UPLINK OFFLINE",
                            color = if (bridgeState == ConnectionState.Connected) TitanGreen else Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text("System Persistence Service (Android 11+ Ready)", color = TitanGray, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun GraphBox(label: String, value: String, history: List<Float>, color: Color, modifier: Modifier = Modifier) {
    Surface(
        color = TitanCard,
        shape = RoundedCornerShape(24.dp),
        modifier = modifier.height(150.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(label, color = TitanGray, fontSize = 9.sp, fontWeight = FontWeight.Black)
            Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Spacer(modifier = Modifier.weight(1f))
            RealTimeLineChart(
                data = history,
                color = color,
                modifier = Modifier.fillMaxWidth().height(50.dp)
            )
        }
    }
}

@Composable
fun LiveStatItem(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = TitanTeal, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = TitanGray, fontSize = 8.sp, fontWeight = FontWeight.ExtraBold)
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black)
    }
}
