package com.titan.performance.service

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.titan.performance.util.Constants

class GamingOverlayService : Service() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Gaming Mode").setContentText("Overlay active")
            .setSmallIcon(android.R.drawable.ic_menu_compass).build()
        startForeground(2, notification); return START_STICKY
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
