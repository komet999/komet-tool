package com.titan.performance.receiver


import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.titan.performance.service.MonitoringService
import com.titan.performance.service.TitanGhostService
import com.titan.performance.worker.BootRecoveryWorker
import timber.log.Timber
import java.util.concurrent.TimeUnit



class BootReceiver : BroadcastReceiver() {



    override fun onReceive(
        context: Context,
        intent: Intent
    ) {



        if(
            intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_LOCKED_BOOT_COMPLETED
        ){

            return

        }




        Timber.i(
            "Titan boot detected: ${intent.action}"
        )



        startMonitoringService(
            context
        )

        startGhostService(context)

        scheduleRecovery(
            context
        )
    }

    private fun startGhostService(context: Context) {
        try {
            val serviceIntent = Intent(context, TitanGhostService::class.java)
            ContextCompat.startForegroundService(context, serviceIntent)
            Timber.i("Titan Ghost Mode Injected")
        } catch (e: Exception) {
            Timber.e(e, "Ghost start failed")
        }
    }







    private fun startMonitoringService(
        context: Context
    ){


        try {


            val serviceIntent =
                Intent(
                    context,
                    MonitoringService::class.java
                )



            ContextCompat
                .startForegroundService(
                    context,
                    serviceIntent
                )



            Timber.i(
                "Titan MonitoringService started"
            )



        }catch(e:Exception){


            Timber.e(
                e,
                "MonitoringService start failed"
            )


        }

    }









    private fun scheduleRecovery(
        context: Context
    ){


        try {



            val request =

                OneTimeWorkRequestBuilder<BootRecoveryWorker>()


                    /*
                     مهم:
                     انتظار حتى:
                     - Shizuku يبدأ
                     - Wireless debugging يبدأ
                     - النظام يحمل التطبيقات
                    */

                    .setInitialDelay(
                        15,
                        TimeUnit.SECONDS
                    )


                    .build()






            WorkManager
                .getInstance(context)
                .enqueueUniqueWork(


                    "Titan_Boot_Recovery",


                    /*
                     لا تلغي Recovery
                     يعمل حالياً
                    */

                    ExistingWorkPolicy.KEEP,


                    request

                )





            Timber.i(
                "BootRecoveryWorker queued"
            )





        }catch(e:Exception){


            Timber.e(
                e,
                "Recovery worker failed"
            )


        }

    }


}