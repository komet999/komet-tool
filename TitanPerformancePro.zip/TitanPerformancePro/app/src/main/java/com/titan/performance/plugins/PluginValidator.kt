package com.titan.performance.plugins

import kotlinx.serialization.json.Json
import timber.log.Timber
import java.io.File
import java.util.zip.ZipFile

object PluginValidator {

    private val dangerousCommands = listOf(
        "rm -rf /",
        "mkfs.",
        "chmod 777 /",
        "mv /system",
        "delete /data",
        "format",
        "wipe"
    )

    fun validate(zipFile: File): ValidationResult {
        if (!zipFile.exists() || !zipFile.name.endsWith(".zip", ignoreCase = true)) {
            return ValidationResult(false, "Invalid file. Must be a ZIP archive.")
        }

        return try {
            ZipFile(zipFile).use { zip ->
                val entries = zip.entries().toList()

                // Improved detection for Vexiro/Magisk/Titan
                val titanManifest = entries.find { it.name.endsWith("plugin.json", true) }
                val magiskProp = entries.find { it.name.endsWith("module.prop", true) }
                val installScript = entries.find { 
                    it.name.endsWith("install.sh", true) || 
                    it.name.endsWith("update.sh", true) ||
                    it.name.endsWith("active.sh", true)
                }

                if (titanManifest == null && magiskProp == null && installScript == null) {
                    return ValidationResult(false, "No identifiable installation script or manifest found in ZIP.")
                }

                val manifest = if (titanManifest != null) {
                    val json = zip.getInputStream(titanManifest).bufferedReader().use { it.readText() }
                    Json.decodeFromString<PluginManifest>(json)
                } else if (magiskProp != null) {
                    val props = zip.getInputStream(magiskProp).bufferedReader().use { it.readText() }
                    val name = props.lineSequence().find { it.startsWith("name=") }?.substringAfter("=") ?: zipFile.nameWithoutExtension
                    val version = props.lineSequence().find { it.startsWith("version=") }?.substringAfter("=") ?: "1.0.0"
                    val author = props.lineSequence().find { it.startsWith("author=") }?.substringAfter("=") ?: "MRKOMET"
                    PluginManifest(
                        name = name, 
                        version = version, 
                        author = author, 
                        description = "Imported Magisk/Vexiro Module", 
                        minAndroid = 29,
                        type = "magisk"
                    )
                } else {
                    PluginManifest(
                        name = zipFile.nameWithoutExtension, 
                        version = "1.0.0", 
                        author = "Imported", 
                        description = "Generic Shell Module", 
                        minAndroid = 29,
                        type = "shell"
                    )
                }

                // Security Check (Lenient for Devs)
                val scriptEntries = entries.filter { it.name.endsWith(".sh", true) }
                val dangerousFound = mutableListOf<String>()
                
                scriptEntries.forEach { entry ->
                    val content = zip.getInputStream(entry).bufferedReader().use { it.readText() }
                    dangerousCommands.forEach { cmd ->
                        if (content.contains(cmd, ignoreCase = true)) {
                            dangerousFound.add("${entry.name}: '$cmd'")
                        }
                    }
                }

                ValidationResult(true, "Validated: ${manifest.name}", manifest)
            }
        } catch (e: Exception) {
            Timber.e(e, "Validation failed")
            ValidationResult(false, "Validation error: ${e.message}")
        }
    }

    data class ValidationResult(
        val valid: Boolean,
        val message: String,
        val manifest: PluginManifest? = null
    )
}
