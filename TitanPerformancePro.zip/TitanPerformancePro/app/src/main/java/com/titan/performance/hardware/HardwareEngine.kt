package com.titan.performance.hardware

import com.titan.performance.shell.ShellEngine
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HardwareEngine @Inject constructor(
    private val shellEngine: ShellEngine
) {

    /**
     * تفعيل وضع الأداء الأقصى للمعالج (CPU Force Performance)
     */
    suspend fun setCpuPerformanceMode(enable: Boolean): Boolean {
        val governor = if (enable) "performance" else "schedutil"
        val commands = listOf(
            "for i in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo $governor > \$i; done",
            "setprop persist.sys.performance.level ${if (enable) "10" else "5"}"
        )
        var success = true
        for (cmd in commands) {
            if (!shellEngine.execute(cmd).success) success = false
        }
        return success
    }

    /**
     * تحسين أداء الرام عبر ضغط الـ ZRAM (4GB Peak)
     */
    suspend fun optimizeZram(sizeMb: Int = 4096): Boolean {
        val commands = listOf(
            "swapoff /dev/block/zram0",
            "echo 1 > /sys/block/zram0/reset",
            "echo ${sizeMb.toLong() * 1024 * 1024} > /sys/block/zram0/disksize",
            "mkswap /dev/block/zram0",
            "swapon /dev/block/zram0",
            "echo 100 > /proc/sys/vm/swappiness"
        )
        var success = true
        for (cmd in commands) {
            if (!shellEngine.execute(cmd).success) success = false
        }
        return success
    }

    /**
     * إجبار الشاشة على أقصى معدل تحديث (144Hz Unlock)
     */
    suspend fun forceMaxRefreshRate(enable: Boolean): Boolean {
        val value = if (enable) "1" else "0"
        val fps = if (enable) "144" else "60"
        val commands = listOf(
            "settings put global peak_refresh_rate $fps",
            "settings put global min_refresh_rate $fps",
            "setprop persist.vendor.display.refresh_rate $fps",
            "settings put system user_refresh_rate $value"
        )
        var success = true
        for (cmd in commands) {
            if (!shellEngine.execute(cmd).success) success = false
        }
        return success
    }

    /**
     * تحسين استجابة اللمس (Zero Latency Mode)
     */
    suspend fun boostTouchResponse(enable: Boolean): Boolean {
        val value = if (enable) "1" else "0"
        val commands = listOf(
            "settings put system touch_sensitivity_boost $value",
            "setprop windowsmgr.max_events_per_sec ${if (enable) "300" else "120"}",
            "setprop debug.touch_latency 0"
        )
        for (cmd in commands) shellEngine.execute(cmd)
        return true
    }

    /**
     * قفل تردد المعالج على أعلى قيمة (CPU Lock)
     */
    suspend fun lockCpuFrequency(enable: Boolean): Boolean {
        return if (enable) {
            val command = "for i in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq; do " +
                    "read current < \$i; " +
                    "echo \$current > /sys/devices/system/cpu/cpu\${i#*cpu}/cpufreq/scaling_min_freq; done"
            shellEngine.execute(command).success
        } else {
            shellEngine.execute("for i in /sys/devices/system/cpu/cpu*/cpufreq/scaling_min_freq; do echo 0 > \$i; done").success
        }
    }
}
