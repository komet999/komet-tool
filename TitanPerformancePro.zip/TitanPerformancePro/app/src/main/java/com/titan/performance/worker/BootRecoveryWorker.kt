package com.titan.performance.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.titan.performance.bridge.BridgeManager
import com.titan.performance.firewall.FirewallEngine
import com.titan.performance.firewall.FirewallRepository
import com.titan.performance.plugins.PluginManager
import com.titan.performance.hardware.TweaksEngine
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.delay
import timber.log.Timber


@HiltWorker
class BootRecoveryWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val bridgeManager: BridgeManager,
    private val firewallEngine: FirewallEngine,
    private val firewallRepository: FirewallRepository,
    private val tweaksEngine: TweaksEngine
) : CoroutineWorker(context, params) {



    companion object {

        private const val CHANNEL_ID =
            "titan_boot_recovery"

        private const val NOTIFICATION_ID =
            9001


        private const val MAX_RETRY =
            8


        private const val DELAY =
            5000L
    }



    override suspend fun doWork(): Result {


        Timber.i(
            "Titan boot recovery started"
        )


        // انتظار استقرار النظام بعد الإقلاع
        delay(10000)



        var connected = false



        repeat(MAX_RETRY) { index ->


            try {


                connected =
                    bridgeManager.autoConnect()



                if (connected) {

                    Timber.i(
                        "Bridge connected"
                    )

                    // Re-apply persistence tweaks lost on reboot
                    tweaksEngine.applyPersistenceFix()

                    return@repeat
                }



            } catch (e:Exception) {


                Timber.e(
                    e,
                    "Bridge recovery error"
                )

            }



            Timber.d(
                "Retry bridge ${index + 1}/$MAX_RETRY"
            )


            delay(DELAY)

        }




        if (!connected) {


            showNotification(
                false,
                0,
                0
            )


            return Result.retry()

        }




        var pluginsRestored = 0

        var firewallRestored = 0





        try {


            /*
             * Restore shell plugins
             */


            val plugins =
                PluginManager
                    .getInstalledPlugins(applicationContext)
                    .filter {
                        it.isEnabled
                    }




            plugins.forEach { plugin ->

                val config = PluginManager.getConfig(plugin)

                if(config?.runOnBoot == true){

                    val installScript = PluginManager.getInstallScript(plugin)
                    installScript?.let { script ->
                        val result =
                            bridgeManager.execute(
                                script.readText()
                            )

                        if(result.success){
                            pluginsRestored++
                        }

                        Timber.d(
                            "Plugin ${plugin.name} restored ${result.success}"
                        )
                    }
                }
            }






            /*
             * Restore firewall
             */


            val blockedApps =
                firewallRepository
                    .getBlockedApps()



            blockedApps.forEach { app ->


                val result =
                    firewallEngine.block(
                        app.uid,
                        app.packageName
                    )



                if(result){

                    firewallRestored++

                }


            }




        }catch(e:Exception){


            Timber.e(
                e,
                "Recovery restore failed"
            )

        }





        showNotification(
            true,
            pluginsRestored,
            firewallRestored
        )



        return Result.success()

    }





    private fun showNotification(

        connected:Boolean,

        plugins:Int,

        firewall:Int

    ){


        val manager =
            applicationContext
                .getSystemService(
                    NotificationManager::class.java
                )
                ?: return




        if(Build.VERSION.SDK_INT >= 26){


            manager.createNotificationChannel(

                NotificationChannel(

                    CHANNEL_ID,

                    "Titan Recovery",

                    NotificationManager
                        .IMPORTANCE_DEFAULT

                )

            )

        }





        val text =

            if(connected){

                "Shell OK • Plugins:$plugins • Firewall:$firewall"

            }else{

                "Shell غير متصل - افتح Titan لإعادة الربط"

            }






        val notification =

            NotificationCompat.Builder(

                applicationContext,

                CHANNEL_ID

            )

                .setContentTitle(
                    "Titan Performance Pro"
                )

                .setContentText(
                    text
                )

                .setSmallIcon(
                    android.R.drawable.ic_menu_info_details
                )

                .setAutoCancel(true)

                .build()





        manager.notify(

            NOTIFICATION_ID,

            notification

        )

    }

}