package com.titan.performance.plugins

import android.content.Context
import com.titan.performance.bridge.ShellResult
import com.titan.performance.shell.ShellEngine
import com.titan.performance.shizuku.ShizukuManager
import com.titan.performance.util.NotificationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import timber.log.Timber
import java.io.File
import javax.inject.Inject

class PluginExecutor @Inject constructor(
    private val shellEngine: ShellEngine
) {

    data class ExecutionLog(
        val pluginName: String,
        val command: String,
        val stdout: String,
        val stderr: String,
        val exitCode: Int,
        val timestamp: Long = System.currentTimeMillis()
    )

    fun runInstallLive(context: Context, plugin: Plugin): Flow<String> = flow {
        val script = PluginManager.getInstallScript(plugin)
        if (script == null) {
            emit("! CRITICAL: No installation script (install.sh) detected.")
            return@flow
        }
        executeScriptLive(context, plugin, script, "INSTALLING", this)
    }

    fun runUninstallLive(context: Context, plugin: Plugin): Flow<String> = flow {
        val script = PluginManager.getUninstallScript(plugin)
        if (script == null) {
            emit("! WARNING: No uninstall script found. Manual removal initiated.")
            return@flow
        }
        executeScriptLive(context, plugin, script, "UNINSTALLING", this)
    }

    private suspend fun executeScriptLive(
        context: Context,
        plugin: Plugin,
        script: File,
        action: String,
        collector: kotlinx.coroutines.flow.FlowCollector<String>
    ) {
        collector.emit("[*] TITAN UPLINK: $action ${plugin.name}")
        NotificationHelper.showShellNotification(context, "TITAN ENGINE", "$action: ${plugin.name}", 50)

        if (ShizukuManager.hasPermission()) {
            try {
                // Execute the script FILE directly, providing its directory as CWD
                val process = Shizuku.newProcess(
                    arrayOf("sh", script.absolutePath), 
                    null, 
                    script.parent
                )
                
                val reader = process.inputStream.bufferedReader()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    line?.let { 
                        collector.emit(it)
                        Timber.d("Plugin Output: $it")
                    }
                }
                
                val errorReader = process.errorStream.bufferedReader()
                while (errorReader.readLine().also { line = it } != null) {
                    line?.let { collector.emit("! ERR: $it") }
                }

                val exitCode = process.waitFor()
                collector.emit("[+] SYSTEM INFILTRATION COMPLETE (Exit: $exitCode)")
                NotificationHelper.showShellNotification(context, "TITAN PRO", "DEPLOYED: ${plugin.name}", -1)
            } catch (e: Exception) {
                collector.emit("! INJECTION FAILURE: ${e.message}")
                NotificationHelper.showShellNotification(context, "TITAN ERROR", "Deployment Failed", -1)
            }
        } else {
            // Fallback for Rooted Devices
            collector.emit("[!] Falling back to standard shell...")
            val result = shellEngine.execute("cd ${script.parent} && sh ${script.absolutePath}")
            collector.emit(result.output)
            if (result.error.isNotBlank()) collector.emit("! ERR: ${result.error}")
            collector.emit("[+] DONE (Exit Code: ${result.exitCode})")
            NotificationHelper.clearNotification(context)
        }
    }

    suspend fun runInstall(plugin: Plugin): ExecutionLog = withContext(Dispatchers.IO) {
        val script = PluginManager.getInstallScript(plugin)
        if (script == null) return@withContext ExecutionLog(plugin.name, "install.sh", "", "Not found", -1)
        val result = shellEngine.execute("sh ${script.absolutePath}")
        ExecutionLog(plugin.name, "install.sh", result.output, result.error, result.exitCode)
    }

    suspend fun runUninstall(plugin: Plugin): ExecutionLog = withContext(Dispatchers.IO) {
        val script = PluginManager.getUninstallScript(plugin)
        if (script == null) return@withContext ExecutionLog(plugin.name, "uninstall.sh", "", "Not found", -1)
        val result = shellEngine.execute("sh ${script.absolutePath}")
        ExecutionLog(plugin.name, "uninstall.sh", result.output, result.error, result.exitCode)
    }
}
