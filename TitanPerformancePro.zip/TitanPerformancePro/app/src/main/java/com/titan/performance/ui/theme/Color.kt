package com.titan.performance.ui.theme

import androidx.compose.ui.graphics.Color

val TitanBlack = Color(0xFF080808)
val TitanSurface = Color(0xFF121212)
val TitanCard = Color(0xFF1E1E1E)
val TitanTeal = Color(0xFF00E5FF)
val TitanTealVariant = Color(0xFF00BFA5)
val TitanGray = Color(0xFF8E8E93)
val TitanLightGray = Color(0xFFD1D1D6)
val TitanRed = Color(0xFFFF5252)
val TitanGreen = Color(0xFF00E676)
val TitanOrange = Color(0xFFFFAB40)

val TitanGradient = listOf(TitanTeal, TitanTealVariant)
val TitanBackgroundGradient = listOf(TitanBlack, TitanSurface)
