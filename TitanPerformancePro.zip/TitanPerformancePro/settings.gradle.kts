pluginManagement {

    repositories {

        google()

        mavenCentral()

        gradlePluginPortal()

    }

}



dependencyResolutionManagement {


    repositoriesMode.set(
        RepositoriesMode.FAIL_ON_PROJECT_REPOS
    )


    repositories {


        google()

        mavenCentral()


        // Shizuku repository (احتياطي)
        maven {
            url = uri("https://api.xposed.info/")
        }

    }

}



rootProject.name = "TitanPerformancePro"


include(":app")